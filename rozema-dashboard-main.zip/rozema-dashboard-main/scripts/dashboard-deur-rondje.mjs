// Rondje door de module deur-aan-deur met Playwright (Chromium), tegen een lokaal servertje dat dist/ serveert
// en de echte handlers met een in-memory store aanroept. Geen echte gegevens: verzonnen gebruikers.
//
// Gebruik (na npm run build):   node scripts/dashboard-deur-rondje.mjs
// Omgeving: PLAATS=Winsum (standaard, echt PDOK) of NEP=1 (kleine nagebootste PDOK-antwoorden),
//           SCHERMEN=<map> om schermafdrukken te bewaren.
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { createRequire } from "node:module";
import { fileURLToPath, pathToFileURL } from "node:url";
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";

// Zonder BREED draait het rondje twee keer: op 390 en op 360 px breed.
if (!process.env.BREED) {
  for (const b of ["390", "360"]) {
    console.log(`--- rondje op ${b} px breed ---`);
    const r = spawnSync(process.execPath, [fileURLToPath(import.meta.url)], { env: { ...process.env, BREED: b }, stdio: "inherit" });
    if (r.status !== 0) process.exit(r.status || 1);
  }
  process.exit(0);
}
const BREED = Number(process.env.BREED);

const wortel = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const dist = path.join(wortel, "dist");
const require = createRequire(import.meta.url);
const { chromium } = require("playwright");

process.env.DASHBOARD_SESSIE_GEHEIM = "t".repeat(48);
const { maakWachtwoordHash } = await import(pathToFileURL(path.join(wortel, "netlify/functions/dashboard-lib/sessie.mjs")));
const { zetStoreFabriek, store } = await import(pathToFileURL(path.join(wortel, "netlify/functions/dashboard-lib/opslag.mjs")));
const { geheugenFabriek } = await import(pathToFileURL(path.join(wortel, "netlify/functions/dashboard-lib/test-hulp.mjs")));
const auth = (await import(pathToFileURL(path.join(wortel, "netlify/functions/dashboard-auth.mjs")))).default;
const deur = (await import(pathToFileURL(path.join(wortel, "netlify/functions/dashboard-deur.mjs")))).default;
const meldingen = (await import(pathToFileURL(path.join(wortel, "netlify/functions/dashboard-meldingen.mjs")))).default;
const klanten = (await import(pathToFileURL(path.join(wortel, "netlify/functions/dashboard-klanten.mjs")))).default;

const WW = "proefwachtwoord-12345";
process.env.DASHBOARD_GEBRUIKERS = JSON.stringify({ Kevin: await maakWachtwoordHash(WW, 1000), Ruben: await maakWachtwoordHash(WW, 1000) });
zetStoreFabriek(geheugenFabriek());

const toml = fs.readFileSync(path.join(wortel, "netlify.toml"), "utf8");
const CSP = (toml.match(/Content-Security-Policy\s*=\s*"([^"]+)"/) || [])[1];
assert.ok(CSP, "CSP staat in netlify.toml");
const MIME = { ".html": "text/html; charset=utf-8", ".js": "text/javascript", ".css": "text/css", ".json": "application/json", ".woff2": "font/woff2", ".png": "image/png", ".webmanifest": "application/manifest+json" };
const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, "http://localhost");
    if (url.pathname.startsWith("/api/dashboard/")) {
      const delen = [];
      for await (const d of req) delen.push(d);
      const kopjes = new Headers();
      for (const [k, v] of Object.entries(req.headers)) if (typeof v === "string") kopjes.set(k, v);
      kopjes.set("x-nf-client-connection-ip", "127.0.0.1");
      const body = delen.length && !["GET", "HEAD"].includes(req.method) ? Buffer.concat(delen) : undefined;
      const r = new Request(url, { method: req.method, headers: kopjes, body });
      const ctx = { deploy: { context: "dev" } };
      const h = url.pathname.startsWith("/api/dashboard/auth/") ? auth : url.pathname.startsWith("/api/dashboard/deur/") ? deur : url.pathname.startsWith("/api/dashboard/klanten/") ? klanten : meldingen;
      const a = await h(r, ctx);
      res.statusCode = a.status;
      const cookies = a.headers.getSetCookie ? a.headers.getSetCookie() : [];
      a.headers.forEach((v, k) => { if (k !== "set-cookie") res.setHeader(k, v); });
      if (cookies.length) res.setHeader("set-cookie", cookies);
      res.end(Buffer.from(await a.arrayBuffer()));
      return;
    }
    let p = path.join(dist, decodeURIComponent(url.pathname));
    if (!p.startsWith(dist)) { res.statusCode = 403; res.end(); return; }
    if (fs.existsSync(p) && fs.statSync(p).isDirectory()) p = path.join(p, "index.html");
    if (!fs.existsSync(p)) { res.statusCode = 404; res.end("niet gevonden"); return; }
    res.setHeader("content-type", MIME[path.extname(p)] || "application/octet-stream");
    if (url.pathname.startsWith("/dashboard/")) res.setHeader("content-security-policy", CSP); // zoals netlify.toml dat doet
    res.end(fs.readFileSync(p));
  } catch (e) { console.error("servertje", e); res.statusCode = 500; res.end(); }
});
await new Promise((r) => server.listen(0, "127.0.0.1", r));
const basis = `http://localhost:${server.address().port}`;

// ---- nagebootst PDOK (NEP=1): verzonnen straat, vier huizen in een rij ----
function nepPdok(route) {
  const url = new URL(route.request().url());
  const json = (o) => route.fulfill({ status: 200, contentType: "application/json", headers: { "access-control-allow-origin": "*" }, body: JSON.stringify(o) });
  const pandId = (i) => `00000000-0000-4000-8000-00000000000${i}`;
  if (url.pathname.includes("/verblijfsobject/")) {
    return json({ features: [1, 2, 3, 4, 5, 6].map((i) => ({
      type: "Feature", id: "f" + i, geometry: { type: "Point", coordinates: [6.5 + i * 0.00006, 53.3] },
      properties: { identificatie: `000000000000000${i}`, openbare_ruimte_naam: "Teststraat", huisnummer: i, huisletter: null, toevoeging: null, postcode: "9999ZZ", gebruiksdoel: "woonfunctie", status: "Verblijfsobject in gebruik", oppervlakte: 90, "pand.href": [`https://api.pdok.nl/x/pand/items/${pandId(i)}`] },
    })), links: [] });
  }
  if (url.pathname.includes("/pand/")) {
    return json({ features: [1, 2, 3, 4, 5, 6].map((i) => ({ type: "Feature", id: pandId(i), properties: { bouwjaar: 1950, aantal_verblijfsobjecten: 1 },
      geometry: { type: "Polygon", coordinates: [[[6.5 + i * 0.00006 - 0.00003, 53.29999], [6.5 + i * 0.00006 + 0.00003, 53.29999], [6.5 + i * 0.00006 + 0.00003, 53.30001], [6.5 + i * 0.00006 - 0.00003, 53.30001], [6.5 + i * 0.00006 - 0.00003, 53.29999]]] } })), links: [] });
  }
  if (url.pathname.includes("/buurten/")) {
    return json({ features: [{ type: "Feature", properties: { buurtcode: "BU99990001", buurtnaam: "Proefbuurt", percentage_koopwoningen: 70, perc_huurwoningen_in_bezit_woningcorporaties: -99997, woningvoorraad: 50 },
      geometry: { type: "Polygon", coordinates: [[[6.4, 53.2], [6.6, 53.2], [6.6, 53.4], [6.4, 53.4], [6.4, 53.2]]] } }], links: [] });
  }
  return route.continue();
}

const PROXY = process.env.HTTPS_PROXY || process.env.https_proxy;
let proxy;
if (PROXY && !process.env.NEP) { const u = new URL(PROXY); proxy = { server: `${u.protocol}//${u.host}`, username: decodeURIComponent(u.username), password: decodeURIComponent(u.password) }; }
const browser = await chromium.launch({ proxy, args: ["--proxy-bypass-list=localhost;127.0.0.1"] });
const ctx = await browser.newContext({ viewport: { width: BREED, height: 800 }, ignoreHTTPSErrors: true, acceptDownloads: true, geolocation: { latitude: 53.3, longitude: 6.5 }, permissions: ["geolocation"] });
const page = await ctx.newPage();
await page.addInitScript(() => {
  window.__csp = [];
  document.addEventListener("securitypolicyviolation", (e) => window.__csp.push(e.violatedDirective + " " + e.blockedURI));
});
const fouten = [];
page.on("pageerror", (e) => fouten.push("pageerror " + e.message));
page.on("console", (m) => { if (m.type() === "error" && !/pdok\.nl|Failed to load resource|net::ERR/.test(m.text())) fouten.push("console " + m.text()); });
if (process.env.NEP) await page.route(/api\.pdok\.nl/, nepPdok);
const plaatsNaam = process.env.NEP ? "Testdorp" : process.env.PLAATS || "Winsum";
const schermen = process.env.SCHERMEN;
const foto = async (n) => { if (schermen) { fs.mkdirSync(schermen, { recursive: true }); await page.screenshot({ path: path.join(schermen, n + ".png") }); } };
const sleutels = async (voorvoegsel) => (await store("deur").list({ prefix: voorvoegsel })).blobs.length;
const wachtOpAantal = async (n, ms = 20000) => {
  const eind = Date.now() + ms;
  while (Date.now() < eind) { if ((await sleutels("events/")) === n) return; await new Promise((r) => setTimeout(r, 200)); }
  assert.equal(await sleutels("events/"), n);
};
const stap = (t) => console.log("ok  " + t);

// 1. inloggen
await page.goto(basis + "/dashboard/");
await page.fill("#naam", "Kevin");
await page.fill("#wachtwoord", WW);
await page.click("#inlogknop");
await page.waitForSelector("#start:not([hidden])");
stap("inloggen");

// 2. plaats ophalen
await page.goto(basis + "/dashboard/deur/");
await page.click("#t-plannen");
await page.click("#nieuwKnop");
await page.fill("#nieuwNaam", plaatsNaam);
await page.click("#ophalen");
await page.waitForFunction(() => /staat erin|mislukt|Geen woonadressen/.test(document.getElementById("ophaalStatus").textContent), null, { timeout: 280000 });
const ophaal = await page.textContent("#ophaalStatus");
assert.match(ophaal, /staat erin/, ophaal);
stap("plaats ophalen: " + ophaal);
const buurtenAantal = await page.locator("#buurten .buurt").count();
assert.ok(buurtenAantal >= 1);
await foto("1-plannen");

// 3. lijst: straat kiezen, huis aantikken, uitkomst vastleggen
await page.click("#t-lopen");
await page.click("#w-lijst");
await page.locator("#straten .rijknop").first().click();
const eerste = page.locator("#adressen .rijknop").first();
const label = await eerste.getAttribute("aria-label");
await foto("2-adressen");
await eerste.click();
await page.waitForSelector("#uitkomst[open]");
await foto("3-uitkomst");
const t0 = Date.now();
await page.click('#opties .opt[data-status="nietthuis"]');
await page.waitForSelector("#toast:not([hidden])");
const duur = Date.now() - t0;
assert.ok(duur < 2000, "vastleggen kost een tik: " + duur + " ms");
await wachtOpAantal(1);
const ev = (await store("deur").get((await store("deur").list({ prefix: "events/" })).blobs[0].key, { type: "json" }));
assert.equal(ev.st, "nietthuis");
assert.equal(ev.w, "Kevin");
assert.ok(ev.bu, "buurtcode op het event");
stap(`bezoek vastgelegd (${label}), event bevat bu=${ev.bu} ty=${ev.ty} bj=${ev.bj} koop=${ev.koop} corp=${ev.corp}`);

// 4. volgende huis en ongedaan maken via id
await page.click("#t-lopen");
const volgende = await page.textContent("#volgendeTekst");
assert.match(volgende, /Volgende huis: /);
await page.click("#volgendeKnop");
await page.waitForSelector("#uitkomst[open]");
await page.click('#opties .opt[data-status="gesprek"]');
await page.waitForSelector("#toast:not([hidden])");
await page.click("#ongedaan");
await wachtOpAantal(3);
const evs = await Promise.all((await store("deur").list({ prefix: "events/" })).blobs.map((b) => store("deur").get(b.key, { type: "json" })));
const ongedaan = evs.find((e) => e.ongedaan);
assert.ok(ongedaan && evs.some((e) => e.id === ongedaan.ongedaan && e.st === "gesprek"));
stap("volgende huis en ongedaan maken via event-id");

// 5. offline vastleggen en weer online versturen
await ctx.setOffline(true);
await page.evaluate(() => window.dispatchEvent(new Event("offline")));
await page.click("#t-lopen");
await page.click("#volgendeKnop");
await page.waitForSelector("#uitkomst[open]");
await page.click('#opties .opt[data-status="geeninteresse"]');
await page.waitForFunction(() => /Geen bereik.*1 wachten/.test(document.getElementById("statustekst").textContent));
const offlineTekst = await page.textContent("#statustekst");
assert.match(offlineTekst, /1 wachten/);
assert.equal(await sleutels("events/"), 3);
await foto("4-offline");
await ctx.setOffline(false);
await page.evaluate(() => window.dispatchEvent(new Event("online")));
await wachtOpAantal(4);
stap("offline vastgelegd en na online verstuurd");

// 6. sessie verlopen (401): bezoek blijft bewaard, inlog gevraagd, daarna verstuurd
await page.click("#volgendeKnop");
await page.waitForSelector("#uitkomst[open]");
process.env.DASHBOARD_SESSIE_VERSIE = "2"; // sessies zijn nu ongeldig
await page.click('#opties .opt[data-status="huurder"]');
await page.waitForSelector("#inlogvenster[open]", { timeout: 20000 });
assert.equal(await sleutels("events/"), 4);
await foto("5-inlog");
process.env.DASHBOARD_SESSIE_VERSIE = "1";
await page.fill("#iWw", WW);
await page.click('#inlogform button[type="submit"]');
await wachtOpAantal(5);
stap("401: wachtrij bewaard, opnieuw ingelogd, daarna verstuurd");

// 7. kaart: inzoomen op het volgende huis, blokjes met huisnummer, geen overlap, tikvlak minstens 48 px
await page.click("#t-lopen");
await page.click("#w-lijst");
await page.click("#w-kaart");
await page.waitForSelector("#kaart.leaflet-container");
await page.click("#opKaartKnop");
await page.waitForSelector("#kaart .hb", { timeout: 10000 });
await page.waitForTimeout(500);
const blokken = await page.locator("#kaart .hb").count();
const stippen = await page.locator("#kaart .hp").count();
assert.ok(blokken >= 1, "blokjes met huisnummer op de ingezoomde kaart");
const maten = await page.evaluate(() => [...document.querySelectorAll("#kaart .hb")].map((e) => { const r = e.getBoundingClientRect(); return [Math.round(r.width), Math.round(r.height)]; }));
assert.ok(maten.every(([w, h]) => w >= 48 && h >= 48), "tikvlak van minstens 48 px: " + JSON.stringify(maten));
const overlap = await page.evaluate(() => {
  // Huisnummers (.hb) en straatnamen (.sn) mogen elkaar en de stippen (.hp) nooit raken.
  // Een stip die onder een naburig blokje ligt, telt apart (zie "stippen onder blokjes").
  const els = [...document.querySelectorAll("#kaart .hb, #kaart .sn, #kaart .hp")].map((e) => ({ t: e.className.split(" ")[0], r: e.getBoundingClientRect() }));
  const uit = { labels: 0, stipOnderBlok: 0 };
  for (let i = 0; i < els.length; i++) for (let j = i + 1; j < els.length; j++) {
    const a = els[i].r, b = els[j].r;
    if (!(a.left < b.right && b.left < a.right && a.top < b.bottom && b.top < a.bottom)) continue;
    if ((els[i].t === "hp") !== (els[j].t === "hp") && els[i].t !== "sn" && els[j].t !== "sn") uit.stipOnderBlok++;
    else uit.labels++;
  }
  return uit;
});
assert.equal(overlap.labels, 0, "labels overlappen: " + JSON.stringify(overlap));
const straatnamen = await page.locator("#kaart .sn").count();
await foto("6-kaart");
stap(`kaart ingezoomd: ${blokken} blokjes (allemaal minstens 48 px), ${stippen} stippen, ${straatnamen} straatnamen, 0 overlappende labels, ${overlap.stipOnderBlok} stippen onder een blokje`);
// een blokje aantikken opent de uitkomst
// Het blokje dat helemaal binnen #kaart valt en bovenop ligt (op smalle schermen steekt de kaart soms onder de rest uit).
const hbIndex = await page.evaluate(() => {
  const kaart = document.getElementById("kaart");
  kaart.scrollIntoView({ block: "center" });
  const k = kaart.getBoundingClientRect();
  const vp = { b: window.innerWidth, h: window.innerHeight };
  return [...document.querySelectorAll("#kaart .hb")].findIndex((e) => {
    const r = e.getBoundingClientRect();
    if (r.left < Math.max(0, k.left) || r.right > Math.min(vp.b, k.right) || r.top < Math.max(0, k.top) || r.bottom > Math.min(vp.h, k.bottom)) return false;
    const top = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2);
    return top === e || e.contains(top);
  });
});
assert.ok(hbIndex >= 0, "er is een blokje dat binnen de kaart zichtbaar en aantikbaar is");
await page.locator("#kaart .hb").nth(hbIndex).click();
await page.waitForSelector("#uitkomst[open]");
await page.click("#annuleer");

// 8. vandaag, overzicht en export
await page.click("#t-vandaag");
assert.ok((await page.locator("#log li").count()) >= 3);
await page.click("#t-overzicht");
await foto("7-overzicht");
const [dl] = await Promise.all([page.waitForEvent("download"), page.click("#export")]);
const csv = fs.readFileSync(await dl.path(), "utf8");
const regels = csv.split("\r\n");
assert.match(regels[0], /plaats;buurtcode;buurt;straat/);
assert.equal(regels.length - 1, 3); // nietthuis, geeninteresse, huurder (gesprek is ongedaan gemaakt)
assert.ok(!regels.some((r) => r.includes(";gesprek;")));
stap("export: " + (regels.length - 1) + " rijen");

const klantenApi = (pad) => page.evaluate(async (p) => (await fetch("/api/dashboard/klanten" + p)).json(), pad);
// 9. K10: uitkomst afspraak, met één tik een nieuwe klant uit het bezoek, en terug naar de bezoeken
await page.click("#t-lopen");
await page.click("#w-lijst");
if (await page.locator("#adressenView").isHidden()) await page.locator("#straten .rijknop").first().click();
await page.locator("#adressen .rijknop").nth(3).click();
await page.waitForSelector("#uitkomst[open]");
await page.click('#opties .opt[data-status="afspraak"]');
await page.waitForSelector("#klantToast:not([hidden])");
const kb = await page.locator("#klantToast").boundingBox();
assert.ok(kb.height >= 48 && kb.width >= 48, "tikvlak klant aanmaken minstens 48 px: " + JSON.stringify(kb));
const klantHref = await page.getAttribute("#klantToast", "href");
assert.match(klantHref, /^\/dashboard\/klanten\/nieuw\.html\?herkomst=deur&event=[a-z0-9]{8,40}$/);
assert.ok(!/Teststraat/i.test(klantHref), "geen adres in de URL");
const eventId = new URL(klantHref, basis).searchParams.get("event");
await wachtOpAantal(6);
await page.click("#klantToast");
await page.waitForSelector("#nieuwform");
assert.equal(await page.inputValue("#nw-straat"), "Teststraat");
assert.equal(await page.inputValue("#nw-bron"), "Deur");
assert.match(await page.inputValue("#nw-huisnummer"), /^\d+$/);
await page.fill("#nw-achternaam", "Verzonnen");
await page.click('#nieuwform button[type="submit"]');
await page.waitForURL(/relatie\.html\?id=r_/);
await page.waitForSelector("#deurbezoeken:not([hidden])");
const deurLinkBb = await page.locator("#deurlink").boundingBox();
assert.ok(deurLinkBb.height >= 48, "tikvlak naar de deurbezoeken minstens 48 px");
const relId = new URL(page.url()).searchParams.get("id");
const rel = await klantenApi(`/relaties/${relId}`);
assert.equal(rel.relatie.herkomst.deur.eventId, eventId);
assert.equal(relId, "r_deur_" + eventId, "relatie-id volgt uit het bezoek");
assert.equal(rel.relatie.bron, "Deur");
await page.click("#deurlink");
await page.waitForSelector("#adressenView:not([hidden])");
assert.equal(await page.locator("#adressen .rijknop.klaar").count() >= 1, true);
const zonder = await klantenApi("/straten?plaats=" + encodeURIComponent("Testdorp"));
assert.deepEqual(zonder.straten, [], "een nieuwe relatie zonder traject is nog geen klant in de straat");
const traject = await page.evaluate(async (rid) => (await fetch(`/api/dashboard/klanten/relaties/${rid}/trajecten`, {
  method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ id: "t_" + rid.slice(2, 30), wijzigingId: "w-" + rid.slice(2, 30), velden: { fase: "Aanvraag ingediend" } }),
})).status, relId);
assert.equal(traject, 201);
const str = await klantenApi("/straten?plaats=" + encodeURIComponent("Testdorp"));
assert.deepEqual(str.straten, [{ straat: "Teststraat", klant: true }], "straten telt de klant met traject");
assert.ok(!JSON.stringify(str).includes("Verzonnen"), "geen namen in /straten");
stap("afspraak, nieuwe klant met één tik, herkomst deur gekoppeld, terug naar het bezoek, /straten telt mee");

assert.deepEqual(await page.evaluate(() => window.__csp), [], "geen CSP-schendingen");
assert.deepEqual(fouten, []);
await browser.close();
server.close();
console.log("klaar: alle stappen geslaagd");

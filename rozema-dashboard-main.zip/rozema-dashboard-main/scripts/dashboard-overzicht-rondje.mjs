// Rondje door pijplijn, overzicht en contactmoment met Playwright, tegen een lokaal servertje met de echte handlers,
// een in-memory store en verzonnen data. Geen echte gegevens. Draai eerst `npm run build`.
// Gebruik: node scripts/dashboard-overzicht-rondje.mjs   (SCHERMAFDRUK=<map> bewaart schermafdrukken)
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import vm from "node:vm";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const DIST = path.join(ROOT, "dist");
const F = path.join(ROOT, "netlify", "functions");
const SCHERMAFDRUK = process.env.SCHERMAFDRUK || null;

const { zetStoreFabriek } = await import(`${F}/dashboard-lib/opslag.mjs`);
const { geheugenFabriek } = await import(`${F}/dashboard-lib/test-hulp.mjs`);
const { maakWachtwoordHash, maakToken } = await import(`${F}/dashboard-lib/sessie.mjs`);
const { testCatalogus } = await import(`${F}/dashboard-lib/klanten/test-regels.mjs`);
const { maakHandler } = await import(`${F}/dashboard-klanten.mjs`);
const { default: authHandler } = await import(`${F}/dashboard-auth.mjs`);
const { default: meldingenHandler } = await import(`${F}/dashboard-meldingen.mjs`);
const { default: deurHandler } = await import(`${F}/dashboard-deur.mjs`);

async function laadPlaywright() {
  try { return await import("playwright"); } catch { /* verder zoeken */ }
  const kandidaten = [process.env.PLAYWRIGHT_MODULE, "/opt/node-tools/node_modules/playwright"].filter(Boolean);
  for (const k of kandidaten) {
    try { return createRequire(import.meta.url)(k); } catch { /* volgende */ }
  }
  throw new Error("Playwright niet gevonden. Zet PLAYWRIGHT_MODULE op de map van het pakket.");
}
const { chromium } = await laadPlaywright();

const TEKSTEN = (() => {
  const w = {};
  vm.runInNewContext(fs.readFileSync(path.join(DIST, "dashboard/gedeeld/teksten.js"), "utf8"), { window: w });
  return w.TEKSTEN;
})();
const KT = TEKSTEN.klanten;
const CSP = (() => {
  const toml = fs.readFileSync(path.join(ROOT, "netlify.toml"), "utf8");
  const blok = toml.split("[[headers]]").find((b) => /for = "\/dashboard\/\*"/.test(b));
  return blok.match(/Content-Security-Policy = "([^"]+)"/)[1];
})();

// ---------- verzonnen data (datums ten opzichte van vandaag, want het contactformulier gebruikt de echte datum) ----------
const CTX = { deploy: { context: "deploy-preview" } };
process.env.DASHBOARD_GEBRUIKERS = JSON.stringify({ Kevin: await maakWachtwoordHash("verzonnen-a", 1000) });
process.env.DASHBOARD_SESSIE_GEHEIM = "q".repeat(40);
delete process.env.DASHBOARD_ECHTE_DATA;
zetStoreFabriek(geheugenFabriek());
const klanten = maakHandler({ regels: testCatalogus() });
const sessie = `dashboard_sessie=${maakToken("Kevin")}`;
async function api(method, pad, body) {
  const res = await klanten(new Request(`http://x.test/api/dashboard/klanten${pad}`, {
    method, headers: { cookie: sessie, ...(body !== undefined ? { "content-type": "application/json" } : {}) },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  }), CTX);
  const t = await res.text();
  if (!res.ok) throw new Error(`${method} ${pad}: ${res.status} ${t}`);
  return JSON.parse(t);
}
let wid = 0;
const NAMEN = ["Testman", "Voorbeeld", "Verzonnen", "Papieren", "Voorlopig", "Proefstra", "Onbekendstra"];
await api("POST", "/relaties", { id: "r_a1", wijzigingId: `w${++wid}`, velden: { achternaam: "Testman", plaats: "Teststad", status: "Nieuw", bron: "Deur", eigenaar: "kevin" } });
await api("POST", "/relaties", { id: "r_b2", wijzigingId: `w${++wid}`, velden: { achternaam: "Voorbeeld", plaats: "Proefdorp", status: "Nieuw", bron: "Website", eigenaar: "ruben" } });
await api("POST", "/relaties", { id: "r_c3", wijzigingId: `w${++wid}`, velden: { achternaam: "Verzonnen", plaats: "Proefdorp", status: "Poging 1", bron: "Deur", eigenaar: "ruben" } });
await api("POST", "/relaties", { id: "r_d4", wijzigingId: `w${++wid}`, velden: { achternaam: "Papieren", plaats: "Teststad", status: "Nieuw", bron: "Instagram", eigenaar: "kevin" } });
await api("POST", "/relaties/r_a1/trajecten", { id: "t_a1", wijzigingId: `w${++wid}`, velden: { fase: "Aanvraag ingediend", route: "Maatwerk met onderzoek", fee: 1250 } });
await api("POST", "/relaties/r_b2/trajecten", { id: "t_b2", wijzigingId: `w${++wid}`, velden: { fase: "Opname gepland", route: "AVV", fee: 800 } });
await api("POST", "/relaties/r_d4/trajecten", { id: "t_d4", wijzigingId: `w${++wid}`, velden: { fase: "Aanvraag ingediend", route: "Maatwerk met onderzoek" } });
// Twee extra leads voor de leadpijplijn.
await api("POST", "/relaties", { id: "r_e5", wijzigingId: `w${++wid}`, velden: { achternaam: "Voorlopig", plaats: "Teststad", status: "Nieuw", bron: "Website", eigenaar: "kevin", contactvoorkeur: "WhatsApp" } });
await api("POST", "/relaties", { id: "r_f6", wijzigingId: `w${++wid}`, velden: { achternaam: "Proefstra", plaats: "Proefdorp", status: "Nieuw", bron: "Deur", eigenaar: "ruben" } });
// Een lead zonder eigenaar (zoals een websiteaanvraag): moet worden toegewezen.
await api("POST", "/relaties", { id: "r_g7", wijzigingId: `w${++wid}`, velden: { achternaam: "Onbekendstra", voornaam: "Anna", plaats: "Teststad", status: "Nieuw", bron: "Website", email: "anna@example.invalid", telefoon: "0500000001" } });

// ---------- servertje ----------
const TYPES = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8",
  ".woff2": "font/woff2", ".png": "image/png", ".webmanifest": "application/manifest+json", ".svg": "image/svg+xml", ".json": "application/json" };
const HANDLERS = [["/api/dashboard/klanten/", klanten], ["/api/dashboard/auth/", authHandler], ["/api/dashboard/meldingen/", meldingenHandler], ["/api/dashboard/deur/", deurHandler]];
async function naarRequest(req, basis) {
  const chunks = [];
  for await (const c of req) chunks.push(c);
  const headers = new Headers();
  for (const [k, v] of Object.entries(req.headers)) if (v !== undefined) headers.set(k, Array.isArray(v) ? v.join(", ") : v);
  return new Request(basis + req.url, { method: req.method, headers, body: ["GET", "HEAD"].includes(req.method) ? undefined : Buffer.concat(chunks) });
}
const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, "http://localhost");
    const h = HANDLERS.find(([p]) => url.pathname.startsWith(p) || url.pathname + "/" === p);
    if (h) {
      const r = await h[1](await naarRequest(req, `http://${req.headers.host}`), CTX);
      const kopjes = {};
      r.headers.forEach((v, k) => { if (k !== "set-cookie") kopjes[k] = v; });
      const cookies = r.headers.getSetCookie ? r.headers.getSetCookie() : [];
      if (cookies.length) kopjes["set-cookie"] = cookies;
      res.writeHead(r.status, kopjes);
      res.end(Buffer.from(await r.arrayBuffer()));
      return;
    }
    const p = decodeURIComponent(url.pathname);
    let bestand = path.join(DIST, p);
    if (!bestand.startsWith(DIST)) { res.writeHead(403).end(); return; }
    if (fs.existsSync(bestand) && fs.statSync(bestand).isDirectory()) bestand = path.join(bestand, "index.html");
    if (!fs.existsSync(bestand)) { res.writeHead(404, { "content-type": "text/plain" }).end("niet gevonden"); return; }
    const kopjes = { "content-type": TYPES[path.extname(bestand)] || "application/octet-stream", "cache-control": "no-cache" };
    if (p.startsWith("/dashboard/")) kopjes["content-security-policy"] = CSP;
    res.writeHead(200, kopjes);
    res.end(fs.readFileSync(bestand));
  } catch {
    res.writeHead(500).end("fout in testserver");
  }
});
await new Promise((r) => server.listen(0, "localhost", r));
const BASIS = `http://localhost:${server.address().port}`;

// ---------- controles ----------
const resultaten = [];
function controle(naam, ok, detail = "") {
  resultaten.push({ naam, ok: !!ok });
  console.log(`${ok ? "OK   " : "FOUT "}${naam}${!ok && detail ? ` (${detail})` : ""}`);
}
const browser = await chromium.launch();
const context = await browser.newContext({ viewport: { width: 360, height: 740 }, serviceWorkers: "block", locale: "nl-NL", timezoneId: "Europe/Amsterdam" });
const page = await context.newPage();
const consoleFouten = [];
let negeer = true;
page.on("console", (m) => { if (!negeer && (m.type() === "error" || m.type() === "warning") && !/Service Worker registration blocked/.test(m.text())) consoleFouten.push(`${m.type()}: ${m.text()} ${m.location().url}`); });
page.on("pageerror", (e) => consoleFouten.push(`pageerror: ${e.message}`));

// Gewone spaties: het bedrag (Intl) gebruikt een vaste spatie na het euroteken.
const tekst = async (sel) => (await page.locator(sel).innerText()).replace(/\u00a0/g, " ");
async function schermafdruk(naam) {
  if (!SCHERMAFDRUK) return;
  fs.mkdirSync(SCHERMAFDRUK, { recursive: true });
  // Desktop: alleen wat in beeld is (een vaste zijbalk komt in een samengestelde schermafdruk op de verkeerde plek).
  // Even wachten, zodat een overgang klaar is.
  await page.waitForTimeout(400);
  await page.screenshot({ path: path.join(SCHERMAFDRUK, `${naam}.png`), fullPage: !naam.startsWith("desktop-") });
}
async function geenHorizontaleScroll(naam) {
  const m = await page.evaluate(() => ({ w: window.innerWidth, s: document.documentElement.scrollWidth }));
  controle(`geen horizontale scroll van de pagina: ${naam}`, m.s <= m.w, JSON.stringify(m));
}
async function tikvlakken(naam) {
  const klein = await page.evaluate(() => {
    const uit = [];
    document.querySelectorAll("a[href], button, select, textarea, input, summary, label").forEach((el) => {
      const s = getComputedStyle(el); const r = el.getBoundingClientRect();
      if (s.display === "none" || s.visibility === "hidden" || !r.width || !r.height) return;
      if (el.tagName === "INPUT" && ["radio", "checkbox"].includes(el.type)) return;
      if (el.tagName === "LABEL" && !el.querySelector("input")) return;
      if (r.width < 47.5 || r.height < 47.5) uit.push(`${el.tagName.toLowerCase()} ${Math.round(r.width)}x${Math.round(r.height)}`);
    });
    return uit;
  });
  controle(`alle tikvlakken minimaal 48 px: ${naam}`, klein.length === 0, klein.join("; "));
}
async function lettergrootte(naam) {
  const klein = await page.evaluate(() => {
    const uit = [];
    document.querySelectorAll("body *").forEach((el) => {
      const s = getComputedStyle(el);
      if (s.display === "none" || s.visibility === "hidden") return;
      if (!Array.from(el.childNodes).some((n) => n.nodeType === 3 && n.textContent.trim())) return;
      if (parseFloat(s.fontSize) < 17.99) uit.push(`${el.tagName.toLowerCase()} ${s.fontSize}`);
    });
    return uit;
  });
  controle(`tekst minimaal 18 px: ${naam}`, klein.length === 0, klein.slice(0, 5).join("; "));
}

let gefaald = null;
try {
  await page.goto(`${BASIS}/dashboard/`);
  await page.locator("#inlog").waitFor({ state: "visible" });
  await page.fill("#naam", "Kevin");
  await page.fill("#wachtwoord", "verzonnen-a");
  await page.click("#inlogknop");
  await page.locator("#start").waitFor({ state: "visible" });
  negeer = false;

  // ---------- leadpijplijn (telefoon) ----------
  await page.goto(`${BASIS}/dashboard/klanten/`);
  await page.click('nav.sub a[href="/dashboard/klanten/pijplijn.html"]');
  await page.waitForURL("**/pijplijn.html");
  await page.locator("#bord .kolom").first().waitFor();
  const leadKoppen = await page.locator("#bord .kolom h2 > span:first-child").allInnerTexts();
  controle("leadpijplijn: kolommen per leadstatus plus Contract getekend", leadKoppen[0] === "Nieuwe lead" && leadKoppen.length === 12 && leadKoppen.at(-1) === "Contract getekend" && leadKoppen.includes("Afgevallen"), leadKoppen.join("|"));
  controle("leadpijplijn: vier leads, klanten staan er niet op", (await tekst("#aantal")) === K(KT.pijplijn.totaalLeadMeer, { n: 4 }) && (await page.locator('#bord a.rij[data-id="r_a1"]').count()) === 0);
  controle("leadpijplijn: kaart linkt naar de klant", (await page.getAttribute('#bord a.rij[data-id="r_e5"]', "href")).includes("relatie.html?id=r_e5"));
  controle("leadpijplijn: kaart toont bron en contactwijze", (await tekst('#bord a.rij[data-id="r_e5"]')).includes("Website, WhatsApp"));
  await page.selectOption("#bron", "Deur");
  await page.waitForFunction(() => document.getElementById("aantal").textContent === "2 leads");
  controle("leadpijplijn: filter op bron", (await page.locator("#bord a.rij").count()) === 2);
  await page.selectOption("#bron", "");
  await geenHorizontaleScroll("leadpijplijn op 360 px");
  await tikvlakken("leadpijplijn op 360 px");
  await lettergrootte("leadpijplijn op 360 px");
  await schermafdruk("leadpijplijn-360");

  // ---------- klantpijplijn (telefoon) ----------
  await page.click("#tab-klanten");
  await page.waitForFunction(() => location.search === "?bord=klanten" && document.querySelector('#bord .kolom[data-kolom="Getekend"]'));
  const kolomKoppen = await page.locator("#bord .kolom h2").allInnerTexts();
  controle("klantpijplijn: alle fases als kolom (Schaderapport opgegaan in Adviesrapport)", kolomKoppen.length === 10 && !kolomKoppen.some((k) => /Schaderapport/.test(k)), kolomKoppen.join("|"));
  controle("klantpijplijn: aantal per kolom in de kop", (await tekst('#bord .kolom[data-kolom="Aanvraag ingediend"] .teller')) === "2" && (await tekst('#bord .kolom[data-kolom="Opname gepland"] .teller')) === "1");
  controle("klantpijplijn: totaal", (await tekst("#aantal")) === K(KT.pijplijn.totaalMeer, { n: 3 }));
  const kolomAanvraag = page.locator('#bord .kolom[data-kolom="Aanvraag ingediend"]');
  controle("klantpijplijn: fee samen per kolom", (await kolomAanvraag.innerText()).replace(/\u00a0/g, " ").includes("€ 1.250"));
  const link = await kolomAanvraag.locator("a.rij").first().getAttribute("href");
  controle("klantpijplijn: kaart linkt naar het traject", /traject\.html\?relatie=r_(a1|d4)&id=t_(a1|d4)/.test(link || ""), link);
  controle("klantpijplijn: zijbalk markeert Pijplijn (één item voor beide borden)", (await page.getAttribute('nav.sub a[aria-current="page"]', "href")) === "/dashboard/klanten/pijplijn.html");
  await page.selectOption("#eigenaar", "ruben");
  await page.waitForFunction(() => document.getElementById("aantal").textContent === "1 traject");
  controle("klantpijplijn: filter op eigenaar", (await page.locator("#bord a.rij").count()) === 1);
  await page.selectOption("#eigenaar", "");
  await page.selectOption("#route", "AVV");
  await page.waitForFunction(() => document.getElementById("aantal").textContent === "1 traject");
  controle("klantpijplijn: filter op route", (await page.locator("#bord a.rij").count()) === 1);
  await page.selectOption("#route", "");
  await page.waitForFunction(() => document.getElementById("aantal").textContent === "3 trajecten");
  await geenHorizontaleScroll("klantpijplijn op 360 px");
  await tikvlakken("klantpijplijn op 360 px");
  await schermafdruk("klantpijplijn-360");

  // ---------- overzicht ----------
  await page.click('nav.sub a[href="/dashboard/klanten/overzicht.html"]');
  await page.waitForURL("**/overzicht.html");
  await page.locator("#inhoud h2").first().waitFor();
  const inhoud = await tekst("#inhoud");
  controle("overzicht: leads geteld", inhoud.includes(K(KT.overzicht.leadsTotaal, { n: 7 })), inhoud.slice(0, 120));
  controle("overzicht: conversie per bron", inhoud.includes(K(KT.overzicht.conversieRij, { bron: "Deur", klanten: 1, leads: 3, pct: "33%" })));
  controle("overzicht: fee nog te factureren", inhoud.includes(K(KT.overzicht.feePijplijn, { bedrag: "€ 2.050", n: 2 })));
  controle("overzicht: geen klantnamen op het scherm", !NAMEN.some((n) => inhoud.includes(n)));
  const periodeVerzoek = page.waitForRequest((r) => r.url().includes("/overzicht") && !r.url().includes("van="));
  await page.selectOption("#periode", "alles");
  await periodeVerzoek;
  controle("overzicht: periode Alles vraagt zonder grenzen", true);
  await geenHorizontaleScroll("overzicht op 360 px");
  await tikvlakken("overzicht op 360 px");
  await lettergrootte("overzicht op 360 px");
  await schermafdruk("overzicht-360");

  // ---------- contactmoment ----------
  await page.goto(`${BASIS}/dashboard/klanten/relatie.html?id=r_c3`);
  await page.locator("#inhoud").waitFor({ state: "visible" });
  await page.locator("details:has(#contactform) > summary").click();
  await page.selectOption("#contactform-wijze", "Geen gehoor");
  await page.fill("#contactform-notitie", "Voicemail ingesproken (verzonnen)");
  await page.click("#contactform button[type=submit]");
  await page.waitForFunction(() => /Geen gehoor/.test(document.getElementById("tijdlijn").textContent));
  const tl = await tekst("#tijdlijn");
  controle("contact: verschijnt in de tijdlijn met wie, hoe en notitie", tl.includes("Kevin: Geen gehoor op") && tl.includes("Voicemail ingesproken"), tl.slice(0, 160));
  controle("contact: status van de klant is niet veranderd", (await api("GET", "/relaties/r_c3")).relatie.status === "Poging 1");
  await tikvlakken("relatie met contactformulier op 360 px");
  await schermafdruk("relatie-contact-360");

  // Offline vastleggen, daarna verstuurd zonder dubbele regel.
  negeer = true; // de bedoelde netwerkfout tijdens offline telt niet
  await context.setOffline(true);
  await page.selectOption("#contactform-wijze", "WhatsApp");
  await page.fill("#contactform-notitie", "");
  await page.click("#contactform button[type=submit]");
  await page.waitForFunction(() => /dit toestel/.test(document.getElementById("relmelding").textContent));
  controle("contact offline: blijft op het toestel staan", true);
  await context.setOffline(false);
  negeer = false;
  await page.evaluate(() => window.Wachtrij.verstuur());
  await page.waitForFunction(async () => (await window.Wachtrij.aantal()) === 0);
  const regels = (await api("GET", "/relaties/r_c3/tijdlijn")).regels.filter((r) => r.soort === "contact");
  controle("contact offline: na verbinding verstuurd, twee contactregels", regels.length === 2 && regels.some((r) => r.nieuw.wijze === "WhatsApp"), JSON.stringify(regels.map((r) => r.nieuw.wijze)));
  await page.evaluate(() => window.Wachtrij.verstuur());
  controle("contact: opnieuw versturen maakt geen dubbele regel", (await api("GET", "/relaties/r_c3/tijdlijn")).regels.filter((r) => r.soort === "contact").length === 2);

  // ---------- desktopformaat (klantenmodule) ----------
  await page.setViewportSize({ width: 1440, height: 900 });
  const naastElkaar = (a, b) => page.evaluate(([x, y]) => {
    const p = document.querySelector(x); const q = document.querySelector(y);
    if (!p || !q) return false;
    const r1 = p.getBoundingClientRect(); const r2 = q.getBoundingClientRect();
    return r1.width > 0 && r2.width > 0 && r2.left >= r1.right - 1 && Math.abs(r1.top - r2.top) < 200;
  }, [a, b]);
  const breedte = () => page.evaluate(() => document.querySelector("main").getBoundingClientRect().width);

  // ---------- Start: kerncijfers, taken, toewijzen ----------
  await page.goto(`${BASIS}/dashboard/klanten/`);
  await page.locator("#kerncijfers .cijfer").nth(5).waitFor();
  const kern = (await page.locator("#kerncijfers .cijfer").allInnerTexts()).map((t) => t.replace(/\s+/g, " ").replace(/\u00a0/g, " "));
  controle("Start: zes kerncijfers, met nog te factureren uit het overzicht", kern.length === 6 && kern[2].startsWith("1 ") && kern[5].includes("€"), kern.join(" | "));
  controle("Start: Toewijzen toont de lead zonder eigenaar", (await tekst("#toewijzen-lijst")).includes("Onbekendstra"));
  controle("Start: taken en zijvakken naast elkaar", await naastElkaar(".vak-taken", ".startzij"));
  controle("Start: geen technische blokken (gezondheid, nachtelijke controle) op de startpagina", (await page.locator("#gezondheid, #nachtrun").count()) === 0);
  await schermafdruk("desktop-start-voor-toewijzen");
  await page.locator("#toewijzen-lijst li", { hasText: "Onbekendstra" }).locator("button", { hasText: "Kevin" }).click();
  await page.waitForFunction(() => !document.getElementById("toewijzen-lijst").textContent.includes("Onbekendstra"));
  await page.waitForFunction((t) => document.getElementById("groepen").textContent.includes(t), KT.flow["lead-nieuw"]);
  controle("toewijzen: eigenaar op de server, de lead krijgt meteen de taak Eerste keer bellen", (await api("GET", "/relaties/r_g7")).relatie.eigenaar === "kevin" && (await tekst("#groepen")).includes("Anna Onbekendstra"));
  controle("toewijzen: een bel-knop met het nummer bij de taak", (await page.locator('#groepen a[href="tel:0500000001"]').count()) >= 1);
  await schermafdruk("desktop-start");

  // ---------- Klant zoeken in de vaste kop ----------
  await page.fill("#kopzoek-invoer", "onbek");
  await page.locator("#kopzoek-lijst li[role=option]").first().waitFor();
  controle("zoeken: resultaat als keuzelijst (combobox)", (await page.getAttribute("#kopzoek-invoer", "aria-expanded")) === "true" && (await tekst("#kopzoek-lijst")).includes("Anna Onbekendstra"));
  await page.keyboard.press("Enter");
  await page.waitForURL("**/relatie.html?id=r_g7");
  controle("zoeken: Enter opent de klant", true);
  await page.locator("#inhoud").waitFor({ state: "visible" });
  await page.mouse.wheel(0, 1500);
  await page.waitForTimeout(200);
  controle("de kop staat vast bij scrollen", await page.evaluate(() => document.querySelector("header.kop").getBoundingClientRect().top === 0 && window.scrollY > 0));
  await page.keyboard.press("/");
  controle("zoeken: '/' springt naar het zoekveld", await page.evaluate(() => document.activeElement && document.activeElement.id === "kopzoek-invoer"));

  // ---------- Leads (Anna is nog een lead): contactpersoon, e-mail, telefoon, volgende taak ----------
  await page.goto(`${BASIS}/dashboard/klanten/leads.html`);
  await page.locator("#koprij").waitFor({ state: "visible" });
  controle("lijst: kolommen Contactpersoon, E-mail, Telefoon, Volgende taak", (await page.locator("#koprij span").allInnerTexts()).join("|") === "Contactpersoon|E-mail|Telefoon|Volgende taak");
  const rijAnna = await tekst('#resultaat a.rij[href$="r_g7"]');
  controle("lijst: rij met naam, e-mail, telefoon en de volgende taak uit de flow", rijAnna.includes("Anna Onbekendstra") && rijAnna.includes("anna@example.invalid") && rijAnna.includes("0500000001") && rijAnna.includes(KT.flow["lead-nieuw"]), rijAnna);

  // ---------- Conflict: knop direct naar de plek ----------
  await page.evaluate(() => window.Wachtrij.zet({ soort: "relatie-wijzig", methode: "PATCH", pad: "/relaties/r_c3",
    body: { wijzigingId: "conflict-proef", velden: { plaats: { oud: "Fout", nieuw: "Elders" } } }, recordKey: "r_c3", relatieId: "r_c3", velden: ["plaats"] }));
  await page.locator("#wachtmelding a", { hasText: KT.wachtrij.conflictOplossen }).waitFor();
  controle("conflict: melding noemt het veld en de knop gaat naar de klant", (await tekst("#wachtmelding")).includes("Conflict bij Plaats") && (await page.getAttribute("#wachtmelding a", "href")) === "/dashboard/klanten/relatie.html?id=r_c3");
  controle("conflict: Niet opgeslagen staat nu in het menu", await page.locator("#nav-wachtrij").isVisible());
  await page.click("#wachtmelding a");
  await page.waitForURL("**/relatie.html?id=r_c3");
  await page.locator("#conflict:not([hidden])").waitFor();
  controle("conflict: op de klant staat het conflict om te kiezen", (await tekst("#conflict")).length > 0);
  await page.evaluate(async () => { for (const c of await window.Wachtrij.conflicten()) await window.Wachtrij.wisConflict(c.id); });
  await page.goto(`${BASIS}/dashboard/klanten/lijst.html`);
  await page.locator("#koprij").waitFor({ state: "visible" });
  controle("zonder wachtende of conflicten staat Niet opgeslagen niet in het menu", await page.locator("#nav-wachtrij").isHidden());

  // ---------- Instellingen: systeem, export, termijnregels ----------
  await page.click('nav.sub a[href="/dashboard/klanten/regels.html"]');
  await page.locator("#regels li").first().waitFor();
  controle("Instellingen: systeem, export en termijnregels in vakken", (await page.locator(".instellingen .vak").count()) === 3 && (await page.locator("#nachtrun").count()) === 1);
  await schermafdruk("desktop-instellingen");
  const schermen = [
    ["start", "/dashboard/klanten/", async () => {
      await page.locator("#kerncijfers .cijfer").first().waitFor();
      controle("desktop start: kerncijfers op één rij, taken en zijvakken naast elkaar",
        (await naastElkaar("#kerncijfers li:nth-child(1)", "#kerncijfers li:nth-child(2)")) && (await naastElkaar(".vak-taken", ".startzij")));
    }],
    ["lijst", "/dashboard/klanten/lijst.html", async () => {
      await page.locator("#resultaat > li").first().waitFor();
      await page.locator("#koprij").waitFor({ state: "visible" });
      controle("desktop lijst: kolomkoppen zichtbaar en rijen als tabel", await page.evaluate(() => getComputedStyle(document.querySelector("#resultaat .rij")).display === "grid"));
    }],
    ["relatie", "/dashboard/klanten/relatie.html?id=r_a1", async () => {
      await page.locator("#inhoud").waitFor({ state: "visible" });
      controle("desktop klant: gegevens en de rest naast elkaar", await naastElkaar(".kolom-links", ".kolom-rechts"));
      const g = await page.evaluate(() => ({
        groepen: [...document.querySelectorAll("#gegevens .groepkop")].map((h) => h.textContent),
        naast: (() => { const li = document.querySelector('#gegevens li[data-veld="plaats"]'); const l = li.querySelector(".veldlabel").getBoundingClientRect(); const w = li.querySelector(".veldwaarde").getBoundingClientRect(); return w.left > l.right && Math.abs(w.top - l.top) < 10; })(),
        hoogte: document.querySelector('#gegevens li[data-veld="plaats"]').getBoundingClientRect().height,
      }));
      controle("desktop klant: gegevens in groepen, label naast waarde, compacte regels", g.groepen.join("|").startsWith("Leadinformatie|Kwalificatie|Adres|Omschrijving") && g.naast && g.hoogte < 60, JSON.stringify(g));
      // De hele regel opent de editor (groot tikvlak); Annuleren sluit hem.
      await page.locator('#gegevens li[data-veld="plaats"]').click();
      await page.locator('#gegevens li[data-veld="plaats"] .editor input').waitFor();
      controle("desktop klant: klik op de regel opent de editor", true);
      await page.locator('#gegevens li[data-veld="plaats"] .editor button', { hasText: KT.annuleren }).click();
    }],
    ["traject", "/dashboard/klanten/traject.html?relatie=r_a1&id=t_a1", async () => {
      await page.locator("#inhoud").waitFor({ state: "visible" });
      controle("desktop traject: stappen en datums naast elkaar", await naastElkaar("#inhoud > .kolom-links", "#inhoud > .kolom-rechts"));
    }],
    ["leadpijplijn", "/dashboard/klanten/pijplijn.html?bord=leads", async () => {
      await page.locator("#bord .kolom").first().waitFor();
      controle("desktop leadpijplijn: kolommen naast elkaar", await naastElkaar("#bord .kolom:nth-child(1)", "#bord .kolom:nth-child(2)"));
    }],
    ["klantpijplijn", "/dashboard/klanten/pijplijn.html?bord=klanten", async () => {
      await page.locator('#bord .kolom[data-kolom="Getekend"]').waitFor();
      controle("desktop klantpijplijn: fases naast elkaar", await naastElkaar("#bord .kolom:nth-child(1)", "#bord .kolom:nth-child(2)"));
    }],
    ["overzicht", "/dashboard/klanten/overzicht.html", async () => {
      await page.locator("#inhoud .blok").first().waitFor();
      controle("desktop overzicht: blokken naast elkaar", await naastElkaar("#inhoud .blok:nth-child(2)", "#inhoud .blok:nth-child(3)"));
    }],
    ["nieuw", "/dashboard/klanten/nieuw.html", async () => {
      await page.locator("#kern .veld").first().waitFor();
      controle("desktop nieuwe lead: velden in kolommen", await naastElkaar("#kern .veld:nth-child(1)", "#kern .veld:nth-child(2)"));
      const volgorde = await page.evaluate(() => [...document.querySelectorAll("#kern .veld")].map((v) => v.dataset.veld).join(","));
      controle("nieuwe lead: velden in de volgorde van de opdracht", volgorde.startsWith("voornaam,achternaam,soortWoning,postcode,huisnummer"), volgorde);
      // Adres opzoeken: PDOK wordt nagebootst (geen echt verzoek in de test).
      await page.route("https://api.pdok.nl/bzk/locatieserver/**", (route) => {
        const u = new URL(route.request().url());
        const fq = u.searchParams.getAll("fq").join(" ");
        const gevonden = fq.includes("postcode:9999ZZ") && fq.includes("huisnummer:12");
        route.fulfill({ status: 200, contentType: "application/json", headers: { "access-control-allow-origin": "*" },
          body: JSON.stringify({ response: { docs: gevonden ? [{ straatnaam: "Verzinselweg", woonplaatsnaam: "Proefdorp" }] : [] } }) });
      });
      await page.fill("#nw-postcode", "9999 zz");
      await page.fill("#nw-huisnummer", "12");
      await page.locator("#nw-huisnummer").blur();
      await page.waitForFunction(() => document.getElementById("nw-straat").value === "Verzinselweg");
      controle("nieuwe lead: straat en plaats ingevuld uit postcode en huisnummer", (await page.inputValue("#nw-plaats")) === "Proefdorp" && (await tekst("#nw-adreshint")) === KT.nw.adresGevonden);
      await page.fill("#nw-straat", "Eigen invoer");
      await page.fill("#nw-huisnummer", "13");
      await page.locator("#nw-huisnummer").blur();
      await page.waitForFunction((t) => document.getElementById("nw-adreshint").textContent === t, KT.nw.adresNietGevonden);
      controle("nieuwe lead: niet gevonden laat zelf getypte straat staan", (await page.inputValue("#nw-straat")) === "Eigen invoer");
      await page.unroute("https://api.pdok.nl/bzk/locatieserver/**");
    }],
  ];
  for (const [naam, pad, check] of schermen) {
    await page.goto(`${BASIS}${pad}`);
    await check();
    controle(`desktop ${naam}: pagina breder dan het telefoonformaat`, (await breedte()) > 1000);
    await geenHorizontaleScroll(`${naam} op 1440 px`);
    await tikvlakken(`${naam} op 1440 px`);
    await lettergrootte(`${naam} op 1440 px`);
    await schermafdruk(`desktop-${naam}`);
  }
  // ---------- zijbalk ----------
  await page.goto(`${BASIS}/dashboard/klanten/overzicht.html`);
  await page.locator("#inhoud .blok").first().waitFor();
  const zijbalk = await page.evaluate(() => {
    const nav = document.querySelector("nav.sub").getBoundingClientRect();
    const h1 = document.querySelector("main h1").getBoundingClientRect();
    const links = [...document.querySelectorAll("nav.sub a")].map((a) => a.getBoundingClientRect()).filter((r) => r.width > 0);
    const kleur = getComputedStyle(document.querySelector("nav.sub")).backgroundColor;
    return { links: nav.right <= h1.left, onderElkaar: links.every((r, i) => i === 0 || r.top > links[i - 1].top), huidig: document.querySelector('nav.sub a[aria-current="page"]')?.getAttribute("href"), kleur, hoog: nav.height > window.innerHeight * 0.8 };
  });
  controle("zijbalk: menu links van de inhoud, knoppen onder elkaar", zijbalk.links && zijbalk.onderElkaar, JSON.stringify(zijbalk));
  controle("zijbalk: donker en over de hele hoogte", zijbalk.kleur === "rgb(35, 42, 36)" && zijbalk.hoog, JSON.stringify(zijbalk));
  controle("zijbalk: huidige pagina gemarkeerd", zijbalk.huidig === "/dashboard/klanten/overzicht.html", zijbalk.huidig);
  await page.goto(`${BASIS}/dashboard/klanten/relatie.html?id=r_a1`);
  await page.locator("#inhoud").waitFor({ state: "visible" });
  controle("zijbalk: klantscherm van een klant valt onder Klanten", (await page.getAttribute('nav.sub a[aria-current="page"]', "href")) === "/dashboard/klanten/lijst.html");
  await page.setViewportSize({ width: 360, height: 740 });
  const telefoonMenu = await page.evaluate(() => {
    const a = [...document.querySelectorAll("nav.sub a")].map((x) => x.getBoundingClientRect());
    const h1 = document.querySelector("main h1").getBoundingClientRect();
    return a.some((r, i) => i > 0 && r.top === a[i - 1].top) && a.every((r) => r.bottom <= h1.top);
  });
  controle("op de telefoon blijft het menu knoppen bovenaan", telefoonMenu);
  await page.setViewportSize({ width: 1440, height: 900 });

  // ---------- slepen ----------
  // Met de muis, zoals een gebruiker: eerst het bord zo scrollen dat bron en doel allebei in beeld zijn.
  // zone:true = neerzetten op de eindbestemming onderaan die tijdens het slepen verschijnt.
  async function sleep(bron, doel, { zone = false } = {}) {
    // Het bord kan net opnieuw getekend worden: wachten tot het 300 ms stil is.
    await page.evaluate(() => new Promise((klaar) => {
      let t = setTimeout(() => { o.disconnect(); klaar(); }, 300);
      const o = new MutationObserver(() => { clearTimeout(t); t = setTimeout(() => { o.disconnect(); klaar(); }, 300); });
      o.observe(document.getElementById("bord"), { childList: true, subtree: true });
    }));
    await page.locator(bron).waitFor();
    await page.evaluate((b) => {
      const bord = document.getElementById("bord");
      const kolom = document.querySelector(b).closest(".kolom");
      bord.scrollLeft = kolom.offsetLeft - bord.offsetLeft;
    }, bron);
    const a = await page.locator(bron).boundingBox();
    await page.mouse.move(a.x + a.width / 2, a.y + 20);
    await page.mouse.down();
    await page.mouse.move(a.x + a.width / 2 + 10, a.y + 25, { steps: 3 });
    const sel = zone ? `#sleepzones .zone[data-kolom="${doel}"]` : `#bord .kolom[data-kolom="${doel}"]`;
    if (zone) await page.locator(sel).waitFor();
    const d = await page.locator(sel).boundingBox();
    if (!d || d.x + 20 > page.viewportSize().width) throw new Error(`doel ${doel} niet in beeld`);
    await page.mouse.move(d.x + d.width / 2, d.y + d.height / 2, { steps: 12 });
    await page.mouse.up();
  }
  const toastTekst = () => tekst("#toast");
  // Breed scherm, zodat bron- en doelkolom tegelijk in beeld zijn (in de browser scrolt het bord mee tijdens het slepen).
  await page.setViewportSize({ width: 2560, height: 1000 });

  // Leadpijplijn: status wijzigen door slepen.
  await page.goto(`${BASIS}/dashboard/klanten/pijplijn.html?bord=leads`);
  await page.locator('#bord a.rij[data-id="r_e5"]').waitFor();
  await sleep('#bord a.rij[data-id="r_e5"]', "Poging 1");
  await page.waitForFunction(() => /staat nu op Poging 1/.test(document.getElementById("toast").textContent));
  await page.locator('#bord .kolom[data-kolom="Poging 1"] a.rij[data-id="r_e5"]').waitFor();
  const e5 = (await api("GET", "/relaties/r_e5")).relatie;
  controle("leads slepen: status op de server gewijzigd, met statusgeschiedenis", e5.status === "Poging 1" && e5.statusgeschiedenis.at(-1).status === "Poging 1" && e5.statusgeschiedenis.at(-1).wie === "Kevin");
  await schermafdruk("desktop-leadpijplijn-na-slepen");

  // Afgevallen: vraagt een reden; daarna gearchiveerd (niet meer op het bord, wel geteld).
  await sleep('#bord a.rij[data-id="r_e5"]', "Afgevallen", { zone: true });
  await page.locator("#keuzevenster[open]").waitFor();
  controle("tijdens slepen: eindbestemmingen onderaan, na neerzetten weer weg", await page.locator("#sleepzones").isHidden());
  controle("leads slepen naar Afgevallen: keuzevenster vraagt een reden", (await tekst("#keuzekop")).startsWith("Afgevallen: Voorlopig"));
  await schermafdruk("desktop-keuzevenster-afgevallen");
  await page.click("#keuzeok");
  controle("keuzevenster: zonder reden niet verder", (await tekst("#keuzefout")).includes(B_VERPLICHT()));
  await page.selectOption("#keuze-redenAfgevallen", "Geen interesse");
  await page.click("#keuzeok");
  await page.waitForFunction(() => /staat nu op Afgevallen/.test(document.getElementById("toast").textContent));
  await page.waitForFunction(() => !document.querySelector('#bord a.rij[data-id="r_e5"]'));
  const e5b = (await api("GET", "/relaties/r_e5")).relatie;
  controle("leads Afgevallen: status en reden in één keer opgeslagen, kaart naar het archief", e5b.status === "Afgevallen" && e5b.redenAfgevallen === "Geen interesse" && (await tekst('#bord .kolom[data-kolom="Afgevallen"]')).includes("1 gearchiveerd"));
  await page.click("label.vinkje");
  await page.locator('#bord .kolom[data-kolom="Afgevallen"] a.rij[data-id="r_e5"]').waitFor();
  controle("Toon gearchiveerd: de afgevallen lead staat weer zichtbaar in Afgevallen", true);
  await page.click("label.vinkje");

  // Annuleren in het keuzevenster: niets verandert.
  await sleep('#bord a.rij[data-id="r_f6"]', "Afgevallen", { zone: true });
  await page.locator("#keuzevenster[open]").waitFor();
  await page.click("#keuzeannuleer");
  await page.locator("#keuzevenster:not([open])").waitFor({ state: "attached" });
  controle("keuzevenster annuleren: lead blijft Nieuw", (await api("GET", "/relaties/r_f6")).relatie.status === "Nieuw");

  // Contract getekend: traject in fase Getekend, lead wordt klant en verdwijnt naar de klantpijplijn.
  await page.waitForFunction(() => !!document.querySelector('#bord a.rij[data-id="r_f6"]'));
  await sleep('#bord a.rij[data-id="r_f6"]', "Contract getekend", { zone: true });
  await page.locator("#keuzevenster[open]").waitFor();
  controle("Contract getekend: keuzevenster met route en datum", (await page.inputValue("#keuze-getekendOp")).length === 10 && (await page.inputValue("#keuze-route")) === "Maatwerk met onderzoek");
  await page.click("#keuzeok");
  await page.waitForFunction(() => /is klant/.test(document.getElementById("toast").textContent));
  await page.waitForFunction(() => !document.querySelector('#bord a.rij[data-id="r_f6"]'));
  const f6 = await api("GET", "/relaties/r_f6");
  controle("Contract getekend: relatie is Klant met een traject in fase Getekend", f6.relatie.status === "Klant" && f6.trajecten.length === 1 && f6.trajecten[0].record.fase === "Getekend" && f6.trajecten[0].record.route === "Maatwerk met onderzoek");
  controle("Contract getekend: melding linkt naar de klantpijplijn", (await page.getAttribute("#toast a", "href")).endsWith("bord=klanten"));

  // Later opnieuw (follow-up): vraagt wanneer opnieuw bellen; dat wordt de taak "Bel opnieuw" voor de eigenaar.
  await page.goto(`${BASIS}/dashboard/klanten/pijplijn.html?bord=leads`);
  await sleep('#bord a.rij[data-id="r_c3"]', "Later opnieuw", { zone: true });
  await page.locator("#keuzevenster[open]").waitFor();
  const voorstel = await page.inputValue("#keuze-terugbeldatum");
  controle("Later opnieuw: keuzevenster stelt een datum over 30 dagen voor", /^\d{4}-\d{2}-\d{2}$/.test(voorstel), voorstel);
  await page.fill("#keuze-terugbeldatum", "2027-02-01");
  await page.click("#keuzeok");
  await page.waitForFunction(() => /staat nu op Later opnieuw/.test(document.getElementById("toast").textContent));
  const c3 = (await api("GET", "/relaties/r_c3")).relatie;
  const takenRuben = (await api("GET", "/taken?wie=ruben")).taken;
  controle("Later opnieuw: status en terugbeldatum opgeslagen; taak Bel opnieuw op die dag", c3.status === "Later opnieuw" && c3.terugbeldatum === "2027-02-01"
    && takenRuben.some((t) => t.relatieId === "r_c3" && t.stap === "lead-later" && t.datum === "2027-02-01"), JSON.stringify(takenRuben.map((t) => [t.relatieId, t.stap, t.datum])));
  // Afspraak gepland: datum en tijd; de afspraak wordt een taak, de flow-taak "datum vastleggen" verdwijnt.
  await sleep('#bord a.rij[data-id="r_g7"]', "Afspraak gepland");
  await page.locator("#keuzevenster[open]").waitFor();
  await page.fill("#keuze-datum", "2026-12-02");
  await page.fill("#keuze-tijd", "14:30");
  await page.click("#keuzeok");
  await page.waitForFunction(() => /staat nu op Afspraak gepland/.test(document.getElementById("toast").textContent));
  const takenKevin = (await api("GET", "/taken")).taken.filter((t) => t.relatieId === "r_g7");
  controle("Afspraak gepland: afspraak met datum en tijd als taak, geen dubbele flow-taak", takenKevin.length === 1 && takenKevin[0].soort === "afspraak"
    && takenKevin[0].datum === "2026-12-02" && takenKevin[0].tijd === "14:30", JSON.stringify(takenKevin));

  // Klantpijplijn: fase wijzigen door slepen.
  await page.goto(`${BASIS}/dashboard/klanten/pijplijn.html?bord=klanten`);
  await page.locator('#bord .kolom[data-kolom="Getekend"] a.rij').first().waitFor();
  controle("klantpijplijn: de nieuwe klant staat op Getekend", (await tekst('#bord .kolom[data-kolom="Getekend"]')).includes("Proefstra"));
  await sleep('#bord a.rij[data-id="t_a1"]', "Opname gedaan");
  await page.waitForFunction(() => /staat nu op Opname gedaan/.test(document.getElementById("toast").textContent));
  await page.locator('#bord .kolom[data-kolom="Opname gedaan"] a.rij[data-id="t_a1"]').waitFor();
  const trA1 = (await api("GET", "/relaties/r_a1")).trajecten.find((t) => t.record.id === "t_a1").record;
  controle("klanten slepen: fase op de server gewijzigd, met fasegeschiedenis", trA1.fase === "Opname gedaan" && trA1.fasegeschiedenis.at(-1).fase === "Opname gedaan" && trA1.fasegeschiedenis.at(-1).wie === "Kevin");
  controle("klanten slepen: kolomtelling bijgewerkt", (await tekst('#bord .kolom[data-kolom="Opname gedaan"] .teller')) === "1");
  const nogWacht = await page.waitForFunction(() => !document.querySelector("#bord .rij.wacht"), null, { timeout: 5000 }).then(() => false, () => true);
  controle("klanten slepen: na verzenden staat er geen 'nog niet verstuurd' meer", !nogWacht);
  await schermafdruk("desktop-klantpijplijn-na-slepen");

  // Naar Bezwaar zonder verzenddatum besluitbrief: de server weigert, de kaart gaat terug, de reden en een link erbij.
  negeer = true; // de bedoelde 422 van de server verschijnt als fout in de console
  await sleep('#bord a.rij[data-id="t_b2"]', "Bezwaar");
  await page.waitForFunction(() => /niet naar Bezwaar gezet/.test(document.getElementById("toast").textContent));
  await page.locator('#bord .kolom[data-kolom="Opname gepland"] a.rij[data-id="t_b2"]').waitFor();
  const melding = await toastTekst();
  controle("slepen geweigerd: kaart terug in de oude fase, reden en link naar het traject", melding.includes("verzenddatum") && (await page.locator("#toast a").getAttribute("href")).includes("id=t_b2"), melding);
  const trB2 = (await api("GET", "/relaties/r_b2")).trajecten.find((t) => t.record.id === "t_b2").record;
  controle("slepen geweigerd: fase op de server ongewijzigd", trB2.fase === "Opname gepland");
  negeer = false;
  controle("slepen geweigerd: niets blijft in de wachtrij hangen", (await page.evaluate(() => window.Wachtrij.aantal())) === 0);

  // Uitbetaald (met verzenddatum): de klant gaat naar het archief.
  await api("PATCH", "/trajecten/t_d4", { wijzigingId: `w${++wid}`, velden: { verzenddatumBesluitbrief: { oud: null, nieuw: "2026-10-01" } } });
  await page.reload();
  await page.locator('#bord a.rij[data-id="t_d4"]').waitFor();
  await sleep('#bord a.rij[data-id="t_d4"]', "Uitbetaald", { zone: true });
  await page.waitForFunction(() => /staat nu op Uitbetaald/.test(document.getElementById("toast").textContent));
  await page.waitForFunction(() => !document.querySelector('#bord a.rij[data-id="t_d4"]'));
  controle("Uitbetaald: kaart naar het archief, kolom telt hem", (await tekst('#bord .kolom[data-kolom="Uitbetaald"]')).includes("1 gearchiveerd"));
  controle("Uitbetaald: klant staat niet meer in Alle klanten (archief)", !(await api("GET", "/relaties")).relaties.some((r) => r.id === "r_d4"));

  // Een kaart in dezelfde kolom neerzetten doet niets.
  await sleep('#bord a.rij[data-id="t_b2"]', "Opname gepland");
  controle("slepen binnen dezelfde kolom verandert niets", (await api("GET", "/relaties/r_b2")).trajecten[0].record.fase === "Opname gepland");

  // Naar Besluit: eerst de verzenddatum van de besluitbrief vragen (dan weigert de server niet). Annuleren = niets.
  await sleep('#bord a.rij[data-id="t_b2"]', "Besluit");
  await page.locator("#keuzevenster[open]").waitFor();
  controle("Besluit: keuzevenster vraagt de verzenddatum van de besluitbrief", (await tekst("#keuzekop")).startsWith("Besluit:"));
  await page.click("#keuzeannuleer");
  await page.locator("#keuzevenster:not([open])").waitFor({ state: "attached" });
  controle("Besluit annuleren: fase blijft Opname gepland", (await api("GET", "/relaties/r_b2")).trajecten[0].record.fase === "Opname gepland");
  await sleep('#bord a.rij[data-id="t_b2"]', "Besluit");
  await page.locator("#keuzevenster[open]").waitFor();
  await page.fill("#keuze-verzenddatumBesluitbrief", "2026-11-18");
  await page.click("#keuzeok");
  await page.waitForFunction(() => /staat nu op Besluit/.test(document.getElementById("toast").textContent));
  const b2 = (await api("GET", "/relaties/r_b2")).trajecten[0].record;
  controle("Besluit: fase en verzenddatum in één keer opgeslagen", b2.fase === "Besluit" && b2.verzenddatumBesluitbrief === "2026-11-18");

  // ---------- Gezamenlijke agenda: afspraken (leadpijplijn) en opnames (klantpijplijn) ----------
  const vandaagNL = new Intl.DateTimeFormat("sv-SE", { timeZone: "Europe/Amsterdam" }).format(new Date());
  await page.goto(`${BASIS}/dashboard/klanten/pijplijn.html?bord=klanten`);
  await page.locator('#bord a.rij[data-id="t_a1"]').waitFor();
  await sleep('#bord a.rij[data-id="t_a1"]', "Opname gepland");
  await page.locator("#keuzevenster[open]").waitFor();
  controle("Opname gepland: keuzevenster vraagt datum en tijd", (await page.locator("#keuze-opnamedatum").count()) === 1 && (await page.locator("#keuze-opnametijd").count()) === 1);
  await page.fill("#keuze-opnamedatum", vandaagNL);
  await page.fill("#keuze-opnametijd", "09:15");
  await page.click("#keuzeok");
  await page.waitForFunction(() => /staat nu op Opname gepland/.test(document.getElementById("toast").textContent));
  const a1 = (await api("GET", "/relaties/r_a1")).trajecten.find((t) => t.record.id === "t_a1").record;
  controle("Opname gepland: datum en tijd opgeslagen", a1.opnamedatum === vandaagNL && a1.opnametijd === "09:15", JSON.stringify([a1.opnamedatum, a1.opnametijd]));
  await api("POST", "/relaties", { id: "r_h8", wijzigingId: `w${++wid}`, velden: { achternaam: "Planstra", plaats: "Proefdorp", status: "Afspraak gepland", bron: "Website", eigenaar: "ruben" } });

  await page.click('nav.sub a[href="/dashboard/klanten/agenda.html"]');
  await page.waitForURL("**/agenda.html");
  await page.locator("#week .dag.vandaag .afspraak").first().waitFor();
  controle("agenda: zeven dagen, vandaag gemarkeerd, Agenda in de zijbalk", (await page.locator("#week > li.dag").count()) === 7
    && (await page.getAttribute('nav.sub a[href="/dashboard/klanten/agenda.html"]', "aria-current")) === "page");
  const vandaagVak = await tekst("#week .dag.vandaag");
  controle("agenda: de opname staat op vandaag met tijd, naam en eigenaar", vandaagVak.includes("09:15 " + KT.agendaweek.opname) && vandaagVak.includes("Testman") && vandaagVak.includes("Kevin"), vandaagVak);
  controle("agenda: opname linkt naar het traject", (await page.getAttribute("#week .dag.vandaag a.soort-opname", "href")) === "/dashboard/klanten/traject.html?relatie=r_a1&id=t_a1");
  controle("agenda: nog in te plannen toont de lead op Afspraak gepland zonder datum", (await tekst("#inteplannen")).includes("Planstra") && (await tekst("#inteplannen")).includes(KT.agendaweek.afspraakZonder));
  await schermafdruk("desktop-agenda");
  await page.selectOption("#agenda-wie", "ruben");
  await page.waitForFunction(() => !document.querySelector("#week .dag.vandaag .afspraak"));
  controle("agenda: van wie = Ruben verbergt de opname van Kevin", (await tekst("#inteplannen")).includes("Planstra"));
  await page.selectOption("#agenda-wie", "");
  // De afspraak van Anna (2 december 2026) staat in die week; via ?week= en met de knop Volgende week.
  await page.goto(`${BASIS}/dashboard/klanten/agenda.html?week=2026-12-02`);
  await page.locator('#week .dag[data-dag="2026-12-02"] .afspraak').waitFor();
  const dec2 = await tekst('#week .dag[data-dag="2026-12-02"]');
  controle("agenda: afspraak uit de leadpijplijn met tijd en titel", dec2.includes("14:30 " + KT.flow.afspraakTitel) && dec2.includes("Anna Onbekendstra"), dec2);
  controle("agenda: ?week= begint op de maandag", (await page.getAttribute("#week > li:first-child", "data-dag")) === "2026-11-30");
  await page.click("#week-volgende");
  await page.waitForFunction(() => document.querySelector("#week > li:first-child").getAttribute("data-dag") === "2026-12-07");
  controle("agenda: Volgende week schuift zeven dagen en zet de week in de adresbalk", page.url().includes("week=2026-12-07"));
  await page.click("#week-deze");
  await page.locator("#week .dag.vandaag").waitFor();
  controle("agenda: Deze week gaat terug naar vandaag", !page.url().includes("week="));

  // Deur-aan-deur blijft telefoonformaat: daar verandert de breedte niet.
  await page.goto(`${BASIS}/dashboard/deur/`);
  await page.waitForLoadState("networkidle");
  controle("deur-aan-deur laadt klanten.css niet (blijft telefoonformaat)", await page.evaluate(() => !document.querySelector('link[href*="klanten.css"]')));

  controle("geen fouten of waarschuwingen in de console (CSP, 404, scripts)", consoleFouten.length === 0, consoleFouten.slice(0, 3).join(" | "));
} catch (e) {
  gefaald = e;
  controle("rondje liep zonder uitzondering", false, e.message);
} finally {
  await browser.close();
  server.close();
}

function B_VERPLICHT() { return KT.fouten.verplicht; }
function K(sjabloon, w) { return String(sjabloon).replace(/\{(\w+)\}/g, (m, k) => (w[k] !== undefined ? String(w[k]) : m)); }

const fout = resultaten.filter((r) => !r.ok).length;
console.log(`\n${resultaten.length - fout} van ${resultaten.length} controles in orde${fout ? `, ${fout} fout` : ""}.`);
process.exit(fout || gefaald ? 1 : 0);

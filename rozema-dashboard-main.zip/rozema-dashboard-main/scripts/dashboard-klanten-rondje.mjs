// Rondje door de klantenschermen (K6) met Playwright, tegen een lokaal servertje.
// Het servertje serveert dist/ (draai eerst `npm run build`) en roept de echte handlers aan
// (inloggen, klanten, meldingen) met een in-memory store en verzonnen data. Geen echte gegevens.
// Gebruik: node scripts/dashboard-klanten-rondje.mjs
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import vm from "node:vm";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const DIST = path.join(ROOT, "dist");
const F = path.join(ROOT, "netlify", "functions");

const { zetStoreFabriek, store } = await import(`${F}/dashboard-lib/opslag.mjs`);
const { geheugenFabriek } = await import(`${F}/dashboard-lib/test-hulp.mjs`);
const { maakWachtwoordHash, maakToken } = await import(`${F}/dashboard-lib/sessie.mjs`);
const { testCatalogus } = await import(`${F}/dashboard-lib/klanten/test-regels.mjs`);
const { maakHandler } = await import(`${F}/dashboard-klanten.mjs`);
const { default: beheerHandler } = await import(`${F}/dashboard-klanten-export.mjs`);
const { default: authHandler } = await import(`${F}/dashboard-auth.mjs`);
const { default: meldingenHandler } = await import(`${F}/dashboard-meldingen.mjs`);

// Playwright staat niet in de repo: eerst gewoon proberen, dan de bekende plekken.
async function laadPlaywright() {
  try { return await import("playwright"); } catch { /* verder zoeken */ }
  const kandidaten = [process.env.PLAYWRIGHT_MODULE, "/opt/node-tools/node_modules/playwright"].filter(Boolean);
  for (const k of kandidaten) {
    try { return createRequire(import.meta.url)(k); } catch { /* volgende */ }
  }
  throw new Error("Playwright niet gevonden. Zet PLAYWRIGHT_MODULE op de map van het pakket.");
}
const { chromium } = await laadPlaywright();

// ---------- teksten en CSP uit de repo ----------
const TEKSTEN = (() => {
  const w = {};
  vm.runInNewContext(fs.readFileSync(path.join(DIST, "dashboard/gedeeld/teksten.js"), "utf8"), { window: w });
  return w.TEKSTEN;
})();
const KT = TEKSTEN.klanten;
const CSP = (() => {
  const toml = fs.readFileSync(path.join(ROOT, "netlify.toml"), "utf8");
  const blok = toml.split("[[headers]]").find((b) => /for = "\/dashboard\/\*"/.test(b));
  const m = blok && blok.match(/Content-Security-Policy = "([^"]+)"/);
  if (!m) throw new Error("CSP niet gevonden in netlify.toml");
  return m[1];
})();

// ---------- omgeving en verzonnen data ----------
const NU = new Date("2026-11-10T10:00:00.000Z");
const CTX = { deploy: { context: "deploy-preview" } };
process.env.DASHBOARD_GEBRUIKERS = JSON.stringify({ Kevin: await maakWachtwoordHash("verzonnen-a", 1000), Ruben: await maakWachtwoordHash("verzonnen-b", 1000) });
process.env.DASHBOARD_SESSIE_GEHEIM = "q".repeat(40);
delete process.env.DASHBOARD_ECHTE_DATA;
const fabriek = geheugenFabriek();
zetStoreFabriek(fabriek);
const klanten = maakHandler({ regels: testCatalogus(), nu: () => NU });

const sessie = `dashboard_sessie=${maakToken("Kevin")}`;
async function api(method, pad, body) {
  const res = await klanten(new Request(`http://x.test/api/dashboard/klanten${pad}`, {
    method,
    headers: { cookie: sessie, ...(body !== undefined ? { "content-type": "application/json" } : {}) },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  }), CTX);
  const t = await res.text();
  let data = null;
  try { data = JSON.parse(t); } catch { /* geen json */ }
  if (!res.ok) throw new Error(`${method} ${pad}: ${res.status} ${t}`);
  return data;
}

let wid = 0;
async function maakRelatie(id, velden, taak) {
  await api("POST", "/relaties", { id, wijzigingId: `w${++wid}`, velden: { status: "Nieuw", ...velden } });
  if (taak) {
    await api("PATCH", `/relaties/${id}`, { wijzigingId: `w${++wid}`, velden: {
      "taken.k1.soort": { oud: null, nieuw: "taak" },
      "taken.k1.titel": { oud: null, nieuw: taak.titel },
      "taken.k1.datum": { oud: null, nieuw: taak.datum },
    } });
  }
}
async function maakTrajectInBesluit(rid, tid, besluitbrief) {
  await api("POST", `/relaties/${rid}/trajecten`, { id: tid, wijzigingId: `w${++wid}`, velden: { fase: "Aanvraag ingediend" } });
  await api("PATCH", `/trajecten/${tid}`, { wijzigingId: `w${++wid}`, velden: {
    verzenddatumBesluitbrief: { oud: null, nieuw: besluitbrief },
    fase: { oud: "Aanvraag ingediend", nieuw: "Besluit" },
  } });
}

await maakRelatie("r_a1", { achternaam: "Testman", straat: "Verzinselstraat", huisnummer: "1", plaats: "Teststad", postcode: "9999 ZZ", eigenaar: "kevin" }, { titel: "Proefgesprek terugbellen", datum: "2026-11-10" });
await maakTrajectInBesluit("r_a1", "t_a1", "2026-10-01"); // 3 weken fictief: einde 22 oktober, dus verlopen
await maakRelatie("r_b2", { achternaam: "Voorbeeld - Nepstra", straat: "Verzinselstraat", huisnummer: "2", plaats: "Proefdorp", postcode: "9998 ZZ", eigenaar: "ruben", status: "Poging 1" }, { titel: "Nepbericht sturen", datum: "2026-11-13" });
await maakTrajectInBesluit("r_b2", "t_b2", "2026-10-24"); // einde 14 november: nog 4 dagen
await maakRelatie("r_c3", { achternaam: "Verzonnen", straat: "Nepplein", huisnummer: "5", plaats: "Proefdorp", postcode: "9997 ZZ", eigenaar: "ruben" });
await maakRelatie("r_d4", { achternaam: "Papieren", straat: "Nepplein", huisnummer: "7", plaats: "Teststad", postcode: "9996 ZZ", eigenaar: "kevin", status: "Afspraak gepland" });
// Een onvolledig traject (register zonder record, ouder dan 10 minuten) en een onleesbaar traject.
const winkel = store("klanten"); // de context is al gezet door de aanroepen hierboven
const register = await winkel.get("register/trajecten", { type: "json" });
await winkel.setJSON("register/trajecten", { ids: { ...register.ids,
  t_weg: { relatieId: "r_d4", aangemaakt: "2026-11-10T08:00:00.000Z" },
  t_kapot: { relatieId: "r_c3", aangemaakt: "2026-11-10T07:00:00.000Z" } } });
const origGet = winkel.get.bind(winkel);
winkel.get = async (k, o) => { if (k === "traject/t_kapot") throw new Error("lezen mislukt"); return origGet(k, o); };

const KLANTEN_AANTAL = 4;
const NAMEN = ["Testman", "Voorbeeld", "Nepstra", "Verzonnen", "Papieren"];

// ---------- servertje ----------
const TYPES = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8",
  ".woff2": "font/woff2", ".png": "image/png", ".webmanifest": "application/manifest+json", ".svg": "image/svg+xml", ".json": "application/json" };
const HANDLERS = [
  ["/api/dashboard/klantenbeheer/", beheerHandler],
  ["/api/dashboard/klanten/", klanten],
  ["/api/dashboard/auth/", authHandler],
  ["/api/dashboard/meldingen/", meldingenHandler],
];

async function naarRequest(req, basis) {
  const chunks = [];
  for await (const c of req) chunks.push(c);
  const body = chunks.length ? Buffer.concat(chunks) : undefined;
  const headers = new Headers();
  for (const [k, v] of Object.entries(req.headers)) if (v !== undefined) headers.set(k, Array.isArray(v) ? v.join(", ") : v);
  return new Request(basis + req.url, { method: req.method, headers, body: ["GET", "HEAD"].includes(req.method) ? undefined : body });
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, "http://localhost");
    const h = HANDLERS.find(([p]) => url.pathname.startsWith(p) || url.pathname + "/" === p);
    if (h) {
      const r = await h[1](await naarRequest(req, `http://${req.headers.host}`), CTX);
      const kopjes = {};
      r.headers.forEach((v, k) => { if (k !== "set-cookie") kopjes[k] = v; });
      const cookies = r.headers.getSetCookie ? r.headers.getSetCookie() : [];
      if (cookies.length) kopjes["set-cookie"] = cookies;
      res.writeHead(r.status, kopjes);
      res.end(Buffer.from(await r.arrayBuffer()));
      return;
    }
    let p = decodeURIComponent(url.pathname);
    let bestand = path.join(DIST, p);
    if (!bestand.startsWith(DIST)) { res.writeHead(403).end(); return; }
    if (fs.existsSync(bestand) && fs.statSync(bestand).isDirectory()) bestand = path.join(bestand, "index.html");
    if (!fs.existsSync(bestand)) { res.writeHead(404, { "content-type": "text/plain" }).end("niet gevonden"); return; }
    const kopjes = { "content-type": TYPES[path.extname(bestand)] || "application/octet-stream", "cache-control": "no-cache" };
    if (p.startsWith("/dashboard/")) kopjes["content-security-policy"] = CSP; // zoals netlify.toml
    res.writeHead(200, kopjes);
    res.end(fs.readFileSync(bestand));
  } catch (e) {
    res.writeHead(500).end("fout in testserver");
  }
});
await new Promise((r) => server.listen(0, "localhost", r));
const BASIS = `http://localhost:${server.address().port}`;

// ---------- controles ----------
const resultaten = [];
function controle(naam, ok, detail = "") {
  resultaten.push({ naam, ok: !!ok });
  console.log(`${ok ? "OK   " : "FOUT "}${naam}${!ok && detail ? ` (${detail})` : ""}`);
}

const browser = await chromium.launch();
const context = await browser.newContext({ viewport: { width: 360, height: 740 }, serviceWorkers: "block", locale: "nl-NL", timezoneId: "Europe/Amsterdam" });
const page = await context.newPage();
let consoleFouten = [];
let negeerFouten = true; // aan tot na het inloggen: het inlogscherm vraagt eerst "wie ben ik" en krijgt daar een verwachte 401 op
page.on("console", (m) => { if (!negeerFouten && (m.type() === "error" || m.type() === "warning") && !/Service Worker registration blocked/.test(m.text())) consoleFouten.push(`${m.type()}: ${m.text()} ${m.location().url}`); });
const paginaFouten = []; // niet-afgevangen fouten tellen altijd, ook in de scenario's met bedoelde serverfouten
page.on("pageerror", (e) => { paginaFouten.push(e.message); if (!negeerFouten) consoleFouten.push(`pageerror: ${e.message}`); });
const lijstVerzoeken = [];
page.on("request", (r) => { if (r.url().includes("/api/dashboard/klanten/relaties")) lijstVerzoeken.push(new URL(r.url()).searchParams.get("q")); });

const kleurRatio = () => page.evaluate(() => {
  const parse = (c) => { const m = c.match(/rgba?\(([^)]+)\)/); const d = m[1].split(/[ ,\/]+/).filter(Boolean).map(Number); return { r: d[0], g: d[1], b: d[2], a: d.length > 3 ? d[3] : 1 }; };
  const lum = ({ r, g, b }) => { const f = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; }; return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b); };
  const achtergrond = (el) => { for (let e = el; e; e = e.parentElement) { const c = parse(getComputedStyle(e).backgroundColor); if (c.a > 0.99) return c; } return parse(getComputedStyle(document.body).backgroundColor); };
  const uit = [];
  document.querySelectorAll("body *").forEach((el) => {
    const s = getComputedStyle(el);
    if (s.display === "none" || s.visibility === "hidden" || el.closest("dialog:not([open])") || el.disabled) return;
    if (!Array.from(el.childNodes).some((n) => n.nodeType === 3 && n.textContent.trim())) return;
    const fg = parse(s.color); const bg = achtergrond(el);
    const l1 = lum(fg); const l2 = lum(bg);
    const ratio = (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05);
    const groot = parseFloat(s.fontSize) >= 24 || (parseFloat(s.fontSize) >= 18.66 && parseInt(s.fontWeight, 10) >= 700);
    if (ratio < (groot ? 3 : 4.5)) uit.push(`${el.tagName.toLowerCase()}.${el.className} ${ratio.toFixed(2)}`);
  });
  return uit;
});
async function contrast(naam) {
  const slecht = await kleurRatio();
  controle(`contrast tekst-achtergrond minimaal 4,5 (WCAG AA): ${naam}`, slecht.length === 0, slecht.slice(0, 4).join("; "));
}

const tekstVan = async (sel) => (await page.locator(sel).first().innerText()).replace(/\s+/g, " ").trim();

async function geenHorizontaleScroll(naam) {
  const m = await page.evaluate(() => ({ s: document.documentElement.scrollWidth, b: document.body.scrollWidth, w: window.innerWidth }));
  controle(`geen horizontale scroll op ${m.w} px: ${naam}`, m.s <= m.w && m.b <= m.w, JSON.stringify(m));
}

async function tikvlakken(naam) {
  const klein = await page.evaluate(() => {
    const uit = [];
    const zichtbaar = (el) => {
      const s = getComputedStyle(el);
      const r = el.getBoundingClientRect();
      return s.visibility !== "hidden" && s.display !== "none" && r.width > 0 && r.height > 0;
    };
    document.querySelectorAll("a[href], button, select, textarea, input, summary, label").forEach((el) => {
      if (!zichtbaar(el)) return;
      if (el.tagName === "INPUT" && ["radio", "checkbox"].includes(el.type)) return; // het label eromheen is het tikvlak
      if (el.tagName === "LABEL" && !el.querySelector("input")) return; // alleen een label zonder invoer: geen tikvlak
      const r = el.getBoundingClientRect();
      if (r.width < 47.5 || r.height < 47.5) uit.push(`${el.tagName.toLowerCase()} ${Math.round(r.width)}x${Math.round(r.height)} "${(el.textContent || el.id || "").trim().slice(0, 30)}"`);
    });
    return uit;
  });
  controle(`alle tikvlakken minimaal 48 px: ${naam}`, klein.length === 0, klein.join("; "));
}

async function lettergrootte(naam) {
  const klein = await page.evaluate(() => {
    const uit = [];
    document.querySelectorAll("body *").forEach((el) => {
      const s = getComputedStyle(el);
      if (s.display === "none" || s.visibility === "hidden" || el.closest("dialog:not([open])")) return;
      const heeftTekst = Array.from(el.childNodes).some((n) => n.nodeType === 3 && n.textContent.trim());
      if (!heeftTekst) return;
      if (parseFloat(s.fontSize) < 17.99) uit.push(`${el.tagName.toLowerCase()} ${s.fontSize}`);
    });
    return uit;
  });
  controle(`tekst minimaal 18 px: ${naam}`, klein.length === 0, klein.slice(0, 5).join("; "));
}

async function huisstijl(naam) {
  const m = await page.evaluate(() => {
    const uit = [];
    document.querySelectorAll("body, body *").forEach((el) => {
      const s = getComputedStyle(el);
      if (el.closest("dialog:not([open])")) return;
      if (s.boxShadow !== "none") uit.push("schaduw " + el.tagName);
      if (s.textTransform === "uppercase") uit.push("hoofdletters " + el.tagName);
      if (s.backgroundImage.includes("gradient")) uit.push("verloop " + el.tagName);
      if (s.transitionDuration.split(",").some((d) => parseFloat(d) > 0)) uit.push("transitie " + el.tagName);
      if (s.animationName !== "none") uit.push("animatie " + el.tagName);
    });
    const tekst = document.body.innerText;
    if (tekst.includes(" · ")) uit.push("middenpunt");
    if (/[→←↑↓›»«]/.test(tekst)) uit.push("pijl");
    return uit;
  });
  controle(`huisstijl (geen schaduw, verloop, animatie, hoofdletterstijl, middenpunt, pijl): ${naam}`, m.length === 0, m.slice(0, 5).join("; "));
}

async function pagina(naam) {
  await contrast(naam);
  await geenHorizontaleScroll(naam);
  await tikvlakken(naam);
  await lettergrootte(naam);
  await huisstijl(naam);
}

let gefaald = null;
try {
  // 1. inloggen
  const eerste = await page.goto(`${BASIS}/dashboard/`);
  controle("CSP-header aanwezig op /dashboard/", (eerste.headers()["content-security-policy"] || "") === CSP);
  await page.locator("#inlog").waitFor({ state: "visible" });
  await page.fill("#naam", "Kevin");
  await page.fill("#wachtwoord", "verzonnen-a");
  await page.click("#inlogknop");
  await page.locator("#start").waitFor({ state: "visible" });
  controle("inloggen werkt", (await tekstVan("#wie")).includes("Kevin"));
  negeerFouten = false;
  await page.click('#modules a[href="/dashboard/klanten/"]');
  await page.waitForURL("**/dashboard/klanten/");

  // 2. Taken (startpagina; vervangt het startscherm met fatale termijnen, opdracht Ruben 20-11-2026)
  await page.locator("#groepen .takengroep").first().waitFor();
  const start = await api("GET", "/start");
  const f = start.fataal; // de server rekent de termijnen nog steeds; ze staan alleen niet meer als blok op het scherm
  controle("geen balk en geen blok met fatale termijnen meer", (await tekstVan("#balk")) === "" && !(await tekstVan("main")).includes("fatale termijnen"));
  const takenTekst = await tekstVan("#groepen");
  controle("Taken: de taak van vandaag staat bij Vandaag", (await tekstVan("#groepen .groep-vandaag")).includes("Proefgesprek terugbellen"), takenTekst.slice(0, 300));
  controle("Taken: een verlopen termijn staat als taak bij Te laat, met label termijn", (await tekstVan("#groepen .groep-teLaat")).includes(KT.takenlijst.termijn) && (await tekstVan("#groepen .groep-teLaat")).includes("Testman"));
  controle("Taken: de flow-taak bij Afspraak gepland zonder afspraak staat erbij", takenTekst.includes(KT.flow["lead-afspraak"]) && takenTekst.includes("Papieren"));
  controle("Taken: standaard alleen mijn taken (Kevin), niet die van Ruben", !takenTekst.includes("Nepbericht sturen"));
  await page.click("#wie-alle");
  await page.waitForFunction(() => document.getElementById("groepen").textContent.includes("Nepbericht sturen"));
  controle("Alle taken: ook de taken van Ruben, met eigenaar erbij", (await tekstVan("#groepen")).includes("voor Ruben"));
  await page.click("#wie-mijn");
  await page.waitForFunction(() => !document.getElementById("groepen").textContent.includes("Nepbericht sturen"));
  controle("Taken: een taak linkt naar de klant", (await page.locator('#groepen a[href="/dashboard/klanten/relatie.html?id=r_a1"]').count()) >= 1);
  await page.locator("#systeemlet:not([hidden])").waitFor();
  controle("Start: een melding met link naar Instellingen als de technische controle iets vindt", (await page.getAttribute("#systeemlet a", "href")) === "/dashboard/klanten/regels.html");
  const kern = await page.locator("#kerncijfers .cijfer").allInnerTexts();
  controle("Start: kerncijfers (te laat, vandaag, toe te wijzen, leads, trajecten, fee)", kern.length === 6 && kern[0].includes(KT.start.teLaat), kern.join(" | "));
  controle("knop 'Nieuwe lead' staat in het menu", (await page.locator('a.knop[href="/dashboard/klanten/nieuw.html"]').count()) === 1);
  await pagina("startscherm");
  // De technische controle staat bij Instellingen.
  await page.click('nav.sub a[href="/dashboard/klanten/regels.html"]');
  await page.waitForFunction((t) => document.getElementById("gezondheid").textContent.includes(t), KT.gezondheid.hartslag.ontbreekt);
  controle("Instellingen: gezondheid met ontbrekende hartslag, onvolledig en onleesbaar traject",
    (await page.locator("#gezondheid.opvallend").count()) === 1 && (await tekstVan("#gezondheid")).includes(KT.gezondheid.onvolledigEen) && (await tekstVan("#gezondheid")).includes(KT.gezondheid.onleesbaarEen));
  await pagina("instellingen");

  const letter = await page.evaluate(async () => { await document.fonts.ready; return Array.from(document.fonts).filter((f) => f.status === "loaded").map((f) => f.family); });
  controle("lettertype Atkinson Hyperlegible Next is echt geladen", letter.some((n) => /Atkinson Hyperlegible Next/.test(n)), JSON.stringify(letter));
  controle("de pagina gebruikt Atkinson als eerste lettertype", (await page.evaluate(() => getComputedStyle(document.body).fontFamily)).startsWith('"Atkinson Hyperlegible Next"'));

  // 5. beheerknop
  await page.click("#nachtrun");
  await page.waitForFunction((t) => document.getElementById("beheermelding").textContent.length > 0 && !document.getElementById("beheermelding").textContent.includes(t), KT.beheer.bezig);
  const beheer1 = await tekstVan("#beheermelding");
  controle("beheerknop start de nachtrun", [KT.beheer.klaar, KT.beheer.metFouten].includes(beheer1), beheer1);
  negeerFouten = true; // de 429 is bedoeld
  await page.click("#nachtrun");
  await page.waitForFunction((t) => document.getElementById("beheermelding").textContent === t, KT.beheer.teSnel);
  negeerFouten = false;
  controle("tweede run direct erna geeft 'te snel' (429)", true);

  // 6. Klanten en Leads: twee aparte lijsten (opdracht Ruben 20-11-2026), zoeken, filters, archief
  await page.click('nav.sub a[href="/dashboard/klanten/lijst.html"]');
  await page.waitForURL("**/lijst.html");
  await page.locator("#resultaat > li").first().waitFor();
  const rijenAantal = () => page.locator("#resultaat > li").count();
  const KLANT_NAMEN = "Testman,Voorbeeld - Nepstra";
  controle("Klanten toont alleen klanten (met traject)", (await page.locator("#resultaat .naam").allInnerTexts()).slice().sort().join() === KLANT_NAMEN, String(await rijenAantal()));
  controle("Klanten is gemarkeerd in de zijbalk", (await page.getAttribute('nav.sub a[href="/dashboard/klanten/lijst.html"]', "aria-current")) === "page");
  const eerste4 = await page.locator("#resultaat .naam").allInnerTexts();
  // Met de vaste flow heeft iedereen een volgende taak; de lijst staat op de datum daarvan (vroegste eerst).
  const lijstServer = (await api("GET", "/relaties?soort=klant")).relaties;
  const datums = lijstServer.map((r) => r.volgendeTaak?.datum ?? "9999");
  controle("gesorteerd op eerstvolgende taak (vroegste datum eerst), zoals de server", eerste4[0] === "Testman" && datums.every((d, i) => i === 0 || d >= datums[i - 1]) && eerste4.join() === lijstServer.map((r) => r.achternaam).join(), eerste4.join(" | ") + " / " + datums.join(","));
  const rij1 = page.locator("#resultaat > li a.rij").first();
  controle("een rij is een link naar relatie.html?id=", (await rij1.getAttribute("href")) === "/dashboard/klanten/relatie.html?id=r_a1");
  await pagina("lijst");
  await page.locator("#zoek").pressSequentially("9998zz", { delay: 20 });
  await page.waitForFunction(() => document.querySelectorAll("#resultaat > li").length === 1);
  controle("zoeken op postcode (zonder spatie)", (await tekstVan("#resultaat")).includes("Voorbeeld - Nepstra"));
  await page.fill("#zoek", "");
  await page.waitForFunction(() => document.querySelectorAll("#resultaat > li").length === 2);
  const faseOpties = await page.locator("#status option").allInnerTexts();
  controle("Klanten filtert op fase (de fases van het traject)", faseOpties.slice(1).join() === KT.keuzes.fase.join(), faseOpties.join());
  const fase1 = lijstServer[0].fases[0];
  await page.selectOption("#status", fase1);
  const metFase = (await api("GET", `/relaties?soort=klant&fase=${encodeURIComponent(fase1)}`)).totaal;
  await page.waitForFunction((n) => document.querySelectorAll("#resultaat > li").length === n, metFase);
  controle("filter op fase", (await tekstVan("#resultaat")).includes(lijstServer[0].achternaam));
  await page.selectOption("#status", "");
  await page.check("#archief");
  const metArchief = (await api("GET", "/relaties?soort=klant&archief=toon")).totaal;
  await page.waitForFunction((n) => document.querySelectorAll("#resultaat > li").length === n, metArchief);
  controle("Toon gearchiveerd vraagt het archief mee op", true);
  await page.uncheck("#archief");
  await page.waitForFunction(() => document.querySelectorAll("#resultaat > li").length === 2);

  await page.click('nav.sub a[href="/dashboard/klanten/leads.html"]');
  await page.waitForURL("**/leads.html");
  await page.waitForFunction(() => document.querySelectorAll("#resultaat > li").length === 2);
  controle("Leads toont alleen leads", (await page.locator("#resultaat .naam").allInnerTexts()).sort().join() === "Papieren,Verzonnen");
  controle("Leads filtert op leadstatus, zonder Klant", !(await page.locator("#status option").allInnerTexts()).includes("Klant") && (await page.locator('#status option[value="Afspraak gepland"]').count()) === 1);
  await pagina("leads");

  // zoeken met debounce
  lijstVerzoeken.length = 0;
  await page.locator("#zoek").pressSequentially("verzonnen", { delay: 40 });
  await page.waitForFunction(() => document.querySelectorAll("#resultaat > li").length === 1 || false);
  await page.waitForTimeout(500);
  controle("debounce: tijdens het typen gaat er één verzoek weg met de volledige zoekterm", lijstVerzoeken.length === 1 && lijstVerzoeken[0] === "verzonnen", JSON.stringify(lijstVerzoeken));
  controle("zoeken op naam", (await rijenAantal()) === 1 && (await tekstVan("#resultaat")).includes("Verzonnen"));
  await page.fill("#zoek", "");
  await page.locator("#zoek").pressSequentially("nepplein", { delay: 20 });
  await page.waitForFunction(() => document.querySelectorAll("#resultaat > li").length === 2);
  controle("zoeken op straat", (await rijenAantal()) === 2);
  await page.fill("#zoek", "niemandbestaat");
  await page.waitForFunction((t) => document.getElementById("aantal").textContent.startsWith(t), KT.lijst.leegLeads);
  controle("zoeken zonder uitkomst toont de lege melding", (await rijenAantal()) === 0);
  await page.fill("#zoek", "");
  await page.waitForFunction(() => document.querySelectorAll("#resultaat > li").length === 2);

  await page.selectOption("#status", "Afspraak gepland");
  await page.waitForFunction(() => document.querySelectorAll("#resultaat > li").length === 1);
  controle("filter op status (Afspraak gepland)", (await tekstVan("#resultaat")).includes("Papieren"));
  await page.selectOption("#status", "");
  await page.selectOption("#eigenaar", "kevin");
  await page.waitForFunction(() => document.querySelectorAll("#resultaat > li").length === 1);
  controle("filter op eigenaar", (await page.locator("#resultaat .naam").allInnerTexts()).join() === "Papieren");
  await page.fill("#zoek", "teststad");
  await page.waitForFunction(() => document.querySelectorAll("#resultaat > li").length === 1);
  await page.selectOption("#eigenaar", "ruben");
  await page.waitForFunction((t) => document.getElementById("aantal").textContent.startsWith(t), KT.lijst.leegLeads);
  controle("filters en zoekterm samen", true);
  await page.fill("#zoek", "");
  await page.selectOption("#eigenaar", "");
  await page.waitForFunction(() => document.querySelectorAll("#resultaat > li").length === 2);
  await page.goto(`${BASIS}/dashboard/klanten/lijst.html`);
  await page.locator('#resultaat a.rij[href$="r_a1"]').waitFor();

  // 7. rij aantikken
  await page.locator('#resultaat a.rij[href$="r_a1"]').click();
  await page.waitForURL("**/relatie.html?id=r_a1");
  await page.locator("#inhoud").waitFor({ state: "visible" });
  controle("relatie.html toont de klant, zonder balk met fatale termijnen", (await tekstVan("#naam")).includes("Testman") && (await tekstVan("#balk")) === "");
  controle("een klantkaart markeert Klanten in de zijbalk", (await page.getAttribute('nav.sub a[href="/dashboard/klanten/lijst.html"]', "aria-current")) === "page" && (await page.getAttribute('nav.sub a[href="/dashboard/klanten/leads.html"]', "aria-current")) === null);
  await pagina("relatie.html");
  await page.goto(`${BASIS}/dashboard/klanten/nieuw.html`);
  await page.locator("#nw-achternaam").waitFor();
  controle("nieuw.html toont het formulier", (await page.locator("#nw-achternaam").count()) === 1);
  await pagina("nieuw.html");
  await page.goto(`${BASIS}/dashboard/klanten/agenda.html`);
  await page.locator("#week > li.dag").first().waitFor();
  await page.locator("#inteplannen > li").first().waitFor();
  controle("agenda.html toont de week en Nog in te plannen (Papieren: Afspraak gepland zonder datum)", (await page.locator("#week > li.dag").count()) === 7 && (await tekstVan("#inteplannen")).includes("Papieren"));
  await pagina("agenda");

  // 8. meldknop op elk scherm
  for (const p of ["/dashboard/klanten/", "/dashboard/klanten/lijst.html", "/dashboard/klanten/relatie.html", "/dashboard/klanten/nieuw.html"]) {
    await page.goto(`${BASIS}${p}`);
    controle(`meldknop aanwezig op ${p}`, (await page.locator("button.meldknop").innerText()) === TEKSTEN.meld.knop);
  }
  await page.locator("button.meldknop").click();
  await page.locator("dialog.meldvenster[open]").waitFor();
  await tikvlakken("meldvenster geopend");
  await contrast("meldvenster geopend");
  await page.fill("#meld-tekst", "Proefmelding uit het rondje");
  await page.click('dialog.meldvenster button[type="submit"]');
  await page.waitForFunction((t) => document.querySelector("dialog.meldvenster .melding-tekst").textContent === t, TEKSTEN.meld.gelukt);
  controle("meldknop verstuurt een melding", true);
  await page.waitForFunction(() => !document.querySelector("dialog.meldvenster[open]"));

  // 9. Taken-teller in het menu (te laat + vandaag + toewijzen, van wie is ingelogd)
  await page.goto(`${BASIS}/dashboard/klanten/lijst.html`);
  const telling = (await api("GET", "/taken?alleen=telling")).telling;
  await page.locator('nav.sub a[href="/dashboard/klanten/"] .teller').waitFor();
  controle("menu: Taken toont het aantal dat aandacht vraagt", (await tekstVan('nav.sub a[href="/dashboard/klanten/"] .teller')) === String(telling.teLaat + telling.vandaag + telling.toewijzen), JSON.stringify(telling));

  // 10. geen persoonsgegevens in de opslag van de browser
  const opslag = await page.evaluate(() => ({ l: localStorage.length, s: Object.keys(sessionStorage) }));
  controle("localStorage blijft leeg, sessionStorage heeft alleen dashboard-sleutels", opslag.l === 0 && opslag.s.every((k) => k.startsWith("dashboard.klanten.")), JSON.stringify(opslag));

  // 10b. (vervallen) De scenario's met kapotte antwoorden van /start hoorden bij het oude startscherm met het blok
  // fatale termijnen; dat scherm en die code bestaan niet meer (Taken vervangt ze, opdracht Ruben 20-11-2026).
  // De takenlijst wordt gedekt door scripts/dashboard-overzicht-rondje.mjs.

  // 10c. lijst: een 500 is geen 'geen verbinding'
  negeerFouten = true;
  await page.route("**/api/dashboard/klanten/relaties**", (r) => r.fulfill({ status: 500, contentType: "application/json", body: "{}" }));
  await page.goto(`${BASIS}/dashboard/klanten/lijst.html`);
  await page.waitForFunction((t) => document.getElementById("lijstmelding").textContent === t, KT.lijst.mislukt);
  controle("lijst bij een 500 toont 'kon niet worden opgehaald', niet 'geen verbinding'", !(await tekstVan("#lijstmelding")).includes(TEKSTEN.algemeen.geenVerbinding));
  await page.unroute("**/api/dashboard/klanten/relaties**");
  negeerFouten = false;

  // 10d. een 401 wist de cache
  await page.goto(`${BASIS}/dashboard/klanten/`);
  await page.locator("#groepen .takengroep").first().waitFor();
  controle("na een geslaagd antwoord staat er iets in sessionStorage", (await page.evaluate(() => Object.keys(sessionStorage).filter((k) => k.startsWith("dashboard.")).length)) >= 1);
  negeerFouten = true;
  await page.route("**/api/dashboard/klanten/taken**", (r) => r.fulfill({ status: 401, contentType: "application/json", body: JSON.stringify({ fout: "Niet ingelogd." }) }));
  await page.goto(`${BASIS}/dashboard/klanten/lijst.html`); // de takenteller in het menu krijgt een 401
  await page.waitForURL(`${BASIS}/dashboard/`);
  controle("een 401 wist de cache", (await page.evaluate(() => Object.keys(sessionStorage).filter((k) => k.startsWith("dashboard.") && !k.endsWith(".wie")).length)) === 0);
  await page.unroute("**/api/dashboard/klanten/taken**");
  negeerFouten = false;

  // ======================= K7: relatie, traject, conflict, nieuw, wachtrij, regels =======================
  const wacht = async (fn, ms = 10000, wat = "voorwaarde") => {
    const tot = Date.now() + ms;
    for (;;) {
      let u; try { u = await fn(); } catch { u = false; }
      if (u) return u;
      if (Date.now() > tot) throw new Error(`time-out: ${wat}`);
      await new Promise((r) => setTimeout(r, 100));
    }
  };
  const idb = (p, store) => p.evaluate((st) => new Promise((res) => {
    const rq = indexedDB.open("rozema-klanten", 1);
    rq.onerror = () => res([]);
    rq.onsuccess = () => { const db = rq.result; try { const g = db.transaction(st).objectStore(st).getAll(); g.onsuccess = () => { db.close(); res(g.result); }; g.onerror = () => { db.close(); res([]); }; } catch { db.close(); res([]); } };
  }), store);
  const acties = async (p) => (await idb(p, "wachtrij")).filter((x) => x.soort !== "conflict").sort((a, b) => a.toegevoegd - b.toegevoegd);
  const conflictItems = async (p) => (await idb(p, "wachtrij")).filter((x) => x.soort === "conflict");
  const wachtLeeg = (p) => wacht(async () => { if ((await acties(p)).length === 0) return true; await p.evaluate(() => window.dispatchEvent(new Event("online"))); return false; }, 15000, "wachtrij leeg");
  const online = (p) => p.evaluate(() => window.dispatchEvent(new Event("online")));
  const relatieVan = async (id) => (await api("GET", `/relaties/${id}`));
  const gaRelatie = async (p, id) => { await p.goto(`${BASIS}/dashboard/klanten/relatie.html?id=${id}`); await p.locator("#inhoud").waitFor({ state: "visible" }); };
  const gaTraject = async (p, rid, tid) => { await p.goto(`${BASIS}/dashboard/klanten/traject.html?relatie=${rid}&id=${tid}`); await p.locator("#inhoud").waitFor({ state: "visible" }); };
  const tekstOp = async (p, sel) => (await p.locator(sel).first().innerText()).replace(/\s+/g, " ").trim();
  async function bewerk(p, veld, waarde, lijst = "#gegevens") {
    const li = p.locator(`${lijst} li[data-veld="${veld}"]`);
    await li.locator("button", { hasText: KT.wijzig }).first().click();
    const inv = li.locator(".editor input, .editor select, .editor textarea").first();
    if ((await inv.evaluate((e) => e.tagName)) === "SELECT") await inv.selectOption(waarde); else await inv.fill(waarde);
    await li.locator(".editor button", { hasText: new RegExp(`^${KT.opslaan}$`) }).click();
  }
  const waardeVan = (p, veld, lijst = "#gegevens") => tekstOp(p, `${lijst} li[data-veld="${veld}"] .veldwaarde`);
  const patchLog = [];
  page.on("response", (res) => { const r = res.request(); if (r.method() === "PATCH" || r.method() === "POST") { try { const b = JSON.parse(r.postData() || "{}"); if (b.wijzigingId) patchLog.push({ pad: new URL(r.url()).pathname, wid: b.wijzigingId }); } catch { /* geen json */ } } });

  // gegevens voor K7 (los van de K6-data)
  await maakRelatie("r_k7a", { achternaam: "Proefman", straat: "Verzinselweg", huisnummer: "9", plaats: "Oudedorp", postcode: "9990 ZZ", eigenaar: "kevin", mobiel: "06 12345678", telefoon: "0512 345678" });
  await maakRelatie("r_k7b", { achternaam: "Sluitman", straat: "Nepdijk", huisnummer: "3", plaats: "Nepstad", postcode: "9991 ZZ" });
  await maakTrajectInBesluit("r_k7b", "t_k7b", "2026-10-24");
  negeerFouten = false;

  // contract: de keuzelijsten van de client zijn gelijk aan die van de server (model.mjs)
  const M = await import(`${F}/dashboard-lib/klanten/model.mjs`);
  const contract = { aanhef: M.AANHEFFEN, bron: M.BRONNEN, voorWie: M.VOOR_WIE, contactvoorkeur: M.CONTACTVOORKEUREN, status: M.STATUSSEN, situatie: M.SITUATIES,
    kwalificatie: M.KWALIFICATIES, redenAfgevallen: M.REDENEN_AFGEVALLEN, eigenaar: M.EIGENAREN, soort: M.TAAK_SOORTEN, fase: M.FASES, route: M.ROUTES, redenVerlies: M.REDENEN_VERLIES, wijze: M.CONTACT_WIJZEN, soortWoning: M.SOORTEN_WONING };
  const afwijkend = Object.keys(contract).filter((k) => JSON.stringify(contract[k]) !== JSON.stringify(KT.keuzes[k]));
  controle("keuzelijsten van de client zijn gelijk aan model.mjs", afwijkend.length === 0 && Object.keys(KT.keuzes).length === Object.keys(contract).length, afwijkend.join(","));

  // 1. contactknoppen en de pagina in rust
  await gaRelatie(page, "r_k7a");
  const hrefs = await page.evaluate(() => Object.fromEntries(Array.from(document.querySelectorAll("#contact a")).map((a) => [a.dataset.actie, a.getAttribute("href")])));
  controle("contact: bellen (tel:), WhatsApp (wa.me) en navigeren (maps-link)", hrefs.bel === "tel:0612345678" && hrefs["bel-telefoon"] === "tel:0512345678" && hrefs.whatsapp === "https://wa.me/31612345678"
    && /^https:\/\/www\.google\.com\/maps\/search\/\?api=1&query=.*Verzinselweg/.test(hrefs.navigeer), JSON.stringify(hrefs));
  controle("relatiescherm: gegevens, termijnen, taken, trajecten en tijdlijn staan er", (await page.locator("#gegevens li.veldrij").count()) >= 20 && (await tekstOp(page, "#rel-termijnen")).includes(KT.flow["lead-nieuw"]));
  await pagina("relatie (K7)");
  await page.locator('#gegevens li[data-veld="plaats"] button').click();
  await tikvlakken("relatie met geopende editor");
  await contrast("relatie met geopende editor");
  await page.locator('#gegevens li[data-veld="plaats"] .editor button', { hasText: KT.annuleren }).click();

  // 2. veld bewerken, vervolgknop, validatiefout
  await bewerk(page, "plaats", "Nieuwdorp");
  await wacht(async () => (await waardeVan(page, "plaats")) === "Nieuwdorp", 8000, "plaats zichtbaar");
  controle("een veld bewerken: waarde op het scherm en op de server", (await relatieVan("r_k7a")).relatie.plaats === "Nieuwdorp");
  controle("na een geslaagde bewerking staat de wachtrij leeg", (await acties(page)).length === 0);
  negeerFouten = true; // de 422 is bedoeld
  await bewerk(page, "postcode", "abc");
  await wacht(async () => (await tekstOp(page, '#gegevens li[data-veld="postcode"] .editor')).includes("postcode"), 8000, "foutmelding postcode");
  await page.waitForTimeout(300);
  negeerFouten = false;
  controle("een validatiefout (422) staat inline en wordt niet bewaard", (await acties(page)).length === 0);
  await page.locator('#gegevens li[data-veld="postcode"] .editor button', { hasText: KT.annuleren }).click();
  await page.locator('#rel-termijnen button[data-vervolg="Poging 1"]').click();
  await wacht(async () => (await relatieVan("r_k7a")).relatie.status === "Poging 1", 8000, "vervolgknop");
  controle("vervolgknop zet de status op de server", true);
  await page.locator('#gegevens li[data-veld="status"] button', { hasText: KT.wijzig }).first().click();
  await page.locator('#gegevens li[data-veld="status"] .editor select').first().selectOption("Afgevallen");
  await page.locator('#gegevens li[data-veld="status"] .editor select').nth(1).selectOption("Geen interesse");
  await page.locator('#gegevens li[data-veld="status"] .editor button', { hasText: new RegExp(`^${KT.opslaan}$`) }).click();
  await wacht(async () => (await relatieVan("r_k7a")).relatie.redenAfgevallen === "Geen interesse", 8000, "reden afgevallen");
  controle("status Afgevallen gaat samen met een reden", (await relatieVan("r_k7a")).relatie.status === "Afgevallen");

  // 3. taken
  await page.locator("summary", { hasText: KT.rel.nieuweTaak }).click();
  await page.fill("#taakform-titel", "Proeftaak bellen");
  await page.fill("#taakform-datum", "2026-11-20");
  await page.locator('#taakform button[type="submit"]').click();
  await wacht(async () => (await tekstOp(page, "#taken")).includes("Proeftaak bellen"), 8000, "taak zichtbaar");
  await page.locator("#taken li button", { hasText: KT.rel.klaar }).first().click();
  await wacht(async () => (await tekstOp(page, "#taken")).includes("Klaar, door Kevin"), 8000, "taak klaar");
  // Het scherm toont "klaar" al zodra de wijziging in de wachtrij staat; wacht ook tot de server hem heeft.
  await wacht(async () => !!Object.values((await relatieVan("r_k7a")).relatie.taken ?? {})[0]?.klaar, 8000, "taak klaar op de server").catch(() => {});
  const taak = Object.values((await relatieVan("r_k7a")).relatie.taken)[0];
  controle("een taak toevoegen en afronden", taak.titel === "Proeftaak bellen" && taak.klaar && taak.klaar.wie === "Kevin");

  // 4. nieuw traject
  await page.locator("summary", { hasText: KT.rel.nieuwTraject }).click();
  await page.locator('#trajectform button[type="submit"]').click();
  await wacht(async () => (await page.locator("#trajecten a.rij").count()) === 1, 8000, "traject zichtbaar");
  controle("een nieuw traject aanmaken", (await relatieVan("r_k7a")).trajecten.length === 1);
  controle("tijdlijn toont de wijzigingen", (await tekstOp(page, "#tijdlijn")).includes("Nieuwdorp") && (await tekstOp(page, "#tijdlijn")).includes("Kevin"));
  await pagina("relatie (K7, met data)");

  // 5. conflict tussen twee telefoons
  const context2 = await browser.newContext({ viewport: { width: 360, height: 740 }, serviceWorkers: "block", locale: "nl-NL", timezoneId: "Europe/Amsterdam" });
  const page2 = await context2.newPage();
  const fouten2 = [];
  page2.on("pageerror", (e) => fouten2.push(e.message));
  await page2.goto(`${BASIS}/dashboard/`);
  await page2.fill("#naam", "Ruben"); await page2.fill("#wachtwoord", "verzonnen-b"); await page2.click("#inlogknop");
  await page2.locator("#start").waitFor({ state: "visible" });
  await gaRelatie(page2, "r_k7a");
  await bewerk(page2, "plaats", "Rubendorp");
  await bewerk(page2, "straat", "Rubenstraat");
  await wacht(async () => (await relatieVan("r_k7a")).relatie.straat === "Rubenstraat", 8000, "Ruben slaat op");
  // telefoon 1 heeft nog de oude stand op het scherm
  await bewerk(page, "plaats", "Kevindorp");
  await page.locator("#conflict .conflictrij").first().waitFor();
  const conflictTekst = await tekstOp(page, "#conflict");
  controle("conflict: het scherm noemt wie de ander is en toont beide waarden", conflictTekst.includes("Ruben") && conflictTekst.includes("Kevindorp") && conflictTekst.includes("Rubendorp"), conflictTekst);
  await pagina("relatie met conflictscherm");
  await page.locator('#conflict .conflictrij[data-veld="plaats"] button[data-keuze="mijn"]').click();
  await wacht(async () => (await relatieVan("r_k7a")).relatie.plaats === "Kevindorp", 8000, "mijn waarde");
  controle("conflict: 'mijn waarde' wordt opgeslagen met de waarde van de ander als oud", (await relatieVan("r_k7a")).relatie.plaats === "Kevindorp");
  await wacht(async () => (await page.locator("#conflict").isHidden()), 8000, "conflictscherm weg");
  await bewerk(page2, "straat", "Rubenlaan"); // de ander wijzigt opnieuw terwijl telefoon 1 nog de vorige stand toont
  await wacht(async () => (await relatieVan("r_k7a")).relatie.straat === "Rubenlaan", 8000, "Ruben wijzigt opnieuw");
  await bewerk(page, "straat", "Kevinstraat");
  await page.locator('#conflict .conflictrij[data-veld="straat"] button[data-keuze="hunne"]').click();
  await wacht(async () => (await page.locator("#conflict").isHidden()), 8000, "tweede conflict weg");
  controle("conflict: 'die van de ander' laat de waarde van de ander staan", (await relatieVan("r_k7a")).relatie.straat === "Rubenlaan");
  controle("na de keuzes zijn er geen conflicten meer bewaard", (await conflictItems(page)).length === 0);
  controle("conflict: geen niet-afgevangen fout op de tweede telefoon", fouten2.length === 0, fouten2.join("; "));

  // 6. traject: stappen, termijn naast de datum, 409, afvinken, sluiten, heropenen
  await gaTraject(page, "r_k7b", "t_k7b");
  const stappen = await page.locator("#stappen > li").evaluateAll((l) => l.map((e) => e.dataset.fase));
  controle("fase is een verticale stappenlijst in de volgorde van het traject", JSON.stringify(stappen) === JSON.stringify(KT.keuzes.fase) && (await page.locator("ol#stappen").count()) === 1);
  controle("de huidige fase is met tekst aangegeven", (await tekstOp(page, '#stappen li[data-fase="Besluit"]')).includes(KT.tr.huidig) && (await tekstOp(page, '#stappen li[data-fase="Aanvraag ingediend"]')).includes(KT.tr.gedaan));
  const naast = await tekstOp(page, '#gegevens li[data-veld="verzenddatumBesluitbrief"] .veldextra');
  controle("een datum toont de termijn ernaast", naast.includes(KT.tr.termijn) && /nog \d+ dagen|\d+ dagen verlopen/.test(naast), naast);
  await pagina("traject");
  negeerFouten = true; // het 409-antwoord geeft een bedoelde consolefout
  await page.locator('#stappen li[data-fase="Afgerond"] button').click();
  await page.locator('#blokkade li[data-blokkade="deal-bezwaar"]').waitFor();
  negeerFouten = false;
  controle("sluiten met een open fatale termijn (409) toont de blokkerende termijn", (await tekstOp(page, "#blokkade-kop")).includes(KT.tr.blokkade) && (await tekstOp(page, "#blokkade")).includes("bezwaar") && (await relatieVan("r_k7b")).trajecten[0].record.fase === "Besluit");
  controle("een geweigerde actie komt niet in de wachtrij", (await acties(page)).length === 0);
  const bezwaarLi = page.locator('#termijnen li[data-regel="deal-bezwaar"]');
  controle("afvinken biedt de acties van de regel aan", (await bezwaarLi.locator('button[data-actie="afvinken"]').allInnerTexts()).join("|") === "Afvinken: Bezwaar ingediend|Afvinken: Besluit geaccepteerd");
  await bezwaarLi.locator("button", { hasText: "Besluit geaccepteerd" }).click();
  await wacht(async () => (await relatieVan("r_k7b")).trajecten[0].termijnen.find((t) => t.regelId === "deal-bezwaar").status === "afgevinkt", 8000, "afgevinkt");
  await wacht(async () => (await bezwaarLi.locator('button[data-actie="heropenen"]').count()) === 1, 8000, "heropenknop");
  controle("afvinken met een gekozen actie", true);
  await page.locator('#stappen li[data-fase="Afgerond"] button').click();
  await wacht(async () => (await relatieVan("r_k7b")).trajecten[0].record.fase === "Afgerond", 8000, "afgerond");
  await wacht(async () => (await tekstOp(page, '#stappen li[data-fase="Afgerond"]')).includes(KT.tr.huidig), 8000, "huidige fase Afgerond");
  controle("na het afvinken kan het traject gesloten worden", true);
  await page.locator('#termijnen li[data-regel="deal-bezwaar"] button[data-actie="heropenen"]').click();
  await wacht(async () => (await relatieVan("r_k7b")).trajecten[0].termijnen.find((t) => t.regelId === "deal-bezwaar").status === "open", 8000, "heropend");
  controle("heropenen zet de termijn weer open", true);
  await bewerk(page, "uitkeringImg", "1234,5", "#gegevens");
  await wacht(async () => (await relatieVan("r_k7b")).trajecten[0].record.uitkeringImg === 1234.5, 8000, "bedrag");
  controle("een bedrag bewerken (komma wordt punt)", true);

  // 7. nieuwe klant, met validatie en het id-formaat
  await page.goto(`${BASIS}/dashboard/klanten/nieuw.html`);
  await page.fill("#nw-achternaam", "Nieuwstra");
  negeerFouten = true; // de 422 is bedoeld
  await page.fill("#nw-telefoon", "abc");
  await page.locator('#nieuwform button[type="submit"]').click();
  await wacht(async () => (await tekstOp(page, "#nw-telefoon-fout")).length > 0, 8000, "fout telefoon");
  controle("nieuwe klant: een serverfout staat bij het veld en het formulier blijft staan", (await tekstOp(page, "#nw-telefoon-fout")).includes("telefoon") && (await acties(page)).length === 0);
  await page.waitForTimeout(300);
  negeerFouten = false;
  await page.fill("#nw-telefoon", "0512 111222");
  await page.fill("#nw-plaats", "Nieuwerhoek");
  await page.locator('#nieuwform button[type="submit"]').click();
  await page.waitForURL(/relatie\.html\?id=r_/);
  const nieuwId = new URL(page.url()).searchParams.get("id");
  controle("nieuwe klant: het id heeft het formaat dat de server accepteert", /^r_[A-Za-z0-9_-]{1,62}$/.test(nieuwId), nieuwId);
  await page.locator("#inhoud").waitFor({ state: "visible" });
  controle("nieuwe klant staat op de server en op het scherm", (await relatieVan(nieuwId)).relatie.achternaam === "Nieuwstra" && (await tekstOp(page, "#naam")).includes("Nieuwstra"));

  // 8. regels (alleen lezen), met een niet bevestigde regel via een gemockt antwoord
  await page.goto(`${BASIS}/dashboard/klanten/regels.html`);
  await page.locator("#regels > li").first().waitFor();
  controle("regels: alle regels van de server staan er", (await page.locator("#regels > li").count()) === (await api("GET", "/regels")).regels.length);
  await page.route("**/api/dashboard/klanten/regels", async (route) => {
    const echt = await (await route.fetch()).json();
    echt.regels[0] = { ...echt.regels[0], bevestigingsstatus: "niet-bevestigd", duur: { aantal: null, eenheid: null }, bevestigd: null };
    await route.fulfill({ contentType: "application/json", body: JSON.stringify(echt) });
  });
  await page.reload();
  await page.locator("#regels > li").first().waitFor();
  const nb = await tekstOp(page, "#regels > li.signaal");
  controle("regels: 'niet bevestigd' staat er in tekst en opvallend bij", nb.includes(KT.rg.nietBevestigd) && nb.includes(KT.rg.nietBevestigdUitleg) && (await page.locator("#regels .onbevestigd").count()) === 1, nb);
  await pagina("regels");
  await page.unroute("**/api/dashboard/klanten/regels");
  controle("regels: geen knoppen om iets te wijzigen in de termijnregels", (await page.locator("#regels button").count()) === 0);

  // ---------- offline en wachtrij (bedoelde netwerkfouten: consolefouten negeren) ----------
  negeerFouten = true;

  // 9. vliegtuigmodus: wijzigen, taak, daarna versturen; volgorde en wijzigingId
  await gaRelatie(page, "r_k7a");
  patchLog.length = 0;
  await context.setOffline(true);
  await bewerk(page, "plaats", "Offlinedorp");
  await wacht(async () => (await acties(page)).length === 1, 5000, "eerste wijziging bewaard");
  await bewerk(page, "plaats", "Offlinedorp2");
  await page.locator("summary", { hasText: KT.rel.nieuweTaak }).click();
  await page.fill("#taakform-titel", "Offlinetaak");
  await page.locator('#taakform button[type="submit"]').click();
  await wacht(async () => (await acties(page)).length === 3, 5000, "drie acties bewaard");
  controle("offline: de wijziging staat direct op het scherm", await wacht(async () => (await waardeVan(page, "plaats")) === "Offlinedorp2" && (await tekstOp(page, "#taken")).includes("Offlinetaak"), 5000, "scherm").then(() => true, () => false));
  controle("offline: de navigatie telt de niet-opgeslagen wijzigingen", await wacht(async () => (await tekstOp(page, "#nav-wachtrij")) === "Niet opgeslagen (3)", 5000, "nav").then(() => true, () => false));
  const wachtItems = await acties(page);
  controle("offline: elke actie heeft een eigen vaste wijzigingId, in volgorde", new Set(wachtItems.map((x) => x.body.wijzigingId)).size === 3 && wachtItems.every((x, i, a) => i === 0 || a[i - 1].toegevoegd < x.toegevoegd));
  await context.setOffline(false);
  await online(page);
  await wachtLeeg(page);
  const na = (await relatieVan("r_k7a")).relatie;
  controle("offline daarna online: alles verstuurd, in volgorde, zonder conflict", na.plaats === "Offlinedorp2" && Object.values(na.taken).some((t) => t.titel === "Offlinetaak") && (await conflictItems(page)).length === 0);
  controle("elke wijzigingId is precies één keer verstuurd", patchLog.length === 3 && new Set(patchLog.map((x) => x.wid)).size === 3, JSON.stringify(patchLog.length));
  // offline afvinken op het traject
  await gaTraject(page, "r_k7b", "t_k7b");
  await context.setOffline(true);
  await page.locator('#termijnen li[data-regel="deal-bezwaar"] button', { hasText: "Bezwaar ingediend" }).click();
  await wacht(async () => (await acties(page)).length === 1, 5000, "afvinken bewaard");
  controle("offline afvinken wacht in de wachtrij", (await acties(page))[0].soort === "afvinken" && await wacht(async () => (await tekstOp(page, "#trmelding")).includes("verstuurd"), 5000, "melding").then(() => true, () => false));
  await context.setOffline(false);
  await online(page);
  await wachtLeeg(page);
  controle("offline afvinken wordt daarna verstuurd", (await relatieVan("r_k7b")).trajecten[0].termijnen.find((t) => t.regelId === "deal-bezwaar").status === "afgevinkt");

  // 10. 503 met herhaal: dezelfde wijzigingId
  await gaRelatie(page, "r_k7a");
  await context.setOffline(true);
  await bewerk(page, "plaats", "Druktedorp");
  await wacht(async () => (await acties(page)).length === 1, 5000, "bewaard voor 503");
  await wacht(async () => (await tekstOp(page, "#relmelding")).includes("verstuurd"), 5000, "eerste poging klaar");
  const wid503 = (await acties(page))[0].body.wijzigingId;
  const gezien503 = [];
  let modus503 = "offline"; // vooraf installeren: de online-gebeurtenis na setOffline(false) verstuurt meteen
  await page.route("**/api/dashboard/klanten/relaties/r_k7a", async (route) => {
    if (route.request().method() !== "PATCH") return route.continue();
    if (modus503 === "offline") return route.abort();
    gezien503.push(JSON.parse(route.request().postData()).wijzigingId);
    if (gezien503.length <= 2) return route.fulfill({ status: 503, contentType: "application/json", body: JSON.stringify({ fout: "Het is druk.", code: "gelijktijdig-probeer-opnieuw", herhaal: true }) });
    return route.continue();
  });
  modus503 = "live";
  await context.setOffline(false);
  await online(page);
  await wachtLeeg(page);
  await page.unroute("**/api/dashboard/klanten/relaties/r_k7a");
  controle("503 met herhaal: opnieuw met dezelfde wijzigingId, daarna opgeslagen", gezien503.length === 3 && gezien503.every((w) => w === wid503) && (await relatieVan("r_k7a")).relatie.plaats === "Druktedorp", JSON.stringify(gezien503.length));

  // 11. een 401 halverwege de wachtrij: niets weggooien, inloggen, daarna verder
  await gaRelatie(page, "r_k7a");
  // De route staat er vóór het offline gaan. Chromium laat een PATCH die vlak na setOffline(true) vertrekt soms toch door
  // (onder belasting gezien: de eerste wijziging kwam met 200 aan voordat de 401-route er stond, waarna de tweede
  // wijziging 200 kreeg en de derde de 401). Daarom breekt de route zelf alles af zolang de test "offline" is.
  let teller401 = 0;
  let modus401 = "offline";
  await page.route("**/api/dashboard/klanten/relaties/r_k7a", async (route) => {
    if (route.request().method() !== "PATCH") return route.continue();
    if (modus401 === "offline") return route.abort("internetdisconnected");
    teller401++;
    if (teller401 === 2) { await context.clearCookies(); return route.fulfill({ status: 401, contentType: "application/json", body: JSON.stringify({ fout: "Niet ingelogd." }) }); }
    return route.continue();
  });
  await context.setOffline(true);
  await bewerk(page, "plaats", "Eerstedorp");
  await bewerk(page, "huisnummer", "11");
  await bewerk(page, "toevoeging", "B");
  await wacht(async () => (await acties(page)).length === 3, 5000, "drie voor 401");
  await wacht(async () => (await tekstOp(page, "#relmelding")).includes("verstuurd"), 5000, "eerste poging klaar");
  modus401 = "live";
  await context.setOffline(false);
  await online(page);
  await wacht(async () => (await acties(page)).length === 2, 10000, "twee over na de 401").catch(async (e) => {
    console.log(`DEBUG 401: teller=${teller401} wachtrij=${JSON.stringify((await acties(page)).map((x) => [x.body.velden && Object.keys(x.body.velden), !!x.afgekeurd]))}`);
    throw e;
  });
  await page.waitForTimeout(300);
  controle("401 halverwege: de rest blijft bewaard, het verstuurde is weg", (await acties(page)).length === 2 && (await acties(page)).every((x) => !x.afgekeurd));
  controle("401 halverwege: er is een melding om in te loggen", await wacht(async () => /Log in|Naar inloggen/.test(await page.locator("body").innerText()) || (await page.url()).endsWith("/dashboard/"), 5000, "inlogmelding").then(() => true, () => false));
  await page.unroute("**/api/dashboard/klanten/relaties/r_k7a");
  // inloggen en verder
  await page.goto(`${BASIS}/dashboard/`);
  await page.locator("#inlog").waitFor({ state: "visible" });
  const na401 = [(await acties(page)).length, (await idb(page, "kv")).length];
  controle("een 401 wist de cache maar niet de wachtrij", na401[0] === 2 && na401[1] === 0, JSON.stringify(na401));
  await page.fill("#naam", "Kevin"); await page.fill("#wachtwoord", "verzonnen-a"); await page.click("#inlogknop");
  await page.locator("#start").waitFor({ state: "visible" });
  await gaRelatie(page, "r_k7a");
  await wachtLeeg(page);
  const r401 = (await relatieVan("r_k7a")).relatie;
  controle("na het inloggen worden de resterende wijzigingen verstuurd, in volgorde", r401.plaats === "Eerstedorp" && r401.huisnummer === "11" && r401.toevoeging === "B", JSON.stringify([r401.plaats, r401.huisnummer, r401.toevoeging]));

  // 12. een 422 komt in "Niet opgeslagen"; latere wijzigingen op dat record wachten
  await context.setOffline(true);
  await bewerk(page, "telefoon", "abc");
  await bewerk(page, "plaats", "Naloopdorp");
  await wacht(async () => (await acties(page)).length === 2, 5000, "twee voor 422");
  await wacht(async () => (await tekstOp(page, "#relmelding")).includes("verstuurd"), 5000, "eerste poging klaar");
  await context.setOffline(false);
  await online(page);
  await wacht(async () => (await acties(page)).some((x) => x.afgekeurd), 10000, "afgekeurd");
  controle("422 uit de wachtrij: afgekeurd bewaard, de volgende wijziging op dat record wacht", (await acties(page)).length === 2 && (await relatieVan("r_k7a")).relatie.plaats === "Eerstedorp");
  await page.goto(`${BASIS}/dashboard/klanten/niet-opgeslagen.html`);
  await page.locator("#wachtlijst > li").first().waitFor();
  const nietTekst = await tekstOp(page, "#wachtlijst");
  controle("Niet opgeslagen toont de afgekeurde actie met reden en de wachtende", nietTekst.includes("Niet opgeslagen:") && nietTekst.includes("telefoonnummer") && nietTekst.includes(KT.niet.geblokkeerd), nietTekst);
  await pagina("Niet opgeslagen");
  await page.locator('#wachtlijst button[data-knop="opnieuw"]').click();
  await page.waitForTimeout(600);
  controle("opnieuw proberen met dezelfde fout laat de actie staan", (await acties(page)).filter((x) => x.afgekeurd).length === 1);
  const eersteWeg = page.locator('#wachtlijst > li button[data-knop="verwijder"]').first();
  await eersteWeg.click();
  controle("verwijderen vraagt eerst om bevestiging", (await eersteWeg.innerText()) === KT.niet.verwijderBevestig && (await acties(page)).length === 2);
  await eersteWeg.click();
  await wachtLeeg(page);
  controle("na verwijderen van de afgekeurde actie gaat de wachtende door", (await relatieVan("r_k7a")).relatie.plaats === "Naloopdorp");

  // 13. nieuwe klant in vliegtuigmodus, en tonen vanuit de wachtrij
  await page.goto(`${BASIS}/dashboard/klanten/nieuw.html`);
  await context.setOffline(true);
  await page.fill("#nw-achternaam", "Vluchtman");
  await page.fill("#nw-plaats", "Luchthaven");
  await page.locator('#nieuwform button[type="submit"]').click();
  await page.locator("#naarklant").waitFor({ state: "visible" });
  const vluchtHref = await page.locator("#naarklant").getAttribute("href");
  const vluchtId = new URL(vluchtHref, BASIS).searchParams.get("id");
  controle("nieuwe klant offline: bewaard op het toestel met uitleg en een link", (await tekstOp(page, "#nieuwklaar")).includes(KT.nw.wachtOpslag) && (await acties(page)).length === 1 && (await acties(page))[0].soort === "relatie-nieuw");
  // Eerst de server onbereikbaar maken, dan pas weer online: anders verstuurt de wachtrij de klant al (terecht)
  // bij het online-signaal, en is er niets meer "nog niet verstuurd" om te tonen.
  await page.route("**/api/dashboard/klanten/**", (r) => r.abort());
  await context.setOffline(false);
  await page.locator("#naarklant").click();
  await page.locator("#inhoud").waitFor({ state: "visible" });
  controle("een klant die nog in de wachtrij staat is te openen", (await tekstOp(page, "#naam")).includes("Vluchtman") && (await tekstOp(page, "#relmelding")).includes(KT.rel.nogNietVerstuurd));
  await bewerk(page, "plaats", "Landingsbaan");
  await wacht(async () => (await acties(page)).length === 2, 5000, "wijziging op wachtende klant");
  await page.unroute("**/api/dashboard/klanten/**");
  await online(page);
  await wachtLeeg(page);
  const vlucht = (await relatieVan(vluchtId)).relatie;
  controle("de wachtende klant en zijn wijziging worden in volgorde verstuurd", vlucht.achternaam === "Vluchtman" && vlucht.plaats === "Landingsbaan");

  // 14. uitloggen met iets in de wachtrij: eerst versturen of bewust wissen
  await gaRelatie(page, "r_k7a");
  controle("de cache van de klant staat op het toestel", (await idb(page, "kv")).length >= 1);
  await page.route("**/api/dashboard/klanten/**", (r) => r.abort());
  await bewerk(page, "plaats", "Waarschuwdorp");
  await wacht(async () => (await acties(page)).length === 1, 5000, "item voor uitloggen");
  await page.goto(`${BASIS}/dashboard/`);
  await page.locator("#uitloggen").waitFor({ state: "visible" });
  await page.click("#uitloggen");
  await page.locator("#uitlogwaarschuwing").waitFor({ state: "visible" });
  controle("uitloggen met een gevulde wachtrij waarschuwt en biedt versturen of wissen", (await tekstOp(page, "#uitlogtekst")).includes("1 wijzigingen")
    && (await page.locator("#uitlogversturen").isVisible()) && (await page.locator("#uitlogwissen").isVisible()) && (await page.locator("#uitlogtoch").count()) === 0);
  await tikvlakken("uitlogwaarschuwing");
  await contrast("uitlogwaarschuwing");
  await page.click("#uitlogannuleer");
  controle("annuleren laat je ingelogd", (await page.locator("#uitlogwaarschuwing").isHidden()) && (await page.locator("#inlog").isHidden()));
  await page.click("#uitloggen");
  await page.click("#uitlogversturen");
  await page.waitForTimeout(800);
  controle("eerst versturen zonder verbinding: niet uitgelogd, wachtrij blijft", (await page.locator("#inlog").isHidden()) && (await acties(page)).length === 1 && (await tekstOp(page, "#uitlogtekst")).includes("Niet alles"));
  await page.unroute("**/api/dashboard/klanten/**");
  await page.click("#uitlogversturen");
  await page.locator("#inlog").waitFor({ state: "visible" });
  controle("eerst versturen met verbinding: verstuurd, uitgelogd, cache gewist", (await relatieVan("r_k7a")).relatie.plaats === "Waarschuwdorp" && (await acties(page)).length === 0 && (await idb(page, "kv")).length === 0);
  await page.fill("#naam", "Kevin"); await page.fill("#wachtwoord", "verzonnen-a"); await page.click("#inlogknop");
  await page.locator("#start").waitFor({ state: "visible" });
  // wissen van dit toestel, met een bevestiging die het aantal noemt
  await gaRelatie(page, "r_k7a");
  await page.route("**/api/dashboard/klanten/**", (r) => r.abort());
  await bewerk(page, "plaats", "Wisdorp");
  await wacht(async () => (await acties(page)).length === 1, 5000, "item om te wissen");
  await page.goto(`${BASIS}/dashboard/`);
  await page.locator("#uitloggen").waitFor({ state: "visible" });
  await page.click("#uitloggen");
  await page.click("#uitlogwissen");
  controle("wissen vraagt eerst om bevestiging met het aantal", (await tekstOp(page, "#uitlogwistekst")).includes("1 wijzigingen") && (await acties(page)).length === 1);
  await page.click("#uitlogwisja");
  await page.locator("#inlog").waitFor({ state: "visible" });
  await page.unroute("**/api/dashboard/klanten/**");
  controle("wissen: wachtrij leeg, server ongewijzigd", (await acties(page)).length === 0 && (await relatieVan("r_k7a")).relatie.plaats === "Waarschuwdorp");
  await page.fill("#naam", "Kevin"); await page.fill("#wachtwoord", "verzonnen-a"); await page.click("#inlogknop");
  await page.locator("#start").waitFor({ state: "visible" });
  // ---------- T7: items van een ander en zonder eigenaar houden het uitloggen niet tegen ----------
  const zetItem = (p, item) => p.evaluate((it) => new Promise((res) => {
    const rq = indexedDB.open("rozema-klanten", 1);
    rq.onsuccess = () => { const db = rq.result; const tx = db.transaction("wachtrij", "readwrite"); tx.objectStore("wachtrij").put(it); tx.oncomplete = () => { db.close(); res(true); }; };
  }), item);
  const wisItems = (p) => p.evaluate(() => new Promise((res) => {
    const rq = indexedDB.open("rozema-klanten", 1);
    rq.onsuccess = () => { const db = rq.result; const tx = db.transaction("wachtrij", "readwrite"); tx.objectStore("wachtrij").clear(); tx.oncomplete = () => { db.close(); res(true); }; };
  }));
  const proefItem = (id, wie, extra = {}) => ({ id, soort: "relatie-wijzig", methode: "PATCH", pad: "/relaties/r_k7a", body: { wijzigingId: id, velden: { plaats: { oud: null, nieuw: `Item-${id}` } } },
    recordKey: "r_k7a", relatieId: "r_k7a", velden: ["plaats"], wie, toegevoegd: Date.now() * 1000, afgekeurd: null, ...extra });
  const loginKevin = async () => {
    await page.fill("#naam", "Kevin"); await page.fill("#wachtwoord", "verzonnen-a"); await page.click("#inlogknop");
    await page.locator("#start").waitFor({ state: "visible" });
  };
  const plaatsVoor = (await relatieVan("r_k7a")).relatie.plaats;
  await wisItems(page);

  // T7a: alleen een item van Ruben: Kevin logt direct uit, het item blijft staan en wordt niet verstuurd
  await zetItem(page, proefItem("ruben-t7a", "Ruben"));
  await page.goto(`${BASIS}/dashboard/`);
  await page.locator("#uitloggen").waitFor({ state: "visible" });
  await page.click("#uitloggen");
  await page.locator("#inlog").waitFor({ state: "visible", timeout: 8000 });
  controle("T7: een item van Ruben houdt het uitloggen van Kevin niet tegen en blijft staan", (await acties(page)).length === 1 && (await acties(page))[0].wie === "Ruben" && (await page.locator("#uitlogwaarschuwing").isHidden()));
  await loginKevin();
  await page.waitForTimeout(500);
  controle("T7: Kevin verstuurt het item van Ruben niet", (await relatieVan("r_k7a")).relatie.plaats === plaatsVoor && (await acties(page)).length === 1);

  // T7b: eigen wachtende wijziging naast die van Ruben: de waarschuwing telt alleen de eigen; wissen laat die van Ruben staan
  await gaRelatie(page, "r_k7a");
  await page.route("**/api/dashboard/klanten/**", (r) => r.abort());
  await bewerk(page, "plaats", "Eigenwachtdorp");
  await wacht(async () => (await acties(page)).length === 2, 5000, "eigen naast Ruben");
  await page.goto(`${BASIS}/dashboard/`);
  await page.locator("#uitloggen").waitFor({ state: "visible" });
  await page.click("#uitloggen");
  await page.locator("#uitlogwaarschuwing").waitFor({ state: "visible" });
  const waarsch = await tekstOp(page, "#uitlogtekst");
  controle("T7: de waarschuwing telt alleen eigen wijzigingen en meldt die van een ander apart", waarsch.includes("nog 1 wijzigingen") && waarsch.includes("1 wijzigingen van een ander") && (await page.locator("#uitlogafgekeurd").isHidden()), waarsch);
  await page.click("#uitlogwissen");
  controle("T7: de wisbevestiging noemt het aantal eigen wijzigingen", (await tekstOp(page, "#uitlogwistekst")).includes("1 wijzigingen"));
  await page.click("#uitlogwisja");
  await page.locator("#inlog").waitFor({ state: "visible" });
  await page.unroute("**/api/dashboard/klanten/**");
  const overT7 = await acties(page);
  controle("T7: wissen haalt alleen de eigen items weg; die van Ruben blijft", overT7.length === 1 && overT7[0].wie === "Ruben");
  await loginKevin();

  // T7c: een eigen afgekeurde actie wordt apart getoond met een link; uitloggen blijft mogelijk
  await zetItem(page, proefItem("kevin-t7c", "Kevin", { afgekeurd: { status: 422, code: null, fouten: { plaats: "te-lang" }, termijnen: null, tekst: null } }));
  await page.goto(`${BASIS}/dashboard/`);
  await page.locator("#uitloggen").waitFor({ state: "visible" });
  await page.click("#uitloggen");
  await page.locator("#uitlogwaarschuwing").waitFor({ state: "visible" });
  controle("T7: afgekeurde eigen acties staan apart met een link naar Niet opgeslagen, zonder versturen of wissen",
    (await page.locator("#uitlogafgekeurd").isVisible()) && (await page.locator('#uitlogafgekeurd a').getAttribute("href")) === "/dashboard/klanten/niet-opgeslagen.html"
    && (await page.locator("#uitlogversturen").isHidden()) && (await page.locator("#uitlogdoor").isVisible()));
  await tikvlakken("uitlogwaarschuwing met afgekeurde actie");
  await page.click("#uitlogdoor");
  await page.locator("#inlog").waitFor({ state: "visible" });
  controle("T7: uitloggen met alleen afgekeurde acties lukt en laat ze staan", (await acties(page)).filter((x) => x.wie === "Kevin").length === 1);
  await loginKevin();
  await wisItems(page);

  // wie onbekend: niets in de wachtrij zetten en vragen om in te loggen; een item zonder eigenaar is "van een ander"
  await gaRelatie(page, "r_k7a");
  await page.evaluate(() => { window.Wachtrij.zetWie(null); sessionStorage.removeItem("dashboard.klanten.wie"); });
  await bewerk(page, "plaats", "Onbekenddorp");
  await wacht(async () => (await tekstOp(page, '#gegevens li[data-veld="plaats"] .editor')).includes(KT.wachtrij.eerstInloggen), 5000, "log eerst in");
  controle("wie onbekend: er wordt niets bewaard en er staat dat je eerst moet inloggen", (await acties(page)).length === 0);
  await page.locator('#gegevens li[data-veld="plaats"] .editor button', { hasText: KT.annuleren }).click();
  await page.evaluate(() => { window.Wachtrij.zetWie("Kevin"); sessionStorage.setItem("dashboard.klanten.wie", "Kevin"); });
  await zetItem(page, proefItem("zonder-wie", null));
  await online(page);
  await page.waitForTimeout(800);
  controle("een bestaand item zonder eigenaar wordt niet verstuurd en geldt als van een ander", (await relatieVan("r_k7a")).relatie.plaats === plaatsVoor && (await acties(page)).length === 1
    && await wacht(async () => (await tekstOp(page, "#wachtmelding")).includes("een ander"), 5000, "melding").then(() => true, () => false));
  await wisItems(page);

  // ---------- reviewscenario's T1 tot en met T6, twee tabbladen, en enkele extra's ----------
  const inloggenAls = async (p, naam, ww) => {
    await context.clearCookies();
    await p.goto(`${BASIS}/dashboard/`);
    await p.locator("#inlog").waitFor({ state: "visible" });
    await p.fill("#naam", naam); await p.fill("#wachtwoord", ww); await p.click("#inlogknop");
    await p.locator("#start").waitFor({ state: "visible" });
  };

  // T1: bewaren in IndexedDB mislukt (QuotaExceeded): de wijziging komt toch aan, en blijft zichtbaar bij geen verbinding
  await gaRelatie(page, "r_k7a");
  await page.evaluate(() => {
    const o = IDBObjectStore.prototype.put;
    IDBObjectStore.prototype.put = function (...a) { if (window.__quota && this.name === "wachtrij") throw new DOMException("vol", "QuotaExceededError"); return o.apply(this, a); };
    window.__quota = true;
  });
  await bewerk(page, "plaats", "Quotadorp");
  await wacht(async () => (await relatieVan("r_k7a")).relatie.plaats === "Quotadorp", 8000, "quota online");
  controle("T1: bewaren mislukt maar online: de wijziging komt toch op de server", (await idb(page, "wachtrij")).length === 0);
  await context.setOffline(true);
  await bewerk(page, "plaats", "Quotadorp2");
  await wacht(async () => (await page.evaluate(() => window.Wachtrij.geheugenAantal())) === 1, 5000, "item in geheugen");
  controle("T1: offline staat de actie in het geheugen, wordt geteld en er is een opvallende melding", (await page.evaluate(() => window.Wachtrij.blijvend())) === false
    && await wacht(async () => (await tekstOp(page, "#wachtmelding")).includes(KT.wachtrij.nietBewaard) && (await tekstOp(page, "#nav-wachtrij")) === "Niet opgeslagen (1)", 5000, "melding").then(() => true, () => false));
  await context.setOffline(false);
  await online(page);
  await wacht(async () => (await relatieVan("r_k7a")).relatie.plaats === "Quotadorp2", 10000, "geheugenitem verstuurd");
  controle("T1: het item uit het geheugen wordt alsnog verstuurd", await wacht(async () => (await page.evaluate(() => window.Wachtrij.geheugenAantal())) === 0, 5000, "geheugen leeg").then(() => true, () => false));
  await page.evaluate(() => { window.__quota = false; });

  // T2: offline twee keer heropenen/afvinken: knoppen uit, status optimistisch, en de server is idempotent
  await gaTraject(page, "r_k7b", "t_k7b");
  const bLi = page.locator('#termijnen li[data-regel="deal-bezwaar"]');
  controle("T2: uitgangssituatie: afgevinkt met een heropenknop", (await bLi.locator('button[data-actie="heropenen"]').count()) === 1);
  await context.setOffline(true);
  await bLi.locator('button[data-actie="heropenen"]').click();
  await wacht(async () => (await acties(page)).length === 1, 5000, "heropenen bewaard");
  await wacht(async () => (await bLi.locator("button:not([disabled])").count()) === 0 && (await bLi.innerText()).includes(KT.tr.wachtOpVerzending), 5000, "knoppen uit");
  controle("T2: na een wachtende actie staan de knoppen van die termijn uit en de status staat optimistisch op open (afvinken i.p.v. heropenen)",
    (await bLi.locator('button[data-actie="heropenen"]').count()) === 0 && (await bLi.locator('button[data-actie="afvinken"]').count()) === 2 && (await bLi.locator("button:not([disabled])").count()) === 0);
  controle("T2: een wachtende heropening toont \"wordt heropend\" en niet \"termijn onbekend\"", (await bLi.innerText()).includes(KT.tr.wordtHeropend) && !(await bLi.innerText()).includes(KT.fataal.termijnOnbekend));
  controle("T2: een tweede actie voor dezelfde termijn komt niet in de wachtrij", (await acties(page)).length === 1);
  await context.setOffline(false);
  await online(page);
  await wachtLeeg(page);
  controle("T2: de heropenactie is verstuurd", (await relatieVan("r_k7b")).trajecten[0].termijnen.find((t) => t.regelId === "deal-bezwaar").status === "open");
  const dubbelHe = await api("POST", `/trajecten/t_k7b/termijnen/deal-bezwaar/heropenen`, { wijzigingId: "dubbel-he-1" });
  controle("T2: server: heropenen van een al open termijn is een no-op (200), geen blokkade", dubbelHe.noop === true);
  await api("POST", `/trajecten/t_k7b/termijnen/deal-bezwaar/afvinken`, { wijzigingId: "dubbel-af-1", actie: "Bezwaar ingediend" });
  const dubbelAf = await api("POST", `/trajecten/t_k7b/termijnen/deal-bezwaar/afvinken`, { wijzigingId: "dubbel-af-2", actie: "Bezwaar ingediend" });
  controle("T2: server: nogmaals afvinken met dezelfde actie is een no-op", dubbelAf.noop === true);

  // T3: een op de achtergrond afgekeurde actie (409 bij een fasewissel) laat de cache niet verkeerd staan
  await maakRelatie("r_t3", { achternaam: "Achtergrondman", plaats: "Nepstad" });
  await maakTrajectInBesluit("r_t3", "t_t3", "2026-10-24");
  await gaTraject(page, "r_t3", "t_t3");
  await context.setOffline(true);
  await page.locator('#stappen li[data-fase="Afgerond"] button').click();
  await wacht(async () => (await acties(page)).length === 1, 5000, "fasewissel bewaard");
  await wacht(async () => (await tekstOp(page, "#trmelding")).includes("verstuurd"), 5000, "eerste poging klaar"); // pas online als de eerste (mislukte) poging klaar is
  await wacht(async () => (await tekstOp(page, '#stappen li[data-fase="Afgerond"]')).includes(KT.tr.huidig), 5000, "optimistisch Afgerond");
  controle("T3: offline toont het scherm de wachtende fasewissel eroverheen", true);
  await context.setOffline(false);
  await online(page);
  await wacht(async () => { if ((await acties(page)).some((x) => x.afgekeurd)) return true; await online(page); return false; }, 15000, "afgekeurd");
  await wacht(async () => (await tekstOp(page, '#stappen li[data-fase="Besluit"]')).includes(KT.tr.huidig), 5000, "terug naar Besluit");
  const kvT3 = (await idb(page, "kv")).find((v) => v && v.data && v.data.relatie && v.data.relatie.id === "r_t3");
  controle("T3: na de afkeuring toont het scherm weer Besluit en de cache bevat nooit Afgerond", kvT3 && kvT3.data.trajecten[0].record.fase === "Besluit");
  await page.goto(`${BASIS}/dashboard/klanten/niet-opgeslagen.html`);
  await page.locator("#wachtlijst > li").first().waitFor();
  controle("T3: de afgekeurde actie staat in Niet opgeslagen met de reden", (await tekstOp(page, "#wachtlijst")).includes("fatale termijn"));
  await page.locator('#wachtlijst button[data-knop="verwijder"]').first().click();
  await page.locator('#wachtlijst button[data-knop="verwijder"]').first().click();
  await wachtLeeg(page);

  // T4: twee tabbladen tegelijk versturen niet dezelfde actie twee keer (Web Lock)
  const page3 = await context.newPage();
  page3.on("pageerror", (e) => paginaFouten.push(e.message));
  await gaRelatie(page, "r_k7a");
  await gaRelatie(page3, "r_k7a");
  const tweeTabs = [];
  context.on("response", (res) => { const r = res.request(); if (r.method() === "PATCH" && r.url().includes("/relaties/r_k7a")) { try { tweeTabs.push(JSON.parse(r.postData()).wijzigingId); } catch { /* geen json */ } } });
  await context.setOffline(true);
  await bewerk(page, "plaats", "Tweetabdorp");
  await wacht(async () => (await acties(page)).length === 1, 5000, "item voor twee tabs");
  tweeTabs.length = 0;
  await page.route("**/api/dashboard/klanten/relaties/r_k7a", async (route) => {
    if (route.request().method() !== "PATCH") return route.continue();
    await new Promise((r) => setTimeout(r, 900)); // traag antwoord: het andere tabblad probeert intussen ook
    return route.continue();
  });
  await page3.route("**/api/dashboard/klanten/relaties/r_k7a", async (route) => {
    if (route.request().method() !== "PATCH") return route.continue();
    await new Promise((r) => setTimeout(r, 900));
    return route.continue();
  });
  await context.setOffline(false);
  await Promise.all([online(page), online(page3)]);
  await wachtLeeg(page);
  await page.waitForTimeout(800);
  controle("T4: twee tabbladen: de actie is precies één keer naar de server gegaan", tweeTabs.length === 1 && (await relatieVan("r_k7a")).relatie.plaats === "Tweetabdorp", JSON.stringify(tweeTabs.length));
  await page.unroute("**/api/dashboard/klanten/relaties/r_k7a");
  await page3.close();

  // T5: een andere gebruiker op hetzelfde toestel verstuurt de wachtrij van de eerste niet
  await gaRelatie(page, "r_k7a");
  await context.setOffline(true);
  await bewerk(page, "plaats", "Kevinwachtdorp");
  await wacht(async () => (await acties(page)).length === 1, 5000, "Kevins wijziging");
  await context.clearCookies(); // de sessie van Kevin verloopt
  await context.setOffline(false);
  await inloggenAls(page, "Ruben", "verzonnen-b");
  await gaRelatie(page, "r_k7a");
  await page.waitForTimeout(1200);
  controle("T5: Ruben verstuurt de wijziging van Kevin niet", (await relatieVan("r_k7a")).relatie.plaats === "Tweetabdorp" && (await acties(page)).length === 1);
  await page.waitForFunction(() => document.getElementById("wachtmelding") && /Kevin/.test(document.getElementById("wachtmelding").innerText));
  controle("T5: Ruben ziet dat de wijziging van Kevin is en wacht tot die inlogt", (await tekstOp(page, "#wachtmelding")).includes("van Kevin"));
  await page.goto(`${BASIS}/dashboard/klanten/niet-opgeslagen.html`);
  await page.locator("#wachtlijst > li").first().waitFor();
  controle("T5: Niet opgeslagen noemt van wie de wijziging is", (await tekstOp(page, "#wachtlijst")).includes("Van Kevin, wacht tot die inlogt"));
  await inloggenAls(page, "Kevin", "verzonnen-a");
  await gaRelatie(page, "r_k7a");
  await wachtLeeg(page);
  controle("T5: nadat Kevin inlogt wordt zijn wijziging verstuurd", (await relatieVan("r_k7a")).relatie.plaats === "Kevinwachtdorp");

  // T6: een conflict op een conflict: de eerste keuze loopt weer vast, daarna lukt het
  await gaRelatie(page, "r_k7a");
  await gaRelatie(page2, "r_k7a");
  await bewerk(page2, "plaats", "Rubena");
  await wacht(async () => (await relatieVan("r_k7a")).relatie.plaats === "Rubena", 8000, "Ruben a");
  await bewerk(page, "plaats", "Kevinmijn");
  await page.locator('#conflict .conflictrij[data-veld="plaats"]').waitFor();
  await bewerk(page2, "plaats", "Rubenb");
  await wacht(async () => (await relatieVan("r_k7a")).relatie.plaats === "Rubenb", 8000, "Ruben b");
  await page.locator('#conflict button[data-keuze="mijn"]').click();
  await wacht(async () => (await tekstOp(page, "#relmelding")).includes(KT.conflict.opnieuw), 8000, "tweede conflict");
  const tussen = await tekstOp(page, "#conflict");
  controle("T6: conflict op een conflict: geen 'gelukt', de server is ongewijzigd en de nieuwe waarde van de ander staat er", !(await tekstOp(page, "#relmelding")).includes(KT.conflict.gelukt) && (await relatieVan("r_k7a")).relatie.plaats === "Rubenb" && tussen.includes("Rubenb"), tussen);
  await page.locator('#conflict button[data-keuze="mijn"]').click();
  await wacht(async () => (await relatieVan("r_k7a")).relatie.plaats === "Kevinmijn", 8000, "mijn waarde lukt");
  controle("T6: de tweede keuze lukt en het conflict is weg", await wacht(async () => (await page.locator("#conflict").isHidden()) && (await conflictItems(page)).length === 0, 8000, "conflict weg").then(() => true, () => false));

  // een verloren antwoord: de server paste de wijziging toe maar het antwoord kwam niet aan
  await gaRelatie(page, "r_k7a");
  let verloren = 0;
  await page.route("**/api/dashboard/klanten/relaties/r_k7a", async (route) => {
    if (route.request().method() !== "PATCH") return route.continue();
    verloren++;
    if (verloren === 1) { await route.fetch(); return route.abort(); }
    return route.continue();
  });
  await bewerk(page, "plaats", "Verlorendorp");
  await wacht(async () => (await relatieVan("r_k7a")).relatie.plaats === "Verlorendorp", 8000, "toegepast");
  controle("verloren antwoord: de actie blijft in de wachtrij", (await acties(page)).length === 1);
  await online(page);
  await wachtLeeg(page);
  await page.unroute("**/api/dashboard/klanten/relaties/r_k7a");
  const tl = (await api("GET", "/relaties/r_k7a/tijdlijn")).regels.filter((x) => x.veld === "plaats" && x.nieuw === "Verlorendorp");
  controle("verloren antwoord: opnieuw versturen met dezelfde wijzigingId geeft één logregel en een lege wachtrij", tl.length === 1 && verloren === 2, `${tl.length} ${verloren}`);

  // XSS in telefoon, mobiel, straat en plaats: de hrefs bevatten alleen cijfers of gecodeerde tekst
  await page.route("**/api/dashboard/klanten/relaties/r_k7a", async (route) => {
    if (route.request().method() !== "GET") return route.continue();
    const echt = await (await route.fetch()).json();
    echt.relatie = { ...echt.relatie, telefoon: "javascript:alert(1)", mobiel: "+31 6 12345678\";javascript:window.__pwn=1", straat: "\"><img src=x onerror=window.__pwn=2>", plaats: "<b>x</b>", huisnummer: "1" };
    await route.fulfill({ contentType: "application/json", body: JSON.stringify(echt) });
  });
  await gaRelatie(page, "r_k7a");
  const xss = await page.evaluate(() => ({ hrefs: Array.from(document.querySelectorAll("#contact a")).map((a) => a.getAttribute("href")), pwn: window.__pwn, img: document.querySelectorAll("main img, main b").length }));
  controle("XSS: tel:, wa.me en maps-link bevatten alleen cijfers of gecodeerde tekst, er wordt niets uitgevoerd",
    xss.pwn === undefined && xss.img === 0 && xss.hrefs.every((h) => /^tel:\+?\d+$/.test(h) || /^https:\/\/wa\.me\/\d+$/.test(h) || /^https:\/\/www\.google\.com\/maps\/search\/\?api=1&query=[A-Za-z0-9%._~-]+$/.test(h)), JSON.stringify(xss));
  await page.unroute("**/api/dashboard/klanten/relaties/r_k7a");
  await page.route("**/api/dashboard/klanten/relaties/r_k7a", async (route) => {
    if (route.request().method() !== "GET") return route.continue();
    const echt = await (await route.fetch()).json();
    echt.relatie = { ...echt.relatie, telefoon: "012345", mobiel: "06 1234" };
    await route.fulfill({ contentType: "application/json", body: JSON.stringify(echt) });
  });
  await gaRelatie(page, "r_k7a");
  controle("een nummer van minder dan 9 cijfers geeft geen bel- of WhatsApp-knop", (await page.locator('#contact a[data-actie="bel"], #contact a[data-actie="whatsapp"]').count()) === 0);
  await page.unroute("**/api/dashboard/klanten/relaties/r_k7a");

  // typen in een editor en dan weggestuurd worden (bijvoorbeeld door een 401): de browser waarschuwt
  await gaRelatie(page, "r_k7a");
  await page.locator('#gegevens li[data-veld="notitie"] button').first().click();
  await page.locator('#gegevens li[data-veld="notitie"] .editor textarea').pressSequentially("nog niet opgeslagen", { delay: 5 });
  let dialoogSoort = null;
  page.once("dialog", async (d) => { dialoogSoort = d.type(); await d.dismiss(); });
  await page.evaluate(() => { window.Dashboard.naarInlog(); });
  await page.waitForTimeout(800);
  controle("een open editor met tekst: weggaan geeft een waarschuwing (beforeunload) en je blijft staan", dialoogSoort === "beforeunload" && page.url().includes("relatie.html"), String(dialoogSoort));
  await page.locator('#gegevens li[data-veld="notitie"] .editor button', { hasText: KT.annuleren }).click();

  // de cache van klantgegevens is hoogstens 7 dagen oud
  const oud = await page.evaluate(async () => {
    await window.Wachtrij.kv.set("proef:oud", { op: new Date(Date.now() - 8 * 86400000).toISOString(), x: 1 });
    await window.Wachtrij.kv.set("proef:vers", { op: new Date().toISOString(), x: 2 });
    return [await window.Wachtrij.kv.get("proef:oud"), await window.Wachtrij.kv.get("proef:vers")];
  });
  controle("cache ouder dan 7 dagen wordt niet meer gebruikt", oud[0] === null && oud[1] && oud[1].x === 2);

  await context2.close();
  negeerFouten = false;

  // K11 beheer: pagina laadt, exportlinks werken, verwijderen lukt en de relatie geeft daarna 410 op een tweede tab (cache gewist)
  await maakRelatie("r_e5", { achternaam: "Wegwerp", straat: "Nepplein", huisnummer: "9", plaats: "Teststad", postcode: "9995 ZZ", eigenaar: "kevin" });
  await page.goto(`${BASIS}/dashboard/klanten/beheer.html`);
  await page.locator("#agenda-maak").waitFor({ state: "visible" });
  controle("beheer.html laadt met drie exportknoppen en zonder verwijderformulier", (await page.locator('a[href*="/klantenbeheer/export"]').count()) === 3 && (await page.locator("#verwijder-sectie").isHidden()));
  const uitvoer = await page.evaluate(async () => {
    const r = await fetch("/api/dashboard/klantenbeheer/export?formaat=json&soort=alles", { credentials: "same-origin" });
    const j = await r.json().catch(() => null);
    return { status: r.status, relaties: j && Array.isArray(j.relaties) ? j.relaties.length : -1, nosniff: r.headers.get("x-content-type-options") };
  });
  controle("exportknop (JSON) geeft alle relaties, met nosniff", uitvoer.status === 200 && uitvoer.relaties >= KLANTEN_AANTAL + 1 && uitvoer.nosniff === "nosniff", JSON.stringify(uitvoer));
  const tab2 = await context.newPage();
  const statussen = [];
  tab2.on("response", (r) => { if (/\/api\/dashboard\/klanten\/relaties\/r_e5$/.test(r.url())) statussen.push(r.status()); });
  await tab2.goto(`${BASIS}/dashboard/klanten/relatie.html?id=r_e5`);
  await tab2.waitForFunction(() => document.getElementById("naam") && document.getElementById("naam").textContent.includes("Wegwerp"));
  const cacheVoor = await tab2.evaluate(async () => [await window.Wachtrij.kv.get("relatie:r_e5"), await window.Wachtrij.kv.get("tijdlijn:r_e5")].map((x) => !!x));
  controle("tweede tab: relatie geladen en in de cache gezet", cacheVoor[0] === true && cacheVoor[1] === true, JSON.stringify(cacheVoor));
  await page.goto(`${BASIS}/dashboard/klanten/beheer.html?id=r_e5`);
  await page.locator("#verwijder-sectie").waitFor({ state: "visible" });
  await page.fill("#verwijder-bevestig", "wegwerp");
  await page.click("#verwijder-knop");
  await page.locator("#verwijder-form").waitFor({ state: "hidden", timeout: 15000 });
  controle("verwijderverzoek geslaagd (formulier weg, doorverwijzing naar de lijst)", (await page.locator('a.knop:not(.rand)[href="/dashboard/klanten/lijst.html"]').count()) === 1);
  const cacheNa = await page.evaluate(async () => [await window.Wachtrij.kv.get("relatie:r_e5"), await window.Wachtrij.kv.get("tijdlijn:r_e5")]);
  controle("beheer wist de cache van de relatie op dit toestel", cacheNa[0] === null && cacheNa[1] === null);
  // Een verouderde cache op de tweede tab mag na een 410 niet meer worden getoond.
  await tab2.evaluate(async () => {
    await window.Wachtrij.kv.set("relatie:r_e5", { op: new Date().toISOString(), data: { relatie: { id: "r_e5", achternaam: "Wegwerp", taken: {} }, trajecten: [], termijnen: [], onvolledig: [], onleesbaar: [] } });
  });
  statussen.length = 0;
  await tab2.reload();
  await tab2.waitForFunction(() => document.getElementById("relmelding") && document.getElementById("relmelding").textContent.trim() !== "");
  const naamNa = await tab2.evaluate(() => document.getElementById("naam").textContent);
  const cacheEind = await tab2.evaluate(async () => [await window.Wachtrij.kv.get("relatie:r_e5"), await window.Wachtrij.kv.get("tijdlijn:r_e5")]);
  controle("tweede tab: de server geeft 410 voor de verwijderde relatie", statussen.includes(410), JSON.stringify(statussen));
  controle("tweede tab: geen terugval op de cache en de cache is gewist", !naamNa.includes("Wegwerp") && cacheEind[0] === null && cacheEind[1] === null, naamNa);
  await tab2.close();

  // Deur-items in de uitlogtelling: eigen items tellen mee, "Wissen" wist alleen de eigen, en verstuur.js is vanaf het startscherm te laden
  await page.goto(`${BASIS}/dashboard/`);
  const deurTel = await page.evaluate(async () => {
    const o = await import("/dashboard/deur/opslag.js");
    const v = await import("/dashboard/deur/verstuur.js");
    await o.wachtrij.zet({ id: "proef-eigen", plaats: "p", ev: { id: "proef-eigen" }, toegevoegd: 1, wie: "Kevin" });
    await o.wachtrij.zet({ id: "proef-ander", plaats: "p", ev: { id: "proef-ander" }, toegevoegd: 2, wie: "Ruben" });
    const voor = await window.Dashboard.wachtrijTelling("Kevin");
    await window.Dashboard.wisDeurEigen("Kevin");
    const na = await window.Dashboard.wachtrijTelling("Kevin");
    await o.wachtrij.verwijder("proef-ander");
    return { voor, na, laadt: typeof v.verstuurWachtrij };
  });
  controle("uitlogtelling telt eigen deur-items mee; wissen laat die van een ander staan", deurTel.voor.eigen >= 1 && deurTel.voor.anderen >= 1 && deurTel.na.eigen === 0 && deurTel.na.anderen >= 1 && deurTel.laadt === "function", JSON.stringify(deurTel));

  // 11. breed scherm, voor de zekerheid
  await page.setViewportSize({ width: 1280, height: 900 });
  await page.goto(`${BASIS}/dashboard/klanten/`); // Taken
  await page.waitForFunction(() => document.querySelector("#groepen .takengroep, #taken-leeg:not([hidden])"));
  await tikvlakken("startscherm op 1280 px");
  await lettergrootte("startscherm op 1280 px");
  await page.setViewportSize({ width: 360, height: 740 });

  // 12. CSP: geen fouten in de console, en de CSP werkt in dit testservertje echt
  controle("geen fouten of waarschuwingen in de console (CSP, 404, scripts)", consoleFouten.length === 0, consoleFouten.slice(0, 3).join(" | "));
  const schending = await page.evaluate(() => new Promise((klaar) => {
    document.addEventListener("securitypolicyviolation", () => klaar(true), { once: true });
    const s = document.createElement("script");
    s.textContent = "window.__x = 1";
    document.head.appendChild(s);
    setTimeout(() => klaar(false), 800);
  }));
  controle("controle van de controle: een inline script wordt door de CSP geblokkeerd", schending === true);

  // 13. uitloggen wist de cache
  await page.goto(`${BASIS}/dashboard/klanten/`);
  await page.waitForFunction(() => document.querySelector("#groepen .takengroep, #taken-leeg:not([hidden])"));
  const voorUit = await page.evaluate(() => Object.keys(sessionStorage).filter((k) => k.startsWith("dashboard.")).length);
  await page.goto(`${BASIS}/dashboard/`);
  await page.locator("#uitloggen").waitFor({ state: "visible" });
  negeerFouten = true;
  await page.click("#uitloggen");
  await page.locator("#inlog").waitFor({ state: "visible" });
  const naUit = await page.evaluate(() => Object.keys(sessionStorage).filter((k) => k.startsWith("dashboard.")).length);
  controle("uitloggen wist de cache in sessionStorage", voorUit >= 1 && naUit === 0, `${voorUit} -> ${naUit}`);
  controle("geen niet-afgevangen fouten in het hele rondje", paginaFouten.length === 0, paginaFouten.slice(0, 3).join("; "));
} catch (e) {
  gefaald = e;
  console.log(`FOUT onverwachte fout in het rondje: ${e.message.split("\n").slice(0, 4).join(" | ")}`);
  resultaten.push({ naam: "onverwacht", ok: false });
}

await browser.close();
server.close();
const fouten = resultaten.filter((r) => !r.ok).length;
console.log(`\n${resultaten.length - fouten} van ${resultaten.length} controles in orde${fouten ? `, ${fouten} fout` : ""}.`);
process.exit(fouten || gefaald ? 1 : 0);

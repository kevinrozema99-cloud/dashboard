// Gebruik: node scripts/dashboard-wachtwoord.mjs
// Vraagt het wachtwoord (minstens 12 tekens) met verborgen invoer, twee keer.
// Of via een pipe: printf '%s' "<wachtwoord>" | node scripts/dashboard-wachtwoord.mjs
// Geeft de hash die in DASHBOARD_GEBRUIKERS komt, bijvoorbeeld:
//   {"Kevin":"<hash>","Ruben":"<hash>"}
// Het wachtwoord staat nooit in de argumenten en dus niet in de shellgeschiedenis.
import { maakWachtwoordHash } from "../netlify/functions/dashboard-lib/sessie.mjs";

function leesVerborgen(vraag) {
  return new Promise((klaar, mis) => {
    const inv = process.stdin;
    process.stderr.write(vraag);
    let tekst = "";
    inv.setRawMode(true);
    inv.resume();
    inv.setEncoding("utf8");
    const stop = () => { inv.setRawMode(false); inv.pause(); inv.removeListener("data", op); process.stderr.write("\n"); };
    const op = (chunk) => {
      for (const c of chunk) {
        if (c === "\r" || c === "\n") { stop(); return klaar(tekst); }
        if (c === "\u0003") { stop(); return mis(new Error("Afgebroken.")); }
        if (c === "\u007f" || c === "\b") tekst = tekst.slice(0, -1);
        else if (c >= " ") tekst += c;
      }
    };
    inv.on("data", op);
  });
}

async function leesPipe() {
  let t = "";
  for await (const chunk of process.stdin) t += chunk;
  return t.replace(/\r?\n$/, "");
}

try {
  let wachtwoord;
  if (process.stdin.isTTY) {
    wachtwoord = await leesVerborgen("Wachtwoord: ");
    const nog = await leesVerborgen("Nog een keer: ");
    if (wachtwoord !== nog) throw new Error("De twee wachtwoorden zijn niet gelijk.");
  } else {
    wachtwoord = await leesPipe();
  }
  if (wachtwoord.length < 12) throw new Error("Gebruik minstens 12 tekens.");
  console.log(await maakWachtwoordHash(wachtwoord, 210000));
} catch (e) {
  console.error(e.message);
  process.exit(1);
}

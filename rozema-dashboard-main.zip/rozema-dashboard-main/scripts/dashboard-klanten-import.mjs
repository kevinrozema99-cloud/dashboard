// Klantenmodule K8: import van Zoho-contacten en -deals via de gewone HTTP-API van de klantenmodule.
//
// Gebruik (proefrun is de standaard; pas met --uitvoeren wordt er geschreven):
//   DASHBOARD_COOKIE='dashboard_sessie=...' node scripts/dashboard-klanten-import.mjs <bestand.json> --basis https://<site> [--eigenaar kevin|ruben] [--uitvoeren]
//
// Het bestand staat buiten de repo en heeft de vorm {contacts:[...], deals:[...]}, met de Zoho-veldnamen.
// De sessie-cookie komt uit de omgevingsvariabele DASHBOARD_COOKIE (niet als argument, dat belandt in de shellgeschiedenis).
//
// Idempotent: de ids zijn afgeleid van het Zoho-id (r_zoho_<id>, t_zoho_<id>) en elke wijziging krijgt een vaste
// wijzigingId. Bij --uitvoeren gaat altijd dezelfde POST de API in; de server herkent de herhaling ("bestaatAl") en
// maakt zo nodig het nawerk af. Het Zoho-id staat ook in `herkomst.zoho.id`.
//
// Bijlagen (Machtigingsformulier, Overeenkomst_Intermediair, `bijlagen`) worden NIET geimporteerd.
// De uitvoer noemt alleen aantallen, Zoho-id's, veldnamen en foutcodes. Nooit namen, adressen of andere inhoud.
import fs from "node:fs";
import { fileURLToPath } from "node:url";
import { valideerRelatie, valideerTraject, BRONNEN, AANHEFFEN, FASES, FASES_VANAF_BESLUIT, EIGENAREN } from "../netlify/functions/dashboard-lib/klanten/model.mjs";

export const HERKOMST_BRON = "zoho-import";
const ZOHO_ID = /^[A-Za-z0-9]{1,40}$/;
const MAX_NOTITIE = 5000;
// Een traject kan niet gesloten beginnen en vanaf Besluit is een verzenddatum nodig: die fases komen niet mee.
const IMPORTEERBARE_FASES = FASES.filter((f) => f !== "Afgerond" && f !== "Verloren" && !FASES_VANAF_BESLUIT.includes(f));
// Zoho-fase -> onze fase. Alleen wat hier of in FASES (exact) staat, wordt overgenomen.
export const FASE_MAPPING = { "Aanvraag ingediend": "Aanvraag ingediend" };
const BIJLAGE_VELDEN = ["Machtigingsformulier", "Overeenkomst_Intermediair"];

const tekst = (v) => (typeof v === "string" ? v.trim() : typeof v === "number" ? String(v) : "");
const lege = (v) => tekst(v) === "" || tekst(v) === "-None-";
export const relatieId = (zohoId) => `r_zoho_${zohoId}`;
export const trajectId = (zohoId) => `t_zoho_${zohoId}`;
// Zoho-lookups komen als {id, name}; een kale id mag ook.
export const lookupId = (v) => String((v && typeof v === "object" ? v.id : v) ?? "");
const normPostcode = (p) => tekst(p).replace(/\s+/g, "").toUpperCase();
const lookupNaam = (v) => (v && typeof v === "object" ? tekst(v.name) : tekst(v));

// "Verzinselstraat 12a" -> straat, huisnummer, toevoeging. Bij reeksen ("12-14"), meer cijfergroepen of een
// toevoeging van meer dan 3 letters wordt niet gesplitst: alles in straat, `ongesplitst: true`.
export function splitsStraat(s) {
  const t = tekst(s);
  const geen = { straat: t, ongesplitst: true };
  if ((t.match(/\d+/g) || []).length !== 1) return /\d/.test(t) ? geen : { straat: t };
  const m = /^(.*?)\s+(\d{1,6})(?:\s*[-\s]?\s*([A-Za-z]{1,3}))?$/.exec(t);
  return m && m[1] ? { straat: m[1], huisnummer: m[2], ...(m[3] ? { toevoeging: m[3] } : {}) } : geen;
}

export function mapBron(zohoBron) {
  const t = tekst(zohoBron);
  if (!t || t === "-None-") return {};
  const gevonden = BRONNEN.find((b) => b.toLowerCase() === t.toLowerCase());
  return gevonden ? { bron: gevonden } : { bron: "Anders", extra: `Zoho-bron: ${t}` };
}

export function mapEigenaar(owner) {
  const n = lookupNaam(owner).toLowerCase();
  return EIGENAREN.find((e) => n.includes(e));
}

// Zoho-contact -> relatievelden. Geeft {velden, herkomst, notities}.
export function mapContact(c, dealsNotities = [], opties = {}) {
  const notities = [];
  const velden = { status: "Klant" };
  const zet = (k, v) => { if (!lege(v)) velden[k] = tekst(v); };
  zet("voornaam", c.First_Name);
  zet("achternaam", c.Last_Name);
  zet("email", c.Email);
  zet("telefoon", c.Phone);
  zet("mobiel", c.Mobile);
  zet("aanhef", c.Salutation);
  if (!lege(c.Mailing_Street)) {
    const { ongesplitst, ...adres } = splitsStraat(c.Mailing_Street);
    Object.assign(velden, adres);
    if (ongesplitst) notities.push(`Zoho-adres: ${tekst(c.Mailing_Street)}`);
  }
  if (!lege(c.Mailing_Flat_House_No_Building_Apartment_Name)) {
    const extra = tekst(c.Mailing_Flat_House_No_Building_Apartment_Name);
    if (!velden.toevoeging && velden.huisnummer && /^[A-Za-z0-9][A-Za-z0-9 \-]{0,9}$/.test(extra)) velden.toevoeging = extra;
    else notities.push(`Zoho-adresaanvulling: ${extra}`);
  }
  zet("postcode", c.Mailing_Zip);
  zet("plaats", c.Mailing_City);
  const b = mapBron(c.Lead_Source);
  if (b.bron) velden.bron = b.bron;
  if (b.extra) notities.push(b.extra);
  const eigenaar = opties.eigenaar || mapEigenaar(c.Owner);
  if (eigenaar) velden.eigenaar = eigenaar;
  if (c.Email_Opt_Out === true) notities.push("Zoho: e-mail niet gewenst (Email_Opt_Out)");
  if (!lege(c.Description)) notities.push(`Zoho-opmerking contact: ${tekst(c.Description)}`);
  if (!lege(c.Created_Time)) notities.push(`Zoho-contact aangemaakt: ${tekst(c.Created_Time)}`);
  notities.push(...dealsNotities);
  return { velden, herkomst: { zoho: { module: "Contacts", id: String(c.id), via: HERKOMST_BRON } }, notities };
}

// Geeft {fase} of {overgeslagen: reden}.
export function mapFase(stage) {
  const t = tekst(stage);
  const fase = FASE_MAPPING[t] ?? (FASES.includes(t) ? t : null);
  if (!fase) return { overgeslagen: "fase-onbekend" };
  if (!IMPORTEERBARE_FASES.includes(fase)) return { overgeslagen: "fase-niet-importeerbaar" };
  return { fase };
}

const DEAL_DATUMEN = { Aanvraagdatum: "aanvraagdatum", Opnamedatum: "opnamedatum", Datum_schaderapport: "datumSchaderapport", Datum_adviesrapport: "datumAdviesrapport", Verzenddatum_besluitbrief: "verzenddatumBesluitbrief", Factuur_voldaan_op: "factuurVoldaanOp" };
const num = (v) => (typeof v === "number" ? v : typeof v === "string" && v.trim() !== "" && Number.isFinite(Number(v)) ? Number(v) : undefined);

// Zoho-deal -> trajectvelden. Wat niet door de controle komt, gaat als regel in `notities` (voor de relatienotitie).
// Geeft {velden, notities, weggelaten:[veldnaam]}.
export function mapDeal(d, fase, rid, contactBron) {
  const velden = { fase };
  const notities = [];
  for (const [zoho, eigen] of Object.entries(DEAL_DATUMEN)) if (!lege(d[zoho])) velden[eigen] = tekst(d[zoho]);
  if (!lege(d.Route)) velden.route = tekst(d.Route);
  const bedrag = num(d.Amount); if (bedrag !== undefined && bedrag !== 0) velden.uitkeringImg = bedrag;
  const fee = num(d.Fee); if (fee !== undefined && fee !== 0) velden.fee = fee;
  const weggelaten = [];
  for (let ronde = 0; ronde < 3; ronde++) {
    const r = valideerTraject({ ...velden, relatieId: rid });
    if (r.ok) break;
    for (const veld of Object.keys(r.fouten)) {
      if (veld === "fase" || !(veld in velden)) continue;
      notities.push(`Zoho-deal ${d.id}, niet overgenomen (${veld}): ${velden[veld]}`);
      weggelaten.push(veld);
      delete velden[veld];
    }
  }
  if (!lege(d.Description)) notities.push(`Zoho-deal ${d.id}: ${tekst(d.Description)}`);
  const bron = mapBron(d.Lead_Source);
  if (bron.bron && contactBron && bron.bron !== contactBron) notities.push(`Zoho-deal ${d.id}, bron: ${tekst(d.Lead_Source)}`);
  return { velden, notities, weggelaten };
}

// Valideert lokaal met dezelfde regels als de API. Velden die niet door de controle komen, gaan uit de aanmaak en
// hun oorspronkelijke waarde in de notitie, zodat er niets verloren gaat. Geeft {velden, weggelaten:[veldnaam]}.
export function schoonRelatie(velden, notities) {
  const uit = { ...velden };
  const weggelaten = [];
  for (let ronde = 0; ronde < 3; ronde++) {
    const r = valideerRelatie(uit);
    if (r.ok) break;
    for (const veld of Object.keys(r.fouten)) {
      if (veld === "achternaam" || veld === "status" || !(veld in uit)) continue;
      notities.push(`Zoho-import, niet overgenomen (${veld}): ${uit[veld]}`);
      weggelaten.push(veld);
      delete uit[veld];
    }
  }
  let afgekapt = false;
  if (notities.length) {
    const alles = notities.join("\n");
    afgekapt = alles.length > MAX_NOTITIE;
    uit.notitie = alles.slice(0, MAX_NOTITIE);
  }
  return { velden: uit, weggelaten, afgekapt };
}

// ---------- API ----------
function maakApi({ basis, cookie, fetchFn, wacht }) {
  const url = (pad) => `${basis.replace(/\/+$/, "")}/api/dashboard/klanten${pad}`;
  async function aanroep(methode, pad, body) {
    let laatste = { status: 0, data: null };
    for (let poging = 0; poging < 4; poging++) {
      let res;
      try {
        res = await fetchFn(url(pad), {
          method: methode,
          redirect: "error",
          headers: { cookie, ...(body !== undefined ? { "content-type": "application/json" } : {}) },
          body: body !== undefined ? JSON.stringify(body) : undefined,
        });
      } catch {
        laatste = { status: 0, data: null };
        await wacht(500 * (poging + 1));
        continue;
      }
      let data = null;
      try { data = await res.json(); } catch { /* geen json */ }
      laatste = { status: res.status, data };
      if (res.status === 503 || res.status === 429) { await wacht(500 * (poging + 1)); continue; }
      return laatste;
    }
    return laatste;
  }
  return { aanroep };
}

const foutcode = (r) => {
  if (!r || r.status === 0) return "netwerk";
  const f = r.data?.fouten;
  if (f && typeof f === "object") return `${r.status}:${Object.entries(f).map(([k, v]) => `${k}=${v}`).join(",")}`;
  return String(r.status);
};

// Beoordeelt het antwoord op een aanmaak-POST. Geeft "nieuw", "bestaatAl" of een foutcode.
function beoordeelPost(r, id) {
  if (r.status === 201) return { uitkomst: "nieuw" };
  if (r.status === 409) return { fout: "id-bezet" };
  if (r.status === 200 && r.data?.bestaatAl === true && r.data?.record?.id === id) return { uitkomst: "bestaatAl" };
  if (r.status === 200) return { fout: "onverwacht-antwoord" };
  return { fout: foutcode(r) };
}

// ---------- hoofdfunctie ----------
// invoer: {contacts, deals}. opties: {basis, cookie, uitvoeren, fetchFn, eigenaar, log, wacht}
// Geeft het verslag: aantallen en lijsten met Zoho-id's.
export async function draaiImport(invoer, opties) {
  const { basis, cookie, uitvoeren = false, toch = false, fetchFn = fetch, eigenaar, log = () => {}, wacht = (ms) => new Promise((r) => setTimeout(r, ms)) } = opties;
  const api = maakApi({ basis, cookie, fetchFn, wacht });
  const contacten = Array.isArray(invoer?.contacts) ? invoer.contacts : [];
  const deals = Array.isArray(invoer?.deals) ? invoer.deals : [];
  const v = {
    uitvoeren, contacten: contacten.length, deals: deals.length,
    relaties: { nieuw: [], bestaatAl: [], fout: [] }, trajecten: { nieuw: [], bestaatAl: [], fout: [] },
    overgeslagen: [], veldenWeggelaten: [], bijlagenGenegeerd: [], waarschuwingen: [], afgebroken: [],
  };

  // Ids controleren en dubbelen eruit. Bij een ongeldig id alleen het rijnummer noemen.
  const gezien = new Set();
  const geldig = [];
  contacten.forEach((c, i) => {
    const id = String(c?.id ?? "");
    if (!ZOHO_ID.test(id)) { v.overgeslagen.push({ module: "Contacts", id: `rij ${i + 1}`, reden: "id-ongeldig" }); return; }
    if (gezien.has(id)) { v.overgeslagen.push({ module: "Contacts", id, reden: "dubbel-in-bestand" }); return; }
    gezien.add(id);
    geldig.push(c);
  });

  // Is er al een andere (handmatige) relatie? Alleen lezen: lijst, dan elke relatie die niet van de import is.
  const handmatig = new Set();
  const anderen = []; // {postcode, huisnummer, email} van bestaande, niet-geimporteerde relaties
  const leesProbleem = [];
  const lijst = await api.aanroep("GET", "/relaties");
  if (lijst.status !== 200) leesProbleem.push(`lijst-niet-te-lezen:${foutcode(lijst)}`);
  else {
    if (lijst.data?.afgekapt) leesProbleem.push("lijst-afgekapt");
    for (const rij of lijst.data?.relaties ?? []) {
      if (typeof rij?.id !== "string" || rij.id.startsWith("r_zoho_")) continue;
      const g = await api.aanroep("GET", `/relaties/${rij.id}`);
      if (g.status !== 200) { leesProbleem.push(`relatie-niet-te-lezen:${foutcode(g)}`); continue; }
      const rel = g.data?.relatie ?? {};
      anderen.push({ postcode: normPostcode(rel.postcode), huisnummer: tekst(rel.huisnummer), email: tekst(rel.email).toLowerCase() });
      const zid = rel.herkomst?.zoho?.id;
      if (typeof zid === "string" && gezien.has(zid)) handmatig.add(zid);
    }
  }
  if (uitvoeren) {
    if (leesProbleem.length) v.afgebroken.push(...leesProbleem);
    else if (anderen.length && !toch) v.afgebroken.push(`andere-relaties-aanwezig:${anderen.length} (gebruik --toch om door te gaan)`);
  } else v.waarschuwingen.push(...leesProbleem);
  if (v.afgebroken.length) return v; // niets uitgevoerd
  // Lokale vergelijking op postcode + huisnummer of e-mail; alleen het Zoho-id wordt gemeld.
  const mogelijk = new Set();
  for (const c of geldig) {
    const zid = String(c.id);
    if (handmatig.has(zid)) continue;
    const pc = normPostcode(c.Mailing_Zip);
    const hn = tekst(splitsStraat(c.Mailing_Street).huisnummer);
    const em = tekst(c.Email).toLowerCase();
    if (anderen.some((a) => (em && a.email === em) || (pc && hn && a.postcode === pc && a.huisnummer === hn))) mogelijk.add(zid);
  }
  for (const zid of handmatig) v.overgeslagen.push({ module: "Contacts", id: zid, reden: "al-handmatig" });
  for (const zid of mogelijk) v.overgeslagen.push({ module: "Contacts", id: zid, reden: "mogelijk-handmatig" });
  for (const zid of mogelijk) handmatig.add(zid);

  const mogelijkSet = mogelijk;
  // Deals koppelen aan hun contact en omzetten.
  const dealIds = new Set();
  const dealLijst = [];
  const notitiesPerContact = new Map();
  deals.forEach((d, i) => {
    const id = String(d?.id ?? "");
    if (!ZOHO_ID.test(id)) { v.overgeslagen.push({ module: "Deals", id: `rij ${i + 1}`, reden: "id-ongeldig" }); return; }
    if (dealIds.has(id)) { v.overgeslagen.push({ module: "Deals", id, reden: "dubbel-in-bestand" }); return; }
    dealIds.add(id);
    if (BIJLAGE_VELDEN.some((k) => (Array.isArray(d[k]) ? d[k].length > 0 : !!d[k])) || (Array.isArray(d.bijlagen) && d.bijlagen.length)) v.bijlagenGenegeerd.push(id);
    const cid = lookupId(d.Contact_Name) || lookupId(d.Contact_id);
    if (!gezien.has(cid)) { v.overgeslagen.push({ module: "Deals", id, reden: "contact-onbekend" }); return; }
    if (handmatig.has(cid)) { v.overgeslagen.push({ module: "Deals", id, reden: mogelijkSet.has(cid) ? "mogelijk-handmatig" : "al-handmatig" }); return; }
    const f = mapFase(d.Stage);
    if (f.overgeslagen) { v.overgeslagen.push({ module: "Deals", id, reden: f.overgeslagen, stage: tekst(d.Stage).slice(0, 60) }); return; }
    const contact = geldig.find((c) => String(c.id) === cid);
    const m = mapDeal(d, f.fase, relatieId(cid), mapBron(contact?.Lead_Source).bron);
    if (m.weggelaten.length) v.veldenWeggelaten.push({ id, velden: m.weggelaten });
    dealLijst.push({ id, cid, velden: m.velden });
    if (!notitiesPerContact.has(cid)) notitiesPerContact.set(cid, []);
    notitiesPerContact.get(cid).push(...m.notities);
  });

  const bestaandeRelaties = new Set();
  for (const c of geldig) {
    const zid = String(c.id);
    if (handmatig.has(zid)) continue;
    const rid = relatieId(zid);
    const { velden: ruw, herkomst, notities } = mapContact(c, notitiesPerContact.get(zid) || [], { eigenaar });
    const { velden, weggelaten, afgekapt } = schoonRelatie(ruw, notities);
    if (afgekapt) v.waarschuwingen.push(`notitie-afgekapt:${zid}`);
    const dealNotities = (notitiesPerContact.get(zid) || []).length > 0;
    if (weggelaten.length) v.veldenWeggelaten.push({ id: zid, velden: weggelaten });
    const check = valideerRelatie(velden);
    if (!check.ok) { v.relaties.fout.push({ id: zid, code: `lokaal:${Object.keys(check.fouten).join(",")}` }); continue; }

    if (!uitvoeren) {
      // Proefrun: alleen lezen.
      const bestaat = await api.aanroep("GET", `/relaties/${rid}`);
      if (bestaat.status === 200) {
        bestaandeRelaties.add(rid); v.relaties.bestaatAl.push(zid);
        if (dealNotities) v.waarschuwingen.push(`dealnotitie-niet-bijgewerkt:${zid}`);
      }
      else if (bestaat.status === 404) v.relaties.nieuw.push(zid);
      else v.relaties.fout.push({ id: zid, code: `lezen:${foutcode(bestaat)}` });
      continue;
    }
    // Uitvoeren: altijd dezelfde POST, ook als de relatie al bestaat. De server maakt dan het nawerk af.
    const r = await api.aanroep("POST", "/relaties", { id: rid, wijzigingId: `zoho-${zid}`, velden, herkomst });
    const b = beoordeelPost(r, rid);
    if (b.fout) v.relaties.fout.push({ id: zid, code: b.fout });
    else {
      v.relaties[b.uitkomst].push(zid);
      if (b.uitkomst === "bestaatAl" && dealNotities) v.waarschuwingen.push(`dealnotitie-niet-bijgewerkt:${zid}`);
    }
    log(`contact ${zid}: ${r.status}`);
  }

  const relatieOk = new Set([...v.relaties.nieuw, ...v.relaties.bestaatAl]);
  for (const { id: zid, cid, velden } of dealLijst) {
    const rid = relatieId(cid);
    if (!relatieOk.has(cid)) { v.trajecten.fout.push({ id: zid, code: "relatie-niet-aangemaakt" }); continue; }
    const check = valideerTraject({ ...velden, relatieId: rid });
    if (!check.ok) { v.trajecten.fout.push({ id: zid, code: `lokaal:${Object.keys(check.fouten).join(",")}` }); continue; }
    if (!uitvoeren) {
      if (bestaandeRelaties.has(rid)) {
        const g = await api.aanroep("GET", `/relaties/${rid}`);
        if (g.status !== 200) { v.trajecten.fout.push({ id: zid, code: `lezen:${foutcode(g)}` }); continue; }
        if ((g.data?.trajecten ?? []).some((t) => t?.record?.id === trajectId(zid))) { v.trajecten.bestaatAl.push(zid); continue; }
      }
      v.trajecten.nieuw.push(zid);
      continue;
    }
    const r = await api.aanroep("POST", `/relaties/${rid}/trajecten`, { id: trajectId(zid), wijzigingId: `zoho-${zid}`, velden });
    const b = beoordeelPost(r, trajectId(zid));
    if (b.fout) v.trajecten.fout.push({ id: zid, code: b.fout });
    else v.trajecten[b.uitkomst].push(zid);
    log(`deal ${zid}: ${r.status}`);
  }
  return v;
}

export function toonVerslag(v, schrijf = console.log) {
  const k = v.uitvoeren ? "aangemaakt" : "zou aanmaken";
  schrijf(v.uitvoeren ? "UITGEVOERD" : "PROEFRUN (er is niets geschreven; gebruik --uitvoeren om te schrijven)");
  if (v.afgebroken.length) {
    schrijf("AFGEBROKEN: er is niets uitgevoerd.");
    for (const a of v.afgebroken) schrijf(`  ${a}`);
  }
  schrijf(`In bestand: ${v.contacten} contacten, ${v.deals} deals`);
  schrijf(`Relaties: ${v.relaties.nieuw.length} ${k}, ${v.relaties.bestaatAl.length} bestonden al, ${v.relaties.fout.length} fout`);
  schrijf(`Trajecten: ${v.trajecten.nieuw.length} ${k}, ${v.trajecten.bestaatAl.length} bestonden al, ${v.trajecten.fout.length} fout`);
  schrijf(`Overgeslagen: ${v.overgeslagen.length}`);
  for (const o of v.overgeslagen) schrijf(`  ${o.module} ${o.id}: ${o.reden}${o.stage ? ` (fase ${o.stage})` : ""}`);
  for (const w of v.veldenWeggelaten) schrijf(`  ${w.id}: velden niet overgenomen (waarde staat in de notitie): ${w.velden.join(", ")}`);
  if (v.bijlagenGenegeerd.length) schrijf(`Bijlagen genegeerd (niet geimporteerd) bij ${v.bijlagenGenegeerd.length} deals: ${v.bijlagenGenegeerd.join(", ")}`);
  for (const w of v.waarschuwingen) schrijf(`  WAARSCHUWING: ${w}`);
  for (const f of v.relaties.fout) schrijf(`  FOUT relatie ${f.id}: ${f.code}`);
  for (const f of v.trajecten.fout) schrijf(`  FOUT traject ${f.id}: ${f.code}`);
}

// ---------- opdrachtregel ----------
export function leesArgumenten(argv) {
  const uit = { uitvoeren: false };
  const rest = [];
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--uitvoeren") uit.uitvoeren = true;
    else if (a === "--toch") uit.toch = true;
    else if (a === "--basis") uit.basis = argv[++i];
    else if (a === "--eigenaar") uit.eigenaar = argv[++i];
    else if (a.startsWith("--")) throw new Error(`Onbekende optie: ${a.split("=")[0]}`);
    else rest.push(a);
  }
  uit.bestand = rest[0];
  if (rest.length > 1) throw new Error("Geef precies één bestand op.");
  return uit;
}

async function main() {
  let a;
  try { a = leesArgumenten(process.argv.slice(2)); } catch (e) { console.error(e.message); process.exit(2); }
  const gebruik = "Gebruik: DASHBOARD_COOKIE='dashboard_sessie=...' node scripts/dashboard-klanten-import.mjs <bestand.json> --basis <https://site> [--eigenaar kevin|ruben] [--uitvoeren] [--toch]";
  if (!a.bestand || !a.basis) { console.error(gebruik); process.exit(2); }
  if (a.eigenaar && !EIGENAREN.includes(a.eigenaar)) { console.error("--eigenaar moet kevin of ruben zijn."); process.exit(2); }
  let basis;
  try { basis = new URL(a.basis); } catch { console.error("--basis is geen geldige URL."); process.exit(2); }
  if (basis.protocol !== "https:" && !["localhost", "127.0.0.1"].includes(basis.hostname)) { console.error("--basis moet https zijn."); process.exit(2); }
  const cookieRuw = (process.env.DASHBOARD_COOKIE || "").trim();
  if (!cookieRuw) { console.error("Zet DASHBOARD_COOKIE (de waarde van de cookie dashboard_sessie)."); process.exit(2); }
  const cookie = cookieRuw.includes("=") ? cookieRuw : `dashboard_sessie=${cookieRuw}`;
  let invoer;
  try { invoer = JSON.parse(fs.readFileSync(a.bestand, "utf8")); } catch { console.error("Het bestand is niet te lezen of geen geldige JSON."); process.exit(2); }
  if (!invoer || !Array.isArray(invoer.contacts) || !Array.isArray(invoer.deals)) { console.error("Verwacht {contacts:[...], deals:[...]}."); process.exit(2); }
  const v = await draaiImport(invoer, { basis: basis.origin, cookie, uitvoeren: a.uitvoeren, toch: a.toch, eigenaar: a.eigenaar });
  toonVerslag(v);
  process.exit(v.afgebroken.length || v.relaties.fout.length || v.trajecten.fout.length ? 1 : 0);
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  main().catch((e) => { console.error("Import mislukt:", e && e.name ? e.name : "onbekend"); process.exit(1); });
}

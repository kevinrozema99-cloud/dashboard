// Tests voor scripts/dashboard-klanten-import.mjs (K8). Alleen verzonnen data; de import draait tegen de echte
// handler met een in-memory store, via een nep-fetch.
import { test, beforeEach } from "node:test";
import assert from "node:assert/strict";
import { zetStoreFabriek, store } from "../netlify/functions/dashboard-lib/opslag.mjs";
import { geheugenFabriek } from "../netlify/functions/dashboard-lib/test-hulp.mjs";
import { maakWachtwoordHash, maakToken } from "../netlify/functions/dashboard-lib/sessie.mjs";
import { testCatalogus } from "../netlify/functions/dashboard-lib/klanten/test-regels.mjs";
import { maakHandler } from "../netlify/functions/dashboard-klanten.mjs";
import { draaiImport, lookupId, mapDeal, mapContact, mapFase, mapBron, splitsStraat, leesArgumenten, toonVerslag, relatieId, trajectId } from "./dashboard-klanten-import.mjs";

const NU = new Date("2026-11-10T10:00:00.000Z");
const CTX = { deploy: { context: "deploy-preview" } };
const BASIS = "https://x.test";
let handler; let cookie; let fabriek; let verzoeken;

beforeEach(async () => {
  process.env.DASHBOARD_GEBRUIKERS = JSON.stringify({ Ruben: await maakWachtwoordHash("verzonnen-b", 1000) });
  process.env.DASHBOARD_SESSIE_GEHEIM = "z".repeat(40);
  delete process.env.DASHBOARD_ECHTE_DATA;
  fabriek = geheugenFabriek();
  zetStoreFabriek(fabriek);
  handler = maakHandler({ regels: testCatalogus(), nu: () => NU });
  cookie = `dashboard_sessie=${maakToken("Ruben")}`;
  verzoeken = [];
});

const nepFetch = async (url, init) => {
  verzoeken.push({ methode: init.method, pad: new URL(url).pathname });
  return handler(new Request(url, init), CTX);
};
const opties = (extra = {}) => ({ basis: BASIS, cookie, fetchFn: nepFetch, wacht: async () => {}, ...extra });
const lees = async (pad) => (await handler(new Request(`${BASIS}/api/dashboard/klanten${pad}`, { headers: { cookie } }), CTX)).json();

const contact = (id, extra = {}) => ({
  id, First_Name: "Anna", Last_Name: "Testman", Email: "anna@voorbeeld.invalid", Phone: "0612345678",
  Mailing_Street: "Verzinselstraat 12a", Mailing_Zip: "9999zz", Mailing_City: "Teststad", Lead_Source: "Website",
  Created_Time: "2025-03-01T10:00:00+01:00", ...extra,
});
const deal = (id, contactId, extra = {}) => ({ id, Deal_Name: "Nep - dossier", Stage: "Aanvraag ingediend", Contact_Name: { id: contactId, name: "Anna Testman" }, Description: "Verzonnen opmerking", Created_Time: "2025-03-02T10:00:00+01:00", ...extra });
const bestand = () => ({
  contacts: [contact("1001"), contact("1002", { Last_Name: "Voorbeeld", Phone: "kapot", Lead_Source: "Beurs" })],
  deals: [deal("2001", "1001"), deal("2002", "1002")],
});

test("mapping: velden, adres, bron en herkomst", () => {
  const m = mapContact(contact("1001"), ["Zoho-deal 2001: Verzonnen opmerking"], { eigenaar: "ruben" });
  assert.equal(m.velden.status, "Klant");
  assert.deepEqual([m.velden.straat, m.velden.huisnummer, m.velden.toevoeging], ["Verzinselstraat", "12", "a"]);
  assert.equal(m.velden.bron, "Website");
  assert.equal(m.velden.eigenaar, "ruben");
  assert.deepEqual(m.herkomst, { zoho: { module: "Contacts", id: "1001", via: "zoho-import" } });
  assert.ok(m.notities.some((n) => n.includes("Zoho-deal 2001: Verzonnen opmerking")));
  assert.deepEqual(mapBron("Beurs"), { bron: "Anders", extra: "Zoho-bron: Beurs" });
  assert.deepEqual(splitsStraat("Dorpsweg 7"), { straat: "Dorpsweg", huisnummer: "7" });
  assert.deepEqual(splitsStraat("Dorpsweg 7-B"), { straat: "Dorpsweg", huisnummer: "7", toevoeging: "B" });
  assert.deepEqual(splitsStraat("Postbus"), { straat: "Postbus" });
  for (const s of ["Dorpsweg 12-14", "Dorpsweg 12 t/m 14", "Dorpsweg 12 boven", "2e Dwarsweg 5"]) assert.equal(splitsStraat(s).huisnummer, undefined, s);
  assert.equal(splitsStraat("Dorpsweg 12-14").straat, "Dorpsweg 12-14");
});

test("fase: Aanvraag ingediend wordt overgenomen, de rest niet", () => {
  assert.deepEqual(mapFase("Aanvraag ingediend"), { fase: "Aanvraag ingediend" });
  assert.equal(mapFase("Besluit").overgeslagen, "fase-niet-importeerbaar");
  assert.equal(mapFase("Closed Lost").overgeslagen, "fase-onbekend");
});

test("proefrun schrijft niets en toont alleen aantallen en ids", async () => {
  const v = await draaiImport(bestand(), opties());
  assert.deepEqual(v.relaties.nieuw, ["1001", "1002"]);
  assert.deepEqual(v.trajecten.nieuw, ["2001", "2002"]);
  assert.ok(verzoeken.every((r) => r.methode === "GET"));
  const uit = [];
  toonVerslag(v, (s) => uit.push(s));
  const tekst = uit.join("\n");
  for (const geheim of ["Testman", "Verzinselstraat", "anna@", "0612345678", "Teststad", "9999", "Voorbeeld"]) assert.ok(!tekst.includes(geheim), geheim);
  assert.equal(Object.keys((await store("klanten").get("index/relaties", { type: "json" }))?.rijen ?? {}).length, 0);
});

test("uitvoeren maakt relaties en trajecten via de API met validatie", async () => {
  const v = await draaiImport(bestand(), opties({ uitvoeren: true }));
  assert.deepEqual(v.relaties.fout, []);
  assert.deepEqual(v.trajecten.fout, []);
  assert.equal(v.relaties.nieuw.length, 2);
  assert.deepEqual(v.veldenWeggelaten, [{ id: "1002", velden: ["telefoon"] }]);
  const d = await lees(`/relaties/${relatieId("1001")}`);
  assert.equal(d.relatie.status, "Klant");
  assert.equal(d.relatie.postcode, "9999 ZZ");
  assert.equal(d.relatie.herkomst.zoho.id, "1001");
  assert.equal(d.relatie.herkomst.zoho.via, "zoho-import");
  assert.equal(d.trajecten.length, 1);
  assert.equal(d.trajecten[0].record.id, trajectId("2001"));
  assert.equal(d.trajecten[0].record.fase, "Aanvraag ingediend");
  const d2 = await lees(`/relaties/${relatieId("1002")}`);
  assert.equal(d2.relatie.bron, "Anders");
  assert.ok(d2.relatie.notitie.includes("Zoho-bron: Beurs"));
  assert.equal(d2.relatie.telefoon, undefined);
});

test("tweede run maakt niets dubbel aan", async () => {
  await draaiImport(bestand(), opties({ uitvoeren: true }));
  verzoeken = [];
  const v2 = await draaiImport(bestand(), opties({ uitvoeren: true }));
  assert.deepEqual(v2.relaties.nieuw, []);
  assert.deepEqual(v2.trajecten.nieuw, []);
  assert.deepEqual(v2.relaties.bestaatAl, ["1001", "1002"]);
  assert.deepEqual(v2.trajecten.bestaatAl, ["2001", "2002"]);
  assert.ok(verzoeken.some((r) => r.methode === "POST")); // bij uitvoeren altijd dezelfde POST, de server herkent hem
  const reg = await store("klanten").get("register/trajecten", { type: "json" });
  assert.equal(Object.keys(reg.ids).length, 2);
});

test("herstart na half werk: bestaande relatie, nieuw traject", async () => {
  await draaiImport({ contacts: [contact("1001")], deals: [] }, opties({ uitvoeren: true }));
  const v = await draaiImport({ contacts: [contact("1001")], deals: [deal("2001", "1001")] }, opties({ uitvoeren: true }));
  assert.deepEqual(v.relaties.bestaatAl, ["1001"]);
  assert.deepEqual(v.trajecten.nieuw, ["2001"]);
});

test("overslaan: onbekend contact, andere fase, dubbel en ongeldig id", async () => {
  const invoer = {
    contacts: [contact("1001"), contact("1001"), contact("bad id!")],
    deals: [deal("2001", "9999"), deal("2002", "1001", { Stage: "Besluit" }), deal("2003", "1001", { Stage: "Closed Lost" }), deal("2004", "1001")],
  };
  const v = await draaiImport(invoer, opties({ uitvoeren: true }));
  const redenen = Object.fromEntries(v.overgeslagen.map((o) => [`${o.module}${o.id}`, o.reden]));
  assert.equal(redenen.Contacts1001, "dubbel-in-bestand");
  assert.equal(redenen["Contactsrij 3"], "id-ongeldig");
  assert.equal(redenen.Deals2001, "contact-onbekend");
  assert.equal(redenen.Deals2002, "fase-niet-importeerbaar");
  assert.equal(redenen.Deals2003, "fase-onbekend");
  assert.deepEqual(v.trajecten.nieuw, ["2004"]);
});

test("contact zonder achternaam is een fout, geen crash", async () => {
  const v = await draaiImport({ contacts: [contact("1001", { Last_Name: "" })], deals: [deal("2001", "1001")] }, opties({ uitvoeren: true }));
  assert.equal(v.relaties.fout.length, 1);
  assert.equal(v.trajecten.fout[0].code, "relatie-niet-aangemaakt");
});

test("zonder geldige sessie komt er niets binnen", async () => {
  const v = await draaiImport(bestand(), opties({ uitvoeren: true, cookie: "dashboard_sessie=nep" }));
  assert.equal(v.relaties.nieuw.length, 0);
  assert.equal(v.afgebroken.length, 1);
  assert.ok(v.afgebroken[0].startsWith("lijst-niet-te-lezen"));
  assert.ok(!verzoeken.some((r) => r.methode === "POST"));
});

test("argumenten", () => {
  assert.deepEqual(leesArgumenten(["x.json", "--basis", "https://a.test"]), { uitvoeren: false, bestand: "x.json", basis: "https://a.test" });
  assert.equal(leesArgumenten(["x.json", "--uitvoeren"]).uitvoeren, true);
  assert.throws(() => leesArgumenten(["x.json", "--rare"]));
});

test("echte Zoho-vorm: Contact_Name als lookup, en terugval op Contact_id", async () => {
  const d1 = deal("2001", "1001");
  const d2 = { ...deal("2002", "1001"), Contact_Name: undefined, Contact_id: "1001" };
  assert.equal(lookupId(d1.Contact_Name), "1001");
  const v = await draaiImport({ contacts: [contact("1001")], deals: [d1, d2] }, opties({ uitvoeren: true }));
  assert.deepEqual(v.trajecten.nieuw, ["2001", "2002"]);
});

test("uitvoeren: bij bestaande relatie toch POST, en nawerk wordt hersteld", async () => {
  await draaiImport({ contacts: [contact("1001")], deals: [deal("2001", "1001")] }, opties({ uitvoeren: true }));
  verzoeken = [];
  await draaiImport({ contacts: [contact("1001")], deals: [deal("2001", "1001")] }, opties({ uitvoeren: true }));
  assert.deepEqual(verzoeken.filter((r) => r.methode === "POST").map((r) => r.pad.split("/").slice(4).join("/")), ["relaties", `relaties/${relatieId("1001")}/trajecten`]);
});

test("409 is id-bezet en een 200 zonder bestaatAl is geen succes", async () => {
  const fetch409 = async (url, init) => (init.method === "POST" ? new Response("{}", { status: 409 }) : nepFetch(url, init));
  let v = await draaiImport({ contacts: [contact("1001")], deals: [] }, opties({ uitvoeren: true, fetchFn: fetch409 }));
  assert.deepEqual(v.relaties.fout, [{ id: "1001", code: "id-bezet" }]);
  const fetch200 = async (url, init) => (init.method === "POST" ? Response.json({ bestaatAl: true, record: { id: "r_anders" } }) : nepFetch(url, init));
  v = await draaiImport({ contacts: [contact("1001")], deals: [] }, opties({ uitvoeren: true, fetchFn: fetch200 }));
  assert.deepEqual(v.relaties.fout, [{ id: "1001", code: "onverwacht-antwoord" }]);
  assert.equal(v.relaties.bestaatAl.length, 0);
});

test("fetch krijgt redirect error; netwerkfout geeft code netwerk per record", async () => {
  let opt;
  await draaiImport({ contacts: [contact("1001")], deals: [] }, opties({ fetchFn: async (u, i) => { opt = i; return nepFetch(u, i); } }));
  assert.equal(opt.redirect, "error");
  const kapot = async (u, i) => { if (i.method === "POST") throw new TypeError("fetch failed"); return nepFetch(u, i); };
  const v = await draaiImport({ contacts: [contact("1001"), contact("1002")], deals: [] }, opties({ uitvoeren: true, fetchFn: kapot }));
  assert.deepEqual(v.relaties.fout.map((f) => f.code), ["netwerk", "netwerk"]);
});

test("meer velden worden gemapt, bijlagen genegeerd", async () => {
  const c = contact("1001", { Mobile: "0687654321", Salutation: "Dhr.", Description: "Verzonnen contactnotitie", Owner: { id: "9", name: "Ruben Nep" }, Mailing_Flat_House_No_Building_Apartment_Name: "2", Email_Opt_Out: true, Mailing_Street: "Dorpsweg 12" });
  const d = deal("2001", "1001", { Aanvraagdatum: "2025-04-01", Route: "Maatwerk met onderzoek", Opnamedatum: "2025-05-01", Amount: 1500, Fee: 250, Factuur_voldaan_op: "2025-06-01", Lead_Source: "Beurs", Machtigingsformulier: ["x.pdf"], bijlagen: ["scan.pdf"] });
  const v = await draaiImport({ contacts: [c], deals: [d] }, opties({ uitvoeren: true }));
  assert.deepEqual(v.relaties.fout, []);
  assert.deepEqual(v.trajecten.fout, []);
  assert.deepEqual(v.bijlagenGenegeerd, ["2001"]);
  const r = await lees(`/relaties/${relatieId("1001")}`);
  assert.equal(r.relatie.mobiel, "0687654321");
  assert.equal(r.relatie.aanhef, "Dhr.");
  assert.equal(r.relatie.eigenaar, "ruben");
  assert.equal(r.relatie.toevoeging, "2");
  assert.ok(r.relatie.notitie.includes("Verzonnen contactnotitie"));
  assert.ok(r.relatie.notitie.includes("Email_Opt_Out"));
  const t = r.trajecten[0].record;
  assert.deepEqual([t.aanvraagdatum, t.route, t.opnamedatum, t.uitkeringImg, t.fee, t.factuurVoldaanOp], ["2025-04-01", "Maatwerk met onderzoek", "2025-05-01", 1500, 250, "2025-06-01"]);
  assert.equal(JSON.stringify(r).includes("scan.pdf"), false);
  const m = mapDeal(deal("5", "1", { Opnamedatum: "geen-datum" }), "Aanvraag ingediend", "r_zoho_1", "Website");
  assert.deepEqual(m.weggelaten, ["opnamedatum"]);
  assert.ok(m.notities.some((n) => n.includes("opnamedatum")));
});

test("--eigenaar wint van Owner", () => {
  assert.equal(mapContact(contact("1", { Owner: "Kevin Nep" }), [], { eigenaar: "ruben" }).velden.eigenaar, "ruben");
  assert.equal(mapContact(contact("1", { Owner: "Kevin Nep" })).velden.eigenaar, "kevin");
});

test("handmatig aangemaakte relatie met hetzelfde Zoho-id wordt overgeslagen", async () => {
  await handler(new Request(`${BASIS}/api/dashboard/klanten/relaties`, {
    method: "POST", headers: { cookie, "content-type": "application/json" },
    body: JSON.stringify({ id: "r_hand1", wijzigingId: "w1", velden: { achternaam: "Handmatig", status: "Klant" }, herkomst: { zoho: { module: "Contacts", id: "1001" } } }),
  }), CTX);
  const v = await draaiImport({ contacts: [contact("1001"), contact("1002", { Email: "andere@voorbeeld.invalid", Mailing_Zip: "1234AB" })], deals: [deal("2001", "1001")] }, opties({ uitvoeren: true, toch: true }));
  const redenen = Object.fromEntries(v.overgeslagen.map((o) => [`${o.module}${o.id}`, o.reden]));
  assert.equal(redenen.Contacts1001, "al-handmatig");
  assert.equal(redenen.Deals2001, "al-handmatig");
  assert.deepEqual(v.relaties.nieuw, ["1002"]);
});

test("ongeldig id: alleen rijnummer in de uitvoer; onbekende optie zonder waarde", async () => {
  const v = await draaiImport({ contacts: [contact("bad id!")], deals: [] }, opties());
  assert.deepEqual(v.overgeslagen, [{ module: "Contacts", id: "rij 1", reden: "id-ongeldig" }]);
  assert.throws(() => leesArgumenten(["--geheim=abc"]), (e) => e.message.includes("--geheim") && !e.message.includes("abc"));
});

async function maakHand(id, velden) {
  await handler(new Request(`${BASIS}/api/dashboard/klanten/relaties`, {
    method: "POST", headers: { cookie, "content-type": "application/json" },
    body: JSON.stringify({ id, wijzigingId: `w-${id}`, velden: { status: "Klant", ...velden } }),
  }), CTX);
}

test("uitvoeren stopt als er andere relaties bestaan, tenzij --toch", async () => {
  await maakHand("r_hand2", { achternaam: "Elders", email: "elders@voorbeeld.invalid" });
  verzoeken = [];
  const v = await draaiImport(bestand(), opties({ uitvoeren: true }));
  assert.equal(v.afgebroken.length, 1);
  assert.ok(!verzoeken.some((r) => r.methode === "POST"));
  const uit = []; toonVerslag(v, (x) => uit.push(x));
  assert.ok(uit.join("\n").includes("AFGEBROKEN"));
  const v2 = await draaiImport(bestand(), opties({ uitvoeren: true, toch: true }));
  assert.deepEqual(v2.afgebroken, []);
  assert.equal(v2.relaties.nieuw.length, 2);
});

test("uitvoeren stopt bij afgekapte lijst of onleesbare relatie", async () => {
  await maakHand("r_hand3", { achternaam: "Elders" });
  const afgekapt = async (url, init) => {
    const res = await nepFetch(url, init);
    if (init.method === "GET" && new URL(url).pathname.endsWith("/relaties")) { const d = await res.json(); return Response.json({ ...d, afgekapt: true }); }
    return res;
  };
  let v = await draaiImport(bestand(), opties({ uitvoeren: true, toch: true, fetchFn: afgekapt }));
  assert.deepEqual(v.afgebroken, ["lijst-afgekapt"]);
  const onleesbaar = async (url, init) => (init.method === "GET" && url.includes("r_hand3") ? new Response("{}", { status: 500 }) : nepFetch(url, init));
  v = await draaiImport(bestand(), opties({ uitvoeren: true, toch: true, fetchFn: onleesbaar }));
  assert.ok(v.afgebroken[0].startsWith("relatie-niet-te-lezen"));
  assert.equal(v.relaties.nieuw.length, 0);
});

test("mogelijk-handmatig op e-mail of postcode + huisnummer; alleen het Zoho-id in de uitvoer", async () => {
  await maakHand("r_hand4", { achternaam: "Elders", email: "ANNA@voorbeeld.invalid" });
  await maakHand("r_hand5", { achternaam: "Buur", postcode: "5555 AA", huisnummer: "9" });
  const invoer = { contacts: [contact("1001"), contact("1002", { Email: "x@voorbeeld.invalid", Mailing_Zip: "5555aa", Mailing_Street: "Nepstraat 9" }), contact("1003", { Email: "y@voorbeeld.invalid", Mailing_Zip: "5555 AA", Mailing_Street: "Nepstraat 10" })], deals: [deal("2001", "1001")] };
  const v = await draaiImport(invoer, opties({ uitvoeren: true, toch: true }));
  const redenen = Object.fromEntries(v.overgeslagen.map((o) => [`${o.module}${o.id}`, o.reden]));
  assert.equal(redenen.Contacts1001, "mogelijk-handmatig");
  assert.equal(redenen.Contacts1002, "mogelijk-handmatig");
  assert.equal(redenen.Deals2001, "mogelijk-handmatig");
  assert.deepEqual(v.relaties.nieuw, ["1003"]);
});

test("waarschuwing notitie-afgekapt en dealnotitie bij bestaatAl", async () => {
  const lang = { contacts: [contact("1001")], deals: [deal("2001", "1001", { Description: "x".repeat(6000) })] };
  const v = await draaiImport(lang, opties({ uitvoeren: true }));
  assert.ok(v.waarschuwingen.includes("notitie-afgekapt:1001"));
  const v2 = await draaiImport(lang, opties({ uitvoeren: true, toch: true }));
  assert.ok(v2.waarschuwingen.includes("dealnotitie-niet-bijgewerkt:1001"));
  assert.deepEqual(leesArgumenten(["a.json", "--toch"]).toch, true);
});

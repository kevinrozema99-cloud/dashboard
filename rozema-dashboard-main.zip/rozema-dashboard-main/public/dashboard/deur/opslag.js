// Opslag op de telefoon in IndexedDB. Twee gescheiden stores:
//   kv        cache van plaatsen, adressen en stand (mag leeglopen)
//   wachtrij  bezoeken die nog verstuurd moeten worden (nooit automatisch weggooien)
// Lukt IndexedDB niet (bijvoorbeeld een privévenster), dan werkt alles in het geheugen
// en meldt blijvend() dat bewaren niet duurzaam is.
const DB_NAAM = "rozema-deur";
const VERSIE = 1;

let dbPromise = null;
let geheugenModus = false;
const geheugen = { kv: new Map(), wachtrij: new Map() };

function openDb() {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve) => {
    try {
      const rq = indexedDB.open(DB_NAAM, VERSIE);
      rq.onupgradeneeded = () => {
        const db = rq.result;
        if (!db.objectStoreNames.contains("kv")) db.createObjectStore("kv");
        if (!db.objectStoreNames.contains("wachtrij")) db.createObjectStore("wachtrij", { keyPath: "id" });
      };
      rq.onsuccess = () => resolve(rq.result);
      rq.onerror = () => { geheugenModus = true; resolve(null); };
      rq.onblocked = () => { geheugenModus = true; resolve(null); };
    } catch {
      geheugenModus = true;
      resolve(null);
    }
  });
  return dbPromise;
}

function aanvraag(storeNaam, modus, fn) {
  return openDb().then((db) => {
    if (!db) { const r = fn(null, true); return r && typeof r === "object" && "result" in r ? r.result : undefined; }
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeNaam, modus);
      const st = tx.objectStore(storeNaam);
      let uit;
      const rq = fn(st, false);
      if (rq && "onsuccess" in rq) rq.onsuccess = () => { uit = rq.result; };
      tx.oncomplete = () => resolve(uit);
      tx.onerror = () => reject(tx.error || new Error("opslag"));
      tx.onabort = () => reject(tx.error || new Error("opslag"));
    });
  });
}

export const blijvend = () => !geheugenModus;

// Vraagt de browser de gegevens niet zomaar te wissen (mag stil mislukken).
export function vraagBlijvend() {
  try {
    if (navigator.storage && navigator.storage.persist) navigator.storage.persist().catch(() => {});
  } catch { /* niet beschikbaar */ }
}

export const kv = {
  get(k) {
    return aanvraag("kv", "readonly", (st, mem) => (mem ? { result: geheugen.kv.get(k) } : st.get(k)))
      .then((v) => (v === undefined ? null : v), () => null);
  },
  set(k, v) {
    return aanvraag("kv", "readwrite", (st, mem) => {
      if (mem) { geheugen.kv.set(k, v); return null; }
      return st.put(v, k);
    });
  },
  del(k) {
    return aanvraag("kv", "readwrite", (st, mem) => {
      if (mem) { geheugen.kv.delete(k); return null; }
      return st.delete(k);
    });
  },
};

export const wachtrij = {
  alle() {
    return aanvraag("wachtrij", "readonly", (st, mem) => {
      if (mem) return { result: [...geheugen.wachtrij.values()] };
      return st.getAll();
    }).then((l) => (Array.isArray(l) ? l : []).sort((a, b) => a.toegevoegd - b.toegevoegd));
  },
  // Rejects als bewaren mislukt: de aanroeper moet dat zichtbaar melden.
  zet(item) {
    return aanvraag("wachtrij", "readwrite", (st, mem) => {
      if (mem) { geheugen.wachtrij.set(item.id, item); return null; }
      return st.put(item);
    });
  },
  verwijder(id) {
    return aanvraag("wachtrij", "readwrite", (st, mem) => {
      if (mem) { geheugen.wachtrij.delete(id); return null; }
      return st.delete(id);
    });
  },
};

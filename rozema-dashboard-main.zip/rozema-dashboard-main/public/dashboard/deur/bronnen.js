// Ophalen van adressen, panden en buurten, rechtstreeks bij PDOK (CORS staat open, geen proxy).
import {
  BRON, isWoning, vboNaarAdres, pandNaarInfo, koppelPanden, koppelBuurten, bbox, tegelBboxen,
} from "./logica.js";

const TIJDSLIMIET_MS = 60000;
const POGINGEN = 4;

async function haalJson(url) {
  let laatste;
  for (let i = 0; i < POGINGEN; i++) {
    try {
      const ac = new AbortController();
      const t = setTimeout(() => ac.abort(), TIJDSLIMIET_MS);
      const r = await fetch(url, { headers: { accept: "application/json" }, signal: ac.signal });
      clearTimeout(t);
      if (r.ok) return await r.json();
      laatste = new Error("PDOK antwoordde met " + r.status);
      if (r.status < 500 && r.status !== 429) break;
    } catch (e) {
      laatste = e;
    }
    await new Promise((res) => setTimeout(res, 800 * (i + 1)));
  }
  throw laatste || new Error("PDOK niet bereikbaar");
}

async function allePaginas(url, voortgang) {
  const alles = [];
  let n = 0;
  while (url && n < 400) {
    const d = await haalJson(url);
    alles.push(...(d.features || []));
    n++;
    if (voortgang) voortgang(alles.length);
    const volgende = (d.links || []).find((l) => l.rel === "next");
    url = volgende ? volgende.href : null;
  }
  return alles;
}

// voortgang(stap, n): stap is "bag", "panden" of "buurten".
export async function haalPlaatsOp(naam, voortgang = () => {}) {
  const enc = encodeURIComponent;
  const vbo = await allePaginas(
    `${BRON.bagVbo}?f=json&limit=1000&woonplaats_naam=${enc(naam)}&provincie_naam=${enc(BRON.provincie)}`,
    (n) => voortgang("bag", n),
  );
  const adressen = vbo.filter((f) => isWoning(f.properties || {})).map(vboNaarAdres).filter((a) => a.s && a.n && a.id);
  if (!adressen.length) return { adressen: [], buurten: [], gekoppeld: 0 };
  const bb = bbox(adressen);
  const perId = new Map();
  const vakken = tegelBboxen(adressen);
  for (let i = 0; i < vakken.length; i += 4) {
    const groep = await Promise.all(vakken.slice(i, i + 4).map((v) => allePaginas(`${BRON.bagPand}?f=json&limit=1000&bbox=${v.join(",")}`)));
    for (const feats of groep) for (const f of feats) { const p = pandNaarInfo(f); if (p.id) perId.set(p.id, p); }
    voortgang("panden", perId.size);
  }
  // Alle panden uit de vakken doen mee voor de buren; alleen de adressen krijgen straks een type.
  const panden = [...perId.values()];
  const gekoppeld = koppelPanden(adressen, panden);
  voortgang("buurten", 0);
  const buurtFeat = await allePaginas(`${BRON.cbsBuurten}?f=json&limit=100&bbox=${bb.join(",")}`);
  const buurten = koppelBuurten(adressen, buurtFeat);
  for (const a of adressen) delete a.pand;
  return { adressen, buurten, gekoppeld };
}

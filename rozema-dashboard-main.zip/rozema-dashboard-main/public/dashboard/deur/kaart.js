// Kaart met Leaflet (zelf gehost). Huizen zijn blokjes met huisnummer, zonder markericonen of schaduwen.
// Huisnummers en straatnamen worden zonder overlap geplaatst (plaatsLabels); wat niet past wordt een stip.
import { BRON, nrLabel, plaatsLabels, huidige } from "./logica.js";

const L = window.L;
const BLOK_H = 48; // tikvlak van minstens 48 px
const STIP = 16;
const TIK = 48;
const MAX_ZICHTBAAR = 700;

const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

export function maakKaart(element, opties) {
  // opties: { onKies(adres), tekst: { attributie, kaartLabel } }
  if (!L) return null;
  const kaart = L.map(element, {
    zoomControl: true, maxZoom: 21, minZoom: 7, attributionControl: true,
    zoomAnimation: false, fadeAnimation: false, markerZoomAnimation: false, inertia: false,
  });
  kaart.attributionControl.setPrefix(false);
  L.tileLayer(BRON.tegels, {
    maxNativeZoom: 19, maxZoom: 21, minZoom: 7, attribution: opties.tekst.attributie,
  }).addTo(kaart);
  const laag = L.layerGroup().addTo(kaart);
  kaart.setView([53.32, 6.75], 11);

  let data = { straten: [], stand: {}, volgendId: null };
  let ikMarker = null;
  let wacht = null;

  function pt(a) { return kaart.latLngToContainerPoint([a.y, a.x]); }

  function teken() {
    laag.clearLayers();
    const zoom = kaart.getZoom();
    const grens = kaart.getBounds().pad(0.2);
    const zichtbaar = [];
    for (const s of data.straten) {
      const lijst = [];
      for (const a of s.adressen) if (a.y != null && grens.contains([a.y, a.x])) lijst.push(a);
      if (lijst.length) zichtbaar.push({ straat: s, adressen: lijst });
    }
    const alle = zichtbaar.flatMap((z) => z.adressen);
    const statusVan = (a) => { const h = huidige(data.stand[a.id]); return h ? h.st : null; };
    const maakStip = (a, p) => {
      const st = statusVan(a);
      const icon = L.divIcon({
        className: "huis-icoon", iconSize: [TIK, TIK], iconAnchor: [TIK / 2, TIK / 2],
        html: `<span class="hp ${st ? "st-" + st : "st-leeg"}${a.id === data.volgendId ? " volgend" : ""}"></span>`,
      });
      const m = L.marker([a.y, a.x], { icon, keyboard: true, title: `${a.s} ${nrLabel(a)}` });
      m.on("click", () => opties.onKies(a));
      m.addTo(laag);
    };

    // Ver weg: alleen stippen, en niet meer dan MAX_ZICHTBAAR.
    if (zoom < 16 || (zoom < 18 && alle.length > MAX_ZICHTBAAR)) {
      const stap = Math.max(1, Math.ceil(alle.length / MAX_ZICHTBAAR));
      alle.forEach((a, i) => { if (i % stap === 0) maakStip(a, null); });
      return;
    }
    if (alle.length > MAX_ZICHTBAAR * 2) {
      const stap = Math.ceil(alle.length / MAX_ZICHTBAAR);
      alle.forEach((a, i) => { if (i % stap === 0) maakStip(a, null); });
      return;
    }

    const blokken = zoom >= 18;
    const punten = new Map(alle.map((a) => [a.id, pt(a)]));
    let bezet = [];
    const geplaatst = new Set();
    if (blokken) {
      const items = alle.map((a) => {
        const st = statusVan(a);
        const label = nrLabel(a) + (st ? "X" : "");
        const w = Math.max(TIK, 20 + label.length * 11);
        const p = punten.get(a.id);
        return {
          id: a.id, w, h: BLOK_H, posities: [{ x: p.x, y: p.y }],
          prio: a.id === data.volgendId ? 3 : st ? 1 : 2,
        };
      });
      const r = plaatsLabels(items, { pad: 3 });
      bezet = r.bezet;
      for (const a of alle) if (r.keuze.get(a.id) === 0) geplaatst.add(a.id);
      const itemVan = new Map(items.map((i) => [i.id, i]));
      for (const a of alle) {
        if (!geplaatst.has(a.id)) continue;
        const st = statusVan(a);
        const it = itemVan.get(a.id);
        const klasse = `hb ${st ? "st-" + st : "st-leeg"}${a.id === data.volgendId ? " volgend" : ""}`;
        const letter = st ? `<i>${esc(letterVan(st))}</i>` : "";
        const icon = L.divIcon({
          className: "huis-icoon", iconSize: [it.w, BLOK_H], iconAnchor: [it.w / 2, BLOK_H / 2],
          html: `<span class="${klasse}">${esc(nrLabel(a))}${letter}</span>`,
        });
        const m = L.marker([a.y, a.x], { icon, keyboard: true, title: `${a.s} ${nrLabel(a)}`, zIndexOffset: a.id === data.volgendId ? 500 : 0 });
        m.on("click", () => opties.onKies(a));
        m.addTo(laag);
      }
    }
    // Stippen voor alles wat geen blok kreeg; ze houden hun ruimte bezet voor de straatnamen.
    const stippen = alle.filter((a) => !geplaatst.has(a.id));
    const sr = plaatsLabels(stippen.map((a) => {
      const p = punten.get(a.id);
      return { id: a.id, w: STIP, h: STIP, prio: 1, vast: true, posities: [{ x: p.x, y: p.y }] };
    }), { bezet, pad: 1 });
    bezet = sr.bezet;
    stippen.forEach((a) => maakStip(a, null));

    // Straatnamen op de as van de straat, op een plek waar niets anders staat.
    if (zoom >= 16) {
      const items = [];
      for (const z of zichtbaar) {
        const ps = z.adressen.map((a) => ({ a, p: punten.get(a.id) }));
        const even = ps.filter((q) => q.a.n % 2 === 0), oneven = ps.filter((q) => q.a.n % 2 === 1);
        const gem = (l) => ({ x: l.reduce((s, q) => s + q.p.x, 0) / l.length, y: l.reduce((s, q) => s + q.p.y, 0) / l.length });
        const w = Math.max(60, 16 + z.straat.naam.length * 11.5), h = 28;
        const sorteer = ps.slice().sort((p, q) => p.a.n - q.a.n);
        const posities = [];
        for (const f of [0.5, 0.2, 0.8, 0.0, 1.0]) {
          const q = sorteer[Math.min(sorteer.length - 1, Math.floor(f * sorteer.length))];
          if (even.length && oneven.length) {
            const eigen = q.a.n % 2 === 0 ? gem(even) : gem(oneven);
            const ander = q.a.n % 2 === 0 ? gem(oneven) : gem(even);
            posities.push({ x: q.p.x + (ander.x - eigen.x) / 2, y: q.p.y + (ander.y - eigen.y) / 2 });
          }
          for (const dy of [-(BLOK_H + 14), BLOK_H + 14]) posities.push({ x: q.p.x, y: q.p.y + dy });
        }
        items.push({ id: z.straat.naam, w, h, prio: z.adressen.length, posities, naam: z.straat.naam });
      }
      const r = plaatsLabels(items, { bezet, pad: 2 });
      for (const it of items) {
        const i = r.keuze.get(it.id);
        if (i === null || i === undefined) continue;
        const p = it.posities[i];
        const ll = kaart.containerPointToLatLng([p.x, p.y]);
        const icon = L.divIcon({
          className: "huis-icoon straatnaam-icoon", iconSize: [it.w, it.h], iconAnchor: [it.w / 2, it.h / 2],
          html: `<span class="sn">${esc(it.naam)}</span>`,
        });
        L.marker(ll, { icon, interactive: false, keyboard: false, zIndexOffset: -500 }).addTo(laag);
      }
    }
  }

  const letterVan = (st) => (opties.letters && opties.letters[st]) || "";

  function plan() { clearTimeout(wacht); wacht = setTimeout(teken, 60); }
  kaart.on("moveend zoomend", plan);

  return {
    kaart,
    zet(straten, stand, volgendId) { data = { straten, stand, volgendId: volgendId || null }; plan(); },
    passend(adressen) {
      const p = adressen.filter((a) => a.y != null).map((a) => [a.y, a.x]);
      if (p.length) kaart.fitBounds(p, { padding: [20, 20], animate: false });
      plan();
    },
    middenOp(a) {
      if (a && a.y != null) kaart.setView([a.y, a.x], Math.max(kaart.getZoom(), 19), { animate: false });
    },
    herteken() { kaart.invalidateSize(); plan(); },
    tekenNu: teken,
    positie(lat, lon) {
      if (!ikMarker) {
        ikMarker = L.marker([lat, lon], {
          icon: L.divIcon({ className: "huis-icoon", html: '<span class="ikhier"></span>', iconSize: [20, 20], iconAnchor: [10, 10] }),
          interactive: false, keyboard: false, zIndexOffset: 1000,
        }).addTo(kaart);
      } else ikMarker.setLatLng([lat, lon]);
    },
  };
}

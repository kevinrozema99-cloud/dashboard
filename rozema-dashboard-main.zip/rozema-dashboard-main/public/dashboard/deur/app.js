// Deur-aan-deur: de app. Alle zichtbare tekst komt uit teksten.js (window.TEKSTEN.deur).
import * as V from "./logica.js";
import { kv, wachtrij, vraagBlijvend } from "./opslag.js";
import { haalPlaatsOp } from "./bronnen.js";
import { maakKaart } from "./kaart.js";
import { verstuurWachtrij } from "./verstuur.js";

const D = window.Dashboard;
const TT = window.TEKSTEN.deur;
const API = "/api/dashboard/deur/";
const $ = (id) => document.getElementById(id);
const el = (tag, klasse, tekst) => {
  const e = document.createElement(tag);
  if (klasse) e.className = klasse;
  if (tekst != null) e.textContent = tekst;
  return e;
};
const vul = (s, o) => String(s).replace(/\{(\w+)\}/g, (_, k) => (o[k] ?? ""));
const getal = (n) => Number(n).toLocaleString("nl-NL");
const uid = () => Date.now().toString(36) + Array.from(crypto.getRandomValues(new Uint8Array(8)), (b) => (b % 36).toString(36)).join("");
const iso = () => new Date().toISOString();
const dagSleutel = (ts) => new Date(ts).toLocaleDateString("sv-SE");
const tijd = (ts) => new Date(ts).toLocaleTimeString("nl-NL", { hour: "2-digit", minute: "2-digit" });
const datum = (ts) => new Date(ts).toLocaleDateString("nl-NL", { day: "2-digit", month: "2-digit" });
const api = (pad, o = {}) => D.api(API + pad, { geenOmleiding: true, ...o });
const adresTekst = (a) => `${a.s} ${V.nrLabel(a)}`;
const naamVan = (st) => TT.uitkomst.naam[st] || st;

const S = {
  naam: null, plaatsen: [], plaatsId: null, plaats: null, buurten: [], trilling: {}, adressen: [],
  perId: new Map(), buurtPer: new Map(), stand: {}, tot: "", straten: [], huidigeStraat: null, kant: "alle",
  weergave: "kaart", tab: "lopen", laadTeller: 0, wacht: [], positie: null, laatsteKeuze: 0, volgend: null,
  autoVolgende: false, bijgewerkt: null, inlogNodig: false, bewarenMislukt: false, laatste: null,
  instellingenTik: 0, kaartPlaats: null, klantStraten: new Set(),
};
let kaartCtl = null;

// ---------------- status ----------------
function zetStatus() {
  const n = S.wacht.filter((x) => !x.afgekeurd).length;
  const regel = $("statusregel");
  let tekst, klasse = "";
  if (S.bewarenMislukt) { tekst = TT.status.bewarenMislukt; klasse = "fout"; }
  else if (S.inlogNodig) { tekst = TT.status.inlogNodig; klasse = "wacht"; }
  else if (!navigator.onLine) { tekst = n ? vul(TT.status.geenBereikWacht, { n }) : TT.status.geenBereik; klasse = "wacht"; }
  else if (n) { tekst = n === 1 ? TT.status.wachtEen : vul(TT.status.wachtMeer, { n }); klasse = "wacht"; }
  else tekst = TT.status.verbonden + (S.bijgewerkt ? ", " + vul(TT.status.bijgewerkt, { tijd: tijd(S.bijgewerkt) }) : "");
  regel.className = "statusregel" + (klasse ? " " + klasse : "");
  $("statustekst").textContent = tekst;
  $("inlogknop").hidden = !S.inlogNodig;
}

let toastTimer = null;
function toon(tekst, metOngedaan, klantLink) {
  $("toastTekst").textContent = tekst;
  $("ongedaan").hidden = !metOngedaan;
  $("klantToast").hidden = !klantLink;
  if (klantLink) $("klantToast").setAttribute("href", klantLink);
  $("toast").hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { $("toast").hidden = true; }, klantLink ? 12000 : metOngedaan ? 8000 : 5000);
}

// ---------------- inloggen opnieuw ----------------
let inlogBelofte = null;
function vraagInlog() {
  if (inlogBelofte) return inlogBelofte;
  S.inlogNodig = true;
  zetStatus();
  const dlg = $("inlogvenster");
  $("iNaam").value = S.naam || "";
  $("iWw").value = "";
  D.melding($("iMelding"), "");
  inlogBelofte = new Promise((resolve) => {
    const klaar = (ok) => {
      inlogBelofte = null;
      if (dlg.open) dlg.close();
      $("inlogform").onsubmit = null;
      $("iLater").onclick = null;
      dlg.oncancel = null;
      resolve(ok);
    };
    $("inlogform").onsubmit = async (e) => {
      e.preventDefault();
      const r = await D.api("/api/dashboard/auth/inloggen", {
        method: "POST", geenOmleiding: true, body: { naam: $("iNaam").value.trim(), wachtwoord: $("iWw").value },
      });
      if (r.ok && r.data && r.data.naam) {
        S.naam = r.data.naam; S.inlogNodig = false;
        kv.set("naam", S.naam).catch(() => {});
        zetStatus(); klaar(true);
        leegWachtrij().then(() => synchroniseer(false)).then(tekenNaSync);
      } else if (r.status === 0) D.melding($("iMelding"), TT.inlog.geenVerbinding, true);
      else D.melding($("iMelding"), TT.inlog.fout, true);
    };
    $("iLater").onclick = () => klaar(false);
    dlg.oncancel = (e) => { e.preventDefault(); klaar(false); };
    if (typeof dlg.showModal === "function") dlg.showModal(); else dlg.setAttribute("open", "");
  });
  return inlogBelofte;
}

// ---------------- tabs ----------------
const TABS = ["plannen", "lopen", "vandaag", "overzicht"];
function kiesTab(t) {
  S.tab = t;
  TABS.forEach((x) => { $("t-" + x).setAttribute("aria-selected", String(x === t)); $("p-" + x).hidden = x !== t; });
  if (t === "lopen") { zetWeergave(S.weergave); startLocatie(); }
  if (t === "vandaag") tekenVandaag();
  if (t === "overzicht") tekenOverzicht();
  if (t === "plannen") tekenBuurten();
}

// ---------------- plaatsen laden ----------------
async function laadPlaatsen() {
  const r = await api("plaatsen");
  if (r.ok && r.data) { S.plaatsen = r.data.plaatsen || []; kv.set("plaatsen", S.plaatsen).catch(() => {}); }
  else {
    if (r.status === 401) vraagInlog();
    S.plaatsen = (await kv.get("plaatsen")) || [];
  }
  const sel = $("plaats");
  sel.textContent = "";
  if (!S.plaatsen.length) { const o = el("option", null, TT.plannen.geenPlaatsen); o.value = ""; sel.appendChild(o); }
  S.plaatsen.forEach((p) => {
    const o = el("option", null, vul(TT.plannen.plaatsOptie, { naam: p.naam, aantal: getal(p.aantal) }));
    o.value = p.id;
    sel.appendChild(o);
  });
  if (S.plaatsId) sel.value = S.plaatsId;
}

async function laadPlaats(id) {
  const teller = ++S.laadTeller;
  S.plaatsId = id;
  kv.set("laatstePlaats", id).catch(() => {});
  $("plaats").value = id;
  let info = null;
  const r = await api("plaatsen/" + encodeURIComponent(id));
  if (teller !== S.laadTeller) return;
  if (r.ok && r.data) {
    info = { plaats: r.data.plaats, buurten: r.data.buurten, trilling: r.data.trilling };
    kv.set("plaats:" + id, info).catch(() => {});
  } else {
    if (r.status === 401) vraagInlog();
    info = await kv.get("plaats:" + id);
  }
  if (!info) { toon(TT.status.plaatsNietBeschikbaar); return; }
  S.plaats = info.plaats; S.buurten = info.buurten; S.trilling = info.trilling || {};
  S.buurtPer = new Map(S.buurten.map((b) => [b.code, b]));

  // adressen: uit de cache als de plaats niet is bijgewerkt, anders per buurt in groepen van vier
  const cache = await kv.get("adressen:" + id);
  if (teller !== S.laadTeller) return;
  if (cache && cache.bijgewerkt === S.plaats.bijgewerkt) S.adressen = cache.adressen;
  else if (r.ok) {
    const alle = [];
    const codes = S.buurten.map((b) => b.code);
    let mislukt = false;
    for (let i = 0; i < codes.length && !mislukt; i += 4) {
      const res = await Promise.all(codes.slice(i, i + 4).map((c) => api(`plaatsen/${encodeURIComponent(id)}/buurten/${encodeURIComponent(c)}/adressen`)));
      for (const x of res) { if (x.ok && x.data) alle.push(...x.data.adressen); else mislukt = true; }
    }
    if (teller !== S.laadTeller) return;
    if (mislukt) { toon(TT.status.plaatsNietBeschikbaar); S.adressen = cache ? cache.adressen : []; }
    else { S.adressen = alle; kv.set("adressen:" + id, { bijgewerkt: S.plaats.bijgewerkt, adressen: alle }).catch(() => {}); }
  } else S.adressen = cache ? cache.adressen : [];

  const bewaard = await kv.get("stand:" + id);
  if (teller !== S.laadTeller) return;
  S.stand = bewaard ? bewaard.stand : {};
  S.tot = bewaard ? bewaard.tot : "";
  S.volgend = null;
  bewaardePendingToepassen();
  await synchroniseer(true);
  if (teller !== S.laadTeller) return;
  bouwIndex();
  S.huidigeStraat = null;
  tekenAlles();
  laadKlantStraten(teller);
}

// K10: in welke straten de klantenmodule al een klant of traject heeft ({straat, klant:true}). Alleen in het geheugen:
// niets hiervan komt op het toestel, dus ook niets dat bij uitloggen gewist moet worden. Zonder bereik blijft het bij
// de afspraken uit de bezoeken.
async function laadKlantStraten(teller) {
  const naam = S.plaats && S.plaats.naam;
  if (!naam) return;
  const r = await D.api("/api/dashboard/klanten/straten?plaats=" + encodeURIComponent(naam), { geenOmleiding: true });
  if (teller !== S.laadTeller || !r.ok || !r.data || !Array.isArray(r.data.straten)) return;
  S.klantStraten = new Set(r.data.straten.filter((x) => x.klant === true).map((x) => V.slug(x.straat)));
  bouwIndex();
  if (S.tab === "lopen") tekenStraten();
}

function bewaardePendingToepassen() {
  for (const item of S.wacht) if (item.plaats === S.plaatsId) V.pasToe(S.stand, { ...item.ev, wacht: true });
}

// ---------------- synchroniseren ----------------
async function synchroniseer(volledig) {
  const id = S.plaatsId, teller = S.laadTeller;
  if (!id) return;
  const q = !volledig && S.tot ? "?na=" + encodeURIComponent(S.tot) : "";
  const r = await api(`plaatsen/${encodeURIComponent(id)}/bezoeken${q}`);
  if (teller !== S.laadTeller || id !== S.plaatsId) return; // plaats intussen gewisseld
  if (r.status === 401) { vraagInlog(); return; }
  if (!r.ok || !r.data) { zetStatus(); return; }
  if (r.data.adressen) {
    S.stand = {};
    for (const [a, info] of Object.entries(r.data.adressen)) {
      S.stand[a] = { hist: V.entryNaarHist(a, info), n: info.n, ex: info.ex };
    }
  } else for (const ev of r.data.nieuw || []) V.pasToe(S.stand, ev);
  bewaardePendingToepassen();
  if (r.data.tot && r.data.tot > S.tot) S.tot = r.data.tot;
  S.bijgewerkt = new Date();
  kv.set("stand:" + id, { stand: S.stand, tot: S.tot }).catch(() => {});
  zetStatus();
}

async function ververseInstellingen() {
  const id = S.plaatsId, teller = S.laadTeller;
  if (!id) return;
  const r = await api(`plaatsen/${encodeURIComponent(id)}/instellingen`);
  if (!r.ok || !r.data || teller !== S.laadTeller) return;
  S.trilling = r.data.trilling || {};
  for (const b of S.buurten) {
    const k = r.data.keuzes && r.data.keuzes[b.code];
    if (k) { b.aan = !!k.aan; b.aanDoor = k.wie; b.aanOp = k.wanneer; }
  }
  kv.set("plaats:" + id, { plaats: S.plaats, buurten: S.buurten, trilling: S.trilling }).catch(() => {});
}

let peilt = false;
async function peil() {
  if (peilt || document.hidden || !navigator.onLine || !S.plaatsId) return;
  peilt = true;
  try {
    await leegWachtrij();
    await synchroniseer(false);
    if (++S.instellingenTik % 10 === 0) await ververseInstellingen();
    bouwIndex();
    tekenNaSync();
  } finally { peilt = false; }
}

// ---------------- wachtrij ----------------
let bezigMetWachtrij = false;
async function leegWachtrij() {
  if (bezigMetWachtrij || !navigator.onLine) { zetStatus(); return; }
  bezigMetWachtrij = true;
  try {
    await verstuurWachtrij({
      alle: () => wachtrij.alle(),
      verwijder: (id) => wachtrij.verwijder(id),
      zet: (item) => wachtrij.zet(item),
      api: (pad, o) => api(pad, o),
      vraagInlog,
      wie: () => S.naam,
      geheugen: S.wacht,
      naGelukt: (item, data) => {
        S.wacht = S.wacht.filter((x) => x.id !== item.id);
        if (item.plaats === S.plaatsId) V.pasToe(S.stand, data);
      },
      naAfgekeurd: (item) => {
        const lokaal = S.wacht.find((x) => x.id === item.id);
        if (lokaal) lokaal.afgekeurd = item.afgekeurd;
      },
    });
  } finally {
    bezigMetWachtrij = false;
    if (S.plaatsId) kv.set("stand:" + S.plaatsId, { stand: S.stand, tot: S.tot }).catch(() => {});
    zetStatus();
    tekenNaSync();
  }
}

async function zetInWachtrij(ev) {
  const item = { id: ev.id, plaats: S.plaatsId, ev, toegevoegd: Date.now(), wie: S.naam || null };
  S.wacht.push(item);
  try { await wachtrij.zet(item); S.bewarenMislukt = false; } catch { S.bewarenMislukt = true; }
  zetStatus();
}

// ---------------- index en straten ----------------
function buurtAan(code) {
  const b = S.buurtPer.get(code);
  return b ? b.aan !== false : true;
}
function bouwIndex() {
  const lijst = S.adressen.slice();
  const bekend = new Set(lijst.map((a) => a.id));
  for (const [id, info] of Object.entries(S.stand)) {
    if (!bekend.has(id) && info.ex) {
      const m = String(info.ex.n).match(/^(\d+)(.*)$/);
      lijst.push({ id, s: info.ex.s, n: m ? Number(m[1]) : 0, l: m ? m[2].trim() : info.ex.n, t: "", pc: "", x: info.ex.x, y: info.ex.y, bj: null, m2: null, ty: "onbekend", bu: "overig", ex: info.ex });
    }
  }
  S.perId = new Map(lijst.map((a) => [a.id, a]));
  S.alleAdressen = lijst;
  const perStraat = new Map();
  for (const a of lijst) {
    if (!buurtAan(a.bu)) continue;
    if (!perStraat.has(a.s)) perStraat.set(a.s, []);
    perStraat.get(a.s).push(a);
  }
  S.straten = V.sorteerStraten([...perStraat.entries()].map(([naam, adr]) => {
    adr.sort((p, q) => p.n - q.n || V.nrLabel(p).localeCompare(V.nrLabel(q), "nl"));
    return { naam, adressen: adr, rang: V.straatRang(adr, S.trilling, S.stand, S.klantStraten.has(V.slug(naam))) };
  }));
  if (S.huidigeStraat) S.huidigeStraat = S.straten.find((s) => s.naam === S.huidigeStraat.naam) || null;
}
const statusVan = (a) => { const h = V.huidige(S.stand[a.id]); return h ? h.st : null; };

// ---------------- plannen ----------------
function tekenBuurten() {
  const box = $("buurten");
  box.textContent = "";
  if (!S.plaats) { box.appendChild(el("p", "bron", TT.plannen.buurtenLeeg)); return; }
  for (const b of S.buurten) {
    const rij = el("label", "buurt");
    rij.htmlFor = "cb-" + b.code;
    const cb = el("input");
    cb.type = "checkbox"; cb.id = "cb-" + b.code; cb.checked = b.aan !== false;
    cb.addEventListener("change", async () => {
      const nieuw = cb.checked;
      const r = await api(`plaatsen/${encodeURIComponent(S.plaatsId)}/buurten/${encodeURIComponent(b.code)}/keuze`, { method: "PUT", body: { aan: nieuw } });
      if (r.ok && r.data) { b.aan = nieuw; b.aanDoor = r.data.wie; b.aanOp = r.data.wanneer; D.melding($("buurtMelding"), ""); bouwIndex(); tekenNaSync(); }
      else { cb.checked = !nieuw; D.melding($("buurtMelding"), TT.plannen.keuzeMislukt, true); }
      tekenBuurten();
    });
    const d = el("div");
    d.appendChild(el("div", "naam", b.naam));
    const cijfers = vul(TT.plannen.buurtCijfers, {
      woningen: b.woningen == null ? TT.plannen.onbekend : getal(b.woningen),
      koop: b.koop == null ? TT.plannen.onbekend : b.koop + "%",
      corp: b.corp == null ? TT.plannen.onbekend : b.corp + "%",
    });
    d.appendChild(el("div", "sub", vul(TT.plannen.buurtAdressen, { n: getal(b.aantal) })));
    d.appendChild(el("div", "sub", cijfers));
    if (b.koop != null || b.corp != null) {
      const balk = el("div", "balk");
      balk.setAttribute("aria-hidden", "true");
      const k = el("span", "koop"); k.style.width = (b.koop || 0) + "%";
      const c = el("span", "corp"); c.style.width = (b.corp || 0) + "%";
      balk.appendChild(k); balk.appendChild(c);
      d.appendChild(balk);
    }
    if (b.corp == null) d.appendChild(el("div", "let", TT.plannen.onbekendMelding));
    else if (b.corp >= V.CORPORATIE_GRENS) d.appendChild(el("div", "let", TT.plannen.veelCorporatie));
    if (b.aanDoor) d.appendChild(el("div", "sub", vul(TT.plannen.keuzeDoor, { wie: b.aanDoor })));
    rij.appendChild(cb);
    rij.appendChild(d);
    box.appendChild(rij);
  }
}

$("plaats").addEventListener("change", (e) => { if (e.target.value) laadPlaats(e.target.value); });
$("nieuwKnop").addEventListener("click", function () {
  const v = $("nieuwVak");
  v.hidden = !v.hidden;
  this.setAttribute("aria-expanded", String(!v.hidden));
  if (!v.hidden) $("nieuwNaam").focus();
});

async function zetOp(pad, body) {
  const r = await api(pad, { method: "PUT", body });
  if (!r.ok) throw Object.assign(new Error((r.data && r.data.fout) || String(r.status)), { status: r.status });
  return r.data;
}

$("ophalen").addEventListener("click", async () => {
  const naam = $("nieuwNaam").value.trim();
  const meld = (t) => { $("ophaalStatus").textContent = t; };
  if (!naam) { meld(TT.plannen.leeg); return; }
  $("ophalen").disabled = true;
  try {
    const res = await haalPlaatsOp(naam, (stap, n) => meld(vul(TT.plannen.stap[stap], { n: getal(n) })));
    if (!res.adressen.length) { meld(vul(TT.plannen.stap.geenAdressen, { naam })); return; }
    const id = V.slug(naam);
    const versie = uid().slice(-12); // nieuwe delen komen onder een eigen versie, de meta wijst die pas als laatste aan
    const perBuurt = new Map();
    for (const a of res.adressen) { if (!perBuurt.has(a.bu)) perBuurt.set(a.bu, []); perBuurt.get(a.bu).push(a); }
    let i = 0;
    for (const b of res.buurten) {
      meld(vul(TT.plannen.stap.opslaan, { i: ++i, n: res.buurten.length }));
      const lijst = perBuurt.get(b.code) || [];
      const delen = [];
      for (let j = 0; j < lijst.length; j += 1000) delen.push(lijst.slice(j, j + 1000));
      for (let n = 0; n < delen.length; n++) {
        await zetOp(`plaatsen/${id}/buurten/${encodeURIComponent(b.code)}/delen/${n}?v=${versie}`, { adressen: delen[n] });
      }
      await zetOp(`plaatsen/${id}/buurten/${encodeURIComponent(b.code)}?v=${versie}`, {
        naam: b.naam, koop: b.koop, corp: b.corp, woningen: b.woningen, aantal: lijst.length, delen: delen.length,
      });
    }
    await zetOp(`plaatsen/${id}`, { naam, versie, aantal: res.adressen.length, buurten: res.buurten.map((b) => b.code) });
    await laadPlaatsen();
    await laadPlaats(id);
    meld(vul(TT.plannen.stap.klaar, { naam, adressen: getal(res.adressen.length), buurten: res.buurten.length, gekoppeld: getal(res.gekoppeld) }));
    $("nieuwNaam").value = "";
  } catch (e) {
    meld(vul(TT.plannen.stap.mislukt, { reden: (e && e.message) || "" }) + " " + TT.plannen.stap.netwerk);
  } finally { $("ophalen").disabled = false; }
});

// ---------------- lopen: kaart ----------------
function maakDeKaart() {
  if (kaartCtl) return;
  kaartCtl = maakKaart($("kaart"), {
    onKies: (a) => openUitkomst(a),
    tekst: { attributie: 'Kaart &copy; <a href="https://www.kadaster.nl" target="_blank" rel="noopener">Kadaster</a> via PDOK' },
    letters: Object.fromEntries(V.STATUS_IDS.map((id) => [id, V.STATUS[id].letter])),
  });
}
function tekenKaart() {
  if (!kaartCtl) return;
  kaartCtl.zet(S.straten, S.stand, S.volgend ? S.volgend.adres.id : null);
}
function tekenLegenda() {
  const lg = $("kaartLegenda");
  lg.textContent = "";
  const stuk = (klasse, tekst) => {
    const s = el("span");
    const i = el("i", klasse);
    s.appendChild(i);
    s.appendChild(document.createTextNode(tekst));
    lg.appendChild(s);
  };
  stuk("", TT.lopen.legendaNog);
  V.STATUS_IDS.forEach((id) => stuk("st-" + id, `${V.STATUS[id].letter} ${naamVan(id)}`));
}

// ---------------- lopen: locatie en volgende huis ----------------
let locatieGestart = false;
function startLocatie() {
  if (locatieGestart || !navigator.geolocation) return;
  locatieGestart = true;
  navigator.geolocation.watchPosition((pos) => {
    S.positie = { lat: pos.coords.latitude, lon: pos.coords.longitude };
    if (kaartCtl) kaartCtl.positie(S.positie.lat, S.positie.lon);
    if (Date.now() - S.laatsteKeuze > 60000) {
      const d = V.dichtstbij(S.straten.flatMap((s) => s.adressen), S.positie.lat, S.positie.lon, S.stand, 40);
      if (d) zetVolgend(d.adres, "dichtstbij", d.m);
    }
  }, () => { /* geen toestemming: de app werkt ook zonder */ }, { enableHighAccuracy: true, maximumAge: 10000 });
}
function zetVolgend(adres, soort, m) {
  S.volgend = adres ? { adres, soort, m } : null;
  const balk = $("volgendeBalk");
  balk.hidden = !adres;
  if (adres) {
    const kop = soort === "dichtstbij" ? TT.lopen.dichtstbij : TT.lopen.volgendeKop;
    $("volgendeTekst").textContent = `${kop}: ${adresTekst(adres)}${m != null ? ", " + m + " m" : ""}`;
    $("volgendeKnop").textContent = TT.lopen.volgendeKnop;
  }
  tekenKaart();
}
$("volgendeKnop").addEventListener("click", () => { if (S.volgend) openUitkomst(S.volgend.adres); });
$("opKaartKnop").addEventListener("click", () => {
  if (!S.volgend) return;
  zetWeergave("kaart");
  if (kaartCtl) kaartCtl.middenOp(S.volgend.adres);
});

// ---------------- lopen: weergave en lijsten ----------------
function zetWeergave(w) {
  S.weergave = w;
  $("w-kaart").setAttribute("aria-pressed", String(w === "kaart"));
  $("w-lijst").setAttribute("aria-pressed", String(w === "lijst"));
  $("kaartView").hidden = w !== "kaart";
  $("lijstView").hidden = w !== "lijst";
  if (w === "kaart") {
    maakDeKaart();
    if (kaartCtl) {
      kaartCtl.herteken();
      if (S.kaartPlaats !== S.plaatsId && S.straten.length) {
        kaartCtl.passend(S.straten.flatMap((s) => s.adressen));
        S.kaartPlaats = S.plaatsId;
      }
      tekenKaart();
    }
  } else if (S.huidigeStraat) tekenAdressen(); else tekenStraten();
}
$("w-kaart").addEventListener("click", () => zetWeergave("kaart"));
$("w-lijst").addEventListener("click", () => zetWeergave("lijst"));
$("autoVolgende").addEventListener("change", (e) => { S.autoVolgende = e.target.checked; kv.set("autoVolgende", S.autoVolgende).catch(() => {}); });

function tekenStraten() {
  const box = $("straten");
  box.textContent = "";
  if (!S.straten.length) { box.appendChild(el("p", "bron", S.plaats ? TT.lopen.geenStraten : TT.lopen.kiesPlaats)); return; }
  for (const s of S.straten) {
    const todo = s.adressen.filter((a) => !statusVan(a)).length;
    const b = el("button", "rijknop");
    b.type = "button";
    const l = el("div", "links");
    l.appendChild(el("span", "naam", s.naam));
    const jaren = s.adressen.map((a) => a.bj).filter(Boolean).sort((p, q) => p - q);
    const typen = {};
    s.adressen.forEach((a) => { typen[a.ty] = (typen[a.ty] || 0) + 1; });
    const hoofd = Object.entries(typen).sort((p, q) => q[1] - p[1])[0];
    const delen = [vul(TT.lopen.adresStraat, { adressen: s.adressen.length })];
    if (jaren.length) delen.push(vul(TT.lopen.bouwjaar, { jaar: jaren[Math.floor(jaren.length / 2)] }));
    if (hoofd && hoofd[0] !== "onbekend") delen.push(vul(TT.lopen.vooral, { type: TT.lopen.typen[hoofd[0]] }));
    l.appendChild(el("span", "sub", delen.join(", ")));
    const bd = el("div", "badges");
    if (s.rang.voorrang > 0) bd.appendChild(el("span", "badge", TT.lopen.voorrangTrilling));
    if (s.rang.onbekend) bd.appendChild(el("span", "badge let", TT.lopen.trillingInvullen));
    if (s.rang.klant) bd.appendChild(el("span", "badge", TT.lopen.klantInStraat));
    if (bd.children.length) l.appendChild(bd);
    b.appendChild(l);
    b.appendChild(el("span", "voortgang", todo ? vul(TT.lopen.teDoen, { n: todo }) : TT.lopen.klaar));
    b.addEventListener("click", () => { S.huidigeStraat = s; $("stratenView").hidden = true; $("adressenView").hidden = false; tekenAdressen(); window.scrollTo(0, 0); });
    box.appendChild(b);
  }
}
$("terug").addEventListener("click", () => { S.huidigeStraat = null; $("adressenView").hidden = true; $("stratenView").hidden = false; tekenStraten(); });
document.querySelectorAll("#kantGroep button").forEach((b) => b.addEventListener("click", () => {
  S.kant = b.dataset.kant;
  document.querySelectorAll("#kantGroep button").forEach((x) => x.setAttribute("aria-pressed", String(x === b)));
  tekenAdressen();
}));

function tekenAdressen() {
  const s = S.huidigeStraat;
  if (!s) return;
  $("straatNaam").textContent = s.naam;
  const gedaan = s.adressen.filter((a) => statusVan(a)).length;
  $("straatVoortgang").textContent = vul(TT.lopen.gedaan, { gedaan, totaal: s.adressen.length });
  const box = $("adressen");
  box.textContent = "";
  for (const a of s.adressen) {
    if (S.kant === "even" && a.n % 2 !== 0) continue;
    if (S.kant === "oneven" && a.n % 2 !== 1) continue;
    const st = statusVan(a);
    const h = V.huidige(S.stand[a.id]);
    const b = el("button", "rijknop" + (st ? " klaar" : "") + (st && V.OVERSLAAN[st] ? " overslaan" : ""));
    b.type = "button";
    const l = el("div", "links");
    const kop = el("span", "naam");
    kop.appendChild(el("span", "nr", V.nrLabel(a)));
    l.appendChild(kop);
    const onder = [
      a.bj ? vul(TT.lopen.bouwjaar, { jaar: a.bj }) : null,
      a.m2 ? vul(TT.lopen.m2, { n: a.m2 }) : null,
      a.ty !== "onbekend" ? TT.lopen.typen[a.ty] : null,
      h ? `${datum(h.ts)} ${h.w}` : null,
    ].filter(Boolean).join(", ");
    l.appendChild(el("span", "sub", onder));
    b.appendChild(l);
    const chip = el("span", "chip" + (st ? " st-" + st : " nog"), st ? `${V.STATUS[st].letter} ${naamVan(st)}` : TT.lopen.nogDoen);
    b.appendChild(chip);
    b.setAttribute("aria-label", vul(TT.lopen.adresLabel, { straat: s.naam, nr: V.nrLabel(a), status: st ? naamVan(st) : TT.lopen.nogDoen }));
    b.addEventListener("click", () => openUitkomst(a));
    box.appendChild(b);
  }
  tekenTrilling();
}

function tekenTrilling() {
  const s = S.huidigeStraat, box = $("trilling");
  if (!s) return;
  // Een veld waar nu in getypt wordt, nooit opnieuw tekenen.
  if (box.contains(document.activeElement) && document.activeElement.tagName === "INPUT") return;
  box.textContent = "";
  const pcs = [...new Set(s.adressen.map((a) => a.pc).filter(Boolean))].sort();
  for (const pc of pcs) {
    const rij = el("div", "trilrij");
    rij.appendChild(el("span", "pc", pc));
    const inp = el("input");
    inp.type = "number"; inp.inputMode = "decimal"; inp.step = "0.1"; inp.min = "0";
    inp.placeholder = TT.lopen.trillingPlaats; inp.id = "tril-" + pc;
    inp.setAttribute("aria-label", vul(TT.lopen.trillingLabel, { pc }));
    const t = S.trilling[pc];
    if (t && t.mms != null) inp.value = t.mms;
    const knop = el("button", "rand", TT.lopen.opslaan);
    knop.type = "button";
    knop.addEventListener("click", async () => {
      const r = await api(`plaatsen/${encodeURIComponent(S.plaatsId)}/trilling/${pc}`, { method: "PUT", body: { mms: inp.value === "" ? null : Number(inp.value) } });
      if (r.ok && r.data) { S.trilling[pc] = r.data; bouwIndex(); toon(vul(TT.lopen.trillingOpgeslagen, { pc })); tekenTrilling(); tekenNaSync(); }
      else toon(TT.plannen.keuzeMislukt);
    });
    rij.appendChild(inp);
    rij.appendChild(knop);
    if (t && t.wie) rij.appendChild(el("span", "meta", vul(TT.lopen.trillingDoor, { wie: t.wie, datum: datum(t.wanneer) })));
    box.appendChild(rij);
  }
}

$("extraKnop").addEventListener("click", () => {
  const s = S.huidigeStraat, nr = $("extraNr").value.trim();
  if (!s || !nr) return;
  const m = nr.match(/^(\d+)(.*)$/);
  const a = {
    id: V.handmatigId(s.naam, nr), s: s.naam, n: m ? Number(m[1]) : 0, l: m ? m[2].trim() : nr, t: "", pc: "",
    x: S.positie ? S.positie.lon : null, y: S.positie ? S.positie.lat : null, bj: null, m2: null, ty: "onbekend",
    bu: s.adressen[0] ? s.adressen[0].bu : "overig",
  };
  a.ex = { s: a.s.slice(0, 80), n: nr.slice(0, 12), x: a.x, y: a.y };
  $("extraNr").value = "";
  openUitkomst(a);
});

// ---------------- nieuwe klant uit een bezoek (K10) ----------------
// Het adres gaat via sessionStorage naar het nieuw-klant-scherm, niet via de URL: in de URL staat alleen het
// id van het bezoek. sessionStorage wordt bij uitloggen gewist (D.wisCache). Het scherm koppelt het id aan de relatie.
const KLANT_PAD = "/dashboard/klanten/nieuw.html";
function klantLink(a, eventId) {
  try { sessionStorage.setItem("dashboard.deurklant." + eventId, JSON.stringify(V.klantVoorstel(a, S.plaats && S.plaats.naam, S.plaatsId, S.trilling[a.pc] && S.trilling[a.pc].mms))); } catch { /* het scherm opent dan zonder voorinvulling */ }
  return `${KLANT_PAD}?herkomst=deur&event=${encodeURIComponent(eventId)}`;
}

// ---------------- uitkomst kiezen en vastleggen ----------------
let doel = null, vorigeFocus = null;
V.STATUS_IDS.forEach((id) => {
  const b = el("button", "opt");
  b.type = "button";
  b.dataset.status = id;
  const lt = el("span", "letter st-" + id, V.STATUS[id].letter);
  lt.setAttribute("aria-hidden", "true");
  b.appendChild(lt);
  b.appendChild(el("span", null, naamVan(id)));
  b.addEventListener("click", () => kies(id));
  $("opties").appendChild(b);
});

function openUitkomst(a) {
  doel = a;
  vorigeFocus = document.activeElement;
  $("uitkomstTitel").textContent = adresTekst(a);
  const info = S.stand[a.id];
  const h = V.huidige(info);
  const kenmerken = [a.bj ? vul(TT.lopen.bouwjaar, { jaar: a.bj }) : null, a.m2 ? vul(TT.lopen.m2, { n: a.m2 }) : null, a.ty !== "onbekend" ? TT.lopen.typen[a.ty] : null].filter(Boolean).join(", ");
  $("uitkomstSub").textContent = h
    ? vul(TT.lopen.eerder, { uitkomst: naamVan(h.st), datum: datum(h.ts), wie: h.w, n: V.aantalBezoeken(info) })
    : kenmerken;
  const kl = $("klantDialoog");
  kl.hidden = !(h && h.st === "afspraak" && h.id);
  if (!kl.hidden) kl.setAttribute("href", klantLink(a, h.id));
  $("notitie").value = "";
  $("notitieVak").hidden = true;
  $("notitieKnop").setAttribute("aria-expanded", "false");
  const dlg = $("uitkomst");
  if (typeof dlg.showModal === "function") { if (!dlg.open) dlg.showModal(); } else dlg.setAttribute("open", "");
  $("opties").firstChild.focus();
}
function sluitUitkomst() {
  const dlg = $("uitkomst");
  if (dlg.open) dlg.close();
  if (vorigeFocus && vorigeFocus.focus && document.contains(vorigeFocus)) vorigeFocus.focus();
}
$("annuleer").addEventListener("click", sluitUitkomst);
$("uitkomst").addEventListener("click", (e) => { if (e.target === $("uitkomst")) sluitUitkomst(); });
$("notitieKnop").addEventListener("click", function () {
  const v = $("notitieVak");
  v.hidden = !v.hidden;
  this.setAttribute("aria-expanded", String(!v.hidden));
  if (!v.hidden) $("notitie").focus();
});

function nieuwBezoek(a, status, extra = {}) {
  const t = S.trilling[a.pc];
  const b = S.buurtPer.get(a.bu);
  return {
    id: uid(), a: a.id, st: status, ts: iso(), no: extra.no || "", w: S.naam,
    bu: a.bu || "", ty: a.ty || "onbekend", bj: a.bj ?? null, pc: a.pc || "",
    mms: t && t.mms != null ? t.mms : null, koop: b ? b.koop : null, corp: b ? b.corp : null,
    ex: a.ex, ...extra,
  };
}

async function kies(status) {
  const a = doel;
  if (!a) return;
  const ev = nieuwBezoek(a, status, { no: $("notitie").value.trim() });
  doel = null;
  V.pasToe(S.stand, { ...ev, wacht: true });
  S.laatste = { a, ev };
  S.laatsteKeuze = Date.now();
  sluitUitkomst();
  if (navigator.vibrate) navigator.vibrate(25);
  bouwIndex();
  const straat = S.straten.find((s) => s.naam === a.s);
  const volgende = straat ? V.volgendeHuis(straat.adressen, a, S.stand) : null;
  zetVolgend(volgende, "volgende");
  tekenNaSync();
  toon(vul(TT.uitkomst.vastgelegd, { adres: adresTekst(a), uitkomst: naamVan(status) }), true, status === "afspraak" ? klantLink(a, ev.id) : null);
  await zetInWachtrij(ev);
  if (S.autoVolgende && volgende) openUitkomst(volgende);
  leegWachtrij();
}

$("ongedaan").addEventListener("click", async () => {
  if (!S.laatste) return;
  const { a, ev } = S.laatste;
  S.laatste = null;
  // Verwijst naar het id van het bezoek, nooit naar "het laatste".
  const u = { id: uid(), a: a.id, st: null, ongedaan: ev.id, ts: iso(), w: S.naam, ex: a.ex };
  V.pasToe(S.stand, { ...u, wacht: true });
  $("toast").hidden = true;
  bouwIndex();
  zetVolgend(a, "volgende"); // het teruggezette huis staat weer klaar
  tekenNaSync();
  toon(TT.uitkomst.ongedaanGedaan);
  await zetInWachtrij(u);
  leegWachtrij();
});

// ---------------- vandaag ----------------
function tekenVandaag() {
  const afg = S.wacht.filter((x) => x.afgekeurd);
  const box = $("afgekeurd");
  box.textContent = "";
  box.hidden = !afg.length;
  if (afg.length) {
    box.className = "afgekeurd";
    box.appendChild(el("h2", null, TT.vandaag.afgekeurdKop));
    box.appendChild(el("p", "bron", TT.vandaag.afgekeurdUitleg));
    for (const x of afg) {
      const rij = el("div", "rij2");
      const a = S.perId && S.perId.get(x.ev.a);
      rij.appendChild(el("span", null, `${a ? adresTekst(a) : TT.vandaag.onbekendAdres}, ${x.afgekeurd}`));
      const k = el("button", "rand", TT.vandaag.verwijder);
      k.type = "button";
      k.addEventListener("click", async () => {
        await wachtrij.verwijder(x.id);
        S.wacht = S.wacht.filter((w) => w.id !== x.id);
        tekenVandaag();
      });
      const opnieuw = el("button", null, TT.vandaag.opnieuw);
      opnieuw.type = "button";
      opnieuw.addEventListener("click", async () => {
        x.afgekeurd = null;
        try { await wachtrij.zet(x); } catch { /* blijft in het geheugen */ }
        tekenVandaag();
        leegWachtrij();
      });
      rij.appendChild(opnieuw);
      rij.appendChild(k);
      box.appendChild(rij);
    }
  }
  const dag = dagSleutel(Date.now());
  const regels = [];
  for (const [id, info] of Object.entries(S.stand)) {
    const vandaagH = V.effectief(info.hist).filter((h) => dagSleutel(h.ts) === dag);
    if (vandaagH.length) regels.push({ a: S.perId && S.perId.get(id), h: vandaagH[vandaagH.length - 1] });
  }
  regels.sort((p, q) => String(q.h.ts).localeCompare(String(p.h.ts)));
  const ul = $("log");
  ul.textContent = "";
  if (!regels.length) ul.appendChild(el("li", "bron", TT.vandaag.leeg));
  for (const { a, h } of regels) {
    const li = el("li");
    li.appendChild(el("span", null, `${a ? adresTekst(a) : TT.vandaag.onbekendAdres}, ${naamVan(h.st)}${h.no ? ", " + h.no : ""}`));
    li.appendChild(el("span", "meta", `${tijd(h.ts)} ${h.w}${h.wacht ? ", " + TT.vandaag.wacht : ""}`));
    ul.appendChild(li);
  }
  const t = $("telling");
  t.textContent = "";
  t.appendChild(el("span", "chip", vul(TT.vandaag.deuren, { n: regels.length })));
  V.STATUS_IDS.forEach((k) => {
    const n = regels.filter((r) => r.h.st === k).length;
    if (n) t.appendChild(el("span", "chip st-" + k, `${n} ${naamVan(k).toLowerCase()}`));
  });
}

// ---------------- overzicht ----------------
function vulFilters() {
  const wie = $("ovWie");
  const keuze = wie.value;
  const namen = new Set([S.naam].filter(Boolean));
  for (const info of Object.values(S.stand)) for (const h of info.hist) if (h.w) namen.add(h.w);
  wie.textContent = "";
  const o = el("option", null, TT.overzicht.samen); o.value = ""; wie.appendChild(o);
  [...namen].sort().forEach((n) => { const x = el("option", null, n); x.value = n; wie.appendChild(x); });
  wie.value = keuze;
  const per = $("ovPeriode");
  if (!per.options.length) {
    [["", TT.overzicht.alles], ["7", TT.overzicht.zevenDagen], ["30", TT.overzicht.dertigDagen]].forEach(([v, t]) => { const x = el("option", null, t); x.value = v; per.appendChild(x); });
  }
}
function gefilterd() {
  const wie = $("ovWie").value, dagen = Number($("ovPeriode").value) || 0;
  const vanaf = dagen ? Date.now() - dagen * 864e5 : 0;
  const uit = new Map();
  for (const [id, info] of Object.entries(S.stand)) {
    const h = V.effectief(info.hist).filter((x) => (!wie || x.w === wie) && (!vanaf || new Date(x.ts).getTime() >= vanaf));
    if (h.length) uit.set(id, h);
  }
  return uit;
}
$("ovWie").addEventListener("change", tekenOverzicht);
$("ovPeriode").addEventListener("change", tekenOverzicht);

function tekenOverzicht() {
  vulFilters();
  const kop = $("ovKop");
  if (!kop.children.length) {
    const K = TT.overzicht.kolom;
    [K.straat, K.gedaan, K.nietThuis, K.afspr, K.per100].forEach((t) => { const th = el("th", null, t); th.scope = "col"; kop.appendChild(th); });
  }
  if (!S.plaats) return;
  const f = gefilterd();
  const per = (a, g) => (g ? (Math.round((a / g) * 1000) / 10).toLocaleString("nl-NL") : "0");
  let gedaan = 0, nt = 0, afs = 0;
  const groepen = new Map();
  for (const a of S.alleAdressen || []) {
    const bn = S.buurtPer.get(a.bu);
    const g = bn ? bn.naam : TT.overzicht.overig;
    if (!groepen.has(g)) groepen.set(g, new Map());
    const straten = groepen.get(g);
    if (!straten.has(a.s)) straten.set(a.s, { totaal: 0, gedaan: 0, nt: 0, afs: 0 });
    const r = straten.get(a.s);
    r.totaal++;
    const h = f.get(a.id);
    if (!h) continue;
    r.gedaan++; gedaan++;
    if (h[h.length - 1].st === "nietthuis") { r.nt++; nt++; }
    if (h.some((x) => x.st === "afspraak")) { r.afs++; afs++; }
  }
  const k = $("kpis");
  k.textContent = "";
  [[gedaan, TT.overzicht.kpi.gedaan], [nt, TT.overzicht.kpi.nietThuis], [afs, TT.overzicht.kpi.afspraken], [per(afs, gedaan), TT.overzicht.kpi.per100]].forEach(([v, l]) => {
    const d = el("div", "kpi");
    d.appendChild(el("div", "getal", String(v)));
    d.appendChild(el("div", "lbl", l));
    k.appendChild(d);
  });
  const tb = $("ovTabel").querySelector("tbody");
  tb.textContent = "";
  for (const [g, straten] of [...groepen.entries()].sort((p, q) => p[0].localeCompare(q[0], "nl"))) {
    const rijen = [...straten.entries()].filter(([, r]) => r.gedaan).sort((p, q) => q[1].gedaan - p[1].gedaan);
    if (!rijen.length) continue;
    const tr = el("tr", "groep");
    const td = el("td", null, g);
    td.colSpan = 5;
    tr.appendChild(td);
    tb.appendChild(tr);
    for (const [naam, r] of rijen) {
      const rij = el("tr");
      [naam, `${r.gedaan} / ${r.totaal}`, r.nt, r.afs, per(r.afs, r.gedaan)].forEach((v) => rij.appendChild(el("td", null, String(v))));
      tb.appendChild(rij);
    }
  }
  if (!tb.children.length) {
    const tr = el("tr");
    const td = el("td", null, TT.overzicht.geen);
    td.colSpan = 5;
    tr.appendChild(td);
    tb.appendChild(tr);
  }
  const ul = $("ovLog");
  ul.textContent = "";
  const alle = [];
  for (const [id, h] of f) for (const x of h) alle.push({ a: S.perId.get(id), x });
  alle.sort((p, q) => String(q.x.ts).localeCompare(String(p.x.ts))).slice(0, 15).forEach(({ a, x }) => {
    const li = el("li");
    li.appendChild(el("span", null, `${a ? adresTekst(a) : TT.vandaag.onbekendAdres}, ${naamVan(x.st)}${x.no ? ", " + x.no : ""}`));
    li.appendChild(el("span", "meta", `${datum(x.ts)} ${x.w}`));
    ul.appendChild(li);
  });
}

$("export").addEventListener("click", async () => {
  if (!S.plaatsId) return;
  const meld = $("exportMelding");
  D.melding(meld, TT.overzicht.exportBezig);
  let r;
  try {
    r = await fetch(API + `plaatsen/${encodeURIComponent(S.plaatsId)}/export`, { credentials: "same-origin", signal: AbortSignal.timeout(30000) });
  } catch { D.melding(meld, TT.overzicht.exportMislukt, true); return; }
  if (r.status === 401) { D.melding(meld, ""); vraagInlog(); return; }
  if (!r.ok) { D.melding(meld, TT.overzicht.exportMislukt, true); return; }
  const blob = await r.blob();
  const link = el("a");
  link.href = URL.createObjectURL(blob);
  link.download = `deuren-${S.plaatsId}-${dagSleutel(Date.now())}.csv`;
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(link.href), 2000);
  D.melding(meld, "");
});

// ---------------- algemeen ----------------
function tekenAlles() { tekenBuurten(); tekenLegenda(); tekenNaSync(); if (S.tab === "lopen") zetWeergave(S.weergave); }
function tekenNaSync() {
  if (S.tab === "lopen") {
    if (S.weergave === "kaart") tekenKaart();
    else if (S.huidigeStraat) tekenAdressen(); else tekenStraten();
  }
  if (S.tab === "vandaag") tekenVandaag();
  if (S.tab === "overzicht") tekenOverzicht();
}

// Toont de adressenlijst van de straat waar dit adres in ligt, zodat de bezoeken op dat adres in beeld staan.
function openAdresLijst(adresId) {
  const a = adresId && S.perId.get(adresId);
  const straat = a && S.straten.find((s) => s.naam === a.s);
  if (!straat) return;
  kiesTab("lopen");
  S.huidigeStraat = straat;
  $("stratenView").hidden = true;
  $("adressenView").hidden = false;
  zetWeergave("lijst");
}

async function start() {
  vraagBlijvend();
  $("ophalen").disabled = false;
  TABS.forEach((t) => $("t-" + t).addEventListener("click", () => kiesTab(t)));
  $("inlogknop").addEventListener("click", () => vraagInlog());
  window.addEventListener("dashboard:sessie-verlopen", () => vraagInlog());
  window.addEventListener("online", () => { zetStatus(); peil(); });
  window.addEventListener("offline", zetStatus);
  document.addEventListener("visibilitychange", () => { if (!document.hidden) peil(); });
  setInterval(peil, 30000);

  S.autoVolgende = !!(await kv.get("autoVolgende"));
  $("autoVolgende").checked = S.autoVolgende;
  S.naam = await kv.get("naam");
  S.wacht = await wachtrij.alle();
  zetStatus();
  tekenLegenda();
  for (const id of ["klantToast", "klantDialoog"]) $(id).setAttribute("aria-label", TT.klant.aanmakenLabel);
  kiesTab("lopen");
  D.zegWie().then((w) => {
    if (w.naam) { S.naam = w.naam; kv.set("naam", w.naam).catch(() => {}); }
    else if (w.status === 401) vraagInlog();
  });
  await laadPlaatsen();
  // K10: de relatiepagina verwijst met ?plaats=<id>&adres=<id> naar de bezoeken op een adres.
  const vraag = new URLSearchParams(location.search);
  const naarPlaats = V.PLAATS_ID.test(vraag.get("plaats") || "") && S.plaatsen.some((p) => p.id === vraag.get("plaats")) ? vraag.get("plaats") : null;
  const naarAdres = vraag.get("adres");
  history.replaceState(null, "", location.pathname); // de parameters hoeven niet in de adresbalk of de geschiedenis te blijven
  const laatste = naarPlaats || (await kv.get("laatstePlaats")) || (S.plaatsen[0] && S.plaatsen[0].id);
  if (laatste && S.plaatsen.some((p) => p.id === laatste)) await laadPlaats(laatste);
  else kiesTab("plannen");
  if (naarPlaats) openAdresLijst(naarAdres);
  leegWachtrij();
}

if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start);
else start();

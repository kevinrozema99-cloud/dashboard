// Verstuurt de offline-wachtrij. Zonder scherm of netwerkkennis, zodat het los te testen is.
// Regel: een bezoek wordt nooit weggegooid. Alleen een echte invoerfout (400, 403, 404 met melding,
// 413, 415 enzovoort) zet het item op "afgekeurd", en dan blijft het zichtbaar en opnieuw te proberen.

export const isTijdelijk = (r) =>
  r.status === 0 || r.status === 408 || r.status === 429 || r.status >= 500
  // een 404 zonder melding van onze eigen server is een route die er tijdelijk niet is (bijvoorbeeld tijdens een deploy)
  || (r.status === 404 && !(r.data && r.data.fout));

// opties: { wie() (naam van de ingelogde gebruiker), alle(), verwijder(id), zet(item), api(pad, o), vraagInlog(), geheugen: [items], naGelukt(item, data), naAfgekeurd(item) }
export async function verstuurWachtrij(o) {
  const inDb = await o.alle();
  const ids = new Set(inDb.map((x) => x.id));
  const items = inDb.slice();
  for (const m of o.geheugen || []) {
    if (!ids.has(m.id)) {
      items.push(m); // stond alleen in het geheugen (opslaan mislukte): opnieuw proberen te bewaren
      try { await o.zet(m); } catch { /* blijft in het geheugen */ }
    }
  }
  items.sort((a, b) => a.toegevoegd - b.toegevoegd);
  let verstuurd = 0;
  let gestopt = null;
  const inlogPogingen = new Map();
  for (let i = 0; i < items.length; i++) {
    const item = items[i];
    if (item.afgekeurd) continue;
    // Alleen eigen items: een item van een ander blijft staan tot die inlogt. Zonder `wie` op het item (nog niemand bekend)
    // of zonder bekende gebruiker wordt niet geweigerd, zodat een bezoek nooit blijft hangen.
    const nu = o.wie ? o.wie() : null;
    if (nu && item.wie && item.wie !== nu) continue;
    const r = await o.api(`plaatsen/${encodeURIComponent(item.plaats)}/bezoeken`, { method: "POST", body: item.ev });
    if (r.ok && r.data) {
      try { await o.verwijder(item.id); } catch { /* volgende ronde: de server herkent het id */ }
      verstuurd++;
      if (o.naGelukt) o.naGelukt(item, r.data);
    } else if (r.status === 401) {
      const n = (inlogPogingen.get(item.id) || 0) + 1;
      inlogPogingen.set(item.id, n);
      const ok = n <= 2 && (await o.vraagInlog());
      if (!ok) { gestopt = "inlog"; break; }
      i--; // opnieuw proberen na het inloggen
    } else if (isTijdelijk(r)) {
      gestopt = "tijdelijk";
      break;
    } else {
      item.afgekeurd = (r.data && r.data.fout) || String(r.status);
      try { await o.zet(item); } catch { /* blijft in het geheugen gemarkeerd */ }
      if (o.naAfgekeurd) o.naAfgekeurd(item);
    }
  }
  return { verstuurd, gestopt };
}

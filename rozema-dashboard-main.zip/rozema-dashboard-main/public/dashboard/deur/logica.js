// Deur-aan-deur: rekenwerk zonder netwerk of scherm.
// Eén bron voor browser (import in app.js) en backend (import in dashboard-deur.mjs en de tests).
// Bevat geen zichtbare teksten: die staan in teksten.js.

// ---- Bronnen ----
export const BRON = {
  bagVbo: "https://api.pdok.nl/kadaster/bag/ogc/v2/collections/verblijfsobject/items",
  bagPand: "https://api.pdok.nl/kadaster/bag/ogc/v2/collections/pand/items",
  cbsBuurten: "https://api.pdok.nl/cbs/wijken-en-buurten-2024/ogc/v1/collections/buurten/items",
  tegels: "https://service.pdok.nl/brt/achtergrondkaart/wmts/v2_0/grijs/EPSG:3857/{z}/{x}/{y}.png",
  provincie: "Groningen",
};

export const CORPORATIE_GRENS = 40; // procent; vanaf hier staat een buurt standaard uit

// ---- Uitkomsten ----
// Volgorde = volgorde van de knoppen (meest gebruikte bovenaan).
export const STATUS_IDS = ["nietthuis", "geeninteresse", "gesprek", "afspraak", "huurder", "nietaanbellen"];
export const STATUS = {
  nietthuis: { letter: "N" },
  geeninteresse: { letter: "X" },
  gesprek: { letter: "G" },
  afspraak: { letter: "A" },
  huurder: { letter: "H" },
  nietaanbellen: { letter: "S" },
};
export const OVERSLAAN = { geeninteresse: 1, huurder: 1, nietaanbellen: 1 };
export const WONINGTYPEN = ["vrijstaand", "2-onder-1-kap", "rij", "appartement", "onbekend"];

// ---- Patronen en kleine hulpen ----
export const PLAATS_ID = /^[a-z0-9-]{1,60}$/;
export const BUURT_CODE = /^[A-Za-z0-9_-]{1,20}$/;
export const ADRES_ID = /^[A-Za-z0-9._-]{1,60}$/;
export const EVENT_ID = /^[a-z0-9]{8,40}$/;
export const POSTCODE = /^\d{4}[A-Z]{2}$/;

export const round = (v, d) => Math.round(v * 10 ** d) / 10 ** d;

export function slug(s, max = 60) {
  return String(s ?? "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "")
    .replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, max);
}
export const normPostcode = (s) => String(s ?? "").replace(/\s+/g, "").toUpperCase();
export const nrLabel = (a) => `${a.n}${a.l || ""}${a.t ? "-" + a.t : ""}`;

// Id van een handmatig toegevoegd adres: eerst de straatnaam inkorten, dan het nummer
// erachter zetten, zodat een lange straatnaam het huisnummer nooit afkapt.
export function handmatigId(straat, nummer) {
  const s = slug(straat, 30) || "straat";
  const n = slug(nummer, 20) || "nummer";
  return `x-${s}-${n}`;
}

// ---- BAG: verblijfsobjecten naar adressen ----
// De koppeling naar het pand loopt via de uuid achter "pand.href" (laatste padsegment).
// Dat is gelijk aan het veld "id" van het pand.
export function pandUuid(props) {
  let v = props ? props["pand.href"] : null;
  if (Array.isArray(v)) v = v[0];
  if (typeof v !== "string") return "";
  const schoon = v.split("?")[0].split("#")[0].replace(/\/+$/, "");
  const deel = schoon.slice(schoon.lastIndexOf("/") + 1);
  return /^[0-9a-fA-F-]{8,40}$/.test(deel) ? deel.toLowerCase() : "";
}

export function isWoning(p) {
  const doel = JSON.stringify(p.gebruiksdoel ?? "").toLowerCase();
  const status = String(p.status ?? "").toLowerCase();
  return doel.includes("woonfunctie") && status.includes("in gebruik");
}

export function vboNaarAdres(f) {
  const p = f.properties || {};
  const c = f.geometry && f.geometry.type === "Point" ? f.geometry.coordinates : null;
  return {
    id: String(p.identificatie || f.id || ""),
    s: p.openbare_ruimte_naam || "",
    n: Number(p.huisnummer) || 0,
    l: p.huisletter || "",
    t: p.toevoeging || "",
    pc: normPostcode(p.postcode),
    x: c ? round(c[0], 6) : null,
    y: c ? round(c[1], 6) : null,
    m2: Number(p.oppervlakte) || null,
    pand: pandUuid(p),
    bj: null,
    ty: "onbekend",
    bu: "",
  };
}

export function pandNaarInfo(f) {
  const p = f.properties || {};
  return {
    id: String(f.id || "").toLowerCase(),
    aantal: Number(p.aantal_verblijfsobjecten) || 1,
    bj: Number(p.bouwjaar) || null,
    geometry: f.geometry || null,
  };
}

// Woningtype uit de pandvormen. Panden die minstens twee hoekpunten delen staan tegen elkaar aan.
// Let op: een hoekhuis in een rij heeft één buur en telt hier als twee-onder-een-kap.
export function woningtypen(panden) {
  const hoekNaarPand = new Map();
  const sleutels = (geom) => {
    const ringen = geom.type === "Polygon" ? geom.coordinates
      : geom.type === "MultiPolygon" ? geom.coordinates.flat() : [];
    const set = new Set();
    for (const r of ringen) for (const pt of r) set.add(pt[0].toFixed(6) + "," + pt[1].toFixed(6));
    return set;
  };
  const perPand = new Map();
  for (const p of panden) {
    if (!p.geometry) continue;
    const ks = sleutels(p.geometry);
    perPand.set(p.id, ks);
    for (const k of ks) {
      if (!hoekNaarPand.has(k)) hoekNaarPand.set(k, new Set());
      hoekNaarPand.get(k).add(p.id);
    }
  }
  const uit = {};
  for (const p of panden) {
    if (p.aantal > 1) { uit[p.id] = "appartement"; continue; }
    const gedeeld = new Map();
    for (const k of perPand.get(p.id) || []) {
      for (const ander of hoekNaarPand.get(k)) {
        if (ander !== p.id) gedeeld.set(ander, (gedeeld.get(ander) || 0) + 1);
      }
    }
    const buren = [...gedeeld.values()].filter((n) => n >= 2).length;
    uit[p.id] = buren === 0 ? "vrijstaand" : buren === 1 ? "2-onder-1-kap" : "rij";
  }
  return uit;
}

// Zet bouwjaar en woningtype op de adressen. Geeft het aantal gekoppelde adressen terug.
export function koppelPanden(adressen, panden) {
  const typen = woningtypen(panden);
  const bj = new Map(panden.map((p) => [p.id, p.bj]));
  let gekoppeld = 0;
  for (const a of adressen) {
    const id = a.pand;
    if (id && typen[id]) {
      a.bj = bj.get(id) || null;
      a.ty = typen[id];
      gekoppeld++;
    }
  }
  return gekoppeld;
}

// ---- Buurten ----
function puntInRing(x, y, ring) {
  let binnen = false;
  for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
    const xi = ring[i][0], yi = ring[i][1], xj = ring[j][0], yj = ring[j][1];
    if ((yi > y) !== (yj > y) && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) binnen = !binnen;
  }
  return binnen;
}
export function puntInGeometrie(x, y, g) {
  if (!g) return false;
  const veelhoeken = g.type === "Polygon" ? [g.coordinates] : g.type === "MultiPolygon" ? g.coordinates : [];
  return veelhoeken.some((v) => puntInRing(x, y, v[0]) && !v.slice(1).some((gat) => puntInRing(x, y, gat)));
}
export function bbox(adressen, marge = 0.002) {
  let a = Infinity, b = Infinity, c = -Infinity, d = -Infinity;
  for (const r of adressen) {
    if (r.x != null) { a = Math.min(a, r.x); b = Math.min(b, r.y); c = Math.max(c, r.x); d = Math.max(d, r.y); }
  }
  return [round(a - marge, 6), round(b - marge, 6), round(c + marge, 6), round(d + marge, 6)];
}

// PDOK beantwoordt een bbox-vraag over een groot gebied traag (tientallen seconden per pagina).
// Daarom: kleine vakken, alleen waar adressen liggen, met een marge zodat buurpanden meekomen.
export function tegelBboxen(adressen, stap = 0.004, marge = 0.0005) {
  const cellen = new Set();
  for (const a of adressen) {
    if (a.x == null || a.y == null) continue;
    cellen.add(Math.floor(a.x / stap) + "," + Math.floor(a.y / stap));
  }
  return [...cellen].sort().map((k) => {
    const [cx, cy] = k.split(",").map(Number);
    return [round(cx * stap - marge, 6), round(cy * stap - marge, 6), round((cx + 1) * stap + marge, 6), round((cy + 1) * stap + marge, 6)];
  });
}

// Negatieve getallen zijn bij het CBS "geheim of onbekend"; die zijn nooit 0.
function cbsGetal(v) {
  const n = typeof v === "string" && v.trim() !== "" ? Number(v) : v;
  return typeof n === "number" && Number.isFinite(n) && n >= 0 ? Math.round(n) : null;
}
export function buurtCijfers(props) {
  const p = props || {};
  return {
    koop: cbsGetal(p.percentage_koopwoningen),
    corp: cbsGetal(p.perc_huurwoningen_in_bezit_woningcorporaties),
    woningen: cbsGetal(p.woningvoorraad),
  };
}
// Buurt met onbekend corporatiepercentage staat standaard aan (de app meldt "onbekend").
export function standaardAan(corp) {
  return corp == null || !Number.isFinite(corp) ? true : corp < CORPORATIE_GRENS;
}

// Zet buurtcode op elk adres (punt in veelhoek) en bouwt de buurtenlijst.
export function koppelBuurten(adressen, buurtFeatures) {
  for (const a of adressen) {
    if (a.x == null) continue;
    const f = buurtFeatures.find((b) => b.geometry && puntInGeometrie(a.x, a.y, b.geometry));
    if (f) a.bu = String((f.properties || {}).buurtcode || "");
  }
  for (const a of adressen) if (!a.bu) a.bu = "overig";
  const perCode = new Map(buurtFeatures.map((f) => [String((f.properties || {}).buurtcode || ""), f.properties || {}]));
  const aantal = new Map();
  for (const a of adressen) aantal.set(a.bu, (aantal.get(a.bu) || 0) + 1);
  return [...aantal.keys()].map((code) => {
    const p = perCode.get(code);
    const c = buurtCijfers(p);
    return {
      code,
      naam: p ? p.buurtnaam || code : "overig",
      koop: c.koop, corp: c.corp, woningen: c.woningen,
      aantal: aantal.get(code),
    };
  }).sort((p, q) => p.naam.localeCompare(q.naam, "nl"));
}

// ---- Rangorde van straten ----
// 1. trillingssnelheid (> 8,5 mm/s, of > 5 mm/s bij bouwjaar vóór 1940), 2. woningtype,
// 3. al een klant (afspraak) in de straat.
export const TYPE_SCORE = { vrijstaand: 3, "2-onder-1-kap": 3, rij: 2, appartement: 1, onbekend: 2 };
export function trillingKlasse(a, trilling) {
  const t = trilling[a.pc];
  if (!t || t.mms == null) return null;
  return t.mms > 8.5 || (a.bj && a.bj < 1940 && t.mms > 5) ? 2 : 1;
}
// klantInStraat: de klantenmodule heeft in deze straat al een klant of traject (GET /straten).
export function straatRang(adressen, trilling, stand, klantInStraat = false) {
  let bekend = 0, voorrang = 0, type = 0, klant = klantInStraat === true, onbekend = 0;
  for (const a of adressen) {
    const k = trillingKlasse(a, trilling);
    if (k === null) onbekend++; else { bekend++; if (k === 2) voorrang++; }
    type += TYPE_SCORE[a.ty] ?? 2;
    const h = huidige(stand[a.id]);
    if (h && h.st === "afspraak") klant = true;
  }
  return {
    voorrang: bekend ? voorrang / bekend : 0,
    onbekend,
    type: adressen.length ? type / adressen.length : 0,
    klant,
  };
}
export function sorteerStraten(straten) {
  return straten.sort((p, q) =>
    q.rang.voorrang - p.rang.voorrang || q.rang.type - p.rang.type
    || Number(q.rang.klant) - Number(p.rang.klant) || p.naam.localeCompare(q.naam, "nl"));
}

// ---- Bezoeken ----
// Eén ordening voor telefoon en server: bezoeken met serversleutel (k) staan op serverorde,
// bezoeken die nog wachten komen erna, op telefoontijd.
export const volgorde = (h) => (h.k ? "a" + h.k : "b" + String(h.ts || ""));

// stand = { [adresId]: { hist: [bezoek], ex? } }. Bezoek heeft id, a, st, w, ts, k.
// Een bezoek met "ongedaan: <id>" maakt dat bezoek ongedaan, ongeacht de volgorde van aankomst.
export function pasToe(stand, ev) {
  const a = (stand[ev.a] ||= { hist: [] });
  const i = a.hist.findIndex((h) => h.id === ev.id);
  if (i >= 0) {
    if (ev.k) a.hist[i] = { ...a.hist[i], ...ev, wacht: false };
  } else {
    a.hist.push({ ...ev, wacht: !!ev.wacht && !ev.k });
  }
  a.hist.sort((p, q) => volgorde(p).localeCompare(volgorde(q)));
  if (ev.ex) a.ex = ev.ex;
  return stand;
}
export function effectief(hist) {
  const weg = new Set((hist || []).filter((h) => h.ongedaan).map((h) => h.ongedaan));
  return (hist || []).filter((h) => h.st && !weg.has(h.id));
}
export function huidige(info) {
  if (!info) return null;
  const e = effectief(info.hist);
  return e.length ? e[e.length - 1] : null;
}

// ---- Compacte stand (server) ----
// Per adres alleen het laatste en voorlaatste bezoek en het aantal; de volledige geschiedenis staat in het archief.
// entry: {n, s (letter), w, t (seconden), k, v?: [s, w, t, k], weg?: [ids], ex?}.
// Het id van een bezoek zit in k (na 15 tekens). Uitkomsten staan als hun letter, om ruimte te sparen.
export const idVan = (k) => String(k || "").slice(15);
const LETTER_NAAR_ID = Object.fromEntries(Object.entries(STATUS).map(([id, x]) => [x.letter, id]));
export function vouwIn(stand, ev) {
  const e = (stand.adressen[ev.a] ||= { n: 0 });
  if (ev.ex) e.ex = ev.ex;
  if (ev.ongedaan) {
    const doel = ev.ongedaan;
    if (e.k && idVan(e.k) === doel) {
      e.n = Math.max(0, e.n - 1);
      if (e.v) { [e.s, e.w, e.t, e.k] = e.v; delete e.v; } else { delete e.s; delete e.w; delete e.t; delete e.k; }
    } else if (e.v && idVan(e.v[3]) === doel) {
      e.n = Math.max(0, e.n - 1);
      delete e.v;
    } else {
      e.weg = [...(e.weg || []), doel].slice(-20); // het bezoek zelf komt nog of is dieper weggevallen
    }
    return stand;
  }
  if ((e.k && idVan(e.k) === ev.id) || (e.v && idVan(e.v[3]) === ev.id)) return stand; // zelfde bezoek nogmaals
  if (e.weg && e.weg.includes(ev.id)) { e.weg = e.weg.filter((x) => x !== ev.id); return stand; }
  const nieuw = [STATUS[ev.st] ? STATUS[ev.st].letter : "?", ev.w, Math.floor(Date.parse(ev.ts) / 1000) || 0, ev.k];
  e.n = (e.n || 0) + 1;
  if (!e.k || nieuw[3] > e.k) {
    if (e.k) e.v = [e.s, e.w, e.t, e.k];
    [e.s, e.w, e.t, e.k] = nieuw;
  } else if (!e.v || nieuw[3] > e.v[3]) e.v = nieuw;
  return stand;
}
// Zet een compacte entry om naar bezoeken zoals de telefoon ze kent.
export function entryNaarHist(adresId, e) {
  const uit = [];
  const maak = ([s, w, t, k]) => ({ id: idVan(k), a: adresId, st: LETTER_NAAR_ID[s] || null, w, ts: new Date(t * 1000).toISOString(), k, wacht: false });
  if (e.v) uit.push(maak(e.v));
  if (e.k) uit.push(maak([e.s, e.w, e.t, e.k]));
  return uit;
}
export function aantalBezoeken(info) {
  if (!info) return 0;
  return Math.max(Number(info.n) || 0, effectief(info.hist).length);
}

// ---- Volgende huis en dichtstbijzijnde huis ----
export function volgendeHuis(straatAdressen, huidigAdres, stand) {
  const even = huidigAdres.n % 2 === 0;
  const open = (a) => !huidige(stand[a.id]);
  const zelfdeKant = straatAdressen.filter((a) => a.n % 2 === (even ? 0 : 1) && open(a) && a.id !== huidigAdres.id);
  const verder = zelfdeKant
    .filter((a) => a.n > huidigAdres.n || (a.n === huidigAdres.n && nrLabel(a) > nrLabel(huidigAdres)))
    .sort((p, q) => p.n - q.n || nrLabel(p).localeCompare(nrLabel(q)));
  if (verder.length) return verder[0];
  const overkant = straatAdressen.filter((a) => a.n % 2 !== (even ? 0 : 1) && open(a)).sort((p, q) => q.n - p.n);
  return overkant[0] || null;
}
export function afstandM(lat1, lon1, lat2, lon2) {
  const R = 6371000, r = Math.PI / 180;
  const dLat = (lat2 - lat1) * r, dLon = (lon2 - lon1) * r;
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(lat1 * r) * Math.cos(lat2 * r) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}
export function dichtstbij(adressen, lat, lon, stand, max = 60) {
  let beste = null, bd = Infinity;
  for (const a of adressen) {
    if (a.y == null || huidige(stand[a.id])) continue;
    const d = afstandM(lat, lon, a.y, a.x);
    if (d < bd) { bd = d; beste = a; }
  }
  return beste && bd <= max ? { adres: beste, m: Math.round(bd) } : null;
}

// ---- Labels op de kaart zonder overlap ----
// items: [{id, w, h, prio, posities: [{x, y}], vast?}] in schermpixels (x, y = midden).
// Een item wordt op de eerste positie gezet waar het geen eerder gezet item raakt.
// Een item met vast:true wordt altijd op de eerste positie gezet (en houdt die ruimte bezet).
// Geeft { keuze: Map(id -> index of null), bezet: [rechthoek] }.
export function plaatsLabels(items, opties = {}) {
  const pad = opties.pad ?? 2;
  const bezet = (opties.bezet || []).slice();
  const raakt = (a, b) => a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h;
  const keuze = new Map();
  const rij = items.map((it, i) => ({ it, i })).sort((p, q) => (q.it.prio - p.it.prio) || p.i - q.i);
  for (const { it } of rij) {
    let gekozen = null;
    for (let i = 0; i < it.posities.length; i++) {
      const p = it.posities[i];
      const r = { x: p.x - it.w / 2 - pad, y: p.y - it.h / 2 - pad, w: it.w + 2 * pad, h: it.h + 2 * pad };
      if (it.vast || !bezet.some((b) => raakt(b, r))) { gekozen = i; bezet.push(r); break; }
    }
    keuze.set(it.id, gekozen);
  }
  return { keuze, bezet };
}

// ---- Export ----
// Cellen die met = + - @ (of tab/return) beginnen worden in Excel als formule uitgevoerd:
// tekst krijgt dan een apostrof ervoor. Getallen blijven getallen.
export function celVeilig(v) {
  if (v == null) return "";
  if (typeof v === "number") return Number.isFinite(v) ? String(v) : "";
  const s = String(v);
  return /^[=+\-@\t\r]/.test(s) ? "'" + s : s;
}
export function csv(rijen) {
  const esc = (v) => {
    const s = celVeilig(v);
    return /[;"\n\r]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  };
  return "﻿" + rijen.map((r) => r.map(esc).join(";")).join("\r\n");
}
export const EXPORT_KOLOMMEN = [
  "plaats", "buurtcode", "buurt", "straat", "huisnummer", "postcode", "tijdstip_utc", "wie", "uitkomst",
  "bezoek_nr_adres", "woningtype", "bouwjaar", "trilling_mms", "koop_pct", "corporatie_pct", "notitie",
];
// adressen: Map(id -> adres); buurtNamen: Map(code -> naam); stand: {adresId: {hist, ex}}
export function maakExportRijen({ plaats, adressen, buurtNamen, stand }) {
  const rijen = [];
  for (const [id, info] of Object.entries(stand)) {
    const a = adressen.get(id);
    const ex = info.ex || {};
    const straat = a ? a.s : ex.s || "";
    const nummer = a ? nrLabel(a) : ex.n || "";
    let teller = 0;
    for (const h of effectief(info.hist)) {
      teller++;
      const bu = h.bu || (a ? a.bu : "") || "";
      rijen.push({
        sorteer: volgorde(h),
        rij: [
          plaats, bu, buurtNamen.get(bu) || "", straat, nummer, a ? a.pc : h.pc || "", h.ts, h.w, h.st,
          teller, h.ty || (a ? a.ty : "") || "", h.bj ?? (a ? a.bj : null) ?? "", h.mms ?? "", h.koop ?? "", h.corp ?? "", h.no || "",
        ],
      });
    }
  }
  rijen.sort((p, q) => p.sorteer.localeCompare(q.sorteer));
  return [EXPORT_KOLOMMEN, ...rijen.map((r) => r.rij)];
}

// ---- Validatie van een binnenkomend bezoek (backend) en adres ----
const tekstSchoon = (s, max) => String(s ?? "").replace(/[\u0000-\u001f\u007f]/g, " ").trim().slice(0, max);
const getalOfNull = (v, min, max) => {
  if (v === null || v === undefined || v === "") return null;
  const n = Number(v);
  return Number.isFinite(n) && n >= min && n <= max ? n : null;
};
export const TS_TOEKOMST_MS = 5 * 60 * 1000;
export const TS_VERLEDEN_MS = 14 * 24 * 60 * 60 * 1000;

// Geeft { ev } of { fout }. De telefoontijd wordt begrensd tot een redelijk venster rond de servertijd.
export function schoonBezoek(b, wie, nu = Date.now()) {
  if (!b || typeof b !== "object") return { fout: "Ongeldig bezoek." };
  if (typeof b.id !== "string" || !EVENT_ID.test(b.id)) return { fout: "Ongeldig bezoek." };
  if (typeof b.a !== "string" || !ADRES_ID.test(b.a)) return { fout: "Ongeldig adres." };
  const ev = { id: b.id, a: b.a, w: wie };
  if (b.ongedaan !== undefined && b.ongedaan !== null) {
    if (typeof b.ongedaan !== "string" || !EVENT_ID.test(b.ongedaan) || b.ongedaan === b.id) return { fout: "Ongeldig bezoek." };
    ev.st = null;
    ev.ongedaan = b.ongedaan;
  } else {
    if (!STATUS_IDS.includes(b.st)) return { fout: "Ongeldige uitkomst." };
    ev.st = b.st;
  }
  let t = Date.parse(b.ts);
  if (!Number.isFinite(t)) t = nu;
  t = Math.min(Math.max(t, nu - TS_VERLEDEN_MS), nu + TS_TOEKOMST_MS);
  ev.ts = new Date(t).toISOString();
  ev.no = tekstSchoon(b.no, 300);
  const bu = tekstSchoon(b.bu, 20);
  ev.bu = BUURT_CODE.test(bu) ? bu : "";
  ev.ty = WONINGTYPEN.includes(b.ty) ? b.ty : "onbekend";
  const bj = getalOfNull(b.bj, 1000, 2100);
  ev.bj = bj == null ? null : Math.round(bj);
  const mms = getalOfNull(b.mms, 0, 100);
  ev.mms = mms == null ? null : round(mms, 1);
  const koop = getalOfNull(b.koop, 0, 100), corp = getalOfNull(b.corp, 0, 100);
  ev.koop = koop == null ? null : Math.round(koop);
  ev.corp = corp == null ? null : Math.round(corp);
  const pc = normPostcode(b.pc);
  ev.pc = POSTCODE.test(pc) ? pc : "";
  if (b.ex && typeof b.ex === "object") {
    ev.ex = {
      s: tekstSchoon(b.ex.s, 80), n: tekstSchoon(b.ex.n, 12),
      x: getalOfNull(b.ex.x, -180, 180), y: getalOfNull(b.ex.y, -90, 90),
    };
  }
  return { ev };
}

// K10: voorinvulling voor het nieuw-klant-scherm vanuit een deurbezoek. Alleen velden die het klantenmodel kent
// (huisnummer en bagId met hun eigen patroon); leeg als iets niet past. Het scherm controleert nog eens.
export function klantVoorstel(a, plaatsNaam, plaatsId, mms) {
  const pc = String(a.pc || "").replace(/^(\d{4})([A-Z]{2})$/, "$1 $2");
  return {
    straat: a.s || "",
    huisnummer: Number.isInteger(a.n) && a.n > 0 && a.n < 1e6 ? String(a.n) : "",
    toevoeging: [a.l, a.t].filter(Boolean).join("-").slice(0, 10),
    postcode: pc,
    plaats: plaatsNaam || "",
    bagId: /^[0-9]{16}$/.test(String(a.id)) ? String(a.id) : "",
    bouwjaar: a.bj || "",
    trillingMms: mms != null ? mms : "",
    plaatsId: plaatsId || "",
    adresId: String(a.id),
  };
}

export const stuurtekensWeg = (s, max) => tekstSchoon(s, max);

export function schoonAdres(a) {
  if (!a || typeof a !== "object") return null;
  const id = String(a.id ?? "");
  if (!ADRES_ID.test(id)) return null;
  const typ = WONINGTYPEN.includes(a.ty) ? a.ty : "onbekend";
  const pc = normPostcode(a.pc);
  const bj = getalOfNull(a.bj, 1000, 2100);
  const bu = tekstSchoon(a.bu, 20);
  return {
    id,
    s: tekstSchoon(a.s, 80),
    n: Math.max(0, Math.round(Number(a.n) || 0)),
    l: tekstSchoon(a.l, 4),
    t: tekstSchoon(a.t, 8),
    pc: POSTCODE.test(pc) ? pc : "",
    x: getalOfNull(a.x, -180, 180),
    y: getalOfNull(a.y, -90, 90),
    m2: getalOfNull(a.m2, 0, 100000),
    bj: bj == null ? null : Math.round(bj),
    ty: typ,
    bu: BUURT_CODE.test(bu) ? bu : "overig",
  };
}

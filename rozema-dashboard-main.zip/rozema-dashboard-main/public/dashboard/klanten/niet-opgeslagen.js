// "Niet opgeslagen": de wachtrij met wijzigingen die nog niet verstuurd zijn of zijn afgekeurd, plus conflicten.
(function () {
  "use strict";
  var D = window.Dashboard;
  var K = window.Klanten;
  var W = window.Wachtrij;
  var B = window.Bewerk;
  var T = D.teksten.klanten;
  var N = T.niet;
  var $ = function (id) { return document.getElementById(id); };

  function reden(a) {
    var tekst = [];
    if (a.fouten && typeof a.fouten === "object") {
      Object.keys(a.fouten).forEach(function (k) { tekst.push(B.veldNaam(k) + ": " + B.foutTekst(a.fouten[k])); });
    } else if (a.code) tekst.push(B.foutTekst(a.code));
    else tekst.push(B.foutTekst("algemeen"));
    if (a.termijnen && a.termijnen.length) tekst.push(a.termijnen.map(function (t) { return t && t.titel ? K.titel(t.titel) : ""; }).filter(Boolean).join(", "));
    return tekst.join(" ");
  }

  function regel(a, geblokkeerd) {
    var li = D.maak("li", { klasse: "veldrij", "data-wijziging": a.id });
    li.appendChild(D.maak("p", { klasse: "veldlabel" }, K.eigen(N.soort, a.soort) || a.soort));
    var velden = (a.velden || []).map(B.veldNaam);
    if (velden.length) li.appendChild(D.maak("p", { klasse: "veldextra" }, K.vul(N.velden, { lijst: velden.join(", ") })));
    var vanAnder = !a.afgekeurd && (!a.wie || a.wie !== W.wie());
    var status = a.afgekeurd ? K.vul(N.mislukt, { reden: reden(a.afgekeurd) }) : vanAnder ? K.vul(N.vanAnder, { wie: a.wie || N.anderOnbekend }) : geblokkeerd ? N.geblokkeerd : N.wacht;
    li.appendChild(D.maak("p", { klasse: a.afgekeurd ? "veldwaarde afgekeurd" : "veldwaarde" }, status));
    if (a.relatieId) li.appendChild(D.maak("a", { klasse: "knop rand", href: K.relatieHref(a.relatieId) }, N.naarKlant));
    var acties = D.maak("div", { klasse: "acties" });
    if (a.afgekeurd) {
      var opnieuw = D.maak("button", { type: "button", "data-knop": "opnieuw" }, N.opnieuw);
      opnieuw.addEventListener("click", function () { opnieuw.disabled = true; W.opnieuw(a.id).then(function () { return W.verstuur(); }).then(laad); });
      acties.appendChild(opnieuw);
    }
    var weg = D.maak("button", { type: "button", klasse: "rand", "data-knop": "verwijder" }, N.verwijder);
    var bevestig = false;
    weg.addEventListener("click", function () {
      if (!bevestig) { bevestig = true; weg.textContent = N.verwijderBevestig; return; }
      W.verwijder(a.id).then(function () { return W.verstuur(); }).then(laad);
    });
    acties.appendChild(weg);
    li.appendChild(acties);
    return li;
  }

  function laad() {
    Promise.all([W.acties(), W.conflicten()]).then(function (r) {
      var acties = r[0];
      var lijst = $("wachtlijst");
      lijst.textContent = "";
      $("wachtleeg").textContent = acties.length ? "" : N.leeg;
      var geblokkeerd = {};
      acties.forEach(function (a) {
        if (a.afgekeurd) { lijst.appendChild(regel(a, false)); geblokkeerd[a.recordKey] = true; }
      });
      acties.forEach(function (a) { if (!a.afgekeurd) lijst.appendChild(regel(a, geblokkeerd[a.recordKey] === true)); });
      var cl = $("conflictlijst");
      cl.textContent = "";
      $("conflictleeg").textContent = r[1].length ? "" : N.conflictenLeeg;
      r[1].forEach(function (c) {
        var li = D.maak("li", { klasse: "veldrij" });
        var velden = c.conflicten.map(function (x) { return B.veldNaam(x.veld); }).join(", ");
        li.appendChild(D.maak("p", { klasse: "veldlabel" }, K.vul(N.conflictAan, { veld: velden })));
        var href = c.recordSoort === "traject" && c.relatieId ? "/dashboard/klanten/traject.html?relatie=" + encodeURIComponent(c.relatieId) + "&id=" + encodeURIComponent(c.recordKey)
          : K.relatieHref(c.recordKey);
        li.appendChild(D.maak("a", { klasse: "knop", href: href }, T.wachtrij.conflictOplossen));
        cl.appendChild(li);
      });
    });
  }

  document.addEventListener("DOMContentLoaded", function () {
    document.addEventListener("wachtrij-gewijzigd", laad);
    laad();
  });
})();

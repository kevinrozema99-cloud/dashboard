// Twee pijplijnen op één pagina (opdracht Ruben 20-11-2026):
//   leads:   relaties per leadstatus. Slepen = status wijzigen. Afgevallen vraagt een reden en gaat naar het archief.
//            "Contract getekend" start een traject in fase Getekend; de lead wordt klant en gaat naar de klantpijplijn.
//   klanten: trajecten per fase. Slepen = fase wijzigen. Uitbetaald, Afgerond en Verloren zijn archief.
// Alles gaat via de wachtrij en dezelfde servercontroles als op het klant- en trajectscherm. Een kaart verschuift meteen
// (optimistisch, met een korte overgang); weigert de server, dan gaat hij terug en staat de reden in de melding.
// Slepen kan met de muis; zonder muis (telefoon, toetsenbord) wijzig je status of fase op het scherm van de klant.
(function () {
  "use strict";
  var D = window.Dashboard;
  var K = window.Klanten;
  var W = window.Wachtrij;
  var B = window.Bewerk;
  var T = D.teksten.klanten;
  var P = T.pijplijn;
  var $ = function (id) { return document.getElementById(id); };
  var minderBeweging = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  // Eindbestemmingen die tijdens het slepen ook onderaan het scherm staan (zoals in Pipedrive), zodat je niet over
  // het hele bord hoeft te slepen.
  var ZONES = { leads: ["Later opnieuw", "Afgevallen", "Contract getekend"], klanten: ["Uitbetaald", "Verloren"] };
  var BORDEN = {
    leads: {
      api: "/api/dashboard/klanten/leadpijplijn", sleutel: "status", filters: ["eigenaar", "bron"],
      kop: P.kopLeads, uitleg: P.uitlegLeads, leeg: P.leegLeads, een: P.totaalLeadEen, meer: P.totaalLeadMeer,
    },
    klanten: {
      api: "/api/dashboard/klanten/pijplijn", sleutel: "fase", filters: ["eigenaar", "route"],
      kop: P.kopKlanten, uitleg: P.uitlegKlanten, leeg: P.leeg, een: P.totaalEen, meer: P.totaalMeer,
    },
  };
  var bord = new URLSearchParams(window.location.search).get("bord") === "klanten" ? "klanten" : "leads";
  var cache = {};
  var teller = 0;
  var huidig = null; // laatst getoonde data (met wachtende wijzigingen erover)
  var sleept = null; // id van de kaart die nu gesleept wordt
  var hadWachtend = false;
  var bevestig = null; // id van een kaart die net is verplaatst (korte bevestiging)

  // ---------- hulp ----------
  function plusDagen(datum, n) { return new Date(Date.parse(datum + "T12:00:00Z") + n * 86400000).toISOString().slice(0, 10); }
  var kopie = function (d) { return JSON.parse(JSON.stringify(d)); };
  var kolomNaam = function (k) { return K.eigen(P.kolomNamen, k) || k; };
  var naamVan = function (x) { return K.naamEnPlaats({ achternaam: x.achternaam, naam: x.naam, plaats: x.plaats }); };
  var cfg = function () { return BORDEN[bord]; };
  var sleutelVan = function (kolom) { return kolom[cfg().sleutel]; };

  function vind(data, id) {
    var uit = null;
    (data.kolommen || []).forEach(function (k) {
      (k.kaarten || []).forEach(function (x, i) { if (x.id === id) uit = { kolom: k, kaart: x, index: i }; });
    });
    return uit;
  }
  // Verplaatst een kaart naar kolom `naar` (null = van het bord af). Past aantallen en fee aan. Een archiefkolom zonder
  // "toon gearchiveerd" telt de kaart als gearchiveerd en toont hem niet.
  function verplaatsInData(data, id, naar) {
    var v = vind(data, id);
    if (!v || sleutelVan(v.kolom) === naar) return;
    v.kolom.kaarten.splice(v.index, 1);
    v.kolom.aantal = Math.max(0, (v.kolom.aantal || 0) - 1);
    if (typeof v.kaart.fee === "number") v.kolom.fee = Math.round((v.kolom.fee - v.kaart.fee) * 100) / 100;
    var doel = (data.kolommen || []).filter(function (k) { return sleutelVan(k) === naar; })[0];
    data.totaal = Math.max(0, (data.totaal || 0) - 1);
    if (!doel || doel.doel) return; // van het bord af (bijv. naar de klantpijplijn)
    if (doel.archief && !$("archief").checked) { doel.gearchiveerd = (doel.gearchiveerd || 0) + 1; return; }
    v.kaart.dagenInFase = 0;
    v.kaart.dagenInStatus = 0;
    v.kaart.wacht = true;
    doel.kaarten.unshift(v.kaart);
    doel.aantal = (doel.aantal || 0) + 1;
    data.totaal++;
    if (typeof v.kaart.fee === "number") doel.fee = Math.round(((doel.fee || 0) + v.kaart.fee) * 100) / 100;
  }
  // Wijzigingen die nog in de wachtrij staan (offline of wachtend) over de serverdata heen leggen.
  function metWachtrij(data, items) {
    var d = kopie(data);
    items.forEach(function (x) {
      if (x.afgekeurd || !x.body) return;
      var v = x.body.velden || {};
      if (bord === "klanten" && x.soort === "traject-wijzig" && v.fase) verplaatsInData(d, x.recordKey, v.fase.nieuw);
      if (bord === "leads" && x.soort === "relatie-wijzig" && v.status) verplaatsInData(d, x.recordKey, v.status.nieuw);
      if (bord === "leads" && x.soort === "traject-nieuw") verplaatsInData(d, x.relatieId, "Contract getekend");
    });
    return d;
  }
  var isMijnSoort = function (x) {
    return bord === "klanten" ? x.soort === "traject-wijzig" : x.soort === "relatie-wijzig" || x.soort === "traject-nieuw";
  };

  // ---------- melding (toast: vaste plek onderaan, geen verschuiving van de pagina) ----------
  var toastTimer = null;
  function toast(tekst, isFout, link) {
    var t = $("toast");
    clearTimeout(toastTimer);
    t.textContent = "";
    if (!tekst) { t.hidden = true; return; }
    t.className = "toast" + (isFout ? " fout" : "");
    t.appendChild(D.maak("span", null, tekst));
    if (link) { t.appendChild(document.createTextNode(" ")); t.appendChild(D.maak("a", { href: link.href }, link.tekst)); }
    t.hidden = false;
    // Een fout blijft staan tot de volgende actie; een bevestiging verdwijnt vanzelf.
    if (!isFout) toastTimer = setTimeout(function () { t.hidden = true; }, 5000);
  }

  // ---------- weergave ----------
  function metaRegel(delen) { return delen.filter(Boolean).join(", "); }
  function eigenaarTekst(e) { return e ? K.vul(P.eigenaarIs, { naam: K.eigen(T.lijst.eigenaren, e) || e }) : null; }

  function kaart(k) {
    var li = D.maak("li");
    var href = bord === "klanten" ? K.trajectHref(k.relatieId, k.id) : K.relatieHref(k.id);
    var a = D.maak("a", {
      href: href, draggable: "true", "data-id": k.id,
      klasse: "rij" + (k.fataal > 0 ? " bijna" : "") + (k.wacht ? " wacht" : "") + (bevestig === k.id ? " bevestigd" : ""),
    });
    // Zelfde naam voor dezelfde kaart in elke kolom: de browser laat hem dan van kolom naar kolom bewegen.
    a.style.viewTransitionName = "kaart-" + k.id.replace(/[^A-Za-z0-9_-]/g, "");
    a.appendChild(D.maak("p", { klasse: "naam" }, naamVan(k)));
    if (bord === "klanten") {
      a.appendChild(D.maak("p", { klasse: "wat" }, metaRegel([k.route, eigenaarTekst(k.eigenaar)])));
      if (typeof k.fee === "number") a.appendChild(D.maak("p", { klasse: "wat bedrag" }, K.euro(k.fee)));
    } else {
      a.appendChild(D.maak("p", { klasse: "wat" }, metaRegel([k.bron, k.contactvoorkeur, eigenaarTekst(k.eigenaar)])));
      if (!k.eigenaar) a.appendChild(D.maak("p", { klasse: "termijn" }, P.nietToegewezen));
      if (k.volgendeTaak && (k.volgendeTaak.titel || k.volgendeTaak.datum)) {
        var vt = k.volgendeTaak;
        a.appendChild(D.maak("p", { klasse: "wat" }, K.vul(P.volgende, { titel: metaRegel([vt.titel ? K.titel(vt.titel) : T.taken.zonderTitel, vt.datum ? K.datum(vt.datum) : null]) })));
      }
    }
    var dagen = bord === "klanten" ? k.dagenInFase : k.dagenInStatus;
    if (k.wacht) a.appendChild(D.maak("p", { klasse: "wat" }, P.wacht));
    else if (typeof dagen === "number") {
      var vandaag = bord === "klanten" ? P.inFaseVandaag : P.inStatusVandaag;
      a.appendChild(D.maak("p", { klasse: "wat" }, dagen === 0 ? vandaag : K.vul(bord === "klanten" ? P.inFase : P.inStatus, { d: K.dagen(dagen) })));
    }
    if (k.fataal > 0) a.appendChild(D.maak("p", { klasse: "termijn" }, k.fataal === 1 ? P.fataal : K.vul(P.fataalMeer, { n: k.fataal })));
    a.addEventListener("dragstart", function (e) {
      sleept = k.id;
      a.classList.add("sleept");
      e.dataTransfer.effectAllowed = "move";
      e.dataTransfer.setData("text/plain", k.id);
      toast(""); // de vorige melding mag niet over de eindbestemmingen liggen
      toonZones(k.id);
    });
    a.addEventListener("dragend", function () {
      sleept = null;
      a.classList.remove("sleept");
      $("sleepzones").hidden = true;
      Array.prototype.forEach.call(document.querySelectorAll(".kolom.doel, .zone.doel"), function (x) { x.classList.remove("doel"); });
    });
    li.appendChild(a);
    return li;
  }

  // Een vak waar je een kaart kunt neerzetten (kolom of zone onderaan).
  function maakDoel(el, sleutel) {
    var magHier = function () { var v = sleept && huidig ? vind(huidig, sleept) : null; return !!v && sleutelVan(v.kolom) !== sleutel; };
    el.addEventListener("dragover", function (e) {
      if (!magHier()) return;
      e.preventDefault();
      e.dataTransfer.dropEffect = "move";
      el.classList.add("doel");
    });
    el.addEventListener("dragleave", function (e) { if (!el.contains(e.relatedTarget)) el.classList.remove("doel"); });
    el.addEventListener("drop", function (e) {
      e.preventDefault();
      el.classList.remove("doel");
      $("sleepzones").hidden = true;
      var id = sleept || e.dataTransfer.getData("text/plain");
      sleept = null;
      if (id) neerzetten(id, sleutel);
    });
  }

  function toonZones(id) {
    var vak = $("sleepzones");
    vak.textContent = "";
    var v = huidig ? vind(huidig, id) : null;
    ZONES[bord].forEach(function (z) {
      if (v && sleutelVan(v.kolom) === z) return;
      var el = D.maak("div", { klasse: "zone", "data-kolom": z }, kolomNaam(z));
      maakDoel(el, z);
      vak.appendChild(el);
    });
    vak.hidden = !vak.childNodes.length;
  }

  function kolom(k) {
    var sleutel = sleutelVan(k);
    var sec = D.maak("section", { klasse: "kolom" + (k.doel ? " doelkolom" : "") + (k.archief ? " archiefkolom" : ""), "data-kolom": sleutel });
    var kop = D.maak("h2");
    kop.appendChild(D.maak("span", null, kolomNaam(sleutel)));
    if (!k.doel) kop.appendChild(D.maak("span", { klasse: "teller" }, String(k.aantal || 0)));
    sec.appendChild(kop);
    if (k.fee > 0) sec.appendChild(D.maak("p", { klasse: "rustig bedrag" }, K.vul(P.fee, { bedrag: K.euro(k.fee) })));
    if (k.gearchiveerd > 0) sec.appendChild(D.maak("p", { klasse: "rustig" }, k.gearchiveerd === 1 ? P.gearchiveerdEen : K.vul(P.gearchiveerd, { n: k.gearchiveerd })));
    if (k.doel) sec.appendChild(D.maak("p", { klasse: "rustig" }, P.doelTraject));
    var ul = D.maak("ul", { klasse: "rijen" });
    (k.kaarten || []).forEach(function (x) { ul.appendChild(kaart(x)); });
    sec.appendChild(ul);
    maakDoel(sec, sleutel); // neerzetten: alleen een kaart uit een andere kolom
    return sec;
  }

  // Tekent het bord. Met een overgang als de browser dat kan en de gebruiker geen minder beweging vraagt.
  // Met een overgang tekent de browser pas een frame later. Komt er intussen nieuwere data (de server was sneller),
  // dan mag die latere tekening niet meer overschrijven: alleen de laatste aanroep tekent.
  var tekenNr = 0;
  function toon(data, stand, metOvergang) {
    var mijn = ++tekenNr;
    var teken = function () {
      if (mijn !== tekenNr) return;
      huidig = data;
      var b = $("bord");
      b.textContent = "";
      (data.kolommen || []).forEach(function (k) { b.appendChild(kolom(k)); });
      var n = typeof data.totaal === "number" ? data.totaal : 0;
      $("aantal").textContent = n === 0 ? cfg().leeg : n === 1 ? cfg().een : K.vul(cfg().meer, { n: n });
      var ontbreekt = (data.onvolledig || 0) + (data.onleesbaar || 0);
      var teksten = [];
      if (ontbreekt) teksten.push(K.vul(P.ontbreekt, { n: ontbreekt }));
      if (stand) teksten.push(K.vul(P.stand, { moment: K.moment(stand) }));
      D.melding($("melding"), teksten.join(" "), ontbreekt > 0);
    };
    if (metOvergang && document.startViewTransition && !minderBeweging) { huidig = data; document.startViewTransition(teken); }
    else teken();
  }

  function toonMetWachtrij(data, stand) {
    return W.acties().then(function (items) {
      hadWachtend = items.some(isMijnSoort);
      toon(metWachtrij(data, items), stand, false);
    });
  }

  // ---------- keuzevenster (reden bij Afgevallen, route en datum bij Contract getekend) ----------
  // velden: [{veld, start}] met veldspecificaties uit bewerk.js. Geeft Promise<waarden|null>.
  function vraag(kop, uitleg, knop, velden) {
    return new Promise(function (klaar) {
      var dlg = $("keuzevenster");
      $("keuzekop").textContent = kop;
      $("keuzeuitleg").textContent = uitleg;
      $("keuzeok").textContent = knop;
      D.melding($("keuzefout"), "");
      var vak = $("keuzevelden");
      vak.textContent = "";
      var invoeren = {};
      velden.forEach(function (s) {
        var d = D.maak("div", { klasse: "veld" });
        var fid = "keuze-" + s.veld;
        d.appendChild(D.maak("label", { for: fid }, B.label(s.veld)));
        var inv = B.invoer(s.veld, s.start === undefined ? null : s.start, fid);
        d.appendChild(inv.el);
        vak.appendChild(d);
        invoeren[s.veld] = { inv: inv, verplicht: !!s.verplicht };
      });
      var form = $("keuzeform");
      var sluit = function (w) { form.onsubmit = null; $("keuzeannuleer").onclick = null; dlg.onclose = null; if (dlg.open) dlg.close(); klaar(w); };
      form.onsubmit = function (e) {
        e.preventDefault();
        var w = {};
        for (var k in invoeren) {
          var r = invoeren[k].inv.waarde();
          if (!r.ok) { D.melding($("keuzefout"), B.label(k) + ": " + B.foutTekst(r.fout), true); return; }
          if (invoeren[k].verplicht && r.waarde === null) { D.melding($("keuzefout"), B.label(k) + ": " + B.foutTekst("verplicht"), true); return; }
          if (r.waarde !== null) w[k] = r.waarde;
        }
        sluit(w);
      };
      $("keuzeannuleer").onclick = function () { sluit(null); };
      dlg.onclose = function () { sluit(null); }; // Esc
      dlg.showModal();
      var eerste = vak.querySelector("select, input");
      if (eerste) eerste.focus();
    });
  }

  // ---------- neerzetten ----------
  function neerzetten(id, naar) {
    var v = huidig ? vind(huidig, id) : null;
    if (!v || sleutelVan(v.kolom) === naar) return;
    var k = v.kaart;
    var naam = naamVan(k);
    if (bord === "klanten") {
      // Bij Opname gepland en Besluit hoort een datum: die meteen vragen, dan is de volgende taak meteen goed.
      var datumVraag = { "Opname gepland": ["opnamedatum", P.opnameKop, P.opnameUitleg, P.opnameKnop],
        "Besluit": ["verzenddatumBesluitbrief", P.besluitKop, P.besluitUitleg, P.besluitKnop] }[naar];
      // Bij de opname ook de tijd (mag leeg): die staat dan zo in de gezamenlijke agenda.
      var extra = naar === "Opname gepland" ? [{ veld: "opnametijd", start: k.opnametijd || null }] : [];
      var vraagDatum = datumVraag
        ? vraag(K.vul(datumVraag[1], { naam: naam }), datumVraag[2], datumVraag[3], [{ veld: datumVraag[0], start: k[datumVraag[0]] || null, verplicht: true }].concat(extra))
        : Promise.resolve({});
      return vraagDatum.then(function (w) {
        if (!w) return;
        var tv = { fase: { oud: sleutelVan(v.kolom), nieuw: naar } };
        if (datumVraag && w[datumVraag[0]] !== (k[datumVraag[0]] || null)) tv[datumVraag[0]] = { oud: k[datumVraag[0]] || null, nieuw: w[datumVraag[0]] };
        extra.forEach(function (x) { if ((w[x.veld] || null) !== (k[x.veld] || null)) tv[x.veld] = { oud: k[x.veld] || null, nieuw: w[x.veld] || null }; });
        return verstuur(id, naar, naam, k, {
          soort: "traject-wijzig", methode: "PATCH", pad: "/trajecten/" + encodeURIComponent(id),
          body: { wijzigingId: W.nieuwId(), velden: tv }, recordKey: id, relatieId: k.relatieId, velden: Object.keys(tv),
        });
      });
    }
    var doel = (huidig.kolommen || []).filter(function (x) { return sleutelVan(x) === naar; })[0] || {};
    if (doel.doel === "traject") {
      return vraag(K.vul(P.contractKop, { naam: naam }), P.contractUitleg, P.contractKnop, [
        { veld: "route", start: "Maatwerk met onderzoek" }, { veld: "getekendOp", start: K.vandaagLokaal() },
      ]).then(function (w) {
        if (!w) return;
        var tid = "t_" + W.nieuwId();
        var velden = Object.assign({ fase: "Getekend" }, w);
        return verstuur(id, naar, naam, k, {
          soort: "traject-nieuw", methode: "POST", pad: "/relaties/" + encodeURIComponent(id) + "/trajecten",
          body: { id: tid, wijzigingId: W.nieuwId(), velden: velden }, recordKey: tid, relatieId: id, velden: Object.keys(velden),
        }, true);
      });
    }
    var velden = { status: { oud: sleutelVan(v.kolom), nieuw: naar } };
    var start = Promise.resolve({});
    if (naar === "Afgevallen") start = vraag(K.vul(P.afgevallenKop, { naam: naam }), P.afgevallenUitleg, P.afgevallenKnop, [{ veld: "redenAfgevallen", verplicht: true }]);
    // Follow-up: wanneer opnieuw bellen (standaard over 30 dagen); de taak "Bel opnieuw" staat dan op die dag.
    if (naar === "Later opnieuw") start = vraag(K.vul(P.laterKop, { naam: naam }), P.laterUitleg, P.laterKnop, [{ veld: "terugbeldatum", start: plusDagen(K.vandaagLokaal(), 30), verplicht: true }]);
    // Afspraak: datum en tijd; de afspraak wordt een taak (soort afspraak) voor de eigenaar.
    if (naar === "Afspraak gepland") start = vraag(K.vul(P.afspraakKop, { naam: naam }), P.afspraakUitleg, P.afspraakKnop, [{ veld: "datum", verplicht: true }, { veld: "tijd" }]);
    return start.then(function (w) {
      if (!w) return;
      if (w.redenAfgevallen) velden.redenAfgevallen = { oud: null, nieuw: w.redenAfgevallen };
      if (w.terugbeldatum) velden.terugbeldatum = { oud: k.terugbeldatum || null, nieuw: w.terugbeldatum };
      if (naar === "Afspraak gepland" && w.datum) {
        var tid = "a" + W.nieuwId().replace(/-/g, "").slice(0, 15);
        var taak = { soort: "afspraak", titel: T.flow.afspraakTitel, datum: w.datum, tijd: w.tijd || null, eigenaar: k.eigenaar || null };
        Object.keys(taak).forEach(function (veld) { if (taak[veld] !== null) velden["taken." + tid + "." + veld] = { oud: null, nieuw: taak[veld] }; });
      }
      return verstuur(id, naar, naam, k, {
        soort: "relatie-wijzig", methode: "PATCH", pad: "/relaties/" + encodeURIComponent(id),
        body: { wijzigingId: W.nieuwId(), velden: velden }, recordKey: id, relatieId: id, velden: Object.keys(velden),
      });
    });
  }

  function verstuur(id, naar, naam, k, actie, isTraject) {
    var voorlopig = kopie(huidig);
    verplaatsInData(voorlopig, id, naar);
    bevestig = null;
    toon(voorlopig, null, true);
    var link = bord === "klanten" ? { href: K.trajectHref(k.relatieId, k.id), tekst: P.openTraject } : { href: K.relatieHref(k.id), tekst: P.openKlant };
    return W.zet(actie, { direct: true }).then(function (u) {
      var fout = B.uitkomstFout(u);
      if (fout) { toast(K.vul(P.nietVerplaatst, { naam: naam, fase: kolomNaam(naar) }) + " " + fout, true, link); laad(true); return; }
      if (u.uitkomst === "verstuurd") {
        var conflict = u.r && u.r.data && Array.isArray(u.r.data.conflicten) && u.r.data.conflicten.length > 0;
        if (conflict) toast(K.vul(P.conflict, { naam: naam }), true, link);
        else if (isTraject) toast(K.vul(P.trajectGestart, { naam: naam }), false, { href: "/dashboard/klanten/pijplijn.html?bord=klanten", tekst: P.naarKlantpijplijn });
        else { bevestig = id; toast(K.vul(P.verplaatst, { naam: naam, fase: kolomNaam(naar) }), false); }
        laad(true);
        return;
      }
      // Geen verbinding of wacht op een eerdere wijziging: blijft op dit toestel en wordt later verstuurd.
      toast(u.uitkomst === "wacht-eerder" ? T.wachtrij.wachtEerder : T.wachtrij.wacht, false);
    });
  }

  // ---------- laden en wisselen ----------
  function params() {
    var p = new URLSearchParams();
    cfg().filters.forEach(function (f) { if ($(f).value) p.set(f, $(f).value); });
    if ($("archief").checked) p.set("archief", "ja");
    return p.toString();
  }

  function laad(stil) {
    var sleutel = bord + "?" + params();
    var nr = ++teller;
    D.api(cfg().api + (params() ? "?" + params() : "")).then(function (r) {
      if (nr !== teller) return;
      if (r.ok && r.data && Array.isArray(r.data.kolommen)) {
        cache[sleutel] = { data: r.data, op: new Date() };
        toonMetWachtrij(r.data, null).then(function () { if (stil) bevestig = null; });
      } else if (cache[sleutel]) {
        toonMetWachtrij(cache[sleutel].data, cache[sleutel].op);
      } else {
        huidig = null;
        $("bord").textContent = "";
        $("aantal").textContent = "";
        D.melding($("melding"), r.status === 0 ? D.teksten.algemeen.geenVerbinding : P.mislukt, true);
      }
    });
  }

  function kiesBord(nieuw, opslaan) {
    bord = nieuw;
    var c = cfg();
    $("bordkop").textContent = c.kop;
    $("uitleg").textContent = c.uitleg;
    document.title = c.kop + " - " + D.teksten.merk;
    ["leads", "klanten"].forEach(function (b) {
      var tab = $("tab-" + b);
      tab.setAttribute("aria-selected", b === bord ? "true" : "false");
      tab.tabIndex = b === bord ? 0 : -1;
    });
    $("bord").setAttribute("aria-labelledby", "tab-" + bord);
    Array.prototype.forEach.call(document.querySelectorAll("[data-alleen]"), function (el) { el.hidden = el.getAttribute("data-alleen") !== bord; });
    // Zijbalk: Pijplijn gemarkeerd (één menu-item voor beide borden; de tabs kiezen het bord).
    Array.prototype.forEach.call(document.querySelectorAll('nav.sub a[href^="/dashboard/klanten/pijplijn.html"]'), function (a) { a.setAttribute("aria-current", "page"); });
    if (opslaan) window.history.replaceState(null, "", "?bord=" + bord);
    huidig = null;
    toast("");
    laad();
  }

  function vulKeuze(select, opties) {
    select.appendChild(D.maak("option", { value: "" }, P.alle));
    opties.forEach(function (o) { select.appendChild(D.maak("option", { value: o[0] }, o[1])); });
  }

  function init() {
    vulKeuze($("eigenaar"), Object.keys(T.lijst.eigenaren).map(function (k) { return [k, T.lijst.eigenaren[k]]; }));
    vulKeuze($("route"), T.keuzes.route.map(function (r) { return [r, r]; }));
    vulKeuze($("bron"), T.keuzes.bron.map(function (r) { return [r, r]; }));
    ["eigenaar", "route", "bron", "archief"].forEach(function (id) { $(id).addEventListener("change", function () { laad(); }); });
    $("filterform").addEventListener("submit", function (e) { e.preventDefault(); laad(); });
    ["leads", "klanten"].forEach(function (b) {
      $("tab-" + b).addEventListener("click", function () { if (b !== bord) kiesBord(b, true); });
    });
    // Pijltjestoetsen tussen de twee tabs (gangbaar gedrag voor tabbladen).
    document.querySelector(".schakelaar").addEventListener("keydown", function (e) {
      if (e.key !== "ArrowLeft" && e.key !== "ArrowRight") return;
      e.preventDefault();
      var ander = bord === "leads" ? "klanten" : "leads";
      kiesBord(ander, true);
      $("tab-" + ander).focus();
    });
    // Een wachtende wijziging is verstuurd (hier of in een ander tabblad): het bord opnieuw ophalen.
    document.addEventListener("wachtrij-gewijzigd", function () {
      W.acties().then(function (items) {
        var nu = items.some(isMijnSoort);
        if (hadWachtend && !nu) { hadWachtend = false; laad(); }
      });
    });
    kiesBord(bord, false);
  }

  document.addEventListener("DOMContentLoaded", init);
})();

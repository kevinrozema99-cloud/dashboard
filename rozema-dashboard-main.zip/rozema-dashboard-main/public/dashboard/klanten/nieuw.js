// Nieuwe klant: formulier uit de velden van model.mjs. Het id maakt de telefoon.
(function () {
  "use strict";
  var D = window.Dashboard;
  var K = window.Klanten;
  var W = window.Wachtrij;
  var B = window.Bewerk;
  var T = D.teksten.klanten;
  var $ = function (id) { return document.getElementById(id); };
  var invoeren = {};

  // K10: komt de pagina uit een deurbezoek (?herkomst=deur&event=<id>), dan staat het adres klaar in sessionStorage
  // (gezet door de deur-app) en wordt het id van het bezoek aan de relatie gekoppeld. Zonder geldig id: gewoon leeg.
  var EVENT = /^[a-z0-9]{8,40}$/;
  var KORT = /^[A-Za-z0-9._-]{1,60}$/;
  var deur = null;
  var voorstel = {};
  (function () {
    var ev = B.query("event");
    if (B.query("herkomst") !== "deur" || !ev || !EVENT.test(ev)) return;
    try { voorstel = JSON.parse(window.sessionStorage.getItem("dashboard.deurklant." + ev)) || {}; } catch (e) { voorstel = {}; }
    if (voorstel === null || typeof voorstel !== "object") voorstel = {};
    deur = { eventId: ev };
    if (typeof voorstel.plaatsId === "string" && KORT.test(voorstel.plaatsId)) deur.plaats = voorstel.plaatsId;
    if (typeof voorstel.adresId === "string" && KORT.test(voorstel.adresId)) deur.adres = voorstel.adresId;
    voorstel.bron = "Deur";
  })();

  // Het adres uit de deur-app staat alleen zolang het nodig is in sessionStorage: andere voorstellen ruimen we bij
  // het laden op, dit voorstel zodra de klant is verstuurd of in de wachtrij staat.
  var VOORSTEL = "dashboard.deurklant.";
  function ruimOp(behalve) {
    try {
      var weg = [];
      for (var i = 0; i < window.sessionStorage.length; i++) {
        var k = window.sessionStorage.key(i);
        if (k && k.indexOf(VOORSTEL) === 0 && k !== VOORSTEL + behalve) weg.push(k);
      }
      weg.forEach(function (k) { window.sessionStorage.removeItem(k); });
    } catch (e) { /* geen opslag beschikbaar */ }
  }
  ruimOp(deur ? deur.eventId : "");

  function bouw() {
    var typen = {};
    B.RELATIE.forEach(function (v) { typen[v[0]] = v[1]; });
    function veld(naam, vak) {
      var d = D.maak("div", { klasse: "veld", "data-veld": naam });
      var fid = "nw-" + naam;
      d.appendChild(D.maak("label", { for: fid }, B.label(naam) + (naam === "achternaam" || naam === "status" ? "" : "")));
      var start = naam === "status" ? "Nieuw" : (deur && voorstel[naam] !== undefined && voorstel[naam] !== "" ? voorstel[naam] : null);
      var inv = B.invoer(naam, start, fid);
      if (naam === "status") {
        // Bij een nieuwe klant geen lege keuze voor status.
        var leeg = inv.el.querySelector('option[value=""]');
        if (leeg) leeg.remove();
        inv.el.value = "Nieuw";
      }
      d.appendChild(inv.el);
      d.appendChild(D.maak("p", { klasse: "veldfout", id: fid + "-fout" }));
      vak.appendChild(d);
      invoeren[naam] = inv;
    }
    B.KERN.forEach(function (n) { veld(n, $("kern")); });
    B.RELATIE.forEach(function (v) { if (B.KERN.indexOf(v[0]) === -1) veld(v[0], $("meer")); });
  }

  // Straat en plaats zelf invullen uit postcode en huisnummer (PDOK Locatieserver, dezelfde overheidsbron als de
  // deur-app; alleen postcode en huisnummer gaan erheen). Een straat of plaats die de gebruiker zelf typte, wordt nooit
  // overschreven. Lukt het niet, dan vul je ze gewoon zelf in.
  var PDOK = "https://api.pdok.nl/bzk/locatieserver/search/v3_1/free";
  var zoekNr = 0;
  var zelfIngevuld = { straat: false, plaats: false };
  function adresZoeken() {
    var pc = ($("nw-postcode").value || "").replace(/\s+/g, "").toUpperCase();
    var nr = ($("nw-huisnummer").value || "").trim();
    var hint = $("nw-adreshint");
    if (!/^[1-9][0-9]{3}[A-Z]{2}$/.test(pc) || !/^[0-9]{1,6}$/.test(nr)) { hint.textContent = ""; return; }
    var mijn = ++zoekNr;
    hint.textContent = T.nw.adresZoeken;
    var url = PDOK + "?q=*&fq=type:adres&fq=postcode:" + pc + "&fq=huisnummer:" + nr + "&rows=1&fl=straatnaam,woonplaatsnaam";
    var ac = new AbortController();
    var t = setTimeout(function () { ac.abort(); }, 5000);
    fetch(url, { headers: { accept: "application/json" }, signal: ac.signal, credentials: "omit", referrerPolicy: "no-referrer" })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (d) {
        if (mijn !== zoekNr) return;
        var doc = d && d.response && Array.isArray(d.response.docs) ? d.response.docs[0] : null;
        if (!doc || typeof doc.straatnaam !== "string") { hint.textContent = T.nw.adresNietGevonden; return; }
        [["straat", doc.straatnaam], ["plaats", doc.woonplaatsnaam]].forEach(function (p) {
          var el = $("nw-" + p[0]);
          if (el && typeof p[1] === "string" && (!el.value || !zelfIngevuld[p[0]])) el.value = p[1];
        });
        hint.textContent = T.nw.adresGevonden;
      })
      .catch(function () { if (mijn === zoekNr) hint.textContent = T.nw.adresNietGevonden; })
      .then(function () { clearTimeout(t); });
  }
  function koppelAdres() {
    if (!$("nw-postcode") || !$("nw-huisnummer")) return;
    var hint = D.maak("p", { klasse: "rustig adreshint", id: "nw-adreshint", "aria-live": "polite" });
    $("nw-huisnummer").closest(".veld").appendChild(hint);
    ["postcode", "huisnummer"].forEach(function (n) { $("nw-" + n).addEventListener("change", adresZoeken); });
    ["straat", "plaats"].forEach(function (n) {
      var el = $("nw-" + n);
      if (el) el.addEventListener("input", function () { zelfIngevuld[n] = el.value.trim() !== ""; });
    });
  }

  function wis() {
    Array.prototype.forEach.call(document.querySelectorAll(".veldfout"), function (p) { p.textContent = ""; });
    $("nieuwfouten").textContent = "";
    D.melding($("nieuwmelding"), "");
  }

  function toonFouten(r) {
    var lijst = B.foutenLijst(r);
    var eerste = null;
    lijst.forEach(function (f) {
      var p = f.veld ? document.getElementById("nw-" + f.veld + "-fout") : null;
      if (p) { p.textContent = B.foutTekst(f.code); if (!eerste) eerste = document.getElementById("nw-" + f.veld); }
      else $("nieuwfouten").appendChild(D.maak("li", {}, f.tekst));
    });
    D.melding($("nieuwmelding"), T.nw.fouten, true);
    // Velden onder "meer gegevens" met een fout: klap open.
    if (eerste && eerste.closest("details")) eerste.closest("details").open = true;
    if (eerste) eerste.focus();
  }

  document.addEventListener("DOMContentLoaded", function () {
    bouw();
    if (!deur) koppelAdres(); // uit een deurbezoek staat het adres er al
    if (deur) $("deurvoorgevuld").hidden = false;
    var knop = document.querySelector('#nieuwform button[type="submit"]');
    // Uit een deurbezoek zijn id en wijzigingId vast, afgeleid van het bezoek: een tweede tik maakt geen tweede klant
    // maar geeft bestaatAl, en dan openen we die relatie.
    var id = deur ? "r_deur_" + deur.eventId : "r_" + W.nieuwId(); // wijzigt niet bij opnieuw proberen: dezelfde klant wordt niet twee keer gemaakt
    var wid = deur ? "deur-" + deur.eventId : W.nieuwId();
    $("nieuwform").addEventListener("submit", function (e) {
      e.preventDefault();
      wis();
      var velden = {};
      var lokaal = {};
      Object.keys(invoeren).forEach(function (k) {
        var w = invoeren[k].waarde();
        if (!w.ok) lokaal[k] = w.fout;
        else if (w.waarde !== null) velden[k] = w.waarde;
      });
      if (Object.keys(lokaal).length) { toonFouten({ data: { fouten: lokaal } }); return; }
      if (!velden.achternaam) { toonFouten({ data: { fouten: { achternaam: "verplicht" } } }); return; }
      knop.disabled = true;
      D.melding($("nieuwmelding"), T.bezig);
      W.zet({ soort: "relatie-nieuw", methode: "POST", pad: "/relaties", body: Object.assign({ id: id, wijzigingId: wid, velden: velden }, deur ? { herkomst: { deur: deur } } : {}),
        recordKey: id, relatieId: id, velden: Object.keys(velden) }, { direct: true }).then(function (u) {
        knop.disabled = false;
        if (u.uitkomst === "geen-wie") { D.melding($("nieuwmelding"), T.wachtrij.eerstInloggen, true); return; }
        if (u.uitkomst === "afgekeurd") {
          D.melding($("nieuwmelding"), "");
          toonFouten(u.r);
          wid = deur ? "deur-" + deur.eventId : W.nieuwId(); // de afgekeurde poging is niet bewaard: een nieuwe poging krijgt een nieuwe wijzigingId
          return;
        }
        if (deur) ruimOp(""); // verstuurd of bewaard in de wachtrij: het adres hoeft niet langer in sessionStorage te staan
        var href = K.relatieHref(id);
        $("naarklant").setAttribute("href", href);
        if (u.uitkomst === "verstuurd") { location.href = href; return; }
        // Nog niet verstuurd: staat in de wachtrij. Niet automatisch navigeren, de verbinding is weg.
        D.melding($("nieuwmelding"), "");
        D.melding($("nieuwklaar"), T.nw.wachtOpslag);
        $("naarklant").hidden = false;
        $("nieuwform").hidden = true;
      });
    });
  });
})();

// Trajectscherm: fase als stappenlijst, datums met termijn, afvinken en heropenen, conflicten.
(function () {
  "use strict";
  var D = window.Dashboard;
  var K = window.Klanten;
  var W = window.Wachtrij;
  var B = window.Bewerk;
  var T = D.teksten.klanten;
  var $ = function (id) { return document.getElementById(id); };
  var API = "/api/dashboard/klanten";
  var rid = B.query("relatie");
  var tid = B.query("id");
  var serverData = null; // antwoord van GET /relaties/:id (of de cache daarvan): alleen serverdata
  var data = null; // serverData met de wachtende wijzigingen eroverheen
  var tr = null; // {record, termijnen, wachtend: {regelId: soort}} uit data
  var uitgesteld = false;
  var behoudTekst = null;
  var hadWachtend = false;
  var regels = [];
  var isObj = function (v) { return v !== null && typeof v === "object" && !Array.isArray(v); };

  function trajectPad() { return "/trajecten/" + encodeURIComponent(tid); }

  function patchActie(velden) {
    return { soort: "traject-wijzig", methode: "PATCH", pad: trajectPad(), body: { wijzigingId: W.nieuwId(), velden: velden },
      recordKey: tid, relatieId: rid, velden: Object.keys(velden) };
  }

  function cacheSchrijf() { if (serverData) W.kv.set("relatie:" + rid, { op: new Date().toISOString(), data: serverData }); }

  // Wachtende wijzigingen over de serverdata heen: velden, en afvinken/heropenen van termijnen.
  function metWachtrij(basis, items) {
    var d = JSON.parse(JSON.stringify(basis));
    var t = vind(d);
    if (!t) return { d: d, t: null };
    t.wachtend = {};
    items.forEach(function (x) {
      if (x.afgekeurd || x.recordKey !== tid) return;
      if (x.soort === "traject-wijzig") B.pas(t.record, x.body.velden);
      else if (x.soort === "afvinken" || x.soort === "heropenen") {
        var m = /\/termijnen\/([^/]+)\//.exec(x.pad);
        var regelId = m ? decodeURIComponent(m[1]) : null;
        (Array.isArray(t.termijnen) ? t.termijnen : []).forEach(function (term) {
          if (term && term.regelId === regelId) { term.status = x.soort === "afvinken" ? "afgevinkt" : "open"; term.wachtOp = x.soort; }
        });
        if (regelId) t.wachtend[regelId] = x.soort;
      }
    });
    return { d: d, t: t };
  }

  function toonMetWachtrij() {
    if (!serverData) return;
    if (B.open > 0) { uitgesteld = true; return; }
    uitgesteld = false;
    W.acties().then(function (items) {
      hadWachtend = items.some(function (x) { return x.recordKey === tid; });
      var r = metWachtrij(serverData, items);
      if (!r.t) return;
      data = r.d; tr = r.t;
      toonAlles();
    });
  }

  // Voert een actie uit en vertaalt de uitkomst; optimistisch() past het scherm aan als het nog moet wachten.
  function voerUit(actie) {
    return W.zet(actie, { direct: true }).then(function (u) {
      $("blokkade").textContent = "";
      D.melding($("blokkade-kop"), "");
      if (u.uitkomst === "geen-wie") return { fout: T.wachtrij.eerstInloggen };
      if (u.uitkomst === "afgekeurd") {
        var d = u.r && u.r.data;
        if (u.r.status === 409 && d && d.code === "open-fatale-termijn" && Array.isArray(d.termijnen)) {
          D.melding($("blokkade-kop"), T.tr.blokkade, true);
          d.termijnen.forEach(function (t) {
            var li = D.maak("li", { klasse: "veldrij", "data-blokkade": t && t.regelId ? t.regelId : "" });
            li.appendChild(D.maak("p", { klasse: "veldlabel" }, t && t.titel ? K.titel(t.titel) : T.fataal.onbekendeActie));
            li.appendChild(D.maak("p", { klasse: "veldwaarde" }, B.termijnTekst(t || {})));
            $("blokkade").appendChild(li);
          });
          return { fout: B.foutTekst("open-fatale-termijn") };
        }
        return { fout: B.uitkomstFout(u) };
      }
      if (u.uitkomst === "verstuurd") { laad(); return {}; }
      D.melding($("trmelding"), u.uitkomst === "wacht-eerder" ? T.wachtrij.wachtEerder : T.wachtrij.wacht);
      toonMetWachtrij();
      return {};
    });
  }

  function wijzig(velden) {
    return voerUit(patchActie(velden));
  }

  // ---------- fase ----------
  function toonStappen() {
    var rec = tr.record;
    var fases = T.keuzes.fase;
    var huidigIdx = fases.indexOf(rec.fase);
    var gedaan = {};
    (Array.isArray(rec.fasegeschiedenis) ? rec.fasegeschiedenis : []).forEach(function (e) { if (e && typeof e.fase === "string") gedaan[e.fase] = true; });
    var lijst = $("stappen");
    lijst.textContent = "";
    fases.forEach(function (f, i) {
      var isHuidig = f === rec.fase;
      var klaar = !isHuidig && (rec.fase === "Verloren" ? gedaan[f] === true : f !== "Verloren" && i < huidigIdx);
      var li = D.maak("li", { klasse: "stap" + (isHuidig ? " huidig" : klaar ? " gedaan" : ""), "data-fase": f });
      li.appendChild(D.maak("p", { klasse: "veldlabel" }, f));
      li.appendChild(D.maak("p", { klasse: "veldwaarde" }, isHuidig ? T.tr.huidig : klaar ? T.tr.gedaan : T.tr.nog));
      if (!isHuidig) {
        var knop = D.maak("button", { type: "button", klasse: "rand" }, K.vul(T.tr.zetFase, { fase: f }));
        var melding = D.maak("p", { klasse: "melding-tekst", role: "alert" });
        knop.addEventListener("click", function () {
          knop.disabled = true;
          D.melding(melding, T.bezig);
          wijzig({ fase: { oud: rec.fase === undefined ? null : rec.fase, nieuw: f } }).then(function (u) {
            knop.disabled = false;
            D.melding(melding, u.fout || "", !!u.fout);
          });
        });
        li.appendChild(knop);
        li.appendChild(melding);
      }
      lijst.appendChild(li);
    });
  }

  // ---------- termijnen ----------
  function termijnActie(pad, body, label) {
    return { soort: label, methode: "POST", pad: pad, body: body, recordKey: tid, relatieId: rid, velden: [] };
  }

  function toonTermijnen() {
    var items = (Array.isArray(tr.termijnen) ? tr.termijnen : []).filter(function (t) { return t && t.status !== "nvt"; });
    var lijst = $("termijnen");
    lijst.textContent = "";
    $("termijnen-leeg").textContent = items.length ? "" : T.tr.geenTermijnen;
    items.forEach(function (t) {
      var li = D.maak("li", { klasse: "veldrij", "data-regel": t.regelId || "" });
      li.appendChild(D.maak("p", { klasse: "veldlabel" }, K.titel(t.titel || T.fataal.onbekendeActie)));
      li.appendChild(D.maak("p", { klasse: "veldwaarde" }, B.termijnTekst(t) + ", " + B.fataalTekst(t)));
      var melding = D.maak("p", { klasse: "melding-tekst", role: "alert" });
      var pad = trajectPad() + "/termijnen/" + encodeURIComponent(t.regelId) + "/";
      var acties = Array.isArray(t.afvinkActies) ? t.afvinkActies : [];
      var knoppen = D.maak("div", { klasse: "acties" });
      var wacht = tr.wachtend && K.eigen(tr.wachtend, t.regelId);
      function doe(knop, soort, body) {
        knop.addEventListener("click", function () {
          Array.prototype.forEach.call(knoppen.querySelectorAll("button"), function (b) { b.disabled = true; });
          voerUit(termijnActie(pad + (soort === "afvinken" ? "afvinken" : "heropenen"), body, soort)).then(function (u) {
            Array.prototype.forEach.call(knoppen.querySelectorAll("button"), function (b) { b.disabled = false; });
            D.melding(melding, u.fout || "", !!u.fout);
          });
        });
      }
      if (t.status === "afgevinkt") {
        var h = D.maak("button", { type: "button", klasse: "rand", "data-actie": "heropenen" }, T.tr.heropenen);
        doe(h, "heropenen", { wijzigingId: W.nieuwId() });
        knoppen.appendChild(h);
      } else if (["open", "herbevestigen", "niet-bevestigd"].indexOf(t.status) !== -1) {
        if (acties.length) {
          acties.forEach(function (a) {
            var b = D.maak("button", { type: "button", "data-actie": "afvinken" }, K.vul(T.tr.afvinken, { actie: a }));
            doe(b, "afvinken", { actie: a, wijzigingId: W.nieuwId() });
            knoppen.appendChild(b);
          });
        } else if (t.fataal === false) {
          var b2 = D.maak("button", { type: "button", "data-actie": "afvinken" }, T.tr.afvinkenZonder);
          doe(b2, "afvinken", { wijzigingId: W.nieuwId() });
          knoppen.appendChild(b2);
        } else {
          li.appendChild(D.maak("p", { klasse: "veldextra" }, T.tr.geenActies));
        }
      }
      if (wacht) {
        // Er staat al een actie voor deze termijn in de wachtrij: geen tweede actie tot die is verstuurd.
        Array.prototype.forEach.call(knoppen.querySelectorAll("button"), function (b) { b.disabled = true; });
        li.appendChild(D.maak("p", { klasse: "veldextra" }, T.tr.wachtOpVerzending));
      }
      li.appendChild(knoppen);
      li.appendChild(melding);
      lijst.appendChild(li);
    });
  }

  // ---------- datums met de termijn ernaast ----------
  function toonGegevens() {
    var lijst = $("gegevens");
    lijst.textContent = "";
    var rec = tr.record;
    B.TRAJECT.forEach(function (v) {
      var veld = v[0];
      var naast = [];
      regels.forEach(function (r) {
        if (!isObj(r) || !isObj(r.start) || r.start.soort !== "veld" || r.start.waarde !== veld) return;
        (Array.isArray(tr.termijnen) ? tr.termijnen : []).forEach(function (t) {
          if (t && t.regelId === r.id && t.status !== "nvt") naast.push(K.titel(t.titel || "") + ": " + B.termijnTekst(t));
        });
      });
      lijst.appendChild(B.veldRegel(veld, rec[veld] === undefined ? null : rec[veld], {
        opSlaan: wijzig, extra: naast.length ? K.vul(T.tr.termijn, {}) + ": " + naast.join("; ") : "",
      }));
    });
  }

  function toonConflicten() {
    W.conflicten().then(function (alle) {
      var eigen = alle.filter(function (c) { return c.recordSoort === "traject" && c.recordKey === tid; });
      B.toonConflicten($("conflict"), eigen, {
        maakPatch: function (e, velden) { return patchActie(velden); },
        melding: function (t, fout) { behoudTekst = t; D.melding($("trmelding"), t, fout); },
        na: function () { laad(); },
      });
    });
  }

  function toonAlles() {
    $("inhoud").hidden = false;
    var rel = data && data.relatie ? K.naamEnPlaats({ achternaam: data.relatie.achternaam, plaats: data.relatie.plaats, naam: data.relatie.achternaam }) : "";
    $("naam").textContent = (tr.record.fase || T.tr.kop);
    $("subkop").textContent = [rel, tr.record.route].filter(Boolean).join(", ");
    toonStappen();
    toonTermijnen();
    toonGegevens();
    toonConflicten();
  }

  // ---------- laden ----------
  function vind(d) {
    var lijst = d && Array.isArray(d.trajecten) ? d.trajecten : [];
    return lijst.filter(function (x) { return x && x.record && x.record.id === tid; })[0] || null;
  }

  function uitCache(status) {
    // 404 of 410 van onze eigen server: het record bestaat niet (meer). Nooit terugvallen op de cache; die ook wissen.
    // Bij 404 blijft een nog niet verstuurd traject uit de wachtrij wel zichtbaar (de relatie is dan zelf nog niet aangemaakt).
    var weg = status === 404 || status === 410;
    var wis = weg ? Promise.all([W.kv.del("relatie:" + rid), W.kv.del("tijdlijn:" + rid)]) : Promise.resolve();
    return wis.then(function () {
      if (status === 410) { D.melding($("trmelding"), T.tr.nietGevonden, true); return; }
      return Promise.all([weg ? null : W.kv.get("relatie:" + rid), W.acties()]).then(function (r) {
      var c = r[0];
      var gevonden = c && c.data ? vind(c.data) : null;
      if (gevonden) serverData = c.data;
      else {
        // Een traject dat nog in de wachtrij staat.
        var nieuw = r[1].filter(function (x) { return x.soort === "traject-nieuw" && x.recordKey === tid; })[0];
        if (nieuw) {
          var basis = c && c.data ? JSON.parse(JSON.stringify(c.data)) : { relatie: null, trajecten: [] };
          basis.trajecten = (basis.trajecten || []).concat([{ record: Object.assign({ id: tid, relatieId: rid }, nieuw.body.velden), termijnen: [] }]);
          serverData = basis;
          gevonden = vind(basis);
        }
      }
      if (!gevonden) {
        D.melding($("trmelding"), status === 404 ? T.tr.nietGevonden : status === 0 ? D.teksten.algemeen.geenVerbinding : D.teksten.algemeen.foutAlgemeen, true);
        return;
      }
      D.melding($("trmelding"), c ? K.vul(T.rel.standOffline, { moment: K.moment(new Date(c.op)) }) : T.rel.nogNietVerstuurd, !!c);
      toonMetWachtrij();
      });
    });
  }

  function laad() {
    if (!rid || !tid) { D.melding($("trmelding"), T.tr.nietGevonden, true); return; }
    $("terug").setAttribute("href", K.relatieHref(rid));
    D.api(API + "/relaties/" + encodeURIComponent(rid)).then(function (r) {
      var g = r.ok && r.data ? vind(r.data) : null;
      if (g) {
        serverData = r.data;
        if ($("trmelding").textContent !== behoudTekst) D.melding($("trmelding"), "");
        cacheSchrijf();
        toonMetWachtrij();
      } else if (r.ok) {
        D.melding($("trmelding"), T.tr.nietGevonden, true);
      } else return uitCache(r.status);
    }).catch(function () { return uitCache(0); });
  }

  document.addEventListener("DOMContentLoaded", function () {
    document.addEventListener("wachtrij-gewijzigd", function () {
      if (!serverData) return;
      toonConflicten();
      W.acties().then(function (items) {
        var n = items.filter(function (x) { return x.recordKey === tid; }).length;
        if (hadWachtend && n === 0) { hadWachtend = false; laad(); } else toonMetWachtrij();
      });
    });
    document.addEventListener("editor-gesloten", function () { if (uitgesteld) toonMetWachtrij(); });
    D.api(API + "/regels").then(function (r) {
      if (r.ok && r.data && Array.isArray(r.data.regels)) { regels = r.data.regels; W.kv.set("regels", { op: new Date().toISOString(), regels: r.data.regels }); if (tr && !B.open) toonGegevens(); }
      else W.kv.get("regels").then(function (c) { if (c && Array.isArray(c.regels)) { regels = c.regels; if (tr) toonGegevens(); } });
    });
    laad();
  });
})();

// Overzicht (Zoho: rapporten): leads per bron/status/eigenaar/maand, van lead naar klant, trajecten per fase en
// route, gemiddelde tijd per fase, en geld. De server geeft alleen aantallen en bedragen, geen namen.
(function () {
  "use strict";
  var D = window.Dashboard;
  var K = window.Klanten;
  var T = D.teksten.klanten;
  var O = T.overzicht;
  var $ = function (id) { return document.getElementById(id); };
  var PERIODEN = ["maand", "kwartaal", "jaar", "alles"];
  var cache = {};
  var teller = 0;

  function iso(d) { return d.toISOString().slice(0, 10); }
  // Periode als {van, tot} in Amsterdamse datums; "alles" zonder grenzen.
  function grenzen(keuze) {
    var vandaag = K.vandaagLokaal();
    var j = Number(vandaag.slice(0, 4));
    var m = Number(vandaag.slice(5, 7));
    if (keuze === "maand") return { van: vandaag.slice(0, 8) + "01", tot: vandaag };
    if (keuze === "jaar") return { van: j + "-01-01", tot: vandaag };
    if (keuze === "kwartaal") return { van: iso(new Date(Date.UTC(j, m - 3, 1, 12))), tot: vandaag };
    return {};
  }

  function naamVan(w) { return w === "onbekend" ? O.onbekend : K.eigen(T.lijst.eigenaren, w) || w; }

  // Lijst met getal en een balk naar verhouding van de grootste waarde. Nullen worden weggelaten.
  function telling(kop, waarden, opties) {
    var o = opties || {};
    var sec = D.maak("section");
    sec.appendChild(D.maak("h3", null, kop));
    var sleutels = Object.keys(waarden || {}).filter(function (k) { return waarden[k] > 0; });
    if (!sleutels.length) { sec.appendChild(D.maak("p", { klasse: "rustig" }, O.niets)); return sec; }
    var max = Math.max.apply(null, sleutels.map(function (k) { return waarden[k]; }));
    var ul = D.maak("ul", { klasse: "telling" });
    sleutels.forEach(function (k) {
      var li = D.maak("li");
      var kopregel = D.maak("p", { klasse: "regel-kop" });
      kopregel.appendChild(D.maak("span", null, o.label ? o.label(k) : naamVan(k)));
      kopregel.appendChild(D.maak("span", { klasse: "getal" }, String(waarden[k])));
      li.appendChild(kopregel);
      var staaf = D.maak("div", { klasse: "staaf", "aria-hidden": "true" });
      var vul = D.maak("span");
      vul.style.width = Math.max(2, Math.round((waarden[k] / max) * 100)) + "%";
      staaf.appendChild(vul);
      li.appendChild(staaf);
      ul.appendChild(li);
    });
    sec.appendChild(ul);
    return sec;
  }

  function kern(regels) {
    var ul = D.maak("ul", { klasse: "kerngetallen" });
    regels.filter(Boolean).forEach(function (t) { ul.appendChild(D.maak("li", null, t)); });
    return ul;
  }

  function maand(ym) {
    var d = new Date(ym + "-15T12:00:00Z");
    return isNaN(d) ? ym : d.toLocaleDateString("nl-NL", { month: "long", year: "numeric", timeZone: "UTC" });
  }

  function pct(a, b) { return b ? Math.round((a / b) * 100) + "%" : "0%"; }

  // Elk onderwerp is een eigen blok (op een breed scherm naast elkaar); tellingen binnen een blok in een raster.
  function blok(w, kop) {
    var sec = D.maak("section", { klasse: "blok" });
    sec.appendChild(D.maak("h2", null, kop));
    w.appendChild(sec);
    return sec;
  }
  function raster(sec) {
    var r = D.maak("div", { klasse: "tellingen" });
    sec.appendChild(r);
    return r;
  }

  function toon(data, stand) {
    var w = $("inhoud");
    w.textContent = "";
    var L = data.leads || {};
    var Tr = data.trajecten || {};
    var G = data.geld || {};

    var leads = blok(w, O.leadsKop);
    leads.appendChild(kern([
      L.totaal === 1 ? O.leadsTotaalEen : K.vul(O.leadsTotaal, { n: L.totaal || 0 }),
      L.zonderDatum ? K.vul(O.zonderDatum, { n: L.zonderDatum }) : null,
    ]));
    var r1 = raster(leads);
    r1.appendChild(telling(O.perBron, L.perBron));
    r1.appendChild(telling(O.perMaand, L.perMaand, { label: maand }));
    r1.appendChild(telling(O.perStatus, L.perStatus));
    r1.appendChild(telling(O.perEigenaar, L.perEigenaar));

    var conversie = blok(w, O.conversieKop);
    conversie.appendChild(D.maak("p", { klasse: "rustig" }, O.conversieUitleg));
    var conv = data.conversie || {};
    var conversieRegels = Object.keys(conv).filter(function (b) { return conv[b].leads > 0; }).map(function (b) {
      return K.vul(O.conversieRij, { bron: naamVan(b), klanten: conv[b].klanten, leads: conv[b].leads, pct: pct(conv[b].klanten, conv[b].leads) });
    });
    conversie.appendChild(conversieRegels.length ? kern(conversieRegels) : D.maak("p", { klasse: "rustig" }, O.niets));

    var geld = blok(w, O.geldKop);
    var bedrag = function (x) { return K.euro((x && x.bedrag) || 0); };
    var n = function (x) { return (x && x.aantal) || 0; };
    geld.appendChild(kern([
      K.vul(O.feePijplijn, { bedrag: bedrag(G.feePijplijn), n: n(G.feePijplijn) }),
      K.vul(O.feeGefactureerd, { bedrag: bedrag(G.feeGefactureerd), n: n(G.feeGefactureerd) }),
      G.feeGefactureerd && G.feeGefactureerd.ouderDan30Dagen ? K.vul(O.feeOud, { n: G.feeGefactureerd.ouderDan30Dagen }) : null,
      K.vul(O.feeVoldaan, { bedrag: bedrag(G.feeVoldaan), n: n(G.feeVoldaan) }),
      K.vul(O.uitkering, { bedrag: bedrag(G.uitkeringImg), n: n(G.uitkeringImg) }),
    ]));

    var trajecten = blok(w, O.trajectenKop);
    trajecten.appendChild(kern([
      K.vul(O.open, { n: Tr.open || 0 }),
      K.vul(O.getekend, { n: Tr.getekend || 0 }),
      K.vul(O.afgerond, { n: Tr.afgerond || 0 }),
      K.vul(O.verloren, { n: Tr.verloren || 0 }),
    ]));
    var r2 = raster(trajecten);
    r2.appendChild(telling(O.perFase, Tr.perFase));
    r2.appendChild(telling(O.perRoute, Tr.perRoute));
    r2.appendChild(telling(O.redenVerlies, Tr.redenVerlies));
    var dl = Tr.doorlooptijd || {};
    var dlSec = D.maak("section");
    dlSec.appendChild(D.maak("h3", null, O.doorlooptijdKop));
    var dlRegels = Object.keys(dl).map(function (f) { return K.vul(O.doorlooptijdRij, { fase: f, d: K.dagen(dl[f].gemiddeld), n: dl[f].aantal }); });
    dlSec.appendChild(dlRegels.length ? kern(dlRegels) : D.maak("p", { klasse: "rustig" }, O.niets));
    r2.appendChild(dlSec);

    var ontbreekt = (data.onvolledig || 0) + (data.onleesbaar || 0);
    var meld = [];
    if (ontbreekt) meld.push(K.vul(O.ontbreekt, { n: ontbreekt }));
    if (stand) meld.push(K.vul(O.stand, { moment: K.moment(stand) }));
    D.melding($("melding"), meld.join(" "), ontbreekt > 0);
  }

  function laad() {
    var keuze = $("periode").value;
    var g = grenzen(keuze);
    var p = new URLSearchParams();
    if (g.van) p.set("van", g.van);
    if (g.tot) p.set("tot", g.tot);
    var sleutel = p.toString();
    var nr = ++teller;
    D.api("/api/dashboard/klanten/overzicht" + (sleutel ? "?" + sleutel : "")).then(function (r) {
      if (nr !== teller) return;
      if (r.ok && r.data && r.data.leads) {
        cache[sleutel] = { data: r.data, op: new Date() };
        toon(r.data, null);
      } else if (cache[sleutel]) {
        toon(cache[sleutel].data, cache[sleutel].op);
      } else {
        $("inhoud").textContent = "";
        D.melding($("melding"), r.status === 0 ? D.teksten.algemeen.geenVerbinding : O.mislukt, true);
      }
    });
  }

  function init() {
    PERIODEN.forEach(function (p) { $("periode").appendChild(D.maak("option", { value: p }, O.perioden[p])); });
    $("periode").value = "jaar";
    $("periode").addEventListener("change", laad);
    $("periodeform").addEventListener("submit", function (e) { e.preventDefault(); laad(); });
    laad();
  }

  document.addEventListener("DOMContentLoaded", init);
})();

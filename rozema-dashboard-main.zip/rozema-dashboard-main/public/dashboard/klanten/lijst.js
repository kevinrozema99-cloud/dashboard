// Leads en Klanten (opdracht Ruben 20-11-2026: twee aparte databases). Dezelfde lijst, de soort staat op <body data-soort>:
//   lead:  alles wat nog geen klant is, filter op leadstatus.
//   klant: relaties met een traject, filter op de fase van een van hun trajecten.
// Gearchiveerd (afgevallen, of elk traject uitbetaald/afgerond/verloren) staat er niet in, tenzij "Toon gearchiveerd".
// Cache alleen in het geheugen.
(function () {
  "use strict";
  var D = window.Dashboard;
  var K = window.Klanten;
  var T = D.teksten.klanten;
  var L = T.lijst;
  var $ = function (id) { return document.getElementById(id); };
  var DEBOUNCE_MS = 300;
  var cache = {}; // sleutel (zoekopdracht) -> {data, op}
  var teller = 0;
  var timer = null;
  var SOORT = document.body.getAttribute("data-soort") === "lead" ? "lead" : "klant";
  // Een filter op een archiefstatus of -fase toont het archief vanzelf mee (anders blijft de lijst leeg).
  var ARCHIEF_KEUZES = ["Afgevallen", "Uitbetaald", "Afgerond", "Verloren"];

  function vulKeuze(select, opties) {
    select.appendChild(D.maak("option", { value: "" }, L.alle));
    opties.forEach(function (o) { select.appendChild(D.maak("option", { value: o[0] }, o[1])); });
  }

  function achternaamVan(r) {
    return K.naamEnPlaats({ achternaam: r.achternaam, naam: r.naam }); // zonder losse achternaam: de hele naam
  }

  // Vier kolommen (opdracht Ruben 20-11-2026): contactpersoon, e-mail, telefoon, volgende taak. Altijd vier cellen,
  // ook leeg, zodat ze op een breed scherm recht onder elkaar staan.
  function rij(r) {
    var li = D.maak("li", r.gearchiveerd ? { klasse: "gearchiveerd" } : null);
    var a = D.maak("a", { href: K.relatieHref(r.id), klasse: "rij" });
    var naam = [r.voornaam, r.achternaam].filter(Boolean).join(" ") || achternaamVan(r);
    // Eerste kolom: naam met de plaats eronder (samen één cel).
    var cel = D.maak("div", { klasse: "cel" });
    var pn = D.maak("p", { klasse: "naam" }, naam);
    if (r.gearchiveerd) pn.appendChild(D.maak("span", { klasse: "label" }, L.gearchiveerd));
    cel.appendChild(pn);
    if (r.plaats) cel.appendChild(D.maak("p", { klasse: "wat" }, r.plaats));
    a.appendChild(cel);
    a.appendChild(D.maak("p", { klasse: "wat" }, r.email || ""));
    a.appendChild(D.maak("p", { klasse: "wat" }, r.telefoon || ""));
    var t = r.volgendeTaak;
    var titel = !t ? null : t.bron === "flow" ? K.eigen(T.flow, t.stap) || T.flow.onbekend : t.titel ? K.titel(t.titel) : T.taken.zonderTitel;
    var actie = t ? titel + (t.datum ? ", " + K.datum(t.datum) : "") + (t.tijd ? ", " + K.vul(T.taken.om, { tijd: t.tijd }) : "") : L.geenActie;
    a.appendChild(D.maak("p", { klasse: "termijn" + (t && t.datum && t.datum < K.vandaagLokaal() ? " telaat" : "") }, actie));
    li.appendChild(a);
    return li;
  }

  function toon(data, stand, melding) {
    var lijst = $("resultaat");
    lijst.textContent = "";
    var rijen = (data && data.relaties) || [];
    // Kolomkoppen boven de lijst; alleen zichtbaar op een breed scherm (klanten.css). Voor schermlezers verborgen:
    // elke rij leest al als één geheel.
    var kop = $("koprij");
    if (!kop.childNodes.length) {
      [L.kolommen.naam, L.kolommen.email, L.kolommen.telefoon, L.kolommen.actie].forEach(function (t) { kop.appendChild(D.maak("span", null, t)); });
    }
    kop.hidden = rijen.length === 0;
    rijen.forEach(function (r) { lijst.appendChild(rij(r)); });
    var totaal = typeof data.totaal === "number" ? data.totaal : rijen.length;
    var tekst = SOORT === "lead"
      ? (totaal === 0 ? L.leegLeads : totaal === 1 ? L.aantalEenLead : K.vul(L.aantalMeerLeads, { n: totaal }))
      : (totaal === 0 ? L.leeg : totaal === 1 ? L.aantalEen : K.vul(L.aantalMeer, { n: totaal }));
    if (data.afgekapt) tekst += ". " + K.vul(L.afgekapt, { n: rijen.length });
    $("aantal").textContent = tekst;
    D.melding($("lijstmelding"), stand ? K.vul(melding, { moment: K.moment(stand) }) : "", false);
  }

  function zoekparams() {
    var p = new URLSearchParams();
    p.set("soort", SOORT);
    var q = $("zoek").value.trim();
    if (q) p.set("q", q);
    var keuze = $("status").value;
    if (keuze) p.set(SOORT === "lead" ? "status" : "fase", keuze);
    if ($("archief").checked || ARCHIEF_KEUZES.indexOf(keuze) >= 0) p.set("archief", "toon");
    if ($("eigenaar").value) p.set("eigenaar", $("eigenaar").value);
    return p.toString();
  }

  function laad() {
    var sleutel = zoekparams();
    var nr = ++teller;
    D.api("/api/dashboard/klanten/relaties" + (sleutel ? "?" + sleutel : "")).then(function (r) {
      if (nr !== teller) return; // een nieuwere zoekopdracht is onderweg
      if (r.ok && r.data && Array.isArray(r.data.relaties)) {
        cache[sleutel] = { data: r.data, op: new Date() };
        toon(r.data, null);
      } else if (cache[sleutel]) {
        toon(cache[sleutel].data, cache[sleutel].op, r.status === 0 ? L.stand : L.standMislukt);
      } else {
        $("resultaat").textContent = "";
        $("aantal").textContent = "";
        D.melding($("lijstmelding"), r.status === 0 ? D.teksten.algemeen.geenVerbinding : L.mislukt, true);
      }
    });
  }

  function init() {
    var keuzes = SOORT === "lead"
      ? L.statussen.filter(function (s) { return s !== "Klant"; }).map(function (s) { return [s, K.eigen(T.pijplijn.kolomNamen, s) || s]; })
      : T.keuzes.fase.map(function (f) { return [f, f]; });
    vulKeuze($("status"), keuzes);
    vulKeuze($("eigenaar"), Object.keys(L.eigenaren).map(function (k) { return [k, L.eigenaren[k]]; }));
    $("zoek").addEventListener("input", function () {
      clearTimeout(timer);
      timer = setTimeout(laad, DEBOUNCE_MS);
    });
    $("status").addEventListener("change", laad);
    $("eigenaar").addEventListener("change", laad);
    $("archief").addEventListener("change", laad);
    $("zoekform").addEventListener("submit", function (e) {
      e.preventDefault();
      clearTimeout(timer);
      laad();
    });
    laad();
  }

  document.addEventListener("DOMContentLoaded", init);
})();

// Relatiescherm: contact, gegevens per veld, termijnen, taken, trajecten, tijdlijn, conflicten.
(function () {
  "use strict";
  var D = window.Dashboard;
  var K = window.Klanten;
  var W = window.Wachtrij;
  var B = window.Bewerk;
  var T = D.teksten.klanten;
  var $ = function (id) { return document.getElementById(id); };
  var API = "/api/dashboard/klanten";
  var id = B.query("id");
  var serverData = null; // alleen wat de server (of de cache van de server) zei
  var data = null; // serverData met de wachtende wijzigingen eroverheen: wat het scherm toont
  var uitgesteld = false;
  var behoudTekst = null; // de melding van een conflictkeuze mag de verversing erna niet wissen
  var hadWachtend = false;
  var wie = "Onbekend";
  var isObj = function (v) { return v !== null && typeof v === "object" && !Array.isArray(v); };

  function nieuweId(voorvoegsel) { return voorvoegsel + W.nieuwId(); }

  // ---------- schrijven ----------
  function schrijf(actie) {
    behoudTekst = null;
    return W.zet(actie, { direct: true }).then(function (u) {
      var fout = B.uitkomstFout(u);
      if (fout) return { fout: fout };
      if (u.uitkomst === "verstuurd") { laad(); return {}; }
      // Wacht op verbinding of op een eerdere wijziging: de wijziging staat in de wachtrij en wordt eroverheen getoond.
      D.melding($("relmelding"), u.uitkomst === "wacht-eerder" ? T.wachtrij.wachtEerder : T.wachtrij.wacht);
      toonMetWachtrij();
      return {};
    });
  }

  function patchActie(velden) {
    return {
      soort: "relatie-wijzig", methode: "PATCH", pad: "/relaties/" + encodeURIComponent(id),
      body: { wijzigingId: W.nieuwId(), velden: velden }, recordKey: id, relatieId: id, velden: Object.keys(velden),
    };
  }

  function wijzig(velden) {
    return schrijf(patchActie(velden));
  }

  // ---------- cache: alleen serverdata ----------
  function cacheSchrijf() {
    if (!serverData) return;
    W.kv.set("relatie:" + id, { op: new Date().toISOString(), data: serverData });
  }

  // Legt de wachtende wijzigingen van deze klant over de serverdata heen (niet de afgekeurde).
  function metWachtrij(basis, items) {
    var d = JSON.parse(JSON.stringify(basis));
    if (!Array.isArray(d.trajecten)) d.trajecten = [];
    items.forEach(function (x) {
      if (x.afgekeurd || x.relatieId !== id) return;
      if (x.soort === "relatie-wijzig") B.pas(d.relatie, x.body.velden);
      else if (x.soort === "traject-nieuw") {
        if (!d.trajecten.some(function (t) { return t.record && t.record.id === x.recordKey; })) {
          d.trajecten.push({ record: Object.assign({ id: x.body.id, relatieId: id }, x.body.velden), termijnen: [] });
        }
      } else if (x.soort === "traject-wijzig") {
        d.trajecten.forEach(function (t) { if (t.record && t.record.id === x.recordKey) B.pas(t.record, x.body.velden); });
      }
    });
    return d;
  }

  function toonMetWachtrij() {
    if (!serverData) return;
    if (B.open > 0) { uitgesteld = true; return; } // geen open editor wegvegen
    uitgesteld = false;
    W.acties().then(function (items) {
      hadWachtend = items.some(function (x) { return x.relatieId === id; });
      data = metWachtrij(serverData, items);
      toonAlles();
    });
  }

  // ---------- weergave ----------
  function telefoonCijfers(nr) { return String(nr).replace(/[^0-9+]/g, ""); }
  function waNummer(nr) {
    var c = String(nr).replace(/[^0-9+]/g, "");
    if (c.indexOf("+") === 0) return c.slice(1);
    if (c.indexOf("00") === 0) return c.slice(2);
    if (c.indexOf("0") === 0) return "31" + c.slice(1);
    return c;
  }

  function toonKop() {
    var r = data.relatie;
    $("naam").textContent = K.naamEnPlaats({ achternaam: r.achternaam, plaats: r.plaats, naam: r.achternaam });
    var extra = [r.status, r.eigenaar ? B.optieTekst("eigenaar", r.eigenaar) : null].filter(Boolean).join(", ");
    $("subkop").textContent = extra;
    document.title = (r.achternaam || T.relatie.kop) + " - " + D.teksten.merk;
  }

  function toonContact() {
    var r = data.relatie;
    var vak = $("contact");
    vak.textContent = "";
    // Alleen een echt nummer (minstens 9 cijfers) geeft een knop; de href bevat alleen cijfers en een plusteken.
    var geldig = function (n) { return typeof n === "string" && n.replace(/\D/g, "").length >= 9; };
    var mob = geldig(r.mobiel) ? r.mobiel : null;
    var tel = geldig(r.telefoon) ? r.telefoon : null;
    var nr = mob || tel;
    if (mob && tel && telefoonCijfers(mob) !== telefoonCijfers(tel)) {
      vak.appendChild(D.maak("a", { klasse: "knop", href: "tel:" + telefoonCijfers(mob), "data-actie": "bel" }, T.contact.belMobiel));
      vak.appendChild(D.maak("a", { klasse: "knop", href: "tel:" + telefoonCijfers(tel), "data-actie": "bel-telefoon" }, T.contact.belTelefoon));
    } else if (nr) {
      vak.appendChild(D.maak("a", { klasse: "knop", href: "tel:" + telefoonCijfers(nr), "data-actie": "bel" }, T.contact.bel));
    }
    if (nr) vak.appendChild(D.maak("a", { klasse: "knop rand", href: "https://wa.me/" + waNummer(nr), "data-actie": "whatsapp", rel: "noopener" }, T.contact.whatsapp));
    var adres = [[r.straat, r.huisnummer, r.toevoeging].filter(Boolean).join(" "), [r.postcode, r.plaats].filter(Boolean).join(" ")].filter(Boolean).join(", ");
    if (r.straat && r.plaats) {
      vak.appendChild(D.maak("a", { klasse: "knop rand", href: "https://www.google.com/maps/search/?api=1&query=" + encodeURIComponent(adres), "data-actie": "navigeer", rel: "noopener" }, T.contact.navigeer));
    }
  }

  // Gegevens in groepen, zoals in Zoho (Miller: liever een paar korte blokken dan één lange lijst). Een veld dat in geen
  // groep staat, komt onder Omschrijving: zo valt er nooit een veld weg.
  var GROEPEN = [
    ["lead", ["eigenaar", "aanhef", "voornaam", "achternaam", "telefoon", "mobiel", "email", "contactvoorkeur", "bron", "status", "terugbeldatum", "soortWoning"]],
    ["kwalificatie", ["situatie", "kwalificatie", "redenAfgevallen", "trillingMms", "bouwjaar", "ruimtesMetSchade", "eerderOntvangen", "bkoZone"]],
    ["adres", ["straat", "huisnummer", "toevoeging", "postcode", "plaats", "bagId"]],
    ["omschrijving", ["notitie", "dossier", "voorWie"]],
  ];
  function toonGegevens() {
    var r = data.relatie;
    var vak = $("gegevens");
    vak.textContent = "";
    var gehad = {};
    GROEPEN.forEach(function (g) { g[1].forEach(function (v) { gehad[v] = true; }); });
    var rest = B.RELATIE.map(function (v) { return v[0]; }).filter(function (v) { return !gehad[v]; });
    GROEPEN.forEach(function (g, i) {
      vak.appendChild(D.maak("h3", { klasse: "groepkop" }, K.eigen(T.rel.groepen, g[0]) || g[0]));
      var lijst = D.maak("ul", { klasse: "veldlijst" });
      g[1].concat(i === GROEPEN.length - 1 ? rest : []).forEach(function (veld) {
        var opties = { opSlaan: wijzig };
        if (veld === "status") opties.reden = { huidig: r.redenAfgevallen === undefined ? null : r.redenAfgevallen };
        lijst.appendChild(B.veldRegel(veld, r[veld] === undefined ? null : r[veld], opties));
      });
      vak.appendChild(lijst);
    });
    // Wie maakte en wijzigde de klant (alleen lezen).
    var sys = D.maak("ul", { klasse: "veldlijst" });
    [["aangemaakt", T.rel.gemaaktDoor], ["gewijzigd", T.rel.gewijzigdDoor]].forEach(function (p) {
      var w = r[p[0]];
      if (!isObj(w) || !w.wie) return;
      var li = D.maak("li", { klasse: "veldrij" });
      li.appendChild(D.maak("p", { klasse: "veldlabel" }, p[1]));
      var d = new Date(w.op);
      li.appendChild(D.maak("p", { klasse: "veldwaarde" }, w.wie + (isNaN(d) ? "" : ", " + K.moment(d))));
      sys.appendChild(li);
    });
    if (sys.childNodes.length) { vak.appendChild(D.maak("h3", { klasse: "groepkop" }, T.rel.groepen.systeem)); vak.appendChild(sys); }
  }

  // Volgende stap (opdracht Ruben 20-11-2026): de flow-taak en bevestigde termijnen van deze klant, uit de server
  // (data.taken, zonder de handmatige taken: die staan hieronder bij Taken). Bij de belketen één knop naar de
  // volgende status.
  var VOLGENDE_STATUS = { "Nieuw": "Poging 1", "Poging 1": "Poging 2", "Poging 2": "Poging 3", "Poging 3": "WhatsApp verstuurd" };
  function toonRelatieTermijnen() {
    var lijst = $("rel-termijnen");
    lijst.textContent = "";
    var items = (Array.isArray(data.taken) ? data.taken : []).filter(function (t) { return isObj(t) && t.bron !== "handmatig"; });
    $("rel-termijnen-leeg").textContent = items.length ? "" : T.rel.geenTermijnen;
    items.forEach(function (t) {
      var li = D.maak("li", { klasse: "veldrij" });
      var titel = t.bron === "flow" ? K.eigen(T.flow, t.stap) || T.flow.onbekend : K.titel(t.titel || T.fataal.onbekendeActie);
      li.appendChild(D.maak("p", { klasse: "veldlabel" }, titel));
      if (t.datum) li.appendChild(D.maak("p", { klasse: "veldwaarde" }, K.datum(t.datum, { weekdag: true, jaar: true })));
      var vervolg = t.bron === "flow" && !t.trajectId ? K.eigen(VOLGENDE_STATUS, data.relatie.status) : null;
      if (vervolg) {
        var knop = D.maak("button", { type: "button", "data-vervolg": vervolg }, K.vul(T.rel.vervolg, { status: vervolg }));
        var melding = D.maak("p", { klasse: "melding-tekst", role: "alert" });
        knop.addEventListener("click", function () {
          knop.disabled = true;
          var velden = { status: { oud: data.relatie.status === undefined ? null : data.relatie.status, nieuw: vervolg } };
          wijzig(velden).then(function (u) { knop.disabled = false; if (u.fout) D.melding(melding, u.fout, true); });
        });
        li.appendChild(knop);
        li.appendChild(melding);
      }
      lijst.appendChild(li);
    });
  }

  // ---------- taken ----------
  function toonTaken() {
    var taken = isObj(data.relatie.taken) ? data.relatie.taken : {};
    var ids = Object.keys(taken).filter(function (k) { return isObj(taken[k]); });
    ids.sort(function (a, b) {
      var ta = taken[a]; var tb = taken[b];
      return (ta.klaar ? 1 : 0) - (tb.klaar ? 1 : 0) || String(ta.datum || "9999").localeCompare(String(tb.datum || "9999")) || a.localeCompare(b);
    });
    var lijst = $("taken");
    lijst.textContent = "";
    $("taken-leeg").textContent = ids.length ? "" : T.rel.geenTaken;
    ids.forEach(function (tid) {
      var t = taken[tid];
      var li = D.maak("li", { klasse: "veldrij", "data-taak": tid });
      li.appendChild(D.maak("p", { klasse: "veldlabel" }, t.titel ? K.titel(t.titel) : T.taken.zonderTitel));
      var delen = [t.soort ? B.optieTekst("soort", t.soort) : null, t.datum ? K.datum(t.datum, { jaar: true }) : null,
        t.tijd ? K.vul(T.taken.om, { tijd: t.tijd }) : null, t.eigenaar ? B.optieTekst("eigenaar", t.eigenaar) : null].filter(Boolean);
      li.appendChild(D.maak("p", { klasse: "veldwaarde" }, delen.join(", ")));
      if (t.klaar) {
        li.appendChild(D.maak("p", { klasse: "veldextra" }, K.vul(T.rel.klaarDoor, { wie: t.klaar.wie || "" })));
      } else {
        var knop = D.maak("button", { type: "button", klasse: "rand" }, T.rel.klaar);
        var melding = D.maak("p", { klasse: "melding-tekst", role: "alert" });
        knop.addEventListener("click", function () {
          knop.disabled = true;
          var velden = {};
          velden["taken." + tid + ".klaar"] = { oud: null, nieuw: { wie: wie, op: new Date().toISOString() } };
          wijzig(velden).then(function (u) { knop.disabled = false; if (u.fout) D.melding(melding, u.fout, true); });
        });
        li.appendChild(knop);
        li.appendChild(melding);
      }
      lijst.appendChild(li);
    });
  }

  // Een klein formulier met velden uit een lijst [[veld,type],...]; opVerstuur(waarden) -> Promise<{fout}>.
  function formulier(vak, specs, knopTekst, opVerstuur) {
    vak.textContent = "";
    var invoeren = {};
    specs.forEach(function (s) {
      var d = D.maak("div", { klasse: "veld" });
      var fid = vak.id + "-" + s.veld;
      d.appendChild(D.maak("label", { for: fid }, B.label(s.veld)));
      var inv = B.invoer(s.veld, s.start === undefined ? null : s.start, fid);
      if (s.opties) { inv.el.textContent = ""; inv.el.appendChild(D.maak("option", { value: "" }, T.nietIngevuld)); s.opties.forEach(function (o) { var op = D.maak("option", { value: o }, B.optieTekst(s.veld, o)); if (o === s.start) op.selected = true; inv.el.appendChild(op); }); }
      d.appendChild(inv.el);
      vak.appendChild(d);
      invoeren[s.veld] = inv;
    });
    var melding = D.maak("p", { klasse: "melding-tekst", role: "alert" });
    var knop = D.maak("button", { type: "submit" }, knopTekst);
    vak.appendChild(melding);
    vak.appendChild(knop);
    vak.onsubmit = function (e) {
      e.preventDefault();
      var waarden = {};
      for (var k in invoeren) {
        var w = invoeren[k].waarde();
        if (!w.ok) { D.melding(melding, B.label(k) + ": " + B.foutTekst(w.fout), true); return; }
        if (w.waarde !== null) waarden[k] = w.waarde;
      }
      knop.disabled = true;
      D.melding(melding, T.bezig);
      opVerstuur(waarden).then(function (u) {
        knop.disabled = false;
        if (u && u.fout) D.melding(melding, u.fout, true);
        else { D.melding(melding, ""); vak.reset && vak.reset(); }
      });
    };
  }

  function taakFormulier() {
    formulier($("taakform"), [
      { veld: "titel" }, { veld: "datum" }, { veld: "tijd" },
      { veld: "soort", start: "taak" }, { veld: "eigenaar" },
    ], T.rel.taakToevoeging, function (w) {
      var tid = "k_" + W.nieuwId().replace(/-/g, "").slice(0, 16);
      var velden = {};
      velden["taken." + tid + ".soort"] = { oud: null, nieuw: w.soort || "taak" };
      Object.keys(w).forEach(function (k) { if (k !== "soort") velden["taken." + tid + "." + k] = { oud: null, nieuw: w[k] }; });
      if (!w.titel) return Promise.resolve({ fout: B.label("titel") + ": " + B.foutTekst("verplicht") });
      return wijzig(velden);
    });
  }

  // ---------- contactmoment ----------
  // Wordt een tijdlijnregel (soort "contact"); de status verandert niet. Offline gaat het via de wachtrij.
  function contactFormulier() {
    formulier($("contactform"), [
      { veld: "wijze", start: "Gebeld" }, { veld: "datum", start: K.vandaagLokaal() }, { veld: "notitie" },
    ], T.contactmoment.knop, function (w) {
      if (!w.wijze) return Promise.resolve({ fout: B.label("wijze") + ": " + B.foutTekst("verplicht") });
      var body = Object.assign({ wijzigingId: W.nieuwId() }, w);
      return schrijf({
        soort: "contact", methode: "POST", pad: "/relaties/" + encodeURIComponent(id) + "/contact",
        body: body, recordKey: id, relatieId: id, velden: Object.keys(w),
      });
    });
  }

  // ---------- trajecten ----------
  function toonTrajecten() {
    var lijst = $("trajecten");
    lijst.textContent = "";
    var items = Array.isArray(data.trajecten) ? data.trajecten : [];
    $("trajecten-leeg").textContent = items.length ? "" : T.rel.geenTrajecten;
    items.forEach(function (tr) {
      var rec = tr && tr.record;
      if (!rec || typeof rec.id !== "string") return;
      var li = D.maak("li");
      var a = D.maak("a", { klasse: "rij", href: "/dashboard/klanten/traject.html?relatie=" + encodeURIComponent(id) + "&id=" + encodeURIComponent(rec.id) });
      a.appendChild(D.maak("p", { klasse: "naam" }, rec.fase || T.nietIngevuld));
      if (rec.route) a.appendChild(D.maak("p", { klasse: "wat" }, rec.route));
      a.appendChild(D.maak("p", { klasse: "termijn" }, T.rel.openTraject));
      li.appendChild(a);
      lijst.appendChild(li);
    });
    var extra = [];
    if (Array.isArray(data.onvolledig) && data.onvolledig.length) extra.push(T.rel.onvolledig);
    if (Array.isArray(data.onleesbaar) && data.onleesbaar.length) extra.push(T.rel.onleesbaar);
    D.melding($("trajecten-melding"), extra.join(" "), extra.length > 0);
  }

  function trajectFormulier() {
    formulier($("trajectform"), [
      { veld: "fase", start: "Aanvraag ingediend", opties: T.keuzes.fase.filter(function (f) { return f !== "Afgerond" && f !== "Verloren"; }) },
      { veld: "route" }, { veld: "getekendOp" },
    ], T.rel.trajectAanmaken, function (w) {
      var tid = "t_" + W.nieuwId();
      var velden = Object.assign({ fase: "Aanvraag ingediend" }, w);
      var actie = {
        soort: "traject-nieuw", methode: "POST", pad: "/relaties/" + encodeURIComponent(id) + "/trajecten",
        body: { id: tid, wijzigingId: W.nieuwId(), velden: velden }, recordKey: tid, relatieId: id, velden: Object.keys(velden),
      };
      return schrijf(actie);
    });
  }

  // ---------- tijdlijn ----------
  function tlWaarde(veld, w) {
    if (w === null || w === undefined || w === "" || typeof w === "object") return T.tl.leeg;
    return B.toon(veld, w);
  }
  function tlRegel(r) {
    var wie = r.wie || "";
    if (r.soort === "aanmaak") return K.vul(T.tl.aanmaak, { wie: wie, record: K.eigen(T.tl.record, r.record) || "" });
    if (r.soort === "wijziging") return K.vul(T.tl.wijziging, { wie: wie, veld: B.veldNaam(r.veld || ""), oud: tlWaarde(r.veld || "", r.oud), nieuw: tlWaarde(r.veld || "", r.nieuw) });
    if (r.soort === "afvinken") return K.vul(T.tl.afvinken, { wie: wie, veld: T.tl.afgevinktVeld }) + (r.nieuw && typeof r.nieuw.actie === "string" ? ": " + r.nieuw.actie : "");
    if (r.soort === "heropenen") return K.vul(T.tl.heropenen, { wie: wie, veld: T.tl.afgevinktVeld });
    if (r.soort === "contact" && isObj(r.nieuw)) {
      var c = r.nieuw;
      var kop = K.vul(T.tl.contact, { wie: wie, wijze: String(c.wijze || ""), datum: K.datum(c.datum, { jaar: true }) || "" });
      return typeof c.notitie === "string" && c.notitie ? kop + "\n" + c.notitie : kop;
    }
    return K.vul(T.tl.overig, { wie: wie, soort: String(r.soort || "") });
  }
  function toonTijdlijn(regels) {
    var lijst = $("tijdlijn");
    lijst.textContent = "";
    $("tijdlijn-leeg").textContent = regels.length ? "" : T.rel.geenTijdlijn;
    regels.forEach(function (r) {
      if (!isObj(r)) return;
      var li = D.maak("li", { klasse: "veldrij" });
      var d = new Date(r.op);
      li.appendChild(D.maak("p", { klasse: "veldextra" }, isNaN(d) ? "" : K.moment(d)));
      li.appendChild(D.maak("p", { klasse: "veldwaarde" }, tlRegel(r)));
      lijst.appendChild(li);
    });
  }

  function laadTijdlijn() {
    D.api(API + "/relaties/" + encodeURIComponent(id) + "/tijdlijn").then(function (r) {
      if (r.ok && r.data && Array.isArray(r.data.regels)) {
        D.melding($("tijdlijn-melding"), "");
        toonTijdlijn(r.data.regels);
        W.kv.set("tijdlijn:" + id, { op: new Date().toISOString(), regels: r.data.regels });
      } else if (r.status === 404 || r.status === 410) {
        wisCacheVanDezeRelatie();
        D.melding($("tijdlijn-melding"), T.rel.tijdlijnMislukt, true);
      } else {
        W.kv.get("tijdlijn:" + id).then(function (c) {
          if (c && Array.isArray(c.regels)) toonTijdlijn(c.regels);
          else D.melding($("tijdlijn-melding"), T.rel.tijdlijnMislukt, true);
        });
      }
    });
  }

  // ---------- conflicten ----------
  function toonConflicten() {
    W.conflicten().then(function (alle) {
      var eigen = alle.filter(function (c) { return c.recordSoort === "relatie" && c.recordKey === id; });
      B.toonConflicten($("conflict"), eigen, {
        maakPatch: function (e, velden) { return patchActie(velden); },
        melding: function (t, fout) { behoudTekst = t; D.melding($("relmelding"), t, fout); },
        na: function () { laad(); },
      });
    });
  }

  function toonAlles() {
    $("inhoud").hidden = false;
    toonKop();
    toonContact();
    toonGegevens();
    toonRelatieTermijnen();
    toonTaken();
    toonTrajecten();
    toonConflicten();
  }

  // ---------- laden ----------
  function pseudoUitWachtrij() {
    return W.acties().then(function (items) {
      var nieuw = items.filter(function (x) { return x.soort === "relatie-nieuw" && x.recordKey === id; })[0];
      if (!nieuw) return null;
      return { relatie: Object.assign({ id: id, taken: {} }, nieuw.body.velden), trajecten: [], termijnen: [], onvolledig: [], onleesbaar: [] };
    });
  }

  // 404 of 410 van onze eigen server: het record bestaat niet (meer). Nooit terugvallen op de cache; die ook wissen.
  function wisCacheVanDezeRelatie() {
    return Promise.all([W.kv.del("relatie:" + id), W.kv.del("tijdlijn:" + id)]);
  }

  function uitCacheOfWachtrij(status) {
    if (status === 410) {
      return wisCacheVanDezeRelatie().then(function () { D.melding($("relmelding"), T.rel.nietGevonden, true); });
    }
    return pseudoUitWachtrij().then(function (p) {
      if (status === 404 && !p) return wisCacheVanDezeRelatie().then(function () { D.melding($("relmelding"), T.rel.nietGevonden, true); });
      if (p) { serverData = p; D.melding($("relmelding"), T.rel.nogNietVerstuurd, false); toonMetWachtrij(); return; }
      return W.kv.get("relatie:" + id).then(function (c) {
        if (c && c.data && c.data.relatie) {
          serverData = c.data;
          D.melding($("relmelding"), K.vul(T.rel.standOffline, { moment: K.moment(new Date(c.op)) }), true);
          toonMetWachtrij();
        } else {
          D.melding($("relmelding"), status === 404 ? T.rel.nietGevonden : status === 0 ? D.teksten.algemeen.geenVerbinding : D.teksten.algemeen.foutAlgemeen, true);
        }
      });
    });
  }

  function laad() {
    if (!id) { D.melding($("relmelding"), T.rel.nietGevonden, true); return; }
    D.api(API + "/relaties/" + encodeURIComponent(id)).then(function (r) {
      if (r.ok && r.data && isObj(r.data.relatie)) {
        serverData = r.data;
        K.markeerAls(r.data.relatie.status === "Klant" ? "/dashboard/klanten/lijst.html" : "/dashboard/klanten/leads.html");
        if ($("relmelding").textContent !== behoudTekst) D.melding($("relmelding"), "");
        cacheSchrijf();
        toonMetWachtrij();
      } else {
        // 404 van onze eigen server met een nog niet verstuurde aanmaak in de wachtrij: toon die.
        return uitCacheOfWachtrij(r.status);
      }
    }).catch(function () { return uitCacheOfWachtrij(0); });
    laadTijdlijn();
  }

  document.addEventListener("DOMContentLoaded", function () {
    B.wie().then(function (w) { wie = w; });
    document.addEventListener("wachtrij-gewijzigd", function () {
      if (!serverData) return;
      toonConflicten();
      W.acties().then(function (items) {
        var n = items.filter(function (x) { return x.relatieId === id; }).length;
        // Het laatste wachtende item is verstuurd (door dit of een ander tabblad): verse serverdata ophalen.
        if (hadWachtend && n === 0) { hadWachtend = false; laad(); } else toonMetWachtrij();
      });
    });
    document.addEventListener("editor-gesloten", function () { if (uitgesteld) toonMetWachtrij(); });
    taakFormulier();
    contactFormulier();
    trajectFormulier();
    laad();
  });
})();

// K10: teksten van de koppeling met de deur-module. Vult window.TEKSTEN.klanten aan (laad na gedeeld/teksten.js).
// De echte teksten komen uit de aparte tekstchat; tot die tijd staan hier placeholders.
window.TEKSTEN.klanten.deurkoppeling = {
  voorgevuld: "[[TEKST: klanten.deurkoppeling.voorgevuld]]",
  kop: "[[TEKST: klanten.deurkoppeling.kop]]",
  link: "[[TEKST: klanten.deurkoppeling.link]]",
};

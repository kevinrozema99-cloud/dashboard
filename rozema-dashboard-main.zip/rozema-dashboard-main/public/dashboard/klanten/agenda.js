// Gezamenlijke agenda (opdracht Ruben 20-11-2026): de keukentafelgesprekken (leadpijplijn, Afspraak gepland) en de
// opnames (klantpijplijn, Opname gepland) van Kevin en Ruben, per week. Daarnaast "Nog in te plannen": wat op zo'n
// status of fase staat maar nog geen datum heeft, zodat niets tussen wal en schip valt.
// De week staat in de adresbalk (?week=maandag), de keuze "van wie" alleen in sessionStorage (deze sessie).
(function () {
  "use strict";
  var D = window.Dashboard;
  var K = window.Klanten;
  var T = D.teksten.klanten;
  var A = T.agendaweek;
  var $ = function (id) { return document.getElementById(id); };
  var API = "/api/dashboard/klanten/";
  var WIE_SLEUTEL = "dashboard.klanten.agendawie";
  var DAG_MS = 86400000;
  var maandag = null;
  var teller = 0;

  var isIso = function (d) { return typeof d === "string" && /^\d{4}-\d{2}-\d{2}$/.test(d); };
  function plus(datum, n) { return new Date(Date.parse(datum + "T12:00:00Z") + n * DAG_MS).toISOString().slice(0, 10); }
  function maandagVan(datum) {
    var d = new Date(datum + "T12:00:00Z");
    return plus(datum, -((d.getUTCDay() + 6) % 7));
  }
  // ISO-weeknummer: de week met de donderdag erin.
  function weekNr(ma) {
    var don = new Date(Date.parse(plus(ma, 3) + "T12:00:00Z"));
    var jan1 = Date.UTC(don.getUTCFullYear(), 0, 1, 12);
    return Math.floor((don.getTime() - jan1) / DAG_MS / 7) + 1;
  }
  var dagKop = new Intl.DateTimeFormat("nl-NL", { weekday: "short", day: "numeric", month: "short", timeZone: "UTC" });
  function dagNaam(iso) { return dagKop.format(new Date(iso + "T12:00:00Z")); }

  function leesWie() { try { return window.sessionStorage.getItem(WIE_SLEUTEL) || ""; } catch (e) { return ""; } }
  function schrijfWie(w) { try { if (w) window.sessionStorage.setItem(WIE_SLEUTEL, w); else window.sessionStorage.removeItem(WIE_SLEUTEL); } catch (e) { /* geen opslag: niet erg */ } }

  function hrefVan(x) { return x.trajectId ? K.trajectHref(x.relatieId, x.trajectId) : K.relatieHref(x.relatieId); }
  function eigenaarNaam(e) { return (e && T.lijst.eigenaren[e]) || T.pijplijn.nietToegewezen; }

  function item(x) {
    var li = D.maak("li");
    var a = D.maak("a", { klasse: "afspraak soort-" + x.soort, href: hrefVan(x) });
    var wat = x.soort === "opname" ? A.opname : (x.titel ? K.titel(x.titel) : A.afspraak);
    a.appendChild(D.maak("p", { klasse: "tijd" }, (x.tijd || A.heleDag) + " " + wat));
    a.appendChild(D.maak("p", { klasse: "naam" }, x.naam || T.taken.zonderTitel));
    var onder = [x.plaats, eigenaarNaam(x.eigenaar)].filter(Boolean).join(", ");
    a.appendChild(D.maak("p", { klasse: "wat" }, onder));
    li.appendChild(a);
    return li;
  }

  function toon(data) {
    var vandaag = data.vandaag || K.vandaagLokaal();
    var perDag = {};
    (data.items || []).forEach(function (x) { (perDag[x.datum] = perDag[x.datum] || []).push(x); });
    var week = $("week");
    week.textContent = "";
    for (var i = 0; i < 7; i++) {
      var dag = plus(maandag, i);
      var li = D.maak("li", { klasse: "dag" + (dag === vandaag ? " vandaag" : "") + (i >= 5 ? " weekend" : ""), "data-dag": dag });
      var kop = D.maak("h3", null, dagNaam(dag));
      if (dag === vandaag) kop.appendChild(D.maak("span", { klasse: "label" }, A.vandaag));
      li.appendChild(kop);
      var items = perDag[dag] || [];
      if (items.length) {
        var ul = D.maak("ul", { klasse: "dagitems" });
        items.forEach(function (x) { ul.appendChild(item(x)); });
        li.appendChild(ul);
      } else {
        li.appendChild(D.maak("p", { klasse: "rustig niets" }, A.niets));
      }
      week.appendChild(li);
    }
    var itp = $("inteplannen");
    itp.textContent = "";
    var lijst = data.inTePlannen || [];
    if (!lijst.length) itp.appendChild(D.maak("li", { klasse: "rustig" }, A.niksInTePlannen));
    lijst.forEach(function (x) {
      var li = D.maak("li");
      var a = D.maak("a", { klasse: "rij", href: hrefVan(x) });
      a.appendChild(D.maak("p", { klasse: "naam" }, x.naam || T.taken.zonderTitel));
      a.appendChild(D.maak("p", { klasse: "wat" }, [x.soort === "opname" ? A.opnameZonder : A.afspraakZonder, eigenaarNaam(x.eigenaar)].join(", ")));
      li.appendChild(a);
      itp.appendChild(li);
    });
    var melding = !(data.items || []).length ? A.leeg : "";
    if (data.onvolledig || data.onleesbaar) melding = (melding ? melding + " " : "") + K.vul(A.onvolledig, { n: (data.onvolledig || 0) + (data.onleesbaar || 0) });
    D.melding($("agendamelding"), melding, false);
  }

  function titel() {
    $("weektitel").textContent = K.vul(A.week, { nr: weekNr(maandag), van: K.datum(maandag), tot: K.datum(plus(maandag, 6), { jaar: true }) });
  }

  function laad() {
    titel();
    var p = new URLSearchParams();
    p.set("van", maandag);
    p.set("tot", plus(maandag, 6));
    if ($("agenda-wie").value) p.set("wie", $("agenda-wie").value);
    var nr = ++teller;
    $("week").setAttribute("aria-busy", "true");
    D.api(API + "agenda?" + p.toString()).then(function (r) {
      if (nr !== teller) return; // een nieuwere week is onderweg
      $("week").removeAttribute("aria-busy");
      if (!r.ok || !r.data || !Array.isArray(r.data.items)) {
        D.melding($("agendamelding"), r.status === 0 ? D.teksten.algemeen.geenVerbinding : A.mislukt, true);
        return;
      }
      toon(r.data);
    });
  }

  function naarWeek(ma) {
    maandag = ma;
    var url = new URL(window.location.href);
    if (ma === maandagVan(K.vandaagLokaal())) url.searchParams.delete("week"); else url.searchParams.set("week", ma);
    window.history.replaceState(null, "", url.pathname + url.search);
    laad();
  }

  function init() {
    var sel = $("agenda-wie");
    sel.appendChild(D.maak("option", { value: "" }, A.iedereen));
    Object.keys(T.lijst.eigenaren).forEach(function (k) { sel.appendChild(D.maak("option", { value: k }, T.lijst.eigenaren[k])); });
    var wie = leesWie();
    if (T.lijst.eigenaren[wie]) sel.value = wie;
    sel.addEventListener("change", function () { schrijfWie(sel.value); laad(); });
    var gevraagd = new URLSearchParams(window.location.search).get("week");
    maandag = isIso(gevraagd) ? maandagVan(gevraagd) : maandagVan(K.vandaagLokaal());
    $("week-vorige").addEventListener("click", function () { naarWeek(plus(maandag, -7)); });
    $("week-deze").addEventListener("click", function () { naarWeek(maandagVan(K.vandaagLokaal())); });
    $("week-volgende").addEventListener("click", function () { naarWeek(plus(maandag, 7)); });
    laad();
  }

  document.addEventListener("DOMContentLoaded", init);
})();

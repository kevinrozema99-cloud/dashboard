// Gedeeld door relatie, traject en nieuwe klant: veldspecificaties, weergave, de editor per veld,
// foutteksten en het conflictscherm. Alle data gaat via textContent.
(function () {
  "use strict";
  var D = window.Dashboard;
  var K = window.Klanten;
  var W = window.Wachtrij;
  var T = D.teksten.klanten;
  var B = (window.Bewerk = {});

  // Velden per record. type: tekst | meerregelig | keuze | datum | telefoon | email | postcode | geheel | getal | bool.
  // Moet gelijk blijven aan model.mjs; het rondje vergelijkt de keuzelijsten met die van de server.
  var RELATIE = [
    ["aanhef", "keuze"], ["voornaam", "tekst"], ["achternaam", "tekst"], ["telefoon", "telefoon"], ["mobiel", "telefoon"], ["email", "email"],
    ["straat", "tekst"], ["huisnummer", "tekst"], ["toevoeging", "tekst"], ["postcode", "postcode"], ["plaats", "tekst"],
    ["status", "keuze"], ["eigenaar", "keuze"], ["bron", "keuze"], ["soortWoning", "keuze"], ["voorWie", "keuze"], ["contactvoorkeur", "keuze"],
    ["terugbeldatum", "datum"], ["situatie", "keuze"], ["kwalificatie", "keuze"], ["redenAfgevallen", "keuze"], ["notitie", "meerregelig"],
    ["bagId", "tekst"], ["trillingMms", "getal"], ["bouwjaar", "geheel"], ["ruimtesMetSchade", "geheel"], ["eerderOntvangen", "getal"],
    ["bkoZone", "bool"], ["dossier", "tekst"],
  ];
  // Bij een nieuwe lead staan deze bovenaan, in deze volgorde (opdracht Ruben 20-11-2026); de rest onder "meer gegevens".
  // Postcode en huisnummer vóór straat en plaats: die vult nieuw.js daarna zelf in (PDOK).
  B.KERN = ["voornaam", "achternaam", "soortWoning", "postcode", "huisnummer", "toevoeging", "straat", "plaats", "telefoon", "email",
    "contactvoorkeur", "bron", "status", "eigenaar"];
  var TRAJECT = [
    ["route", "keuze"], ["getekendOp", "datum"], ["aanvraagdatum", "datum"], ["opnamedatum", "datum"], ["opnametijd", "tekst"], ["datumSchaderapport", "datum"],
    ["datumAdviesrapport", "datum"], ["verzenddatumBesluitbrief", "datum"], ["verzenddatumOnbekend", "bool"], ["uitkeringImg", "getal"],
    ["fee", "getal"], ["factuurVerstuurdOp", "datum"], ["factuurVoldaanOp", "datum"], ["redenVerlies", "keuze"], ["machtigingGetekendOp", "datum"],
  ];
  var TAAK = [["soort", "keuze"], ["titel", "tekst"], ["datum", "datum"], ["tijd", "tekst"], ["eigenaar", "keuze"]];
  var alle = {};
  // Contactmoment (wordt een tijdlijnregel, geen veld op de relatie); datum en notitie delen de specificatie hierboven.
  var CONTACT = [["wijze", "keuze"]];
  RELATIE.concat(TRAJECT, TAAK, CONTACT, [["fase", "keuze"]]).forEach(function (v) { alle[v[0]] = v[1]; });
  B.RELATIE = RELATIE; B.TRAJECT = TRAJECT; B.TAAK = TAAK;
  B.type = function (veld) { return K.eigen(alle, veld) || "tekst"; };
  B.label = function (veld) { return K.eigen(T.veld, veld) || veld; };
  B.opties = function (veld) { return K.eigen(T.keuzes, veld) || null; };

  // "taken.k1.titel" -> "Taak, Titel"; anders het veldlabel.
  B.veldNaam = function (pad) {
    var d = String(pad).split(".");
    if (d[0] === "taken" && d.length === 3) return T.conflict.taak + ", " + B.label(d[2]).toLowerCase();
    if (d[0] === "afgevinkt") return T.tl.afgevinktVeld;
    return B.label(d[0]);
  };

  B.optieTekst = function (veld, waarde) {
    if (veld === "eigenaar" && typeof waarde === "string") return waarde.charAt(0).toUpperCase() + waarde.slice(1);
    return String(waarde);
  };

  // Weergave van een waarde.
  B.toon = function (veld, waarde) {
    if (waarde === null || waarde === undefined || waarde === "") return T.nietIngevuld;
    var t = B.type(veld.split(".").pop());
    if (t === "bool") return waarde === true ? T.ja : T.nee;
    if (t === "datum") return K.datum(waarde, { jaar: true }) || String(waarde);
    if (t === "getal" || t === "geheel") return typeof waarde === "number" ? waarde.toLocaleString("nl-NL") : String(waarde);
    if (t === "keuze") return B.optieTekst(veld.split(".").pop(), waarde);
    return String(waarde);
  };

  // Foutcode of foutenobject uit een antwoord naar leesbare tekst(en).
  B.foutTekst = function (code) {
    return K.eigen(T.fouten, code) || T.fouten.algemeen;
  };
  B.foutenLijst = function (r) {
    var uit = [];
    var d = r && r.data;
    if (d && d.fouten && typeof d.fouten === "object") {
      Object.keys(d.fouten).forEach(function (k) {
        uit.push({ veld: k, tekst: B.veldNaam(k) + ": " + B.foutTekst(d.fouten[k]), code: d.fouten[k] });
      });
    } else if (d && d.code) uit.push({ veld: null, tekst: B.foutTekst(d.code), code: d.code });
    else uit.push({ veld: null, tekst: B.foutTekst("algemeen"), code: "algemeen" });
    return uit;
  };

  // Eén invoerelement voor een veld; geeft {el, waarde()} waar waarde() {ok, waarde} of {ok:false, fout} geeft.
  B.invoer = function (veld, huidig, id) {
    var t = B.type(veld);
    var el;
    if (t === "keuze") {
      el = D.maak("select", { id: id });
      el.appendChild(D.maak("option", { value: "" }, T.nietIngevuld));
      (B.opties(veld) || []).forEach(function (o) {
        var op = D.maak("option", { value: o }, B.optieTekst(veld, o));
        if (o === huidig) op.selected = true;
        el.appendChild(op);
      });
    } else if (t === "bool") {
      el = D.maak("select", { id: id });
      [["", T.nietIngevuld], ["ja", T.ja], ["nee", T.nee]].forEach(function (o) {
        var op = D.maak("option", { value: o[0] }, o[1]);
        if ((o[0] === "ja" && huidig === true) || (o[0] === "nee" && huidig === false)) op.selected = true;
        el.appendChild(op);
      });
    } else if (t === "meerregelig") {
      el = D.maak("textarea", { id: id, rows: "4", maxlength: "5000" });
      el.value = huidig == null ? "" : String(huidig);
    } else {
      var type = t === "datum" ? "date" : t === "email" ? "email" : t === "telefoon" ? "tel" : "text";
      el = D.maak("input", { id: id, type: type });
      if (t === "geheel") el.setAttribute("inputmode", "numeric");
      if (t === "getal") el.setAttribute("inputmode", "decimal");
      if (t === "telefoon") el.setAttribute("autocomplete", "off");
      el.value = huidig == null ? "" : String(huidig);
    }
    return {
      el: el,
      waarde: function () {
        var v = el.value;
        if (t === "bool") return { ok: true, waarde: v === "ja" ? true : v === "nee" ? false : null };
        if (v.trim() === "") return { ok: true, waarde: null };
        if (t === "geheel" || t === "getal") {
          var n = Number(v.trim().replace(",", "."));
          if (!isFinite(n)) return { ok: false, fout: "geen-getal" };
          return { ok: true, waarde: n };
        }
        return { ok: true, waarde: t === "meerregelig" ? v : v.trim() };
      },
    };
  };

  // Open editors met een nog niet opgeslagen waarde: bij weggaan (ook na een 401) waarschuwt de browser.
  var vuil = {};
  B.open = 0;
  B.vuil = function () { return Object.keys(vuil).length; };
  window.addEventListener("beforeunload", function (e) {
    if (Object.keys(vuil).length) { e.preventDefault(); e.returnValue = ""; }
  });

  // Een regel in een gegevenslijst: label, waarde en een knop "Wijzig". opties.extra: tekst naast de waarde.
  // opSlaan(velden {veld:{oud,nieuw}}, doorgeven) -> Promise<{tekst, fout}> ; de editor sluit bij succes.
  B.veldRegel = function (veld, huidig, opties) {
    var o = opties || {};
    var li = D.maak("li", { klasse: "veldrij", "data-veld": veld });
    var kop = D.maak("p", { klasse: "veldlabel" }, B.label(veld));
    var leeg = huidig === null || huidig === undefined || huidig === "";
    var waarde = D.maak("p", { klasse: "veldwaarde" + (leeg ? " leeg" : "") }, B.toon(veld, huidig));
    li.appendChild(kop);
    li.appendChild(waarde);
    if (o.extra) li.appendChild(D.maak("p", { klasse: "veldextra" }, o.extra));
    var vak = D.maak("div", { klasse: "editor" });
    var knop = D.maak("button", { type: "button", klasse: "rand", "aria-expanded": "false" }, T.wijzig);
    knop.setAttribute("aria-label", T.wijzig + " " + B.label(veld).toLowerCase());
    li.appendChild(knop);
    li.appendChild(vak);

    var sleutel = "ed-" + veld + "-" + Math.random().toString(36).slice(2, 8);
    var isOpen = false;
    function sluit() {
      vak.textContent = ""; knop.setAttribute("aria-expanded", "false"); knop.hidden = false;
      delete vuil[sleutel];
      if (isOpen) { isOpen = false; B.open--; document.dispatchEvent(new CustomEvent("editor-gesloten")); }
    }
    knop.addEventListener("click", function () {
      knop.hidden = true;
      knop.setAttribute("aria-expanded", "true");
      if (!isOpen) { isOpen = true; B.open++; }
      var id = "ed-" + veld + "-" + Math.random().toString(36).slice(2, 7);
      var veldDiv = D.maak("div", { klasse: "veld" });
      veldDiv.appendChild(D.maak("label", { for: id }, B.label(veld)));
      var inv = B.invoer(veld, huidig, id);
      veldDiv.appendChild(inv.el);
      vak.appendChild(veldDiv);
      var startWaarde = inv.waarde().ok ? JSON.stringify(inv.waarde().waarde) : null;
      var markeer = function () { if (JSON.stringify(inv.waarde().waarde) !== startWaarde) vuil[sleutel] = true; else delete vuil[sleutel]; };
      inv.el.addEventListener("input", markeer);
      inv.el.addEventListener("change", markeer);
      var extra = null;
      var extraInv = null;
      // Status Afgevallen vraagt een reden in dezelfde wijziging.
      if (veld === "status" && o.reden) {
        extra = D.maak("div", { klasse: "veld", hidden: "hidden" });
        extra.appendChild(D.maak("label", { for: id + "-reden" }, B.label("redenAfgevallen")));
        extraInv = B.invoer("redenAfgevallen", o.reden.huidig, id + "-reden");
        extra.appendChild(extraInv.el);
        vak.appendChild(extra);
        var toon = function () { extra.hidden = inv.el.value !== "Afgevallen"; };
        inv.el.addEventListener("change", toon);
        toon();
      }
      var melding = D.maak("p", { klasse: "melding-tekst", role: "alert" });
      var acties = D.maak("div", { klasse: "acties" });
      var opslaan = D.maak("button", { type: "button" }, T.opslaan);
      var annuleer = D.maak("button", { type: "button", klasse: "rand" }, T.annuleren);
      acties.appendChild(opslaan);
      acties.appendChild(annuleer);
      vak.appendChild(melding);
      vak.appendChild(acties);
      inv.el.focus();
      annuleer.addEventListener("click", sluit);
      opslaan.addEventListener("click", function () {
        var w = inv.waarde();
        if (!w.ok) { D.melding(melding, B.foutTekst(w.fout), true); return; }
        var velden = {};
        velden[veld] = { oud: huidig === undefined ? null : huidig, nieuw: w.waarde };
        if (extraInv && !extra.hidden) {
          var rw = extraInv.waarde();
          if (rw.ok) velden.redenAfgevallen = { oud: o.reden.huidig === undefined ? null : o.reden.huidig, nieuw: rw.waarde };
        }
        if (JSON.stringify(velden[veld].oud) === JSON.stringify(velden[veld].nieuw) && Object.keys(velden).length === 1) { sluit(); return; }
        opslaan.disabled = true;
        D.melding(melding, T.bezig);
        o.opSlaan(velden).then(function (u) {
          opslaan.disabled = false;
          if (u && u.fout) D.melding(melding, u.fout, true);
          else sluit();
        });
      });
    });
    return li;
  };

  // ---------- conflictscherm ----------
  // entries: opgeslagen conflicten van W.conflictenVoor. opties: {huidigeWaarde(), maakPatch(c, velden) -> actie, na()}
  B.toonConflicten = function (vak, entries, opties) {
    vak.textContent = "";
    vak.hidden = entries.length === 0;
    if (!entries.length) return;
    var kop = D.maak("h2", {}, T.conflict.kop);
    vak.appendChild(kop);
    var melding = D.maak("p", { klasse: "melding-tekst", role: "status" });
    entries.forEach(function (e) {
      var wie = e.wie || T.conflict.andere;
      e.conflicten.forEach(function (c) {
        var blok = D.maak("div", { klasse: "conflictrij", "data-veld": c.veld });
        blok.appendChild(D.maak("p", { klasse: "veldlabel" }, B.veldNaam(c.veld)));
        blok.appendChild(D.maak("p", {}, K.vul(T.conflict.uitleg, { wie: wie })));
        var acties = D.maak("div", { klasse: "acties conflictkeuze" });
        var mijn = D.maak("button", { type: "button", "data-keuze": "mijn" }, K.vul(T.conflict.mijn, { waarde: B.toon(c.veld, c.nieuw) }));
        var hunne = D.maak("button", { type: "button", klasse: "rand", "data-keuze": "hunne" }, K.vul(T.conflict.hunne, { wie: wie, waarde: B.toon(c.veld, c.huidig) }));
        acties.appendChild(mijn);
        acties.appendChild(hunne);
        blok.appendChild(acties);
        vak.appendChild(blok);

        function klaar(tekst, isFout) {
          e.conflicten = e.conflicten.filter(function (x) { return x !== c; });
          var p = e.conflicten.length ? W.zetConflict(e) : W.wisConflict(e.id);
          return p.then(function () {
            if (opties.melding) opties.melding(tekst, isFout); else D.melding(melding, tekst, isFout);
            if (opties.na) opties.na();
          });
        }
        hunne.addEventListener("click", function () { mijn.disabled = hunne.disabled = true; klaar(T.conflict.gelukt, false); });
        mijn.addEventListener("click", function () {
          mijn.disabled = hunne.disabled = true;
          // Nieuwe wijziging met de huidige waarde van de ander als "oud".
          var velden = {};
          velden[c.veld] = { oud: c.huidig === undefined ? null : c.huidig, nieuw: c.nieuw === undefined ? null : c.nieuw };
          var actie = opties.maakPatch(e, velden);
          W.zet(actie, { direct: true }).then(function (u) {
            if (u.uitkomst === "afgekeurd" || u.uitkomst === "geen-wie") {
              mijn.disabled = hunne.disabled = false;
              D.melding(melding, B.uitkomstFout(u), true);
              return;
            }
            // Alleen "gelukt" melden als er ook echt iets is opgeslagen.
            if (u.uitkomst !== "verstuurd") { klaar(T.wachtrij.wacht, false); return; }
            var d = u.r && u.r.data ? u.r.data : {};
            var opnieuw = Array.isArray(d.conflicten) && d.conflicten.length > 0;
            var toegepast = Array.isArray(d.toegepast) && d.toegepast.indexOf(c.veld) !== -1;
            if (opnieuw) klaar(T.conflict.opnieuw, true);
            else if (toegepast) klaar(T.conflict.gelukt, false);
            else klaar(T.conflict.nietsOpgeslagen, true);
          });
        });
      });
    });
    vak.appendChild(melding);
  };
})();

// Aanvullingen: termijnregel en gedeelde hulpfuncties voor de schermen met data van de server.
(function () {
  "use strict";
  var D = window.Dashboard;
  var K = window.Klanten;
  var T = D.teksten.klanten;
  var B = window.Bewerk;

  // Tekst over de stand van een termijn: "nog 5 dagen, uiterlijk 12 november 2026", "3 dagen verlopen", of de status.
  B.termijnTekst = function (t) {
    if (t && t.wachtOp === "heropenen") return T.tr.wordtHeropend; // staat nog in de wachtrij
    if (t && t.wachtOp === "afvinken") return T.tr.wordtAfgevinkt;
    var s = t && typeof t.status === "string" ? t.status : "";
    var d = t ? t.dagenOver : null;
    if (s === "open" && typeof d === "number" && isFinite(d)) {
      var datum = K.datum(t.einddatum, { jaar: true });
      var tekst = d < 0 ? K.vul(T.tr.verlopenDagen, { d: K.dagen(d) }) : d === 0 ? T.fataal.nogVandaag : K.vul(T.tr.nogDagen, { d: K.dagen(d) });
      return datum ? tekst + ", " + K.vul(T.fataal.uiterlijk, { datum: datum }) : tekst;
    }
    if (s === "open") return T.fataal.termijnOnbekend;
    return K.eigen(T.tr.status, s) || s;
  };

  B.fataalTekst = function (t) {
    return t.fataal === false ? T.tr.nietFataal : t.fataalOnbekend ? T.tr.fataalOnbekend : T.tr.fataal;
  };

  // Veldwaarde uit een record, ook "taken.k1.titel".
  B.waardeUit = function (rec, pad) {
    var d = String(pad).split(".");
    var w = rec;
    for (var i = 0; i < d.length; i++) w = w === null || w === undefined ? undefined : K.eigen(w, d[i]);
    return w === undefined ? null : w;
  };

  // Past velden {pad:{oud,nieuw}} toe op een record in het geheugen (optimistisch, voor offline weergave).
  B.pas = function (rec, velden) {
    Object.keys(velden).forEach(function (pad) {
      var d = pad.split(".");
      if (d.some(function (x) { return x === "__proto__" || x === "constructor" || x === "prototype"; })) return;
      var w = rec;
      for (var i = 0; i < d.length - 1; i++) {
        if (w[d[i]] === undefined || w[d[i]] === null || typeof w[d[i]] !== "object") w[d[i]] = {};
        w = w[d[i]];
      }
      w[d[d.length - 1]] = velden[pad].nieuw;
    });
  };

  var queryCache = null;
  B.query = function (naam) {
    if (!queryCache) queryCache = new URLSearchParams(location.search);
    return queryCache.get(naam);
  };

  // De naam van wie is ingelogd (voor "klaar door"). Offline uit sessionStorage.
  B.wie = function () {
    var sleutel = "dashboard.klanten.wie";
    return D.zegWie().then(function (w) {
      try {
        if (w.naam) window.sessionStorage.setItem(sleutel, w.naam);
        return w.naam || window.sessionStorage.getItem(sleutel) || "Onbekend";
      } catch (e) { return w.naam || "Onbekend"; }
    });
  };

  // Geeft de fouttekst voor een mislukte uitkomst van W.zet, of null.
  B.uitkomstFout = function (u) {
    if (u.uitkomst === "geen-wie") return T.wachtrij.eerstInloggen;
    if (u.uitkomst !== "afgekeurd") return null;
    return B.foutenLijst(u.r).map(function (f) { return f.tekst; }).join(" ");
  };
})();

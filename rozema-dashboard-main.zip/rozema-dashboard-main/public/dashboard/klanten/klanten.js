// Gedeeld door de klantenschermen: tekstsjablonen, datums, namen, de cache en de balk "N fatale termijnen".
// Geen persoonsgegevens in console of localStorage. sessionStorage bevat alleen sleutels "dashboard.klanten.*"
// en wordt gewist bij uitloggen, een 401 of het sluiten van het tabblad (Dashboard.wisCache).
(function () {
  "use strict";
  var D = window.Dashboard;
  var T = D.teksten.klanten;
  var K = (window.Klanten = {});
  var SLEUTEL_BALK = "dashboard.klanten.balk";
  var SLEUTEL_START = "dashboard.klanten.start";
  var OUD_NA_MS = 24 * 60 * 60 * 1000;

  var isObj = function (v) { return v !== null && typeof v === "object" && !Array.isArray(v); };
  // Alleen eigen eigenschappen: een waarde als "constructor" of "__proto__" vindt niets.
  K.eigen = function (o, k) {
    return o !== null && typeof o === "object" && Object.prototype.hasOwnProperty.call(o, k) ? o[k] : undefined;
  };

  // "nog {d}" met {d: "5 dagen"}
  K.vul = function (sjabloon, waarden) {
    return String(sjabloon).replace(/\{(\w+)\}/g, function (m, k) {
      return waarden && waarden[k] !== undefined ? String(waarden[k]) : m;
    });
  };

  K.dagen = function (n) {
    var a = Math.abs(n);
    return K.vul(a === 1 ? T.dagen.een : T.dagen.meer, { n: a });
  };

  // "12 november" (metJaar: "12 november 2026"; metWeekdag: "donderdag 12 november")
  K.datum = function (iso, opties) {
    if (typeof iso !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(iso)) return "";
    var d = new Date(iso + "T12:00:00Z");
    if (isNaN(d)) return "";
    var o = { day: "numeric", month: "long", timeZone: "UTC" };
    if (opties && opties.weekdag) o.weekday = "long";
    if (opties && opties.jaar) o.year = "numeric";
    return d.toLocaleDateString("nl-NL", o);
  };

  // ISO-datums in een tekst (bijvoorbeeld in een titel) leesbaar maken.
  K.titel = function (tekst) {
    return String(tekst).replace(/\b(\d{4}-\d{2}-\d{2})\b/g, function (m) { return K.datum(m, { jaar: true }) || m; });
  };

  K.tijd = function (d) {
    return d.toLocaleTimeString("nl-NL", { hour: "2-digit", minute: "2-digit" });
  };
  K.moment = function (d) {
    return d.toLocaleDateString("nl-NL", { day: "numeric", month: "long" }) + " " + K.tijd(d);
  };

  K.vandaagLokaal = function () {
    return new Intl.DateTimeFormat("sv-SE", { timeZone: "Europe/Amsterdam" }).format(new Date());
  };
  K.dagenTussen = function (van, tot) {
    return Math.round((Date.parse(tot + "T12:00:00Z") - Date.parse(van + "T12:00:00Z")) / 86400000);
  };

  // Achternaam en plaats komen als losse velden van de server; zonder die velden de hele naam, ongesplitst.
  K.naamEnPlaats = function (item) {
    var i = isObj(item) ? item : {};
    if (typeof i.achternaam === "string" && i.achternaam.trim()) {
      return typeof i.plaats === "string" && i.plaats.trim() ? i.achternaam + ", " + i.plaats : i.achternaam;
    }
    if (typeof i.naam === "string" && i.naam.trim()) return i.naam;
    return T.fataal.geenNaam;
  };

  // "€ 1.234,50" (zonder centen als het een heel bedrag is)
  K.euro = function (n) {
    if (typeof n !== "number" || !isFinite(n)) return "";
    var heel = Math.round(n * 100) % 100 === 0;
    return new Intl.NumberFormat("nl-NL", { style: "currency", currency: "EUR", minimumFractionDigits: heel ? 0 : 2, maximumFractionDigits: 2 }).format(n);
  };

  K.trajectHref = function (relatieId, id) {
    return "/dashboard/klanten/traject.html?relatie=" + encodeURIComponent(relatieId) + "&id=" + encodeURIComponent(id);
  };

  K.relatieHref = function (id) {
    return "/dashboard/klanten/relatie.html?id=" + encodeURIComponent(id);
  };

  // ---------- cache (sessionStorage, alleen deze sessie) ----------
  function leesStore(sleutel) {
    try {
      var s = window.sessionStorage.getItem(sleutel);
      var o = s ? JSON.parse(s) : null;
      if (isObj(o) && typeof o.op === "string" && !isNaN(new Date(o.op)) && isObj(o.data)) return o;
    } catch (e) { /* geen opslag beschikbaar */ }
    return null;
  }
  function schrijfStore(sleutel, data) {
    try { window.sessionStorage.setItem(sleutel, JSON.stringify({ op: new Date().toISOString(), data: data })); } catch (e) { /* idem */ }
  }
  K.telOk = function (t) {
    var f = t && t.fataal;
    return isObj(f) && typeof f.aantal === "number" && isFinite(f.aantal) && f.aantal >= 0 && Math.floor(f.aantal) === f.aantal;
  };
  K.startCacheSchrijf = function (data) {
    if (isObj(data) && isObj(data.fataal) && Array.isArray(data.fataal.items) && K.telOk(data)) {
      schrijfStore(SLEUTEL_START, { vandaag: data.vandaag || null, fataal: data.fataal });
    }
  };
  K.startCacheLees = function () { return leesStore(SLEUTEL_START); };
  K.isOud = function (op) { return Date.now() - new Date(op).getTime() > OUD_NA_MS; };

  // ---------- de balk ----------
  // Tekst uit {fataal:{aantal,verlopen,eerstvolgendeDagen,signalen}}. null als het aantal onbekend is.
  K.balkTekst = function (t, verstreken) {
    if (!K.telOk(t)) return null;
    var B = T.balk;
    var f = t.fataal;
    var aantal = f.aantal;
    var delen = [aantal === 0 ? B.geen : aantal === 1 ? B.een : K.vul(B.meer, { n: aantal })];
    if (f.verlopen > 0) delen.push(K.vul(B.verlopen, { n: f.verlopen }));
    if (f.signalen > 0) delen.push(K.vul(B.signalen, { n: f.signalen }));
    var d = f.eerstvolgendeDagen;
    if (typeof d === "number") {
      d -= verstreken || 0; // uit een oude stand: terugrekenen vanaf de datum van de stand
      if (d < 0) delen.push(K.vul(B.eerstvolgendeVerlopen, { d: K.dagen(d) }));
      else if (d === 0) delen.push(B.eerstvolgendeVandaag);
      else delen.push(K.vul(B.eerstvolgende, { d: K.dagen(d) }));
    }
    return delen.join(", ");
  };

  // Toont de balk. opties.stand (Date) voegt de stand toe; ouder dan 24 uur geeft de opvallende melding.
  K.balkToon = function (telling, opties) {
    var el = document.getElementById("balk");
    if (!el) return;
    var o = opties || {};
    el.textContent = "";
    var verstreken = 0;
    if (o.stand && telling && telling.vandaag) verstreken = Math.max(0, K.dagenTussen(telling.vandaag, K.vandaagLokaal()));
    var tekst = K.balkTekst(telling, verstreken);
    if (tekst === null) {
      el.appendChild(D.maak("p", { klasse: "melding-tekst fout" }, T.balk.onbekend));
      return;
    }
    var f = telling.fataal;
    var oud = o.stand && K.isOud(o.stand.toISOString());
    if (o.stand) tekst += ", " + K.vul(T.balk.stand, { moment: K.moment(o.stand) });
    var klasse = "balk";
    if (f.verlopen > 0 || oud) klasse += " verlopen";
    else if ((typeof f.eerstvolgendeDagen === "number" && f.eerstvolgendeDagen - verstreken < 7) || f.signalen > 0) klasse += " bijna";
    var a = D.maak("a", { href: "/dashboard/klanten/", klasse: klasse });
    a.appendChild(D.maak("span", { klasse: "balk-tekst" }, tekst));
    if (oud) a.appendChild(D.maak("span", { klasse: "balk-extra" }, T.balk.oud));
    if (telling.gezondheid && telling.gezondheid.aantal > 0) a.appendChild(D.maak("span", { klasse: "balk-extra" }, T.balk.gezondheid));
    el.appendChild(a);
  };

  function balkSchoon(data) {
    return { vandaag: data.vandaag || null,
      fataal: { aantal: data.fataal.aantal, verlopen: data.fataal.verlopen, eerstvolgendeDagen: data.fataal.eerstvolgendeDagen, signalen: data.fataal.signalen },
      gezondheid: { aantal: data.gezondheid && typeof data.gezondheid.aantal === "number" ? data.gezondheid.aantal : 0 } };
  }

  // Voor het startscherm, dat de volledige stand al heeft opgehaald. Klopt de stand niet, dan "onbekend".
  K.balkUitStart = function (data) {
    if (!isObj(data) || !K.telOk(data) || !Array.isArray(data.fataal.items)) { K.balkToon(null); return; }
    var schoon = balkSchoon(data);
    schrijfStore(SLEUTEL_BALK, schoon);
    K.balkToon(schoon);
  };

  K.balkLaad = function () {
    var el = document.getElementById("balk");
    if (!el) return Promise.resolve();
    return D.api("/api/dashboard/klanten/start?alleen=telling").then(function (r) {
      if (r.ok && K.telOk(r.data)) {
        var schoon = balkSchoon(r.data);
        schrijfStore(SLEUTEL_BALK, schoon);
        K.balkToon(schoon);
        return;
      }
      var c = leesStore(SLEUTEL_BALK);
      if (c) K.balkToon(c.data, { stand: new Date(c.op) });
      else K.balkToon(null);
    }).catch(function () { K.balkToon(null); });
  };

  // ---------- wachtrij: teller in de navigatie en melding bovenaan ----------
  K.wachtrijWeergave = function () {
    var W = window.Wachtrij;
    if (!W) return;
    Promise.all([W.acties(), W.conflicten()]).then(function (r) {
      var acties = r[0];
      var nav = document.getElementById("nav-wachtrij");
      if (nav) {
        nav.textContent = acties.length ? K.vul(T.navWachtrijTelling, { n: acties.length }) : T.navWachtrij;
        // Alleen in het menu als er iets wacht of te beslissen is (of als je er al bent).
        nav.hidden = !acties.length && !r[1].length && !/niet-opgeslagen\.html$/.test(window.location.pathname);
      }
      var vak = document.getElementById("wachtmelding");
      if (!vak) return;
      vak.textContent = "";
      var afgekeurd = acties.filter(function (a) { return a.afgekeurd; }).length;
      var ander = acties.filter(function (a) { return !a.afgekeurd && (!a.wie || a.wie !== W.wie()); });
      var wachtend = acties.length - afgekeurd - ander.length;
      var regels = [];
      // Bewaren op het toestel mislukt: de acties staan alleen in het geheugen van deze pagina.
      if (!W.blijvend() && W.geheugenAantal() > 0) regels.push({ tekst: T.wachtrij.nietBewaard, fout: true });
      if (ander.length) {
        var anderWie = ander[0].wie || T.niet.anderOnbekend;
        regels.push({ tekst: ander.length === 1 ? K.vul(T.wachtrij.vanAnderEen, { wie: anderWie }) : K.vul(T.wachtrij.vanAnder, { n: ander.length, wie: anderWie }) });
      }
      if (W.laatsteStop() === "inlog" && acties.length) {
        regels.push({ tekst: T.wachtrij.inlog, href: "/dashboard/", link: T.wachtrij.inlogLink });
      }
      if (wachtend > 0) regels.push({ tekst: wachtend === 1 ? T.wachtrij.teVerzendenEen : K.vul(T.wachtrij.teVerzenden, { n: wachtend }) });
      if (afgekeurd > 0) {
        regels.push({ tekst: afgekeurd === 1 ? T.wachtrij.nietOpgeslagenEen : K.vul(T.wachtrij.nietOpgeslagen, { n: afgekeurd }), href: "/dashboard/klanten/niet-opgeslagen.html", link: T.wachtrij.bekijk });
      }
      // Conflict: per conflict een knop die direct naar de klant of het traject gaat, waar je kiest wat je houdt.
      // Niet op de pagina die het conflict zelf al toont.
      if (!document.getElementById("conflict")) {
        r[1].slice(0, 3).forEach(function (c) {
          var veld = (Array.isArray(c.conflicten) ? c.conflicten : []).map(function (x) { return x && x.veld ? (window.Bewerk ? window.Bewerk.veldNaam(x.veld) : K.eigen(T.veld, x.veld) || x.veld) : null; }).filter(Boolean).join(", ");
          var href = c.recordSoort === "traject" && c.relatieId ? K.trajectHref(c.relatieId, c.recordKey) : K.relatieHref(c.recordKey);
          regels.push({ tekst: veld ? K.vul(T.wachtrij.conflictBij, { veld: veld }) : T.wachtrij.conflicten, href: href, link: T.wachtrij.conflictOplossen, fout: true });
        });
        if (r[1].length > 3) regels.push({ tekst: T.wachtrij.conflicten, href: "/dashboard/klanten/niet-opgeslagen.html", link: T.wachtrij.bekijk });
      }
      regels.forEach(function (x) {
        var blok = D.maak("div", { klasse: "wachtregel" });
        blok.appendChild(D.maak("p", { klasse: "melding-tekst" + (x.fout ? " fout" : "") }, x.tekst));
        if (x.href) blok.appendChild(D.maak("a", { klasse: "knop rand", href: x.href }, x.link));
        vak.appendChild(blok);
      });
    });
  };

  // Het menu (op een breed scherm de zijbalk) markeert waar je bent. Klant en traject vallen onder "Alle klanten";
  // de pijplijnpagina markeert zelf het juiste bord.
  function markeerMenu() {
    var pad = window.location.pathname;
    // Een klantkaart hoort bij Leads of Klanten; relatie.js markeert dat zodra de status bekend is (K.markeerAls).
    if (/\/relatie\.html$/.test(pad)) return;
    if (/\/traject\.html$/.test(pad)) pad = "/dashboard/klanten/lijst.html";
    if (/\/beheer\.html$/.test(pad)) pad = "/dashboard/klanten/regels.html"; // export en agenda horen bij Instellingen
    if (/\/dashboard\/klanten\/(index\.html)?$/.test(pad)) pad = "/dashboard/klanten/";
    Array.prototype.forEach.call(document.querySelectorAll("nav.sub a"), function (a) {
      if (a.getAttribute("href") === pad) a.setAttribute("aria-current", "page");
    });
  }

  K.markeerAls = function (href) {
    Array.prototype.forEach.call(document.querySelectorAll("nav.sub a"), function (a) {
      if (a.getAttribute("href") === href) a.setAttribute("aria-current", "page"); else a.removeAttribute("aria-current");
    });
  };

  document.addEventListener("DOMContentLoaded", function () {
    markeerMenu();
    var W = window.Wachtrij;
    if (W) {
      var balkEl = document.getElementById("balk");
      if (balkEl && !document.getElementById("wachtmelding")) {
        var vak = D.maak("div", { id: "wachtmelding", role: "status" });
        balkEl.parentNode.insertBefore(vak, balkEl.nextSibling);
      }
      document.addEventListener("wachtrij-gewijzigd", K.wachtrijWeergave);
      K.wachtrijWeergave();
      W.start();
    }
    // De balk "N fatale termijnen" staat niet meer op elke pagina (opdracht Ruben 20-11-2026: te veel ruis).
    // Wat er te doen is, staat bij Taken; het vak #balk blijft alleen als ankerpunt voor de wachtrijmelding.
    zoekbalk();
    takenTeller();
  });

  // ---------- Taken in de zijbalk: aantal dat aandacht vraagt (te laat, vandaag, toewijzen) ----------
  function takenTeller() {
    var a = document.querySelector('nav.sub a[href="/dashboard/klanten/"]');
    if (!a) return;
    D.api("/api/dashboard/klanten/taken?alleen=telling").then(function (r) {
      if (!r.ok || !r.data || !isObj(r.data.telling)) return;
      var t = r.data.telling;
      var n = (t.teLaat || 0) + (t.vandaag || 0) + (t.toewijzen || 0);
      var oud = a.querySelector(".teller");
      if (oud) oud.remove();
      if (n > 0) {
        a.appendChild(D.maak("span", { klasse: "teller", "aria-hidden": "true" }, String(n)));
        a.setAttribute("aria-label", a.textContent.replace(/\d+$/, "").trim() + ", " + K.vul(T.takenlijst.aandacht, { n: n }));
      }
    });
  }

  // ---------- Klant zoeken in de kop (combobox: pijltjes, Enter, Esc) ----------
  function zoekbalk() {
    var kop = document.querySelector("header.kop .pagina");
    if (!kop || document.getElementById("kopzoek")) return;
    var Z = T.zoeken;
    var vak = D.maak("div", { klasse: "kopzoek", id: "kopzoek", role: "search" });
    var label = D.maak("label", { for: "kopzoek-invoer", klasse: "verborgen" }, Z.label);
    var inv = D.maak("input", {
      type: "search", id: "kopzoek-invoer", placeholder: Z.label, autocomplete: "off", spellcheck: "false", maxlength: "100",
      role: "combobox", "aria-expanded": "false", "aria-controls": "kopzoek-lijst", "aria-autocomplete": "list",
    });
    var lijst = D.maak("ul", { id: "kopzoek-lijst", role: "listbox", klasse: "kopzoek-lijst", "aria-label": Z.label, hidden: "hidden" });
    vak.appendChild(label); vak.appendChild(inv); vak.appendChild(lijst);
    var merk = kop.querySelector(".merk");
    kop.insertBefore(vak, merk ? merk.nextSibling : kop.firstChild);
    var timer = null, nr = 0, actief = -1, items = [];
    function sluit() { lijst.hidden = true; inv.setAttribute("aria-expanded", "false"); inv.removeAttribute("aria-activedescendant"); actief = -1; }
    function markeer(i) {
      actief = i;
      Array.prototype.forEach.call(lijst.children, function (li, j) { li.setAttribute("aria-selected", j === i ? "true" : "false"); });
      if (i >= 0 && lijst.children[i]) inv.setAttribute("aria-activedescendant", lijst.children[i].id); else inv.removeAttribute("aria-activedescendant");
    }
    function toon(rijen, leegTekst) {
      lijst.textContent = "";
      items = rijen;
      rijen.forEach(function (r, i) {
        var li = D.maak("li", { id: "kopzoek-" + i, role: "option", "aria-selected": "false" });
        var naam = [r.voornaam, r.achternaam].filter(Boolean).join(" ") || r.naam || T.fataal.geenNaam;
        li.appendChild(D.maak("span", { klasse: "naam" }, naam));
        li.appendChild(D.maak("span", { klasse: "wat" }, [r.plaats, r.status].filter(Boolean).join(", ")));
        li.addEventListener("mousedown", function (e) { e.preventDefault(); ga(i); });
        lijst.appendChild(li);
      });
      if (!rijen.length) lijst.appendChild(D.maak("li", { klasse: "leeg", role: "option", "aria-disabled": "true" }, leegTekst));
      lijst.hidden = false;
      inv.setAttribute("aria-expanded", "true");
      markeer(rijen.length ? 0 : -1);
    }
    function ga(i) { var r = items[i]; if (r) window.location.href = K.relatieHref(r.id); }
    function zoek() {
      var q = inv.value.trim();
      if (q.length < 2) { sluit(); return; }
      var mijn = ++nr;
      D.api("/api/dashboard/klanten/relaties?archief=toon&q=" + encodeURIComponent(q)).then(function (r) {
        if (mijn !== nr) return;
        if (r.ok && r.data && Array.isArray(r.data.relaties)) toon(r.data.relaties.slice(0, 8), Z.geen);
        else toon([], r.status === 0 ? D.teksten.algemeen.geenVerbinding : Z.mislukt);
      });
    }
    inv.addEventListener("input", function () { clearTimeout(timer); timer = setTimeout(zoek, 200); });
    inv.addEventListener("keydown", function (e) {
      if (e.key === "ArrowDown" && items.length) { e.preventDefault(); if (lijst.hidden) zoek(); else markeer((actief + 1) % items.length); }
      else if (e.key === "ArrowUp" && items.length) { e.preventDefault(); markeer((actief - 1 + items.length) % items.length); }
      else if (e.key === "Enter") { e.preventDefault(); if (actief >= 0) ga(actief); else { clearTimeout(timer); zoek(); } }
      else if (e.key === "Escape") { sluit(); }
    });
    inv.addEventListener("blur", function () { setTimeout(sluit, 120); });
    // "/" springt naar het zoekveld (zoals in veel programma's), behalve als je al in een veld typt.
    document.addEventListener("keydown", function (e) {
      if (e.key !== "/" || e.ctrlKey || e.metaKey || e.altKey) return;
      var t = e.target;
      if (t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable)) return;
      e.preventDefault();
      inv.focus();
    });
  }
})();

// Termijnregels, alleen lezen. "Niet bevestigd" staat er duidelijk bij, met tekst en niet alleen met kleur.
(function () {
  "use strict";
  var D = window.Dashboard;
  var K = window.Klanten;
  var W = window.Wachtrij;
  var R = D.teksten.klanten.rg;
  var $ = function (id) { return document.getElementById(id); };

  function toon(regels, stand) {
    var lijst = $("regels");
    lijst.textContent = "";
    $("regelmelding").textContent = "";
    if (stand) D.melding($("regelmelding"), K.vul(D.teksten.klanten.rel.standOffline, { moment: K.moment(stand) }), true);
    else if (!regels.length) D.melding($("regelmelding"), R.leeg);
    regels.forEach(function (r) {
      if (!r || typeof r !== "object") return;
      var bevestigd = r.bevestigingsstatus === "bevestigd";
      var li = D.maak("li", { klasse: "veldrij regel" + (bevestigd ? "" : " signaal"), "data-regel": r.id || "" });
      li.appendChild(D.maak("p", { klasse: "veldlabel" }, K.titel(typeof r.titel === "string" && r.titel ? r.titel : String(r.zoho || r.id || ""))));
      li.appendChild(D.maak("p", { klasse: bevestigd ? "veldwaarde" : "veldwaarde onbevestigd" }, bevestigd ? R.bevestigd : R.nietBevestigd));
      if (!bevestigd) li.appendChild(D.maak("p", { klasse: "veldextra" }, R.nietBevestigdUitleg));
      var delen = [];
      delen.push(K.eigen(R.record, r.record) || "");
      delen.push(r.fataal === true ? R.fataal : r.fataal === false ? R.nietFataal : R.fataalOnbekend);
      if (r.duur && typeof r.duur.aantal === "number") delen.push(K.vul(R.duur, { aantal: r.duur.aantal, eenheid: r.duur.eenheid || "" }));
      else delen.push(R.duurOnbekend);
      if (r.actief === false) delen.push(R.uit);
      li.appendChild(D.maak("p", { klasse: "veldextra" }, delen.filter(Boolean).join(", ")));
      if (Array.isArray(r.afvinkActies) && r.afvinkActies.length) li.appendChild(D.maak("p", { klasse: "veldextra" }, K.vul(R.acties, { lijst: r.afvinkActies.join(", ") })));
      lijst.appendChild(li);
    });
  }

  document.addEventListener("DOMContentLoaded", function () {
    D.api("/api/dashboard/klanten/regels").then(function (r) {
      if (r.ok && r.data && Array.isArray(r.data.regels)) {
        toon(r.data.regels, null);
        W.kv.set("regels", { op: new Date().toISOString(), regels: r.data.regels });
      } else {
        W.kv.get("regels").then(function (c) {
          if (c && Array.isArray(c.regels)) toon(c.regels, new Date(c.op));
          else D.melding($("regelmelding"), R.mislukt, true);
        });
      }
    });
  });
})();

// Offline-wachtrij en cache voor de klantenschermen, in IndexedDB (database "rozema-klanten").
//   kv        cache van klantgegevens: alleen serverdata, hoogstens 7 dagen oud, gewist bij uitloggen en een 401
//   wachtrij  niet-verstuurde schrijfacties en onbeslechte conflicten (nooit automatisch gewist)
// Het schema staat ook in gedeeld/dashboard.js (wisCache en wachtrijTelling): wijzig beide samen.
// Opzet naar de deur-wachtrij (branch dashboard-deur, deur/opslag.js en deur/verstuur.js). Die twee kunnen later
// samengevoegd worden tot een gedeelde wachtrij; hier zit alles in klanten/ zodat de branches niet botsen.
//
// Regels:
//  - elke schrijfactie heeft een vaste wijzigingId (in de body) en de naam van wie hem maakte (wie);
//  - er wordt eerst bewaard, dan verstuurd. Lukt bewaren in IndexedDB niet, dan blijft de actie in het geheugen en
//    wordt hij toch verstuurd; blijvend() is dan false en de pagina meldt dat de pagina open moet blijven;
//  - nooit weggooien bij 401, 408, 429, 5xx of een netwerkfout; een 401 stopt het versturen tot er is ingelogd;
//  - alleen acties van de ingelogde gebruiker worden verstuurd; acties van een ander wachten tot die inlogt;
//  - een 503 met herhaal:true wordt direct een paar keer herhaald met dezelfde wijzigingId;
//  - volgorde blijft behouden; na een afgekeurde actie (of een actie van een ander) wachten latere acties op
//    hetzelfde record;
//  - een echte invoerfout (422, 409, ...) wordt "afgekeurd" en blijft zichtbaar in "Niet opgeslagen";
//  - versturen gebeurt onder een Web Lock, zodat twee tabbladen niet tegelijk dezelfde actie versturen.
(function () {
  "use strict";
  var D = window.Dashboard;
  var W = (window.Wachtrij = {});
  var DB_NAAM = "rozema-klanten";
  var KV_MAX_MS = 7 * 24 * 60 * 60 * 1000;
  var dbPromise = null;
  var geheugenModus = false;
  var geheugen = { kv: new Map(), wachtrij: new Map() };
  var teller = 0;
  var bezig = null;
  var directIds = {}; // acties waarvan de aanroeper het resultaat zelf toont (bij een invoerfout dan niet bewaren)
  var HERHAAL_MAX = 3;
  var wieNu = null;
  var wieKlaar = null;
  var lastGestopt = null;

  function openDb() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise(function (resolve) {
      try {
        var rq = window.indexedDB.open(DB_NAAM, 1);
        rq.onupgradeneeded = function () {
          var db = rq.result;
          if (!db.objectStoreNames.contains("kv")) db.createObjectStore("kv");
          if (!db.objectStoreNames.contains("wachtrij")) db.createObjectStore("wachtrij", { keyPath: "id" });
        };
        rq.onsuccess = function () { resolve(rq.result); };
        rq.onerror = function () { geheugenModus = true; resolve(null); };
        rq.onblocked = function () { geheugenModus = true; resolve(null); };
      } catch (e) { geheugenModus = true; resolve(null); }
    });
    return dbPromise;
  }

  // fn(store, geheugenmodus) geeft een IDBRequest of, in geheugenmodus, {result}. Zonder database gooit fn in
  // geheugenmodus een fout of geeft {result}; de aanroeper vangt dat af.
  function aanvraag(naam, modus, fn) {
    return openDb().then(function (db) {
      if (!db) { var r = fn(null, true); return r && "result" in r ? r.result : undefined; }
      return new Promise(function (resolve, reject) {
        var tx = db.transaction(naam, modus);
        var uit;
        var rq = fn(tx.objectStore(naam), false);
        if (rq && "onsuccess" in rq) rq.onsuccess = function () { uit = rq.result; };
        tx.oncomplete = function () { resolve(uit); };
        tx.onerror = tx.onabort = function () { reject(tx.error || new Error("opslag")); };
      });
    });
  }

  // blijvend() is false als bewaren op het toestel niet lukt (en acties dus alleen in het geheugen staan).
  W.blijvend = function () { return !geheugenModus; };
  W.geheugenAantal = function () { return geheugen.wachtrij.size; };

  // ---------- wie ----------
  W.zetWie = function (naam) { wieNu = naam || null; };
  W.wie = function () { return wieNu; };
  function wieOnthouden(naam) { try { if (naam) window.sessionStorage.setItem("dashboard.klanten.wie", naam); } catch (e) { /* idem */ } }
  function wieUitSessie() { try { return window.sessionStorage.getItem("dashboard.klanten.wie"); } catch (e) { return null; } }

  // ---------- cache ----------
  W.kv = {
    get: function (k) {
      return aanvraag("kv", "readonly", function (st, mem) { return mem ? { result: geheugen.kv.get(k) } : st.get(k); })
        .then(function (v) {
          if (v === undefined || v === null) return null;
          // Hoogstens 7 dagen oud: oudere klantgegevens worden niet meer getoond.
          if (typeof v.op === "string" && Date.now() - Date.parse(v.op) > KV_MAX_MS) return null;
          return v;
        }, function () { return null; });
    },
    set: function (k, v) {
      return aanvraag("kv", "readwrite", function (st, mem) {
        if (mem) { geheugen.kv.set(k, v); return null; }
        return st.put(v, k);
      }).catch(function () { /* de cache mag mislukken */ });
    },
    del: function (k) {
      return aanvraag("kv", "readwrite", function (st, mem) {
        if (mem) { geheugen.kv.delete(k); return null; }
        return st.delete(k);
      }).catch(function () { /* de cache mag mislukken */ });
    },
  };

  // ---------- wachtrij: database en geheugen samen ----------
  function dbItems() {
    return openDb().then(function (db) {
      if (!db) return [];
      return new Promise(function (resolve) {
        try {
          var rq = db.transaction("wachtrij", "readonly").objectStore("wachtrij").getAll();
          rq.onsuccess = function () { resolve(Array.isArray(rq.result) ? rq.result : []); };
          rq.onerror = function () { resolve([]); };
        } catch (e) { resolve([]); }
      });
    });
  }
  function alleItems() {
    return dbItems().then(function (l) {
      var m = {};
      l.forEach(function (x) { m[x.id] = x; });
      geheugen.wachtrij.forEach(function (v, k) { m[k] = v; }); // wat alleen in het geheugen staat of daar nieuwer is
      return Object.keys(m).map(function (k) { return m[k]; }).sort(function (a, b) { return a.toegevoegd - b.toegevoegd; });
    });
  }
  // Nieuw item bewaren. Mislukt dat (quota, privévenster), dan blijft het in het geheugen: het wordt toch verstuurd.
  function bewaar(item) {
    return aanvraag("wachtrij", "readwrite", function (st, mem) {
      if (mem) throw new Error("geen database");
      return st.put(item);
    }).then(function () { geheugen.wachtrij.delete(item.id); }, function () {
      geheugen.wachtrij.set(item.id, item);
      geheugenModus = true;
    });
  }
  // Bestaand item bijwerken: alleen als het nog bestaat (een ander tabblad kan het al verwijderd hebben).
  function bewaarBijwerk(item) {
    return openDb().then(function (db) {
      if (geheugen.wachtrij.has(item.id)) geheugen.wachtrij.set(item.id, item);
      if (!db) return false;
      return new Promise(function (resolve) {
        try {
          var tx = db.transaction("wachtrij", "readwrite");
          var st = tx.objectStore("wachtrij");
          var g = st.get(item.id);
          g.onsuccess = function () { if (g.result) st.put(item); };
          tx.oncomplete = function () { resolve(true); };
          tx.onerror = tx.onabort = function () { resolve(false); };
        } catch (e) { resolve(false); }
      });
    });
  }
  function verwijder(id) {
    geheugen.wachtrij.delete(id);
    return aanvraag("wachtrij", "readwrite", function (st, mem) {
      if (mem) return null;
      return st.delete(id);
    }).catch(function () { /* onbereikbare database: niets te wissen */ });
  }

  function meld() { document.dispatchEvent(new CustomEvent("wachtrij-gewijzigd")); }

  // Wachtrij zonder conflicten.
  W.acties = function () {
    return alleItems().then(function (l) { return l.filter(function (x) { return x.soort !== "conflict"; }); });
  };
  W.conflicten = function () {
    return alleItems().then(function (l) { return l.filter(function (x) { return x.soort === "conflict"; }); });
  };
  W.aantal = function () { return W.acties().then(function (l) { return l.length; }); };

  W.verwijder = function (id) { return verwijder(id).then(meld); };
  W.opnieuw = function (id) {
    return alleItems().then(function (l) {
      var it = l.filter(function (x) { return x.id === id; })[0];
      if (!it) return null;
      it.afgekeurd = null;
      return bewaarBijwerk(it).then(meld);
    });
  };
  // Alleen de wijzigingen en conflicten van deze gebruiker wissen (bewuste keuze bij het uitloggen).
  // Wat van een ander is (of geen eigenaar heeft) blijft staan.
  W.wisEigen = function (naam) {
    return alleItems().then(function (l) {
      return Promise.all(l.filter(function (x) { return naam && (x.soort === "conflict" ? x.van === naam : x.wie === naam); })
        .map(function (x) { return verwijder(x.id); }));
    }).then(meld);
  };
  // Alles van dit toestel wissen (acties en conflicten).
  W.wisAlles = function () {
    geheugen.wachtrij.clear();
    return aanvraag("wachtrij", "readwrite", function (st, mem) { return mem ? null : st.clear(); })
      .catch(function () { /* niets te wissen */ }).then(meld);
  };

  // Een nieuwe wijzigingId (voor een nieuwe actie).
  W.nieuwId = function () {
    var u = window.crypto && window.crypto.randomUUID ? window.crypto.randomUUID() : null;
    if (!u) {
      var b = new Uint8Array(16);
      window.crypto.getRandomValues(b);
      u = Array.prototype.map.call(b, function (x) { return ("0" + x.toString(16)).slice(-2); }).join("");
    }
    return u;
  };

  function isTijdelijk(r) {
    return r.status === 0 || r.status === 408 || r.status === 429 || r.status >= 500
      // een 404 zonder melding van onze eigen server is een route die er tijdelijk niet is
      || (r.status === 404 && !(r.data && r.data.fout));
  }

  function pauze(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

  function stuurEen(item) {
    function poging(n) {
      return D.api("/api/dashboard/klanten" + item.pad, { method: item.methode, body: item.body, geenOmleiding: true }).then(function (r) {
        if (r.status === 503 && r.data && r.data.herhaal === true && n < HERHAAL_MAX) {
          return pauze(250).then(function () { return poging(n + 1); });
        }
        return r;
      });
    }
    return poging(1);
  }

  // Bewaart een conflict zodat het blijft staan tot de gebruiker kiest (ook als het op de achtergrond ontstond).
  function bewaarConflict(item, data) {
    var rec = data.record || {};
    var soort = item.pad.indexOf("/trajecten/") === 0 ? "traject" : "relatie";
    return bewaar({
      id: "c_" + item.id, soort: "conflict", toegevoegd: item.toegevoegd, recordSoort: soort,
      pad: item.pad, recordKey: item.recordKey, relatieId: item.relatieId || null, van: item.wie || null,
      wie: rec.gewijzigd && rec.gewijzigd.wie ? rec.gewijzigd.wie : null, conflicten: data.conflicten,
    });
  }

  // De eigenlijke ronde (altijd onder de lock). Geeft {uitkomsten, gestopt}.
  function ronde() {
    return W.acties().then(function (items) {
      var uitkomsten = {};
      var geblokkeerd = {};
      var gestopt = null;
      var i = 0;
      function volgende() {
        if (i >= items.length || gestopt) return Promise.resolve();
        var item = items[i++];
        if (item.afgekeurd) { geblokkeerd[item.recordKey] = true; return volgende(); }
        // Van een andere gebruiker op dit toestel: niet versturen, en latere acties op dat record wachten.
        // Zonder bekende eigenaar (wie null) telt ook als "van een ander".
        if (!item.wie || item.wie !== wieNu) {
          uitkomsten[item.id] = { uitkomst: "andere-gebruiker" };
          geblokkeerd[item.recordKey] = true;
          return volgende();
        }
        if (geblokkeerd[item.recordKey]) { uitkomsten[item.id] = { uitkomst: "wacht-eerder" }; return volgende(); }
        return stuurEen(item).then(function (r) {
          if (r.ok && r.data) {
            uitkomsten[item.id] = { uitkomst: "verstuurd", r: r };
            var conflict = Array.isArray(r.data.conflicten) && r.data.conflicten.length > 0;
            return (conflict ? bewaarConflict(item, r.data) : Promise.resolve())
              .then(function () { return verwijder(item.id); })
              .then(volgende);
          }
          // Sessie weg: de cache met klantgegevens wissen (de wachtrij blijft), en wachten tot er is ingelogd.
          if (r.status === 401) { gestopt = "inlog"; D.wisCache(); return null; }
          if (isTijdelijk(r)) { gestopt = "tijdelijk"; return null; }
          // Echte invoerfout. Direct teruggemeld (formulier staat nog open): niet bewaren.
          uitkomsten[item.id] = { uitkomst: "afgekeurd", r: r };
          geblokkeerd[item.recordKey] = true;
          if (directIds[item.id] || r.status === 410) return verwijder(item.id).then(volgende);
          item.afgekeurd = { status: r.status, code: r.data && r.data.code ? r.data.code : null, fouten: r.data && r.data.fouten ? r.data.fouten : null,
            termijnen: r.data && r.data.termijnen ? r.data.termijnen : null, tekst: r.data && r.data.fout ? r.data.fout : null };
          return bewaarBijwerk(item).then(volgende);
        });
      }
      return volgende().then(function () {
        items.forEach(function (it) { if (!uitkomsten[it.id] && !it.afgekeurd) uitkomsten[it.id] = { uitkomst: "wacht" }; });
        return { uitkomsten: uitkomsten, gestopt: gestopt };
      });
    });
  }

  // Verstuurt alles wat kan, in volgorde. uitkomst per actie:
  // "verstuurd" | "afgekeurd" | "wacht" | "wacht-eerder" | "andere-gebruiker".
  W.verstuur = function () {
    if (bezig) return bezig;
    var start = function () { return wieKlaar || Promise.resolve(); };
    var uitvoeren = function () { return start().then(ronde); };
    var p = window.navigator && navigator.locks && typeof navigator.locks.request === "function"
      ? navigator.locks.request("rozema-klanten-wachtrij", uitvoeren)
      : uitvoeren();
    bezig = Promise.resolve(p).then(function (res) { bezig = null; lastGestopt = res.gestopt; meld(); return res; }, function (e) { bezig = null; throw e; });
    return bezig;
  };
  W.laatsteStop = function () { return lastGestopt; };

  // Voegt een actie toe en probeert hem meteen te versturen.
  // actie: {soort, methode, pad, body (met wijzigingId), recordKey, relatieId?, velden?: [veldnamen]}
  // opties.direct: de aanroeper toont zelf het resultaat; een invoerfout wordt dan niet bewaard.
  // Geeft {uitkomst, r?, gestopt?}.
  W.zet = function (actie, opties) {
    return (wieKlaar || Promise.resolve()).then(function () {
      // Zonder bekende gebruiker niets in de wachtrij zetten: eerst inloggen.
      if (!wieNu && !wieUitSessie()) return { uitkomst: "geen-wie" };
      var item = {
        id: actie.body.wijzigingId, soort: actie.soort, methode: actie.methode, pad: actie.pad, body: actie.body,
        recordKey: actie.recordKey, relatieId: actie.relatieId || null, velden: actie.velden || [],
        wie: wieNu || wieUitSessie(),
        toegevoegd: Date.now() * 1000 + (teller++ % 1000), afgekeurd: null,
      };
      if (opties && opties.direct) directIds[item.id] = true;
      return bewaar(item).then(function () {
        meld();
        return W.verstuur();
      }).then(function (res) {
        var u = res.uitkomsten[item.id];
        delete directIds[item.id];
        if (!u) {
          // De lopende ronde had deze actie nog niet gezien: nog een ronde.
          return W.verstuur().then(function (res2) { return Object.assign({ gestopt: res2.gestopt }, res2.uitkomsten[item.id] || { uitkomst: "wacht" }); });
        }
        return Object.assign({ gestopt: res.gestopt }, u);
      });
    });
  };

  // ---------- conflicten ----------
  W.conflictenVoor = function (recordKey) {
    return W.conflicten().then(function (l) { return l.filter(function (c) { return c.recordKey === recordKey; }); });
  };
  W.zetConflict = function (c) { return bewaarBijwerk(c).then(meld); };
  W.wisConflict = function (id) { return verwijder(id).then(meld); };

  // ---------- automatisch versturen ----------
  W.start = function () {
    wieKlaar = D.zegWie().then(function (w) {
      if (w.naam) { wieNu = w.naam; wieOnthouden(w.naam); }
      else if (w.status === 0) wieNu = wieUitSessie(); // geen verbinding: de laatst bekende gebruiker op dit tabblad
      else { wieNu = null; lastGestopt = "inlog"; meld(); }
    });
    function probeer() { W.aantal().then(function (n) { if (n > 0) W.verstuur(); }); }
    wieKlaar.then(probeer);
    window.addEventListener("online", probeer);
    setInterval(probeer, 20000);
  };
})();

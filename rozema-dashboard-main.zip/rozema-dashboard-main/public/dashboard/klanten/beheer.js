// Beheer (K11): export, agenda-link en AVG-verwijderen. Alleen teksten uit beheer-teksten.js.
(function () {
  "use strict";
  var D = window.Dashboard;
  var T = D.teksten.klanten.beheerK11;
  var W = window.Wachtrij;
  var API = "/api/dashboard/klantenbeheer/";
  var VERWIJDER_TIMEOUT_MS = 25000;
  var RELATIE_ID = /^r_[A-Za-z0-9_-]{1,62}$/;
  var $ = function (id) { return document.getElementById(id); };

  // ---------- agenda ----------
  var heeftToken = false;
  function toonStand(stand) {
    heeftToken = !!(stand && stand.bestaat);
    $("agenda-stand").textContent = heeftToken ? T.agendaStandBestaat : T.agendaStandGeen;
    $("agenda-maak").textContent = heeftToken ? T.agendaVernieuw : T.agendaMaak;
  }

  function laadStand() {
    D.api(API + "agenda/token").then(function (r) {
      if (r.ok) toonStand(r.data);
      else D.melding($("agenda-melding"), T.agendaFout, true);
    });
  }

  $("agenda-maak").addEventListener("click", function () {
    var knop = $("agenda-maak");
    knop.disabled = true;
    D.melding($("agenda-melding"), "", false);
    D.api(API + "agenda/token", { method: "POST", body: {} }).then(function (r) {
      knop.disabled = false;
      if (!r.ok || !r.data || !r.data.url) { D.melding($("agenda-melding"), T.agendaFout, true); return; }
      // De link staat alleen nu op het scherm: de server bewaart het token niet leesbaar.
      $("agenda-url").value = r.data.url;
      $("agenda-uitkomst").hidden = false;
      toonStand({ bestaat: true });
      D.melding($("agenda-melding"), T.agendaNieuw, false);
    });
  });

  $("agenda-kopieer").addEventListener("click", function () {
    var veld = $("agenda-url");
    veld.focus();
    veld.select();
    var klaar = function () { D.melding($("agenda-melding"), T.agendaGekopieerd, false); };
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(veld.value).then(klaar, function () {});
    else if (document.execCommand && document.execCommand("copy")) klaar();
  });

  // ---------- verwijderen ----------
  var id = new URLSearchParams(window.location.search).get("id");
  if (id && RELATIE_ID.test(id)) {
    $("verwijder-sectie").hidden = false;
    $("verwijder-relatie").setAttribute("href", "/dashboard/klanten/relatie.html?id=" + encodeURIComponent(id));
  }

  var FOUTEN = { "komt-niet-overeen": "verwijderKomtNietOvereen", "gelijktijdig-probeer-opnieuw": "verwijderDruk" };

  // Eigen aanroep met een langere timeout dan de 15 seconden van D.api. De server stopt na ongeveer 8 s met opruimen en meldt dan deels:true (ok); de dagelijkse run maakt het af. Dat telt hier als gelukt.
  function verstuurVerwijder(body) {
    return fetch(API + "beheer/verwijderen", {
      method: "POST", credentials: "same-origin", headers: { "content-type": "application/json" }, body: JSON.stringify(body),
      signal: AbortSignal.timeout ? AbortSignal.timeout(VERWIJDER_TIMEOUT_MS) : undefined
    }).then(function (r) {
      return r.json().then(function (d) { return d; }, function () { return null; }).then(function (data) {
        if (r.status === 401) D.naarInlog();
        return { ok: r.ok, status: r.status, data: data };
      });
    }, function () { return { ok: false, status: 0, data: null }; });
  }

  // Na een geslaagde verwijdering: lokale resten van deze relatie op dit toestel weg.
  // Caches op andere apparaten blijven bestaan (zie dashboard/INTEGRATIE.md).
  function wisLokaal(relatieId) {
    try {
      var weg = [];
      for (var i = 0; i < window.sessionStorage.length; i++) {
        var k = window.sessionStorage.key(i);
        if (k && k.indexOf("dashboard.klanten.") === 0) weg.push(k);
      }
      weg.forEach(function (k) { window.sessionStorage.removeItem(k); });
    } catch (e) { /* geen opslag */ }
    var kv = Promise.all([W.kv.del("relatie:" + relatieId), W.kv.del("tijdlijn:" + relatieId)]);
    var hoort = function (x) { return x.relatieId === relatieId || x.recordKey === relatieId; };
    var wachtrij = Promise.all([W.acties(), W.conflicten()]).then(function (r) {
      return Promise.all(r[0].concat(r[1]).filter(hoort).map(function (x) { return W.verwijder(x.id); }));
    });
    return Promise.all([kv, wachtrij]).catch(function () {});
  }

  var eerderGeprobeerd = false;
  $("verwijder-form").addEventListener("submit", function (e) {
    e.preventDefault();
    var melding = $("verwijder-melding");
    var bevestig = $("verwijder-bevestig").value;
    if (!bevestig.trim()) { D.melding(melding, T.verwijderBevestigLeeg, true); return; }
    var knop = $("verwijder-knop");
    knop.disabled = true;
    D.melding(melding, T.verwijderBezig, false);
    var vorige = eerderGeprobeerd;
    eerderGeprobeerd = true;
    verstuurVerwijder({ id: id, bevestig: bevestig }).then(function (r) {
      knop.disabled = false;
      // Een 404 na een eerdere poging (bijvoorbeeld na een time-out) betekent dat de relatie al weg is: geslaagd.
      if (r.ok || (r.status === 404 && vorige)) {
        wisLokaal(id).then(function () {
          $("verwijder-form").hidden = true;
          $("verwijder-relatie").hidden = true;
          D.melding(melding, T.verwijderKlaar, false);
          melding.parentNode.appendChild(D.maak("a", { klasse: "knop", href: "/dashboard/klanten/lijst.html" }, T.naarLijst));
        });
        return;
      }
      var f = r.data && r.data.fouten ? r.data.fouten : {};
      var sleutel = r.status === 404 ? "verwijderNietGevonden" : FOUTEN[f.bevestig] || FOUTEN[f._] || (r.status === 503 ? "verwijderDruk" : "verwijderFout");
      D.melding(melding, T[sleutel], true);
    });
  });

  laadStand();
})();

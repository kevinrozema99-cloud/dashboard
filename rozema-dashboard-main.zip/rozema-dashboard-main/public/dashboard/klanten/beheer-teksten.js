// Teksten voor beheer.html (K11): export, agenda en AVG-verwijderen.
// Alleen placeholders; de echte teksten komen via Kevin uit het content-bestand (CLAUDE.md regel 1).
// Een eigen bestand, zodat gedeeld/teksten.js niet hoeft te veranderen. Verhuist later naar teksten.js.
(function () {
  "use strict";
  var K = window.TEKSTEN.klanten;
  var p = function (sleutel) { return "[[TEKST: klanten.beheerK11." + sleutel + "]]"; };
  K.beheerK11 = {
    kop: p("kop"),
    exportKop: p("exportKop"),
    exportJson: p("exportJson"),
    exportCsvRelaties: p("exportCsvRelaties"),
    exportCsvTrajecten: p("exportCsvTrajecten"),
    agendaKop: p("agendaKop"),
    agendaStandGeen: p("agendaStandGeen"),
    agendaStandBestaat: p("agendaStandBestaat"),
    agendaMaak: p("agendaMaak"),
    agendaVernieuw: p("agendaVernieuw"),
    agendaLinkLabel: p("agendaLinkLabel"),
    agendaKopieer: p("agendaKopieer"),
    agendaGekopieerd: p("agendaGekopieerd"),
    agendaNieuw: p("agendaNieuw"),
    agendaFout: p("agendaFout"),
    verwijderKop: p("verwijderKop"),
    naarRelatie: p("naarRelatie"),
    verwijderUitleg: p("verwijderUitleg"),
    bevestigLabel: p("bevestigLabel"),
    verwijderKnop: p("verwijderKnop"),
    verwijderBezig: p("verwijderBezig"),
    verwijderKlaar: p("verwijderKlaar"),
    verwijderBevestigLeeg: p("verwijderBevestigLeeg"),
    verwijderKomtNietOvereen: p("verwijderKomtNietOvereen"),
    verwijderNietGevonden: p("verwijderNietGevonden"),
    verwijderDruk: p("verwijderDruk"),
    verwijderFout: p("verwijderFout"),
    naarLijst: p("naarLijst"),
    relatieLink: p("relatieLink")
  };
})();

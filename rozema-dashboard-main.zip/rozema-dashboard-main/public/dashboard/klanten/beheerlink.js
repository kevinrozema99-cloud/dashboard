// Relatiepagina: zet de href van de link naar beheer.html?id=... (relatie.js blijft ongemoeid).
(function () {
  "use strict";
  var a = document.getElementById("beheer-link");
  var id = new URLSearchParams(window.location.search).get("id");
  if (a && id && /^r_[A-Za-z0-9_-]{1,62}$/.test(id)) a.setAttribute("href", "/dashboard/klanten/beheer.html?id=" + encodeURIComponent(id));
  else if (a) a.hidden = true;
})();

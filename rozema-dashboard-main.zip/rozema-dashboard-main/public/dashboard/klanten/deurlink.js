// K10: op de relatiepagina een verwijzing terug naar de deurbezoeken op het adres, als de relatie uit een
// deurbezoek is aangemaakt (herkomst.deur). Staat los van relatie.js en doet zelf geen verzoek: relatie.js bewaart
// de relatie na elke keer laden in de cache (W.kv.set "relatie:<id>"); die schrijfactie volgen we hier, en bij het
// openen lezen we de bewaarde cache (voor offline).
(function () {
  "use strict";
  var W = window.Wachtrij;
  var B = window.Bewerk;
  var KORT = /^[A-Za-z0-9._-]{1,60}$/;
  var id = B.query("id");
  var sleutel = "relatie:" + id;

  // Geeft de href naar de deur-app, of null als de relatie geen deurbezoek met bekend adres heeft.
  function deurHref(relatie) {
    var d = relatie && relatie.herkomst && relatie.herkomst.deur;
    if (!d || typeof d.plaats !== "string" || typeof d.adres !== "string") return null;
    if (!KORT.test(d.plaats) || !KORT.test(d.adres)) return null;
    return "/dashboard/deur/?plaats=" + encodeURIComponent(d.plaats) + "&adres=" + encodeURIComponent(d.adres);
  }

  function toon(relatie) {
    var href = deurHref(relatie);
    var vak = document.getElementById("deurbezoeken");
    if (!vak) return;
    vak.hidden = !href;
    if (href) document.getElementById("deurlink").setAttribute("href", href);
  }

  function uitCache(c) { if (c && c.data) toon(c.data.relatie); }

  if (id && W && W.kv) {
    var oorspronkelijk = W.kv.set;
    W.kv.set = function (k, v) {
      if (k === sleutel) uitCache(v);
      return oorspronkelijk.apply(W.kv, arguments);
    };
    document.addEventListener("DOMContentLoaded", function () { W.kv.get(sleutel).then(uitCache); });
  }
  window.DeurLink = { deurHref: deurHref };
})();

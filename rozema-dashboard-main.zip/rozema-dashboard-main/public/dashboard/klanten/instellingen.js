// Instellingen: de technische controle (gezondheid van de opslag en de nachtelijke controle). Stond eerst op het
// startscherm; daar staat nu alleen een melding als er iets mis is (opdracht Ruben 20-11-2026).
(function () {
  "use strict";
  var D = window.Dashboard;
  var K = window.Klanten;
  var T = D.teksten.klanten;
  var G = T.gezondheid;
  var API = "/api/dashboard/klanten/";
  var $ = function (id) { return document.getElementById(id); };
  var isObj = function (v) { return v !== null && typeof v === "object" && !Array.isArray(v); };

  function gezondheid() {
    D.api(API + "start").then(function (r) {
      if (!r.ok || !isObj(r.data)) return;
      var d = r.data;
      var regels = [];
      var g = isObj(d.gezondheid) ? d.gezondheid : {};
      var n = Array.isArray(g.onvolledig) ? g.onvolledig.length : 0;
      if (n) regels.push(n === 1 ? G.onvolledigEen : K.vul(G.onvolledig, { n: n }));
      n = Array.isArray(g.onleesbaar) ? g.onleesbaar.length : 0;
      if (n) regels.push(n === 1 ? G.onleesbaarEen : K.vul(G.onleesbaar, { n: n }));
      var h = isObj(d.hartslag) ? d.hartslag : {};
      if (h.waarschuwing) {
        var tekst = typeof h.waarschuwing === "string" ? K.eigen(G.hartslag, h.waarschuwing) : undefined;
        if (tekst) regels.push(K.vul(tekst, { uren: typeof h.leeftijdUren === "number" ? Math.round(h.leeftijdUren) : "" }));
      }
      var reg = isObj(d.register) && Array.isArray(d.register.afwijkingen) ? d.register.afwijkingen.length : 0;
      if (reg) regels.push(reg === 1 ? G.registerEen : K.vul(G.register, { n: reg }));
      $("gezondheid").classList.toggle("opvallend", regels.length > 0);
      $("gezondheid-kop").textContent = regels.length ? G.kopOpvallend : G.kop;
      $("gezondheid-oke").textContent = regels.length ? "" : G.oke;
      var lijst = $("gezondheid-lijst");
      lijst.textContent = "";
      regels.forEach(function (t) { lijst.appendChild(D.maak("li", {}, t)); });
    });
  }

  function beheer() {
    var knop = $("nachtrun");
    var melding = $("beheermelding");
    knop.addEventListener("click", function () {
      knop.disabled = true;
      D.melding(melding, T.beheer.bezig);
      D.api(API + "dagelijks", { method: "POST", body: {} }).then(function (r) {
        knop.disabled = false;
        if (r.status === 429) D.melding(melding, T.beheer.teSnel, true);
        else if (r.ok) {
          var fouten = isObj(r.data) && Array.isArray(r.data.fouten) && r.data.fouten.length > 0;
          D.melding(melding, fouten ? T.beheer.metFouten : T.beheer.klaar, fouten);
          gezondheid();
        } else if (r.status === 0) D.melding(melding, D.teksten.algemeen.geenVerbinding, true);
        else D.melding(melding, T.beheer.mislukt, true);
      });
    });
  }

  document.addEventListener("DOMContentLoaded", function () { beheer(); gezondheid(); });
})();

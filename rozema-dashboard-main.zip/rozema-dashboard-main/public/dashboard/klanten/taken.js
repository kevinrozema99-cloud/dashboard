// Start (startpagina van de klantenmodule, opdracht Ruben 20-11-2026): in losse vakken.
//   Kerncijfers  te laat, vandaag, toe te wijzen, lopende leads en trajecten, nog te factureren (elk een link)
//   Taken        te laat, vandaag, deze week, later, zonder datum
//   Toewijzen    nieuwe leads zonder eigenaar: met één klik aan Kevin of Ruben
//   Pijplijn     aantallen per status en fase
// Taken komen uit de vaste flow (klaar = kaart verder zetten), uit handmatige taken en afspraken (afvinken), en uit
// bevestigde termijnen. De technische controle staat bij Instellingen; hier alleen een melding als er iets mis is.
(function () {
  "use strict";
  var D = window.Dashboard;
  var K = window.Klanten;
  var W = window.Wachtrij;
  var B = window.Bewerk;
  var T = D.teksten.klanten;
  var L = T.takenlijst;
  var API = "/api/dashboard/klanten/";
  var $ = function (id) { return document.getElementById(id); };
  var isObj = function (v) { return v !== null && typeof v === "object" && !Array.isArray(v); };
  var SLEUTEL = "dashboard.klanten.takenwie";
  var wie = "mijn";
  try { if (window.sessionStorage.getItem(SLEUTEL) === "alle") wie = "alle"; } catch (e) { /* geen opslag */ }
  var cache = {};
  var nr = 0;
  var ik = "Onbekend"; // naam voor "klaar door"; komt uit de sessie (bewerk.js)

  // ---------- melding ----------
  var toastTimer = null;
  function toast(tekst, isFout) {
    var t = $("toast");
    clearTimeout(toastTimer);
    t.textContent = tekst || "";
    t.className = "toast" + (isFout ? " fout" : "");
    t.hidden = !tekst;
    if (tekst && !isFout) toastTimer = setTimeout(function () { t.hidden = true; }, 4000);
  }

  // ---------- weergave ----------
  function titelVan(t) {
    if (t.bron === "flow") return K.eigen(T.flow, t.stap) || T.flow.onbekend;
    if (t.bron === "termijn") return t.titel ? K.titel(t.titel) : T.fataal.onbekendeActie;
    return t.titel ? K.titel(t.titel) : T.taken.zonderTitel;
  }
  function hrefVan(t) { return t.trajectId ? K.trajectHref(t.relatieId, t.trajectId) : K.relatieHref(t.relatieId); }
  function naamVan(t) { return [t.naam, t.plaats].filter(Boolean).join(", ") || T.fataal.geenNaam; }

  function taakRij(t, vandaag) {
    var li = D.maak("li", { klasse: "taak" + (t.datum && t.datum < vandaag ? " telaat" : ""), "data-id": t.id });
    // Titel en klant samen één link: een groot tikvlak naar de klant of het traject.
    var links = D.maak("a", { klasse: "taak-wat", href: hrefVan(t) });
    var kop = D.maak("p", { klasse: "taak-titel" }, titelVan(t));
    if (t.soort === "afspraak") kop.appendChild(D.maak("span", { klasse: "label" }, L.afspraak));
    if (t.bron === "termijn") kop.appendChild(D.maak("span", { klasse: "label" }, L.termijn));
    links.appendChild(kop);
    var wat = naamVan(t);
    if (wie === "alle" && t.eigenaar) wat += " " + K.vul(L.eigenaarIs, { naam: K.eigen(T.lijst.eigenaren, t.eigenaar) || t.eigenaar });
    links.appendChild(D.maak("p", { klasse: "taak-klant" }, wat));
    li.appendChild(links);
    var rechts = D.maak("div", { klasse: "taak-acties" });
    var wanneer = [t.datum ? K.datum(t.datum, { weekdag: true }) : null, t.tijd ? K.vul(T.taken.om, { tijd: t.tijd }) : null].filter(Boolean).join(", ");
    if (wanneer) rechts.appendChild(D.maak("span", { klasse: "taak-datum" }, wanneer));
    if (t.telefoon) {
      var nummer = String(t.telefoon).replace(/[^0-9+]/g, "");
      rechts.appendChild(D.maak("a", { klasse: "knop rand klein", href: "tel:" + nummer, "aria-label": K.vul(L.bel, { nummer: t.telefoon }) }, T.contact.bel));
    }
    if (t.bron === "handmatig" && t.taakId) {
      var knop = D.maak("button", { type: "button", klasse: "klein" }, L.klaar);
      knop.addEventListener("click", function () { afvinken(t, knop); });
      rechts.appendChild(knop);
    }
    li.appendChild(rechts);
    return li;
  }

  function toewijzenRij(r) {
    var li = D.maak("li", { klasse: "taak" });
    var links = D.maak("a", { klasse: "taak-wat", href: K.relatieHref(r.relatieId) });
    links.appendChild(D.maak("p", { klasse: "taak-titel" }, naamVan(r)));
    links.appendChild(D.maak("p", { klasse: "taak-klant" }, [r.bron, r.aangemaakt ? K.vul(L.binnenSinds, { datum: K.datum(r.aangemaakt) }) : null].filter(Boolean).join(", ")));
    li.appendChild(links);
    var rechts = D.maak("div", { klasse: "taak-acties" });
    Object.keys(T.lijst.eigenaren).forEach(function (e) {
      var knop = D.maak("button", { type: "button", klasse: "klein" }, K.vul(L.toewijzenAan, { naam: T.lijst.eigenaren[e] }));
      knop.addEventListener("click", function () { toewijzen(r, e, knop); });
      rechts.appendChild(knop);
    });
    li.appendChild(rechts);
    return li;
  }

  function groepVan(datum, vandaag, weekGrens) {
    if (!datum) return "zonderDatum";
    if (datum < vandaag) return "teLaat";
    if (datum === vandaag) return "vandaag";
    if (datum <= weekGrens) return "week";
    return "later";
  }

  function toon(data, stand) {
    var vandaag = data.vandaag || K.vandaagLokaal();
    var weekGrens = new Date(Date.parse(vandaag + "T12:00:00Z") + 7 * 86400000).toISOString().slice(0, 10);
    var tw = Array.isArray(data.toewijzen) ? data.toewijzen : [];
    $("toewijzen-leeg").hidden = tw.length > 0;
    var twLijst = $("toewijzen-lijst");
    twLijst.textContent = "";
    tw.forEach(function (r) { twLijst.appendChild(toewijzenRij(r)); });
    var groepen = { teLaat: [], vandaag: [], week: [], later: [], zonderDatum: [] };
    (Array.isArray(data.taken) ? data.taken : []).forEach(function (t) { if (isObj(t)) groepen[groepVan(t.datum, vandaag, weekGrens)].push(t); });
    var vak = $("groepen");
    vak.textContent = "";
    var totaal = 0;
    ["teLaat", "vandaag", "week", "later", "zonderDatum"].forEach(function (g) {
      if (!groepen[g].length) return;
      totaal += groepen[g].length;
      var sec = D.maak("section", { klasse: "takengroep groep-" + g, id: "groep-" + g });
      var h = D.maak("h2");
      h.appendChild(D.maak("span", null, L[g]));
      h.appendChild(D.maak("span", { klasse: "teller" }, String(groepen[g].length)));
      sec.appendChild(h);
      var ul = D.maak("ul", { klasse: "takenrijen" });
      groepen[g].forEach(function (t) { ul.appendChild(taakRij(t, vandaag)); });
      sec.appendChild(ul);
      vak.appendChild(sec);
    });
    $("taken-leeg").hidden = totaal > 0;
    laatsteTelling = data.telling || null;
    toonKern();
    var meld = [];
    var ontbreekt = (data.onvolledig || 0) + (data.onleesbaar || 0);
    if (ontbreekt) meld.push(K.vul(L.ontbreekt, { n: ontbreekt }));
    if (stand) meld.push(K.vul(L.stand, { moment: K.moment(stand) }));
    D.melding($("takenmelding"), meld.join(" "), ontbreekt > 0);
  }

  function laad() {
    var mijn = ++nr;
    var pad = API + "taken" + (wie === "alle" ? "?wie=alle" : "");
    D.api(pad).then(function (r) {
      if (mijn !== nr) return;
      if (r.ok && r.data && Array.isArray(r.data.taken)) { cache[wie] = { data: r.data, op: new Date() }; toon(r.data, null); }
      else if (cache[wie]) toon(cache[wie].data, cache[wie].op);
      else D.melding($("takenmelding"), r.status === 0 ? D.teksten.algemeen.geenVerbinding : L.mislukt, true);
    });
  }

  // ---------- acties (via de wachtrij: werkt ook offline) ----------
  function verstuur(actie, knop, gelukt) {
    knop.disabled = true;
    return W.zet(actie, { direct: true }).then(function (u) {
      knop.disabled = false;
      var fout = B.uitkomstFout(u);
      if (fout) { toast(fout, true); return; }
      if (u.uitkomst === "verstuurd") { toast(gelukt, false); laad(); return; }
      toast(u.uitkomst === "wacht-eerder" ? T.wachtrij.wachtEerder : T.wachtrij.wacht, false);
    });
  }
  function toewijzen(r, eigenaar, knop) {
    var velden = { eigenaar: { oud: null, nieuw: eigenaar } };
    return verstuur({ soort: "relatie-wijzig", methode: "PATCH", pad: "/relaties/" + encodeURIComponent(r.relatieId),
      body: { wijzigingId: W.nieuwId(), velden: velden }, recordKey: r.relatieId, relatieId: r.relatieId, velden: ["eigenaar"] },
    knop, K.vul(L.toegewezen, { naam: naamVan(r), wie: T.lijst.eigenaren[eigenaar] }));
  }
  function afvinken(t, knop) {
    var velden = {};
    velden["taken." + t.taakId + ".klaar"] = { oud: null, nieuw: { wie: ik, op: new Date().toISOString() } };
    return verstuur({ soort: "relatie-wijzig", methode: "PATCH", pad: "/relaties/" + encodeURIComponent(t.relatieId),
      body: { wijzigingId: W.nieuwId(), velden: velden }, recordKey: t.relatieId, relatieId: t.relatieId, velden: Object.keys(velden) },
    knop, L.afgevinkt);
  }

  // ---------- kerncijfers en pijplijn in het kort (uit het overzicht, zonder periode: de stand van nu) ----------
  var laatsteTelling = null;
  var overzicht = null;
  var LEAD_STATUSSEN = ["Nieuw", "Poging 1", "Poging 2", "Poging 3", "WhatsApp verstuurd", "Contact gehad", "Afspraak gepland",
    "Keukentafelgesprek gedaan", "Later opnieuw", "Niet gekwalificeerd"];
  function cijfer(waarde, label, href, nadruk) {
    var li = D.maak("li");
    var a = D.maak("a", { href: href, klasse: "cijfer" + (nadruk ? " nadruk" : "") });
    a.appendChild(D.maak("span", { klasse: "getal" }, String(waarde)));
    a.appendChild(D.maak("span", { klasse: "wat" }, label));
    li.appendChild(a);
    return li;
  }
  function toonKern() {
    var S = T.start;
    var ul = $("kerncijfers");
    ul.textContent = "";
    var t = laatsteTelling || {};
    ul.appendChild(cijfer(t.teLaat || 0, S.teLaat, "#groep-teLaat", (t.teLaat || 0) > 0));
    ul.appendChild(cijfer(t.vandaag || 0, S.vandaag, "#groep-vandaag", false));
    ul.appendChild(cijfer(t.toewijzen || 0, S.toewijzen, "#toewijzen", (t.toewijzen || 0) > 0));
    if (overzicht) {
      var ps = (overzicht.leads && overzicht.leads.perStatus) || {};
      var leads = LEAD_STATUSSEN.reduce(function (n, st) { return n + (ps[st] || 0); }, 0);
      ul.appendChild(cijfer(leads, S.leads, "/dashboard/klanten/pijplijn.html?bord=leads", false));
      ul.appendChild(cijfer((overzicht.trajecten && overzicht.trajecten.open) || 0, S.trajecten, "/dashboard/klanten/pijplijn.html?bord=klanten", false));
      var fee = overzicht.geld && overzicht.geld.feePijplijn ? overzicht.geld.feePijplijn.bedrag : 0;
      ul.appendChild(cijfer(K.euro(fee || 0), S.fee, "/dashboard/klanten/overzicht.html", false));
    }
  }
  function kortLijst(kop, waarden, volgorde, href) {
    var sleutels = volgorde.filter(function (k) { return waarden && waarden[k] > 0; });
    var vak = D.maak("div", { klasse: "kort" });
    vak.appendChild(D.maak("h3", null, kop));
    if (!sleutels.length) { vak.appendChild(D.maak("p", { klasse: "rustig" }, T.overzicht.niets)); return vak; }
    var ul = D.maak("ul", { klasse: "kortlijst" });
    sleutels.forEach(function (k) {
      var li = D.maak("li");
      var a = D.maak("a", { href: href });
      a.appendChild(D.maak("span", null, K.eigen(T.pijplijn.kolomNamen, k) || k));
      a.appendChild(D.maak("span", { klasse: "getal" }, String(waarden[k])));
      li.appendChild(a);
      ul.appendChild(li);
    });
    vak.appendChild(ul);
    return vak;
  }
  function laadOverzicht() {
    D.api(API + "overzicht").then(function (r) {
      if (!r.ok || !isObj(r.data)) return;
      overzicht = r.data;
      toonKern();
      var vak = $("pijplijnkort");
      vak.textContent = "";
      vak.appendChild(kortLijst(T.start.leadsPerStatus, r.data.leads && r.data.leads.perStatus, LEAD_STATUSSEN, "/dashboard/klanten/pijplijn.html?bord=leads"));
      vak.appendChild(kortLijst(T.start.trajectenPerFase, r.data.trajecten && r.data.trajecten.perFase, T.keuzes.fase, "/dashboard/klanten/pijplijn.html?bord=klanten"));
    });
  }
  // Alleen een melding als de technische controle iets vindt; de details staan bij Instellingen.
  function systeemCheck() {
    D.api(API + "start").then(function (r) {
      if (!r.ok || !isObj(r.data)) return;
      var g = isObj(r.data.gezondheid) ? r.data.gezondheid : {};
      var h = isObj(r.data.hartslag) ? r.data.hartslag : {};
      var reg = isObj(r.data.register) && Array.isArray(r.data.register.afwijkingen) ? r.data.register.afwijkingen.length : 0;
      // Ook een nachtelijke controle die nooit draaide telt: zo valt een kapotte geplande controle op.
      var hartslagMis = !!h.waarschuwing;
      $("systeemlet").hidden = !((g.aantal || 0) > 0 || hartslagMis || reg > 0);
    });
  }

  function kiesWie(w) {
    wie = w;
    try { window.sessionStorage.setItem(SLEUTEL, w); } catch (e) { /* geen opslag */ }
    $("wie-mijn").setAttribute("aria-pressed", w === "mijn" ? "true" : "false");
    $("wie-alle").setAttribute("aria-pressed", w === "alle" ? "true" : "false");
    laad();
  }

  document.addEventListener("DOMContentLoaded", function () {
    B.wie().then(function (w) { if (w) ik = w; });
    $("wie-mijn").addEventListener("click", function () { kiesWie("mijn"); });
    $("wie-alle").addEventListener("click", function () { kiesWie("alle"); });
    document.addEventListener("wachtrij-gewijzigd", function () { W.aantal().then(function (n) { if (n === 0) laad(); }); });
    kiesWie(wie);
    laadOverzicht();
    systeemCheck();
  });
})();

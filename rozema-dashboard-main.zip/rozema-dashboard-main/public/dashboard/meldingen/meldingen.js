// Lijst met meldingen en status wijzigen.
(function () {
  "use strict";
  var D = window.Dashboard;
  var T = D.teksten.meldingen;
  var $ = function (id) { return document.getElementById(id); };
  var VOLGORDE = ["nieuw", "opgepakt", "klaar"];

  function wanneer(iso) {
    var d = new Date(iso);
    return isNaN(d) ? "" : d.toLocaleString("nl-NL", { dateStyle: "short", timeStyle: "short" });
  }

  function regel(m) {
    var li = D.maak("li");
    li.appendChild(D.maak("p", { klasse: "soort" + (m.soort === "fout" ? " fout" : "") }, T.soort[m.soort] || m.soort));
    li.appendChild(D.maak("p", { klasse: "tekst" }, m.tekst));
    var meta = [T.van + " " + m.wie, wanneer(m.wanneer), T.scherm + " " + m.scherm];
    if (m.info && m.info.breedte) meta.push(T.breedte + " " + m.info.breedte);
    li.appendChild(D.maak("p", { klasse: "meta" }, meta.join(", ")));

    var groep = D.maak("div", { klasse: "statusknoppen", role: "group", "aria-label": T.statusKop });
    VOLGORDE.forEach(function (s) {
      var b = D.maak("button", { type: "button", klasse: "rand", "aria-pressed": String(m.status === s) }, T.status[s]);
      b.addEventListener("click", function () { wijzig(m, s, groep); });
      groep.appendChild(b);
    });
    li.appendChild(groep);
    return li;
  }

  function markeer(groep, status) {
    Array.prototype.forEach.call(groep.querySelectorAll("button"), function (b, i) {
      b.setAttribute("aria-pressed", String(VOLGORDE[i] === status));
    });
  }

  function wijzig(m, status, groep) {
    if (m.status === status) return;
    D.api("/api/dashboard/meldingen/" + encodeURIComponent(m.id), { method: "PATCH", body: { status: status } })
      .then(function (r) {
        if (r.ok) { m.status = status; markeer(groep, status); D.melding($("status"), ""); }
        else D.melding($("status"), T.opslaanMislukt, true);
      });
  }

  function laad() {
    D.melding($("status"), D.teksten.algemeen.laden);
    D.api("/api/dashboard/meldingen/").then(function (r) {
      var lijst = $("lijst");
      lijst.textContent = "";
      if (!r.ok) {
        D.melding($("status"), r.status === 0 ? D.teksten.algemeen.geenVerbinding : D.teksten.algemeen.foutAlgemeen, true);
        return;
      }
      var items = (r.data && r.data.meldingen) || [];
      D.melding($("status"), items.length ? "" : T.leeg);
      items.forEach(function (m) { lijst.appendChild(regel(m)); });
    });
  }

  document.addEventListener("DOMContentLoaded", laad);
})();

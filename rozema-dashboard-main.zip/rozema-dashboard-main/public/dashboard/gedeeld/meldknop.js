// Knop "Wens of fout melden", vast rechtsonder op elk scherm.
(function () {
  "use strict";
  var D = window.Dashboard;
  var M = window.TEKSTEN.meld;

  // Een id per melding, zodat een herhaald verzoek geen tweede melding maakt.
  function nieuwId() {
    if (window.crypto && typeof window.crypto.randomUUID === "function") return window.crypto.randomUUID();
    var b = new Uint8Array(16);
    window.crypto.getRandomValues(b);
    b[6] = (b[6] & 0x0f) | 0x40;
    b[8] = (b[8] & 0x3f) | 0x80;
    var h = Array.prototype.map.call(b, function (x) { return ("0" + x.toString(16)).slice(-2); }).join("");
    return h.slice(0, 8) + "-" + h.slice(8, 12) + "-" + h.slice(12, 16) + "-" + h.slice(16, 20) + "-" + h.slice(20);
  }

  function bouw() {
    var huidigId = null;
    var knop = D.maak("button", { type: "button", klasse: "meldknop" }, M.knop);
    var dlg = D.maak("dialog", { klasse: "meldvenster", "aria-labelledby": "meld-kop" });
    var form = D.maak("form", { method: "dialog", novalidate: "novalidate" });

    form.appendChild(D.maak("h2", { id: "meld-kop" }, M.kop));

    var set = D.maak("fieldset");
    set.appendChild(D.maak("legend", {}, M.soort));
    var keuze = D.maak("div", { klasse: "keuze" });
    [["wens", M.wens], ["fout", M.fout]].forEach(function (s, i) {
      var lab = D.maak("label");
      var inp = D.maak("input", { type: "radio", name: "soort", value: s[0] });
      if (i === 0) inp.checked = true;
      inp.addEventListener("change", function () { huidigId = null; });
      lab.appendChild(inp);
      lab.appendChild(document.createTextNode(s[1]));
      keuze.appendChild(lab);
    });
    set.appendChild(keuze);
    form.appendChild(set);

    var veld = D.maak("div", { klasse: "veld" });
    veld.appendChild(D.maak("label", { for: "meld-tekst" }, M.tekst));
    var ta = D.maak("textarea", { id: "meld-tekst", name: "tekst", maxlength: "2000", rows: "5" });
    veld.appendChild(ta);
    form.appendChild(veld);

    var status = D.maak("p", { klasse: "melding-tekst", role: "status", "aria-live": "polite" });
    form.appendChild(status);

    var acties = D.maak("div", { klasse: "acties" });
    var verstuur = D.maak("button", { type: "submit" }, M.versturen);
    var annuleer = D.maak("button", { type: "button", klasse: "rand" }, M.annuleren);
    acties.appendChild(verstuur);
    acties.appendChild(annuleer);
    form.appendChild(acties);
    dlg.appendChild(form);

    function sluit() { if (dlg.open) dlg.close(); }

    knop.addEventListener("click", function () {
      D.melding(status, "");
      verstuur.disabled = false;
      if (typeof dlg.showModal === "function") dlg.showModal(); else dlg.setAttribute("open", "");
      ta.focus();
    });
    annuleer.addEventListener("click", sluit);
    // Andere tekst is een andere melding: nieuw id. Opnieuw proberen met dezelfde tekst houdt het id.
    ta.addEventListener("input", function () { huidigId = null; });

    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var tekst = ta.value.trim();
      if (!tekst) { D.melding(status, M.leeg, true); ta.focus(); return; }
      var soort = form.querySelector('input[name="soort"]:checked').value;
      if (!huidigId) huidigId = nieuwId();
      verstuur.disabled = true;
      D.melding(status, M.bezig);
      D.api("/api/dashboard/meldingen/", {
        method: "POST",
        geenOmleiding: true,
        body: {
          id: huidigId,
          scherm: location.pathname,
          tekst: tekst,
          soort: soort,
          info: { breedte: window.innerWidth, versie: D.VERSIE },
        },
      }).then(function (r) {
        if (r.ok) {
          ta.value = "";
          huidigId = null;
          D.melding(status, M.gelukt);
          setTimeout(sluit, 1500);
        } else {
          verstuur.disabled = false;
          D.melding(status, r.status === 401 ? M.nietIngelogd : M.mislukt, true);
        }
      });
    });

    document.body.appendChild(knop);
    document.body.appendChild(dlg);
  }

  document.addEventListener("DOMContentLoaded", bouw);
})();

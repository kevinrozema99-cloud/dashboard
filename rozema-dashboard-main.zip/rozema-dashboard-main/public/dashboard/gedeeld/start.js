// Startscherm: inloggen of lijst met modules.
(function () {
  "use strict";
  var D = window.Dashboard;
  var T = D.teksten;
  var $ = function (id) { return document.getElementById(id); };

  function toonInlog() {
    $("start").hidden = true;
    $("inlog").hidden = false;
    $("naam").focus();
  }

  var huidigeNaam = null;

  function toonStart(naam) {
    huidigeNaam = naam;
    if (window.Wachtrij) window.Wachtrij.zetWie(naam);
    $("inlog").hidden = true;
    $("start").hidden = false;
    var lijst = $("modules");
    lijst.textContent = "";
    T.start.modules.forEach(function (m) {
      var li = D.maak("li");
      li.appendChild(D.maak("a", { href: m.href }, m.naam));
      lijst.appendChild(li);
    });
    // Zonder naam (geen verbinding): wel de lijst, zodat je offline bij de modules komt.
    $("wie").textContent = naam ? T.start.ingelogdAls + " " + naam : "";
    $("uitloggen").hidden = !naam;
    D.melding($("startmelding"), naam ? "" : T.algemeen.geenVerbinding, !naam);
  }

  function init() {
    D.zegWie().then(function (w) {
      if (w.naam) toonStart(w.naam);
      else if (w.status === 0) toonStart(null);
      else toonInlog();
    });

    $("inlogform").addEventListener("submit", function (e) {
      e.preventDefault();
      var knop = $("inlogknop");
      var melding = $("inlogmelding");
      knop.disabled = true;
      D.melding(melding, T.inlog.bezig);
      D.api("/api/dashboard/auth/inloggen", {
        method: "POST",
        geenOmleiding: true,
        body: { naam: $("naam").value.trim(), wachtwoord: $("wachtwoord").value },
      }).then(function (r) {
        knop.disabled = false;
        if (r.ok && r.data && r.data.naam) {
          $("wachtwoord").value = "";
          D.melding(melding, "");
          toonStart(r.data.naam);
        } else if (r.status === 0) {
          D.melding(melding, T.algemeen.geenVerbinding, true);
        } else {
          var tekst = r.data && r.data.fout ? r.data.fout : T.algemeen.foutAlgemeen;
          D.melding(melding, tekst, true);
        }
      });
    });

    function uitloggen() {
      $("uitlogwaarschuwing").hidden = true;
      // Onbeslechte conflicten van deze gebruiker vervallen. Wat van een ander is, blijft staan.
      D.wisCache({ conflicten: huidigeNaam || true }).then(function () {
        D.api("/api/dashboard/auth/uitloggen", { method: "POST", geenOmleiding: true }).then(function (r) {
          // Geen verbinding: de sessie is niet beëindigd. Dat melden en het inlogscherm niet tonen.
          if (r.status === 0) D.melding($("startmelding"), T.start.uitlogMislukt, true);
          else toonInlog();
        });
      });
    }
    var W = window.Wachtrij;
    var telNu = { eigen: 0, afgekeurd: 0, anderen: 0 };
    // Toont de waarschuwing: eigen wachtende wijzigingen met versturen/wissen; afgekeurde apart met een link.
    function toonWaarschuwing(t) {
      telNu = t;
      var regels = [];
      if (t.eigen > 0) regels.push(T.start.uitlogWaarschuwing.replace("{n}", String(t.eigen)));
      if (t.anderen > 0) regels.push(T.start.uitlogAnderen.replace("{n}", String(t.anderen)));
      D.melding($("uitlogtekst"), regels.join(" "), t.eigen > 0);
      $("uitlogafgekeurd").hidden = t.afgekeurd === 0;
      $("uitlogafgekeurdtekst").textContent = T.start.uitlogAfgekeurd.replace("{n}", String(t.afgekeurd));
      $("uitlogversturen").hidden = t.eigen === 0;
      $("uitlogwissen").hidden = t.eigen === 0;
      $("uitlogdoor").hidden = t.eigen > 0;
      $("uitlogwisbevestig").hidden = true;
      $("uitlogwaarschuwing").hidden = false;
      (t.eigen > 0 ? $("uitlogversturen") : $("uitlogdoor")).focus();
    }
    // Verstuurt de eigen deur-items vanaf het startscherm. Zonder verbinding of bij een fout blijven ze staan.
    function verstuurDeur() {
      return Promise.all([import("/dashboard/deur/opslag.js"), import("/dashboard/deur/verstuur.js")]).then(function (m) {
        return m[1].verstuurWachtrij({
          alle: function () { return m[0].wachtrij.alle(); },
          verwijder: function (id) { return m[0].wachtrij.verwijder(id); },
          zet: function (item) { return m[0].wachtrij.zet(item); },
          api: function (pad, o) { return D.api("/api/dashboard/deur/" + pad, Object.assign({ geenOmleiding: true }, o)); },
          vraagInlog: function () { return Promise.resolve(false); },
          wie: function () { return huidigeNaam; },
          geheugen: []
        });
      }).catch(function () { /* blijft staan; de telling laat het zien */ });
    }
    $("uitloggen").addEventListener("click", function () {
      // Alleen eigen wijzigingen die nog wachten houden het uitloggen tegen; afgekeurde worden apart getoond.
      D.wachtrijTelling(huidigeNaam).then(function (t) {
        if (t.eigen > 0 || t.afgekeurd > 0) toonWaarschuwing(t); else uitloggen();
      });
    });
    $("uitlogdoor").addEventListener("click", uitloggen);
    $("uitlogversturen").addEventListener("click", function () {
      if (!W) return;
      $("uitlogversturen").disabled = true;
      D.melding($("uitlogtekst"), T.start.uitlogBezig);
      W.zetWie(huidigeNaam);
      // Eerst de klantenwijzigingen, daarna de eigen items uit de deur-wachtrij (dezelfde regels als in de deur-app).
      W.verstuur().then(verstuurDeur).then(function () { return D.wachtrijTelling(huidigeNaam); }, function () { return { eigen: 1, afgekeurd: 0, anderen: 0 }; }).then(function (t) {
        $("uitlogversturen").disabled = false;
        if (t.eigen === 0 && t.afgekeurd === 0) uitloggen();
        else {
          toonWaarschuwing(t);
          if (t.eigen > 0) D.melding($("uitlogtekst"), T.start.uitlogNietAlles + " " + T.start.uitlogWaarschuwing.replace("{n}", String(t.eigen)), true);
        }
      });
    });
    $("uitlogwissen").addEventListener("click", function () {
      D.melding($("uitlogwistekst"), T.start.uitlogWisBevestig.replace("{n}", String(telNu.eigen)), true);
      $("uitlogwisbevestig").hidden = false;
      $("uitlogwisja").focus();
    });
    $("uitlogwisja").addEventListener("click", function () {
      var klaar = W ? W.wisEigen(huidigeNaam) : Promise.resolve();
      klaar.then(function () { return D.wisDeurEigen(huidigeNaam); }).then(uitloggen);
    });
    $("uitlogannuleer").addEventListener("click", function () { $("uitlogwaarschuwing").hidden = true; });
  }

  document.addEventListener("DOMContentLoaded", init);
})();

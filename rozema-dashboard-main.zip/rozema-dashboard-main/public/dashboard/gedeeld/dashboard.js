// Gedeelde hulpmiddelen: API-helper, DOM-helper, teksten invullen, service worker.
(function () {
  "use strict";
  var T = window.TEKSTEN;
  var D = (window.Dashboard = { VERSIE: "1", teksten: T });

  D.maak = function (tag, opties, tekst) {
    var el = document.createElement(tag);
    var o = opties || {};
    Object.keys(o).forEach(function (k) {
      if (k === "klasse") el.className = o[k];
      else el.setAttribute(k, o[k]);
    });
    if (tekst !== undefined && tekst !== null) el.textContent = tekst;
    return el;
  };

  function timeoutSignaal(ms) {
    if (typeof AbortSignal !== "undefined" && typeof AbortSignal.timeout === "function") {
      return AbortSignal.timeout(ms);
    }
    var c = new AbortController();
    setTimeout(function () { c.abort(); }, ms);
    return c.signal;
  }

  // api("/api/dashboard/...", {method, body, geenOmleiding})
  // Geeft {ok, status, data}. Bij netwerkfout {ok:false, status:0, data:null}.
  // Bij 401 gaat de pagina naar het inlogscherm, tenzij geenOmleiding.
  D.api = function (pad, opties) {
    var o = opties || {};
    var init = {
      method: o.method || "GET",
      credentials: "same-origin",
      headers: {},
      signal: timeoutSignaal(15000),
    };
    if (o.body !== undefined) {
      init.headers["content-type"] = "application/json";
      init.body = JSON.stringify(o.body);
    }
    return fetch(pad, init).then(
      function (r) {
        return r.json().then(
          function (d) { return d; },
          function () { return null; }
        ).then(function (data) {
          if (r.status === 401 && !o.geenOmleiding) D.naarInlog();
          return { ok: r.ok, status: r.status, data: data };
        });
      },
      function () { return { ok: false, status: 0, data: null }; }
    );
  };

  // Klanten-database op het toestel (zie klanten/wachtrij.js, daar staat het schema ook):
  //   kv        cache van klantgegevens: wordt gewist bij uitloggen en een 401
  //   wachtrij  niet-verstuurde wijzigingen en onbeslechte conflicten: wordt NOOIT gewist
  var KLANTEN_DB = "rozema-klanten";
  function openKlantenDb(klaar) {
    try {
      var rq = window.indexedDB.open(KLANTEN_DB, 1);
      rq.onupgradeneeded = function () {
        var db = rq.result;
        if (!db.objectStoreNames.contains("kv")) db.createObjectStore("kv");
        if (!db.objectStoreNames.contains("wachtrij")) db.createObjectStore("wachtrij", { keyPath: "id" });
      };
      rq.onsuccess = function () { klaar(rq.result); };
      rq.onerror = function () { klaar(null); };
      rq.onblocked = function () { klaar(null); };
    } catch (e) { klaar(null); }
  }

  // Wachtrij van de deur-module (database rozema-deur, schema gelijk aan deur/opslag.js). Items hebben `wie` en eventueel `afgekeurd`.
  var DEUR_DB = "rozema-deur";
  function openDeurDb(klaar) {
    try {
      var rq = window.indexedDB.open(DEUR_DB, 1);
      rq.onupgradeneeded = function () {
        var db = rq.result;
        if (!db.objectStoreNames.contains("kv")) db.createObjectStore("kv");
        if (!db.objectStoreNames.contains("wachtrij")) db.createObjectStore("wachtrij", { keyPath: "id" });
      };
      rq.onsuccess = function () { klaar(rq.result); };
      rq.onerror = function () { klaar(null); };
      rq.onblocked = function () { klaar(null); };
    } catch (e) { klaar(null); }
  }

  // Wist de eigen items (wie === naam) uit de deur-wachtrij. Items van anderen blijven staan.
  D.wisDeurEigen = function (naam) {
    return new Promise(function (klaar) {
      if (!naam) { klaar(); return; }
      openDeurDb(function (db) {
        if (!db) { klaar(); return; }
        try {
          var tx = db.transaction("wachtrij", "readwrite");
          var cur = tx.objectStore("wachtrij").openCursor();
          cur.onsuccess = function () {
            var c = cur.result;
            if (!c) return;
            if (c.value && c.value.wie === naam) c.delete();
            c.continue();
          };
          tx.oncomplete = function () { db.close(); klaar(); };
          tx.onerror = tx.onabort = function () { db.close(); klaar(); };
        } catch (e) { db.close(); klaar(); }
      });
    });
  };

  // Wist de cache van het dashboard: sessionStorage-sleutels die met "dashboard." beginnen en de kv-cache in
  // IndexedDB. De wachtrij met niet-verstuurde wijzigingen blijft staan. Aanroepen bij uitloggen en bij een 401.
  // opties.conflicten: wis ook de onbeslechte conflicten (bij uitloggen): true = alle, een naam = alleen van die gebruiker.
  D.wisCache = function (opties) {
    try {
      var weg = [];
      for (var i = 0; i < window.sessionStorage.length; i++) {
        var k = window.sessionStorage.key(i);
        if (k && k.indexOf("dashboard.") === 0) weg.push(k);
      }
      weg.forEach(function (k) { window.sessionStorage.removeItem(k); });
    } catch (e) { /* geen opslag beschikbaar */ }
    return new Promise(function (klaar) {
      openKlantenDb(function (db) {
        if (!db) { klaar(); return; }
        try {
          var tx = db.transaction(["kv", "wachtrij"], "readwrite");
          tx.objectStore("kv").clear();
          if (opties && opties.conflicten) {
            // true: alle conflicten; een naam: alleen de conflicten van die gebruiker
            var van = typeof opties.conflicten === "string" ? opties.conflicten : null;
            var cur = tx.objectStore("wachtrij").openCursor();
            cur.onsuccess = function () {
              var c = cur.result;
              if (!c) return;
              if (c.value && c.value.soort === "conflict" && (van === null || c.value.van === van)) c.delete();
              c.continue();
            };
          }
          tx.oncomplete = function () { db.close(); klaar(); };
          tx.onerror = tx.onabort = function () { db.close(); klaar(); };
        } catch (e) { db.close(); klaar(); }
      });
    });
  };

  // Telling van de wachtrij voor deze gebruiker: eigen wijzigingen die nog wachten, eigen afgekeurde, en die van anderen
  // (of zonder bekende eigenaar). Conflicten tellen niet mee.
  // Telt de klanten-wachtrij en de deur-wachtrij samen.
  D.wachtrijTelling = function (naam) {
    var leeg = { eigen: 0, afgekeurd: 0, anderen: 0 };
    function tel(open) {
      return new Promise(function (klaar) {
        open(function (db) {
          if (!db) { klaar(); return; }
          try {
            var rq = db.transaction("wachtrij", "readonly").objectStore("wachtrij").getAll();
            rq.onsuccess = function () {
              (rq.result || []).forEach(function (x) {
                if (x.soort === "conflict") return;
                if (!x.wie || x.wie !== naam) leeg.anderen++;
                else if (x.afgekeurd) leeg.afgekeurd++;
                else leeg.eigen++;
              });
              db.close(); klaar();
            };
            rq.onerror = function () { db.close(); klaar(); };
          } catch (e) { db.close(); klaar(); }
        });
      });
    }
    return tel(openKlantenDb).then(function () { return tel(openDeurDb); }).then(function () { return leeg; });
  };

  D.naarInlog = function () {
    // Eerst de cache wissen, dan pas navigeren (anders breekt de browser het wissen af).
    D.wisCache().then(function () {
      if (location.pathname !== "/dashboard/" && location.pathname !== "/dashboard/index.html") {
        location.href = "/dashboard/";
      }
    });
  };

  // Geeft {naam, status}. naam is null als er geen geldige sessie is;
  // status 0 betekent: geen verbinding (dan niet uitloggen of doorsturen).
  D.zegWie = function () {
    return D.api("/api/dashboard/auth/ik", { geenOmleiding: true }).then(function (r) {
      return { naam: r.ok && r.data ? r.data.naam : null, status: r.status };
    });
  };

  // Elementen met data-tekst="a.b.c" krijgen die tekst.
  D.vulTeksten = function (wortel) {
    (wortel || document).querySelectorAll("[data-tekst]").forEach(function (el) {
      var delen = el.getAttribute("data-tekst").split(".");
      var w = T;
      for (var i = 0; i < delen.length && w; i++) w = w[delen[i]];
      if (typeof w === "string") el.textContent = w;
    });
    var titel = document.body.getAttribute("data-titel");
    if (titel && T.titels[titel]) {
      document.title = T.titels[titel] === T.merk ? T.merk : T.titels[titel] + " - " + T.merk;
    }
  };

  D.melding = function (el, tekst, isFout) {
    el.textContent = tekst || "";
    el.classList.toggle("fout", !!(tekst && isFout));
  };

  function serviceWorker() {
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("/dashboard/sw.js", { scope: "/dashboard/" }).catch(function () {});
    }
  }

  document.addEventListener("DOMContentLoaded", function () {
    D.vulTeksten();
    serviceWorker();
    if (document.body.hasAttribute("data-beveiligd")) {
      // Alleen bij een echte 401 naar inloggen; offline blijft de pagina staan.
      // Met data-beveiligd="zacht" regelt de pagina de inlog zelf (de wachtrij blijft dan bewaard).
      var zacht = document.body.getAttribute("data-beveiligd") === "zacht";
      D.zegWie().then(function (w) {
        if (w.status !== 401) return;
        if (zacht) window.dispatchEvent(new CustomEvent("dashboard:sessie-verlopen"));
        else D.naarInlog();
      });
    }
  });
})();

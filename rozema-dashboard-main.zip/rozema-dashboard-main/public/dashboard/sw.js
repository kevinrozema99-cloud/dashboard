// Service worker voor /dashboard/. Cachet alleen een vaste lijst eigen bestanden.
var CACHE = "dashboard-v8";
var BESTANDEN = [
  "/dashboard/",
  "/dashboard/meldingen/",
  "/dashboard/deur/",
  "/dashboard/klanten/",
  "/dashboard/klanten/lijst.html",
  "/dashboard/klanten/leads.html",
  "/dashboard/klanten/agenda.html",
  "/dashboard/klanten/agenda.js",
  "/dashboard/klanten/nieuw.html",
  "/dashboard/klanten/relatie.html",
  "/dashboard/klanten/klanten.css",
  "/dashboard/klanten/klanten.js",
  "/dashboard/klanten/taken.js",
  "/dashboard/klanten/lijst.js",
  "/dashboard/klanten/pijplijn.html",
  "/dashboard/klanten/pijplijn.js",
  "/dashboard/klanten/overzicht.html",
  "/dashboard/klanten/overzicht.js",
  "/dashboard/klanten/traject.html",
  "/dashboard/klanten/niet-opgeslagen.html",
  "/dashboard/klanten/regels.html",
  "/dashboard/klanten/wachtrij.js",
  "/dashboard/klanten/bewerk.js",
  "/dashboard/klanten/relatie.js",
  "/dashboard/klanten/traject.js",
  "/dashboard/klanten/nieuw.js",
  "/dashboard/klanten/deurteksten.js",
  "/dashboard/klanten/deurlink.js",
  "/dashboard/klanten/niet-opgeslagen.js",
  "/dashboard/klanten/regels.js",
  "/dashboard/klanten/instellingen.js",
  "/dashboard/klanten/beheer.html",
  "/dashboard/klanten/beheer.css",
  "/dashboard/klanten/beheer.js",
  "/dashboard/klanten/beheer-teksten.js",
  "/dashboard/klanten/beheerlink.js",
  "/dashboard/manifest.webmanifest",
  "/dashboard/gedeeld/dashboard.css",
  "/dashboard/gedeeld/teksten.js",
  "/dashboard/gedeeld/dashboard.js",
  "/dashboard/gedeeld/meldknop.js",
  "/dashboard/gedeeld/start.js",
  "/dashboard/meldingen/meldingen.js",
  "/dashboard/deur/deur.css",
  "/dashboard/deur/teksten.js",
  "/dashboard/deur/app.js",
  "/dashboard/deur/logica.js",
  "/dashboard/deur/opslag.js",
  "/dashboard/deur/verstuur.js",
  "/dashboard/deur/bronnen.js",
  "/dashboard/deur/kaart.js",
  "/dashboard/gedeeld/leaflet/leaflet.js",
  "/dashboard/gedeeld/leaflet/leaflet.css",
  "/dashboard/gedeeld/fonts/atkinson-hyperlegible-next-400-latin.woff2",
  "/dashboard/gedeeld/fonts/atkinson-hyperlegible-next-400-latin-ext.woff2",
  "/dashboard/gedeeld/fonts/atkinson-hyperlegible-next-600-latin.woff2",
  "/dashboard/gedeeld/fonts/atkinson-hyperlegible-next-600-latin-ext.woff2",
  "/dashboard/gedeeld/fonts/atkinson-hyperlegible-next-700-latin.woff2",
  "/dashboard/gedeeld/fonts/atkinson-hyperlegible-next-700-latin-ext.woff2",
  "/favicon-180.png"
];

function inLijst(url) {
  return url.origin === self.location.origin && BESTANDEN.indexOf(url.pathname) !== -1;
}

self.addEventListener("install", function (e) {
  e.waitUntil(
    caches.open(CACHE).then(function (cache) {
      // Per bestand toevoegen: een mislukt bestand laat de rest niet vallen.
      return Promise.all(BESTANDEN.map(function (pad) {
        return fetch(pad, { cache: "reload", credentials: "same-origin" }).then(function (r) {
          if (r.ok) return cache.put(pad, r);
        }).catch(function () {});
      }));
    }).then(function () { return self.skipWaiting(); })
  );
});

self.addEventListener("activate", function (e) {
  e.waitUntil(
    caches.keys().then(function (namen) {
      return Promise.all(namen.filter(function (n) { return n !== CACHE; })
        .map(function (n) { return caches.delete(n); }));
    }).then(function () { return self.clients.claim(); })
  );
});

// Netwerk eerst (altijd de nieuwste), cache als het netwerk ontbreekt.
self.addEventListener("fetch", function (e) {
  var req = e.request;
  if (req.method !== "GET") return;
  var url = new URL(req.url);
  if (url.pathname.indexOf("/api/") === 0) return;
  if (!inLijst(url)) return;
  e.respondWith(
    fetch(req).then(function (r) {
      if (r.ok) {
        var kopie = r.clone();
        caches.open(CACHE).then(function (c) { return c.put(url.pathname, kopie); }).catch(function () {});
      }
      return r;
    }).catch(function () {
      return caches.match(url.pathname).then(function (c) { return c || Response.error(); });
    })
  );
});

# Ontwerp — rozema-adviseurs.nl

**Versie:** 0.1 · 16 oktober 2026
**Eigenaar:** Kevin
**Volgt uit:** B3 v0.1 (huisstijl), B1 v0.5

Dit document legt vast hoe de huisstijl uit B3 op de website wordt toegepast: kleurverdeling, maten, opmaak en wat niet mag. Logo, palet en lettertypes zelf staan in B3; hier staan alleen de keuzes voor de site. Structuur en pagina-opbouw staan in `docs/bouwdocument.md`.

---

## Het idee

Twee broers die bij u aan tafel zitten. De site moet voelen als dat gesprek: rustig, direct, met echte gezichten. Niet als een product.

**De gedurfde keuze zit op één plek: grote koppen in Anton, links uitgelijnd, naast grote eigen foto's.** Al het andere is stil en gedisciplineerd. Geen decoratie die niets zegt.

---

## Kleur op de site

| Kleur (B3) | Rol op de site | Aandeel |
|---|---|---|
| Donker | Header, hero, footer, één of twee accentsecties | ± 45% |
| Salie vlak | Basis voor leessecties | ± 40% |
| Zand | Formuliervelden en de dossiercheck-flow | ± 10% |
| Salie / salie donker | Primaire knoppen en hover | detail |
| Klei | Dunne lijnen en kleine details | detail |

**Salie vlak is de lichte basis, niet zand.** Een crèmekleurige achtergrond met een kleiaccent is op dit moment een van de herkenbaarste kenmerken van een gegenereerde site. Salie vlak heeft een groene zweem en is specifiek voor ons palet.

Secties onderscheiden zich door een wisseling van achtergrond en door ruimte, niet door kaders of kaartjes.

Contrast: alleen combinaties die in B3 onder Contrast als "alle tekst" staan. Gebruik nooit zuiver wit of zuiver zwart.

---

## Typografie op de site

Lettertypes lokaal hosten in `/public/fonts` als woff2, met `font-display: swap`. Niet via Google Fonts. Alleen de gewichten die we gebruiken: Anton Regular, Atkinson Hyperlegible Regular en Bold.

| Rol | Lettertype | Mobiel | Desktop | Regelafstand |
|---|---|---|---|---|
| H1 | Anton, hoofdletters | 44 px | 76 px | 1,02 |
| H2 | Anton, hoofdletters | 32 px | 48 px | 1,05 |
| H3 | Atkinson Bold | 21 px | 24 px | 1,3 |
| Lopende tekst | Atkinson Regular | 18 px | 19 px | 1,6 |
| Klein (bijschrift, footer) | Atkinson Regular | 16 px | 16 px | 1,5 |
| Knoppen | Atkinson Bold | 18 px | 18 px | — |

- Nooit kleiner dan 16 px, ook niet in de footer.
- Regellengte lopende tekst maximaal 65 tekens.
- Alle tekst links uitgelijnd. Niets gecentreerd behalve losse knoppen op mobiel.
- Koppen kort: liefst onder de acht woorden. Anton in hoofdletters wordt zwaar bij lange zinnen.
- Geen woord in een kop een andere kleur of stijl geven.

---

## Opmaak

- **Eén kolom op mobiel.** Op desktop een container van maximaal 1120 px; tekst in een kolom van maximaal 65 tekens, foto's mogen breder.
- **Ruimte tussen secties:** mobiel 64 px, desktop 120 px. Ruimte is de scheiding, geen lijnen of kaders.
- **Hoeken:** 4 px op knoppen en invoervelden, verder niets afgerond.
- **Geen schaduwen** en geen gradiënten.
- **Lijsten** zonder kaartjes: een dunne kleilijn links of een witregel ertussen is genoeg.
- **Nummering** alleen waar de inhoud echt een volgorde is: de stappen van het traject. Nergens anders.

---

## Componenten

**Primaire knop.** Salie met tekst in zand, hover salie donker. Minimaal 56 px hoog, op mobiel over de volle breedte. Tekst zegt wat er gebeurt, zonder pijltje.

**Bel- en WhatsApp-knop.** Secundair: omlijnd (2 px), zelfde hoogte als de primaire knop. Op donker in steen, op licht in donker.

**Mobiele actiebalk.** Vast onderin, donker, met de primaire knop en de belknop naast elkaar. Niet op de dossiercheck zelf.

**Header.** Donker, met het lichte logo. Op mobiel alleen logo en primaire knop; de link naar Werkwijze en tarief zit in een eenvoudig menu.

**Vragen (FAQ).** Uitklapbaar, de hele regel is klikbaar, scheiding met een dunne lijn. Een plus- of minteken mag als teken voor open en dicht.

**Dossiercheck-flow.** Eén vraag per scherm op een zandkleurig vlak. Antwoorden als grote knoppen onder elkaar, links uitgelijnd, minimaal 64 px hoog. Voortgang als eenvoudige tekst ("vraag 2 van 4"), geen balk met animatie.

**Formuliervelden.** Label boven het veld, 18 px. Veld op zand met een rand van 2 px in lijn. Foutmelding direct onder het veld in donker, met de rand van het veld in klei donker.

**Focus.** Elk klikbaar element krijgt bij toetsenbordbediening een zichtbare rand van 3 px in donker (op licht) of steen (op donker), met 2 px afstand.

---

## Beeld op de site

Foto-placeholders tot de fotoshoot: een vlak in steen met daarin de sleutel en de verhouding, bijvoorbeeld `[[FOTO: home.hero]] 4:5`. Geen stockbeelden en geen gegenereerde beelden, ook niet tijdelijk.

| Plek | Verhouding mobiel | Verhouding desktop |
|---|---|---|
| Hero (home, aan de deur) | 4:5 | 3:2, naast de kop |
| Wie wij zijn | 4:5 | 4:5 |
| Overige secties | 3:2 | 3:2 |

Foto's lopen op mobiel tot de rand van het scherm. Geen kaders, geen afgeronde hoeken, geen filters.

---

## Beweging

Geen animaties bij het scrollen en geen inschuivende secties. Beweging alleen als antwoord op een handeling: een vraag die openklapt, de volgende vraag in de flow. Altijd uit bij `prefers-reduced-motion`.

---

## Wat niet mag

Dit zijn de herkenbaarste kenmerken van een standaard gegenereerde site. Geen van alle gebruiken:

- rasters van gelijke kaartjes met een icoon, kop en drie regels tekst;
- schaduwen, gradiënten, glaseffecten;
- kleine labels in hoofdletters boven koppen;
- nummering (01, 02, 03) bij iets dat geen volgorde is;
- teksten met middenpuntjes ertussen ("A · B · C");
- een pijltje in knoppen of links;
- één woord in een kop anders gekleurd;
- secties die bij het scrollen invagen of inschuiven;
- iconen, tot B3 daarover besloten heeft;
- emoji;
- stock- of AI-beelden;
- gecentreerde tekstblokken.

---

## Toegankelijkheid

Minimaal WCAG 2.2 niveau AA. Tikvlakken minimaal 48 × 48 px. De site moet werken bij 200% zoom zonder horizontaal scrollen. Bedienbaar met alleen een toetsenbord.

---

## Wijzigingen

| Datum | Versie | Wat |
|---|---|---|
| 16-10-2026 | 0.1 | Opgezet: kleurverdeling, typografische schaal, opmaak, componenten, beeld, beweging, verboden patronen en toegankelijkheid |

# Bouwdocument — rozema-adviseurs.nl

**Versie:** 0.1 · 16 oktober 2026
**Eigenaar:** Kevin
**Volgt uit:** B1 v0.5, B2 v2.0

Dit document legt de bouwbesluiten vast: welke pagina's, in welke volgorde, met welke logica. Het bevat geen klantteksten. Waarom iets zo is, staat in de kennisbank; dit document volgt daaruit.

---

## Bouwbesluiten die overal gelden

- Eén primaire actie op de hele site: **Gratis dossiercheck**. Er is geen tweede route (de Dossierwijzer vervalt en gaat op in de dossiercheck).
- Secundaire contactroute op elke pagina: telefoon en WhatsApp (gezamenlijk nummer, WhatsApp Business).
- Het percentage (15%) staat **alleen** op Werkwijze en tarief. "No cure no pay" mag overal.
- Geen element over "u kunt het ook zelf doen". Niet in tekst, niet in een banner, niet in de FAQ.
- "Wij zijn niet het IMG": één vaste regel in de footer, plus één vraag in de FAQ op Werkwijze en tarief. Geen balk bovenaan.
- Geen referenties of klantcases tot daar een besluit over is.
- Geen uploadveld, geen BSN, geen zaaknummer.
- Mobiel eerst.

## Sitestructuur

| Pagina | URL | Doel |
|---|---|---|
| Home | `/` | Vertrouwen en kernboodschap, door naar de dossiercheck |
| Werkwijze en tarief | `/werkwijze-en-tarief` | Dienstpagina: hoe het gaat, wat de klant doet, wat het kost |
| Gratis dossiercheck | `/gratis-dossiercheck` | Kwalificatie-flow en aanvraag |
| Bedankt | `/gratis-dossiercheck/bedankt` | Bevestiging; eigen URL voor conversiemeting |
| Aan de deur | `/aan-de-deur` | Landing voor NFC-kaart en QR op het visitekaartje |
| Privacyverklaring | `/privacyverklaring` | Verplicht bij uitvragen gegevens |

Redirects: `/dossierwijzer` → `/gratis-dossiercheck` (301).

Later, zonder dat de structuur verandert: landingspagina's voor advertenties, SEO-pagina's.

## Globale elementen

**Header:** logo (naar home), link Werkwijze en tarief, knop Gratis dossiercheck.
**Mobiel:** vaste balk onderin met knop Gratis dossiercheck en een bel/WhatsApp-knop. Niet tonen op de dossiercheck zelf.
**Footer:** contact (telefoon, WhatsApp, e-mail), adres, KvK, regel "niet het IMG", link privacyverklaring.

---

## Home `/`

| # | Sectie | Inhoud (structuur, geen tekst) |
|---|---|---|
| 1 | Hero | Kernzin, kop eronder, knop dossiercheck, bel/WhatsApp. Foto van Kevin en Ruben samen |
| 2 | Waarom het ertoe doet | Drie blokken, elk één IMG-regel (opname op aanwijs; opnemer kijkt vanaf de grond / achter behang alleen op aanwijzing; eerder behandeld geldt per schade, niet per adres) |
| 3 | Wat u zelf doet | Eén blok: na het eerste gesprek niets meer; niet thuis hoeven zijn bij de opname |
| 4 | Wie wij zijn | Kevin en Ruben, broers, familiebedrijf, steeds dezelfde gezichten. Twee portretten of één duofoto |
| 5 | Hoe het gaat | Drie stappen (dossiercheck, opname, uitbetaling), "no cure no pay", link naar Werkwijze en tarief. Geen percentage |
| 6 | Slot | Knop dossiercheck |

## Werkwijze en tarief `/werkwijze-en-tarief`

| # | Sectie | Inhoud |
|---|---|---|
| 1 | Intro | Korte kop en inleiding |
| 2 | De stappen | Van dossiercheck tot afronding (volgt B2, onder Het klanttraject) |
| 3 | Wat u zelf doet | Na het eerste gesprek niets |
| 4 | Tarief | No cure no pay, 15% incl. btw over de totale uitkering inclusief overlastvergoeding, factuur na uitbetaling, 14 dagen |
| 5 | Loopt er al een zaak? | Opname nog niet geweest / wel geweest |
| 6 | Vragen | Vijf à zes uitklapbare vragen, waaronder "Zijn jullie het IMG?" |
| 7 | Slot | Knop dossiercheck |

Doorlooptijd: geen eigen schatting op de site, alleen IMG-cijfers.

## Aan de deur `/aan-de-deur`

Bron via parameter: `?bron=nfc` (kaart aan de deur gescand) of `?bron=kaart` (QR op het achtergelaten visitekaartje). De bron gaat mee in het formulier.

| # | Sectie | Inhoud |
|---|---|---|
| 1 | Begroeting | "U spreekt nu met …"-opening, duofoto Kevin en Ruben |
| 2 | Wat wij doen | Drie zinnen |
| 3 | Actie | Knop dossiercheck, bel/WhatsApp |

Niet opnemen in de navigatie.

## Privacyverklaring `/privacyverklaring`

Placeholder. Inhoud volgt apart (let op: Netlify slaat formulierinzendingen op).

---

## Gratis dossiercheck `/gratis-dossiercheck`

### Opbouw

1. Korte intro (wat de check is, dat de vragen ongeveer een minuut kosten).
2. Vragen, één per scherm, met grote klikknoppen. Elke vraag heeft "Weet ik niet". Terugknop.
3. Uitkomstscherm per profiel: korte feitelijke tekst.
4. Contactblok (niet bij profiel H).
5. Na verzenden: `/gratis-dossiercheck/bedankt`.

Zonder JavaScript moet minimaal het contactblok werken.

### Vragen en routing

Formuleringen hieronder zijn **werktitels**; de definitieve teksten volgen als placeholders.

| Vraag | Antwoord | Gaat naar |
|---|---|---|
| **V0** Voor wie is dit? | Ik ben de eigenaar | V1 |
| | Ik help een eigenaar (familie, mantelzorger) | V1, vervolgvragen in de vorm "de eigenaar" |
| | Ik huur de woning | Uitkomst **H** |
| **V1** Is er ooit schade gemeld? (IMG, of eerder NAM, CVW, TCMG) | Ja | V2 |
| | Nee | Uitkomst **A** |
| | Weet ik niet | Uitkomst **?** |
| **V2** Loopt er nu een aanvraag? | Ja | V3 |
| | Nee | V5 |
| | Weet ik niet | Uitkomst **?** |
| **V3** Is de schade-opname al geweest? | Nee | Uitkomst **C** |
| | Ja | V4 |
| | Weet ik niet | Uitkomst **?** |
| **V4** Waar staat de aanvraag nu? | Wacht op het adviesrapport | Uitkomst **D1** |
| | Adviesrapport ligt er, nog geen besluit | Uitkomst **D2** |
| | Besluit genomen | Uitkomst **E** |
| | Weet ik niet | Uitkomst **?** |
| **V5** Hoe is het de laatste keer afgehandeld? | Met een rapport van een deskundige | Uitkomst **B** |
| | Met een vast bedrag | Uitkomst **F** |
| | Met herstel door een aannemer | Uitkomst **F-H** |
| | Weet ik niet | Uitkomst **?** |

### Uitkomsten

| Code | Situatie | Uitkomstscherm | Contactblok |
|---|---|---|---|
| A | Nooit gemeld | Tekst | Ja |
| B | Historie, geen lopende zaak | Tekst | Ja |
| C | Loopt, opname nog niet geweest | Tekst | Ja |
| D1 | Opname geweest, wacht op rapport | Tekst | Ja |
| D2 | Rapport ligt er, nog geen besluit | Tekst (met zienswijzetermijn) | Ja |
| E | Besluit genomen | Tekst (met fatale bezwaartermijn) | Ja |
| F | Vast bedrag aanvaard | Tekst + link naar de trillingstool van het IMG | Ja |
| F-H | Herstel met aannemer | Als F | Ja |
| ? | Weet het niet | Tekst ("zoeken we samen uit") | Ja |
| H | Huurder | Tekst | Nee |

### Contactblok

| Veld | Verplicht |
|---|---|
| Adres van de woning (straat + huisnummer, postcode, plaats) | Ja |
| Naam | Ja |
| Telefoonnummer | Ja |
| E-mailadres | Nee |
| Liever contact via: bellen / WhatsApp | Ja |

Verborgen velden: uitkomstcode, alle gegeven antwoorden, voor wie (V0), bron (`nfc`, `kaart`, of leeg).
Vaste regel onder het formulier: geen documenten meesturen. Link naar privacyverklaring.
Spambescherming: honeypot.

### Verwerking

Netlify Forms, melding per mail naar het bedrijfsadres. De mail toont bovenaan de uitkomstcode, daaronder antwoorden en contactgegevens.

---

## Wijzigingen

| Datum | Versie | Wat |
|---|---|---|
| 16-10-2026 | 0.1 | Opgezet: sitestructuur, globale elementen, opbouw per pagina, dossiercheck-flow met routing en uitkomsten |

# Website Rozema Adviseurs

One-page site, statisch gebouwd met Astro en Tailwind. Geen backend, geen CMS, geen database.

## In Netlify openen

**Snelste manier, zonder iets te installeren.** Ga naar app.netlify.com, kies *Add new site →
Deploy manually*, en sleep de map `dist` uit deze projectmap het venster in. De site staat er
dan meteen op, op een tijdelijk netlify.app-adres. `dist` is de gebouwde versie en zit hierbij.

**Zodra je zelf wilt gaan bewerken.** Zet de projectmap in een Git-repository en koppel die aan
Netlify. `netlify.toml` staat er al in, dus Netlify weet wat het moet doen: `npm run build`,
publiceren vanuit `dist`, Node 22.

## Zelf aanpassen

Hiervoor is Node nodig; dat staat nog niet op deze Mac. Installeer de LTS-versie via nodejs.org.
Daarna:

    npm install
    npm run dev      # lokale voorvertoning op localhost:4321
    npm run build    # bouwt opnieuw naar dist/

De teksten staan in `src/pages/index.astro`, de kleuren en typografie in `src/styles/global.css`.

## De Dossierwijzer

`/dossierwijzer` is het instapaanbod van de site: drie tot vijf vragen, daarna een uitslag
per situatie. De bezoeker laat geen gegevens achter — de antwoorden blijven in de browser en
worden nergens heen gestuurd. Pas ná de uitslag wordt de gratis dossiercheck aangeboden.

De inhoud staat los van de opmaak, in `src/data/dossierwijzer.ts`. Daar pas je vragen,
antwoorden en uitslagteksten aan zonder aan de pagina zelf te komen. Bij elk blok staat in
een commentaar uit welke paragraaf van K1 of B1 het feit komt.

De route hangt af van de antwoorden: huurders krijgen meteen een uitslag, bij een lopende
melding volgt een vraag over de voortgang, en bij een besluit wordt de datum gevraagd om de
resterende bezwaartermijn uit te rekenen. Die berekening is indicatief; dat staat er ook bij.

**Twee punten die eerst nagevraagd moeten worden bij het IMG:**

1. Hoeveel tijd iemand precies heeft om op het adviesrapport te reageren. K1 §2.1 markeert dat
   als `[ONBEVESTIGD]`, dus de Dossierwijzer zegt nu dat wij het niet met zekerheid weten.
2. Wat een huurder zelf kan aanvragen. K1 beschrijft alleen de positie van de eigenaar, dus
   de tekst verwijst huurders door naar de verhuurder en naar het IMG, zonder verdere claims.

**Wat er bewust níét in staat:** de vaste vergoeding. Daardoor krijgt iemand die nog nooit
schade heeft gemeld alleen de maatwerkroute te zien. Wil je dat later neutraal noemen, dan is
dat één zin bij de uitkomst met `id: 'A'` in `src/data/dossierwijzer.ts`.

## Het formulier

Het keukentafelformulier loopt via **Netlify Forms**. Netlify herkent het bij het bouwen aan
`data-netlify="true"` in de HTML en vangt de POST zelf op. Geen backend, geen JavaScript.

Eenmalig instellen na de eerste deploy: **Netlify > Forms > Form notifications > Add
notification > Email notification**, met `schade@rozema-adviseurs.nl` als ontvanger. Zonder
die instelling komen inzendingen alleen in het dashboard te staan en krijg je geen bericht.

Na verzenden komt de bezoeker op `/bedankt/`. Die pagina staat op `noindex` en niet in de
sitemap. Een verborgen veld `bot-field` vangt spambots af.

Dit is een tussenoplossing tot het leadsysteem er is. Wil je later naar een eigen endpoint,
dan vervang je in `src/pages/index.astro` de attributen `data-netlify` en `netlify-honeypot`
door een `action` naar die URL. De velden zelf kunnen blijven zoals ze zijn.

## Nog open

| Wat | Waar |
|---|---|
| Tekst "Waarom wij dit doen" | `src/pages/index.astro` — concept, in eigen woorden te herschrijven |
| Reactietermijn op het adviesrapport | staat in K1 §2.1 als ONBEVESTIGD; navragen bij het IMG |
| Wat een huurder zelf kan aanvragen | idem, K1 beschrijft alleen de positie van de eigenaar |
| B1 bijwerken naar v1.2 | zie de losse notitie; de site volgt K1 v2.1 en W1 v1.2 |
| Contrast van het woordmerk | "ADVISEURS" haalt op donker 2,08 — een kwestie in het logobestand zelf |

Ingevuld en afgerond: domeinnaam, logo's en favicons, deelafbeelding, portretten, KvK 42135008,
telefoon 06 48 31 53 79, schade@rozema-adviseurs.nl, Raadhuisplein 190 te Drachten,
privacyverklaring (vastgesteld 11 september 2026) en het formulier-endpoint.

## Uitgangspunten in de bouw

- Kleuren en typografie komen uit B2 §7 en §8. Elke kleur is een named token in
  `src/styles/global.css`; er staan geen losse hex-waarden in de code.
- Contrast is per combinatie doorgerekend tegen WCAG AA. De uitkomsten staan als commentaar in
  `src/styles/global.css`. Eén bevinding: klei donker (`#8F6A4D`) haalt op zand 4,29 en dus geen
  AA voor kleine tekst — die kleur wordt daarom alleen groot gebruikt (de stapnummers).
- Geen animaties, geen tellers, geen scroll-effecten, geen stockfoto's.
- Verhouding donker/licht ongeveer 60/25: alleen "Wat wij doen" en het formulier staan op zand,
  omdat daar gelezen en ingevuld wordt.

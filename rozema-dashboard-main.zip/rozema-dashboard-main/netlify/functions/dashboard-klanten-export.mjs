// Klantenmodule K11: export, AVG-verwijderen en agenda onder /api/dashboard/klantenbeheer/.
// Eigen voorvoegsel /api/dashboard/klantenbeheer/, zonder overlap met de wildcard /api/dashboard/klanten/* van dashboard-klanten.mjs.
//
// Routes:
//   GET  /api/dashboard/klantenbeheer/export?formaat=json|csv&soort=relaties|trajecten|alles  (csv: soort relaties of trajecten)
//   POST /api/dashboard/klantenbeheer/beheer/verwijderen   {id, bevestig}
//   GET  /api/dashboard/klantenbeheer/agenda/token         stand van het token (niet het token zelf)
//   POST /api/dashboard/klantenbeheer/agenda/token         maakt of vernieuwt het token; geeft de feed-url één keer terug
//   GET  /api/dashboard/klantenbeheer/agenda/feed/<token>.ics   iCal-feed, zonder cookie: het token is de toegang
//
// Geen console.log; alleen interneFout logt, en dan alleen de soort fout. Geen persoonsgegevens in logs.
import { json, fout, interneFout, leesJson, BASIS_HEADERS } from "./dashboard-lib/antwoord.mjs";
import { vereisSessie } from "./dashboard-lib/sessie.mjs";
import { storeNaam, zetContext } from "./dashboard-lib/opslag.mjs";
import { CATALOGUS } from "./dashboard-lib/klanten/termijnregels.mjs";
import { verzamelAlles, waarschuwingen, maakCsv, logExport, verwijderRelatie } from "./dashboard-lib/klanten/export.mjs";
import { vernieuwToken, tokenStand, wieIsToken, verzamelGebeurtenissen, maakIcs } from "./dashboard-lib/klanten/agenda.mjs";

export const config = {
  path: [
    "/api/dashboard/klantenbeheer/export",
    "/api/dashboard/klantenbeheer/beheer/verwijderen",
    "/api/dashboard/klantenbeheer/agenda/token",
    "/api/dashboard/klantenbeheer/agenda/feed/*",
  ],
};

const PREFIX = "/api/dashboard/klantenbeheer/";
const nietGevonden = () => fout("Niet gevonden.", 404);
const ongeldig = (fouten) => json({ fout: "Ongeldige invoer.", fouten }, 422);

function bestand(tekst, type, naam, nu, extra = {}) {
  const ext = type.startsWith("text/csv") ? "csv" : "json";
  const h = new Headers({ ...BASIS_HEADERS, "content-type": type, "content-disposition": `attachment; filename="${naam}-${nu.toISOString().slice(0, 10)}.${ext}"`, ...extra });
  return new Response(tekst, { status: 200, headers: h });
}

async function exporteer(req, { wie, nu }) {
  const q = new URL(req.url).searchParams;
  const formaat = q.get("formaat") ?? "json";
  const soort = q.get("soort") ?? (formaat === "json" ? "alles" : null);
  const f = {};
  if (!["json", "csv"].includes(formaat)) f.formaat = "geen-keuze";
  if (formaat === "csv" ? !["relaties", "trajecten"].includes(soort) : !["alles", "relaties", "trajecten"].includes(soort)) f.soort = "geen-keuze";
  if (Object.keys(f).length) return ongeldig(f);
  const a = await verzamelAlles(nu, { tijdlijnen: formaat === "json" && soort !== "trajecten" });
  const waarschuw = waarschuwingen(a);
  const aantallen = { relaties: a.relaties.length, trajecten: a.trajecten.length };
  // Eerst loggen, dan pas uitleveren: een export zonder logregel mag niet bestaan.
  if (!(await logExport({ wie, nu, formaat, soort, aantallen }))) return fout("Export niet gelogd, daarom niet geleverd.", 503);
  if (formaat === "csv") return bestand(maakCsv(soort === "relaties" ? a.relaties : a.trajecten), "text/csv; charset=utf-8", `rozema-${soort}`, nu, waarschuw.length ? { "x-export-waarschuwing": waarschuw.join(",") } : {});
  const inhoud = soort === "relaties" ? { relaties: a.relaties, tijdlijnen: a.tijdlijnen } : soort === "trajecten" ? { trajecten: a.trajecten } : { relaties: a.relaties, trajecten: a.trajecten, tijdlijnen: a.tijdlijnen };
  const tekst = JSON.stringify({ geexporteerdOp: nu.toISOString(), aantallen, waarschuwingen: waarschuw, onvolledig: a.onvolledig, onleesbaar: a.onleesbaar, ...inhoud }, null, 2);
  return bestand(tekst, "application/json; charset=utf-8", `rozema-${soort}`, nu, waarschuw.length ? { "x-export-waarschuwing": waarschuw.join(",") } : {});
}

async function verwijder(req, { wie, nu, verwijderBudgetMs }) {
  const lengte = Number(req.headers.get("content-length"));
  if (Number.isFinite(lengte) && lengte > 4096) return fout("Te groot.", 413);
  const b = await leesJson(req, 4096);
  if (!b) return ongeldig({ _: "geen-json" });
  const onbekend = Object.keys(b).filter((k) => !["id", "bevestig"].includes(k));
  if (onbekend.length) return ongeldig(Object.fromEntries(onbekend.map((k) => [k, "onbekend-veld"])));
  const r = await verwijderRelatie(b.id, b.bevestig, wie, nu, { budgetMs: verwijderBudgetMs });
  if (r.ok) return json({ ok: true, tombstone: r.tombstone, verwijderd: r.verwijderd, alVerwijderd: r.alVerwijderd === true, ...(r.deels ? { deels: true } : {}) });
  if (r.fouten.id === "niet-gevonden") return nietGevonden();
  if (r.fouten._ === "gelijktijdig-probeer-opnieuw") return json({ fout: "Het is druk, probeer het nog eens.", code: "gelijktijdig-probeer-opnieuw", herhaal: true }, 503, { "retry-after": "1" });
  return ongeldig(r.fouten);
}

async function tokenGet(_req, { wie }) {
  return json(await tokenStand(wie));
}

async function tokenPost(req, { wie, nu }) {
  if (!(req.headers.get("content-type") || "").toLowerCase().startsWith("application/json")) return fout("Verzoek wordt niet ondersteund.", 415);
  const site = req.headers.get("sec-fetch-site");
  if (site !== null && site !== "same-origin") return fout("Niet toegestaan.", 403);
  const nieuw = await vernieuwToken(wie, nu);
  if (!nieuw) return json({ fout: "Het is druk, probeer het nog eens.", code: "gelijktijdig-probeer-opnieuw", herhaal: true }, 503, { "retry-after": "1" });
  const { token, op } = nieuw;
  return json({ ok: true, url: `${new URL(req.url).origin}${PREFIX}agenda/feed/${token}.ics`, op });
}

async function feed(req, { nu, regels }) {
  const m = /^\/api\/dashboard\/klantenbeheer\/agenda\/feed\/([A-Za-z0-9_-]+)\.ics$/.exec(new URL(req.url).pathname);
  const wie = m ? await wieIsToken(m[1]) : null;
  if (!wie) return nietGevonden(); // zelfde antwoord voor onbekend, vervangen en misvormd token
  const ics = maakIcs(await verzamelGebeurtenissen(regels, nu), nu);
  return new Response(ics, {
    status: 200,
    headers: { "content-type": "text/calendar; charset=utf-8", "cache-control": "no-store", "x-robots-tag": "noindex, nofollow", "referrer-policy": "no-referrer" },
  });
}

const ROUTES = [
  { pad: `${PREFIX}export`, GET: exporteer },
  { pad: `${PREFIX}beheer/verwijderen`, POST: verwijder },
  { pad: `${PREFIX}agenda/token`, GET: tokenGet, POST: tokenPost },
  { prefix: `${PREFIX}agenda/feed/`, GET: feed, geenSessie: true },
];

export function maakHandler({ regels = CATALOGUS, nu = () => new Date(), verwijderBudgetMs } = {}) {
  return async function handler(req, context) {
    try {
      zetContext(context);
      const pad = new URL(req.url).pathname.replace(/\/+$/, "");
      const route = ROUTES.find((r) => (r.pad ? r.pad === pad : pad.startsWith(r.prefix)));
      if (!route) return nietGevonden();
      let wie = null;
      if (!route.geenSessie) {
        const sessie = vereisSessie(req);
        if (!sessie) return fout("Niet ingelogd.", 401);
        wie = sessie.wie;
      }
      storeNaam("klanten"); // 500 als de deploy-context ontbreekt terwijl echte data aan staat
      const ok = ["GET", "POST"].filter((m) => route[m]);
      const methode = req.method.toUpperCase();
      if (!ok.includes(methode)) return fout("Methode niet toegestaan.", 405, { allow: ok.join(", ") });
      return await route[methode](req, { wie, nu: nu(), regels, verwijderBudgetMs });
    } catch (err) {
      return interneFout(err, "klanten-export");
    }
  };
}

export default maakHandler();

// Klantenmodule K5: geplande Function (KLANTEN-ARCHITECTUUR.md §2 "Nooit uit beeld" punt 6). De kern staat in
// dashboard-lib/klanten/dagelijks.mjs. Draait alleen op de productiedeploy van Netlify.
import { interneFout } from "./dashboard-lib/antwoord.mjs";
import { storeNaam, zetContext } from "./dashboard-lib/opslag.mjs";
import { voerDagelijksUit } from "./dashboard-lib/klanten/dagelijks.mjs";

// 03:00 UTC is 04:00 Amsterdamse wintertijd en 05:00 zomertijd.
export const config = { schedule: "0 3 * * *" };

// Netlify roept dit aan volgens `config.schedule`. Zonder bruikbare deploy-context (echte data aan) een fout.
export default async function handler(_req, context) {
  try {
    zetContext(context);
    storeNaam("klanten");
    const r = await voerDagelijksUit({ nu: new Date() });
    if (!r.schrijfOk) throw Object.assign(new Error("hartslag"), { name: "HartslagNietGeschreven" });
    return new Response(null, { status: 200 });
  } catch (err) {
    return interneFout(err, "klanten-dagelijks");
  }
}

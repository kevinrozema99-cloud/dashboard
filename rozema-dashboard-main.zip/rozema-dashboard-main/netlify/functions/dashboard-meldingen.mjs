import { json, fout, interneFout, leesJson } from "./dashboard-lib/antwoord.mjs";
import { vereisSessie } from "./dashboard-lib/sessie.mjs";
import { store, zetContext, bijwerk } from "./dashboard-lib/opslag.mjs";
import {
  valideerNieuweMelding, valideerStatus, ID_PATROON,
} from "./dashboard-lib/meldingen-regels.mjs";

export const config = { path: "/api/dashboard/meldingen/*" };

const MAX_LIJST = 500;

export default async function handler(req, context) {
  try {
    zetContext(context);
    const sessie = vereisSessie(req);
    if (!sessie) return fout("Niet ingelogd.", 401);
    const st = store("meldingen");
    const delen = new URL(req.url).pathname.split("/").filter(Boolean);
    // ["api","dashboard","meldingen", id?]
    const id = delen[3];

    if (!id && req.method === "POST") {
      const v = valideerNieuweMelding(await leesJson(req, 6000));
      if (v.fout) return fout(v.fout, 400);
      // Stap 1: het uuid claimen in een index (onlyIfNew). De index bewaart de
      // sleutel met tijd vooraan, zodat een herhaald verzoek dezelfde sleutel gebruikt.
      const nu = new Date();
      const claim = {
        sleutel: `melding/${nu.toISOString().replace(/[-:.]/g, "")}-${v.waarde.id}`,
        wie: sessie.wie,
      };
      const indexSleutel = `index/${v.waarde.id}`;
      const res = await st.setJSON(indexSleutel, claim, { onlyIfNew: true });
      let werkelijk = claim;
      if (res && res.modified === false) {
        werkelijk = await st.get(indexSleutel, { type: "json", consistency: "strong" });
        if (!werkelijk || werkelijk.wie !== sessie.wie) return fout("Dit id is al in gebruik.", 409);
      }
      // Stap 2: de melding zelf (onlyIfNew). Bestaat die al, dan was dit een herhaling.
      const melding = {
        ...v.waarde,
        wie: sessie.wie,
        wanneer: nu.toISOString(),
        status: "nieuw",
      };
      const w = await st.setJSON(werkelijk.sleutel, melding, { onlyIfNew: true });
      if (w && w.modified === false) {
        const bestaand = await st.get(werkelijk.sleutel, { type: "json", consistency: "strong" });
        return json(bestaand, 200);
      }
      return json(melding, 201);
    }

    if (!id && req.method === "GET") {
      // Sleutels beginnen met de tijd: nieuwste eerst, en er valt nooit een nieuwe af.
      const { blobs } = await st.list({ prefix: "melding/" });
      const sleutels = blobs.map((b) => b.key).sort().reverse().slice(0, MAX_LIJST);
      const lijst = (await Promise.all(sleutels.map((k) => st.get(k, { type: "json", consistency: "strong" }))))
        .filter(Boolean);
      return json({ meldingen: lijst });
    }

    if (id && req.method === "PATCH") {
      if (!ID_PATROON.test(id)) return fout("Niet gevonden.", 404);
      const v = valideerStatus(await leesJson(req, 500));
      if (v.fout) return fout(v.fout, 400);
      const index = await st.get(`index/${id}`, { type: "json", consistency: "strong" });
      if (!index) return fout("Niet gevonden.", 404);
      const res = await bijwerk(st, index.sleutel, (bestaand) =>
        bestaand
          ? { ...bestaand, status: v.waarde.status, gewijzigdDoor: sessie.wie, gewijzigdOp: new Date().toISOString() }
          : undefined);
      if (res.conflict) return fout("Het is druk, probeer het nog eens.", 409);
      if (!res.geschreven) return fout("Niet gevonden.", 404);
      return json(res.waarde);
    }

    return fout("Niet gevonden.", 404);
  } catch (err) {
    return interneFout(err, "meldingen");
  }
}

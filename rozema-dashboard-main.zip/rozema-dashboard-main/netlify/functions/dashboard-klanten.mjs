// Klantenmodule K4: routes onder /api/dashboard/klanten/* (KLANTEN-ARCHITECTUUR.md §3 en §6).
// Alle opslag loopt via dashboard-lib/klanten/opslag.mjs. Deze Function valideert, vertaalt codes naar
// statuscodes en bepaalt `wie` (uit de sessie) en `nu` (van de server); beide komen nooit uit de body.
// Nog niet hier (later): import: die geeft 404. Export, agenda en verwijderen staan in
// dashboard-klanten-export.mjs onder /api/dashboard/klantenbeheer/ (eigen voorvoegsel, geen overlap met deze wildcard).
//
// Geen console.log: alleen interneFout logt, en dan alleen de soort fout. Geen persoonsgegevens in logs.
import { createHash } from "node:crypto";
import { json, fout, interneFout, leesJson } from "./dashboard-lib/antwoord.mjs";
import { vereisSessie } from "./dashboard-lib/sessie.mjs";
import { storeNaam, zetContext } from "./dashboard-lib/opslag.mjs";
import {
  maakRelatie, wijzigRelatie, maakTraject, wijzigTraject, vinkAf, heropen,
  leesRelatie, isVerwijderd, leesTraject, leesRegister, leesIndex, leesTijdlijn, ONVOLLEDIG_NA_MS,
  leesAlleTrajecten, legContactVast, indexRij,
} from "./dashboard-lib/klanten/opslag.mjs";
import { maakTaken, takenVanRelatie, volgendeTaakVan } from "./dashboard-lib/klanten/taken.mjs";
import { maakAgenda, maandagVan, dagenTussen, MAX_DAGEN } from "./dashboard-lib/klanten/agendaweek.mjs";
import { STATUSSEN, LEAD_STATUSSEN, FASES, EIGENAREN, ROUTES, BRONNEN, isVanafBesluit, deurHerkomstOk, isIsoDatum, valideerContact, isGearchiveerd, OUDE_FASES, normFase } from "./dashboard-lib/klanten/model.mjs";
import { maakPijplijn, maakLeadPijplijn, maakOverzicht } from "./dashboard-lib/klanten/overzicht.mjs";
import { STATUS, termijnenVoor, isBevestigd } from "./dashboard-lib/klanten/termijnen.mjs";
import { CATALOGUS } from "./dashboard-lib/klanten/termijnregels.mjs";
import { vandaagAmsterdam } from "./dashboard-lib/klanten/datum.mjs";
import { berekenFataalBlok, telFataal, takenUitIndex, leesHartslag, beoordeelHartslag } from "./dashboard-lib/klanten/start.mjs";
import { voerDagelijksUit } from "./dashboard-lib/klanten/dagelijks.mjs";
import { klantRijenInPlaats, maakStraten } from "./dashboard-lib/klanten/straten.mjs";

export const config = { path: "/api/dashboard/klanten/*" };

// De etag in de antwoorden is nu alleen informatief (hash van de recordinhoud); er is nog geen If-Match.
// Gelijktijdige wijzigingen worden per veld samengevoegd, niet met een etag-controle van de client.

export const MAX_BODY = 64 * 1024; // tekens
const MAX_Q = 100;
const MAX_LIJST = 500;
const GROEP = 20;
const MIN_TUSSEN_RUNS_MS = 15 * 60 * 1000;

// Zelfde patronen als opslag.mjs (die exporteert ze niet).
const RELATIE_ID = /^r_[A-Za-z0-9_-]{1,62}$/;
const TRAJECT_ID = /^t_[A-Za-z0-9_-]{1,62}$/;
const REGEL_ID = /^[a-z0-9-]{1,64}$/;
const HERKOMST_SLEUTELS = ["zoho", "website", "deur"];
const GESLOTEN = ["Afgerond", "Verloren"];
const MAX_TEKST = 100;

// VOORLOPIGE regel (ligt bij Ruben): een termijn houdt het sluiten van een traject (Afgerond/Verloren) alleen
// tegen als de regel zeker fataal is (fataal === true), de termijn open, verlopen of te herbevestigen is, en
// de gebruiker hem ook kan afvinken (de regel kent afvinkacties). Zo kan een traject nooit vastzitten op iets
// dat niet af te vinken is. Niet-bevestigde regels, fataal:null, datum-ontbreekt en kon-niet-berekenen houden
// het sluiten niet tegen; ze blijven wel in het fatale blok en de balk staan.
export function blokkeertSluiten(item, regel) {
  if (!regel || regel.fataal !== true) return false;
  if (item.status !== STATUS.OPEN && item.status !== STATUS.HERBEVESTIGEN) return false;
  return Array.isArray(regel.afvinkActies) && regel.afvinkActies.length > 0;
}

// herkomst: bekende sleutels; elke waarde een korte string, of een object met korte strings (bijv. {zoho:{module,id}}).
const kort = (v) => typeof v === "string" && v.length <= MAX_TEKST;
function herkomstOk(h) {
  if (!isObj(h) || Object.keys(h).some((k) => !HERKOMST_SLEUTELS.includes(k))) return false;
  return Object.entries(h).every(([k, w]) => (k === "deur" ? deurHerkomstOk(w) : kort(w) || (isObj(w) && Object.values(w).every(kort))));
}

const isObj = (v) => v !== null && typeof v === "object" && !Array.isArray(v);

// ---------- antwoorden ----------
const ONGELDIG = "Ongeldige invoer.";
const ongeldig = (fouten) => json({ fout: ONGELDIG, fouten }, 422);
const nietGevonden = () => fout("Niet gevonden.", 404);
const verwijderd = () => fout("Verwijderd.", 410); // K11: AVG-verwijderd
// Ontbreekt het record: 410 als er een tombstone is, anders 404.
const ontbreekt = async (relatieId) => ((await isVerwijderd(relatieId)) ? verwijderd() : nietGevonden());
const druk = (extra = {}) => json({ fout: "Het is druk, probeer het nog eens.", code: "gelijktijdig-probeer-opnieuw", herhaal: true, ...extra }, 503, { "retry-after": "1" });
// Opgeslagen, maar het logboek (of de statuswissel naar Klant) is niet af: de client herhaalt met dezelfde wijzigingId.
const logNietAf = (wijzigingId) => json({ fout: "Opgeslagen, maar nog niet helemaal verwerkt. Herhaal dit verzoek.", code: "log-niet-bijgewerkt", herhaal: true, wijzigingId: wijzigingId ?? null }, 503, { "retry-after": "1" });

// Vertaalt een mislukt opslagresultaat ({ok:false, fouten}) naar een antwoord.
function vertaalFout(res) {
  const f = res?.fouten ?? {};
  if (f._ === "niet-gevonden" || f.relatieId === "niet-gevonden") return nietGevonden();
  if (f._ === "verwijderd") return verwijderd(); // K11: AVG-verwijderd, de wachtrij herhaalt dit niet
  if (f.id === "bestaat-al") return fout("Bestaat al.", 409);
  if (f._ === "gelijktijdig-probeer-opnieuw") return druk();
  return ongeldig(f); // veldfouten, ongeldig, velden:"te-veel", ...
}

// Weergave van een record met een inhoudsetag (de opslag geeft geen etag terug; zie verslag).
const etagVan = (rec) => `"${createHash("sha256").update(JSON.stringify(rec)).digest("hex").slice(0, 24)}"`;

// ---------- invoer ----------
// Leest en controleert een JSON-body: alleen toegestane sleutels. Geeft {waarde} of {antwoord}.
async function leesBody(req, toegestaan) {
  const lengte = Number(req.headers.get("content-length"));
  if (Number.isFinite(lengte) && lengte > MAX_BODY) return { antwoord: fout("Te groot.", 413) };
  const kopie = req.clone();
  const b = await leesJson(req, MAX_BODY); // gooit Weiger bij verkeerd content-type of andere herkomst
  if (!b) {
    // Te groot of ongeldig? Zelf meten, ook zonder content-length.
    if ((await kopie.text()).length > MAX_BODY) return { antwoord: fout("Te groot.", 413) };
    return { antwoord: ongeldig({ _: "geen-json" }) };
  }
  const onbekend = Object.keys(b).filter((k) => !toegestaan.includes(k));
  if (onbekend.length) return { antwoord: ongeldig(Object.fromEntries(onbekend.map((k) => [k, "onbekend-veld"]))) };
  return { waarde: b };
}

// ---------- hulp voor lezen ----------
async function inGroepen(lijst, fn) {
  const uit = [];
  for (let i = 0; i < lijst.length; i += GROEP) uit.push(...(await Promise.allSettled(lijst.slice(i, i + GROEP).map(fn))));
  return uit;
}

const vouw = (s) => String(s ?? "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
const zonderSpaties = (s) => vouw(s).replace(/\s+/g, "");

function pasBij(rij, q) {
  const doel = [rij.voornaam, rij.naam, rij.adres, rij.plaats, rij.postcode, rij.eigenaar, rij.email, rij.telefoon].map(vouw).join(" ");
  const woorden = vouw(q).split(/\s+/).filter(Boolean);
  const pc = zonderSpaties(rij.postcode);
  const tel = String(rij.telefoon ?? "").replace(/\D/g, "");
  return woorden.every((w) => doel.includes(w) || (pc && pc.includes(w)) || (tel && w.replace(/\D/g, "").length >= 4 && tel.includes(w.replace(/\D/g, ""))));
}

// relatie-id -> haar trajecten (alleen leesbare trajecten).
async function trajectenPerRelatie(nu) {
  const { trajecten } = await leesAlleTrajecten(nu);
  const m = new Map();
  for (const t of trajecten) if (t?.relatieId) m.set(t.relatieId, [...(m.get(t.relatieId) ?? []), t]);
  return m;
}

// ---------- routes ----------
function maakRoutes({ regels }) {
  const vandaagVan = (nu) => vandaagAmsterdam(nu);

  async function lijst(req, { nu }) {
    const url = new URL(req.url);
    const q = url.searchParams.get("q") ?? "";
    const status = url.searchParams.get("status");
    const eigenaar = url.searchParams.get("eigenaar");
    const archief = url.searchParams.get("archief") ?? "";
    // Leads en klanten apart (opdracht Ruben 20-11-2026): ?soort=lead (alles behalve Klant) of ?soort=klant.
    // Bij klanten filtert ?fase= op de fase van een van hun trajecten.
    const soort = url.searchParams.get("soort") ?? "";
    const fase = url.searchParams.get("fase") ?? "";
    const f = {};
    if (!["", "verberg", "toon", "alleen"].includes(archief)) f.archief = "geen-keuze";
    if (!["", "lead", "klant"].includes(soort)) f.soort = "geen-keuze";
    if (fase !== "" && (!FASES.includes(fase) || soort === "lead")) f.fase = "geen-keuze";
    if (q.length > MAX_Q) f.q = "te-lang";
    if (status !== null && status !== "" && !STATUSSEN.includes(status)) f.status = "geen-keuze";
    if (status && soort === "lead" && !LEAD_STATUSSEN.includes(status)) f.status = "geen-keuze";
    if (eigenaar !== null && eigenaar !== "" && !EIGENAREN.includes(eigenaar)) f.eigenaar = "geen-keuze";
    if (Object.keys(f).length) return ongeldig(f);

    let rijen = Object.values((await leesIndex()).rijen ?? {});
    if (soort === "lead") rijen = rijen.filter((r) => r.status !== "Klant");
    if (soort === "klant") rijen = rijen.filter((r) => r.status === "Klant");
    if (status) rijen = rijen.filter((r) => r.status === status);
    if (eigenaar) rijen = rijen.filter((r) => r.eigenaar === eigenaar);
    if (q.trim()) rijen = rijen.filter((r) => pasBij(r, q));
    // Archief (afgeleid): Afgevallen, of klant van wie elk traject Uitbetaald/Afgerond/Verloren is. Alleen voor klanten
    // zijn de trajecten nodig; die worden dan één keer gelezen.
    const trajectenPer = rijen.some((r) => r.status === "Klant") ? await trajectenPerRelatie(nu) : new Map();
    const dag = vandaagVan(nu);
    rijen = rijen.map((r) => {
      const eigen = trajectenPer.get(r.id) ?? [];
      // De volgende taak is de eerste van alle bronnen (flow, handmatig, termijn), niet alleen de handmatige.
      const fases = eigen.map((t) => normFase(t.fase));
      return { ...r, gearchiveerd: isGearchiveerd(r.status, fases), volgendeTaak: volgendeTaakVan(r, eigen, regels, dag),
        ...(r.status === "Klant" ? { fases } : {}) };
    });
    if (fase) rijen = rijen.filter((r) => (r.fases ?? []).includes(fase));
    if (archief === "" || archief === "verberg") rijen = rijen.filter((r) => !r.gearchiveerd);
    else if (archief === "alleen") rijen = rijen.filter((r) => r.gearchiveerd);
    // Eerstvolgende actie eerst; zonder open taak achteraan; dan op naam.
    rijen.sort((a, b) => (a.volgendeTaak?.datum ?? "9999").localeCompare(b.volgendeTaak?.datum ?? "9999")
      || String(a.naam).localeCompare(String(b.naam), "nl") || String(a.id).localeCompare(String(b.id)));
    const totaal = rijen.length;
    // Het fatale blok staat bewust niet hier maar in GET /start: ongefilterd en live (§2 "Nooit uit beeld").
    return json({ relaties: rijen.slice(0, MAX_LIJST), totaal, afgekapt: totaal > MAX_LIJST });
  }

  // K10: voor de deur-app: de straten van één plaats waar al een klant of traject is, als {straat, klant:true}.
  // `onvolledig` telt de klanten waarvan de straat niet te lezen was. ?plaats= is verplicht (anders 422).
  async function straten(req) {
    const plaats = new URL(req.url).searchParams.get("plaats");
    if (plaats === null || !plaats.trim()) return ongeldig({ plaats: "verplicht" });
    if (plaats.length > MAX_TEKST) return ongeldig({ plaats: "te-lang" });
    const [index, register] = await Promise.all([leesIndex(), leesRegister()]);
    const hier = klantRijenInPlaats(Object.values(index.rijen ?? {}), register, plaats);
    const straatPer = new Map();
    const gelezen = await inGroepen(hier, (r) => leesRelatie(r.id));
    gelezen.forEach((g, i) => { if (g.status === "fulfilled" && g.value) straatPer.set(hier[i].id, g.value.straat); });
    return json({ plaats: plaats.trim(), ...maakStraten(hier, (r) => straatPer.get(r.id)) });
  }

  // Startscherm: fatale blok live en ongefilterd, taken, gezondheid, hartslag van de dagelijkse run.
  async function start(req, { nu }) {
    const alleen = new URL(req.url).searchParams.get("alleen");
    if (alleen !== null && alleen !== "telling") return ongeldig({ alleen: "geen-keuze" });
    const vandaag = vandaagVan(nu);
    if (alleen === "telling") {
      // Lichte balk: zelfde berekening, alleen de tellingen.
      const b = await berekenFataalBlok(regels, vandaag, nu);
      return json({
        vandaag, fataal: telFataal(b.items),
        gezondheid: { aantal: b.gezondheid.length + b.onvolledig.length + b.onleesbaar.length },
      });
    }
    // Het blok, de index en de hartslag parallel; index en hartslag mogen falen zonder het blok te verbergen.
    const [b, indexUitslag, hartslagUitslag] = await Promise.all([
      berekenFataalBlok(regels, vandaag, nu),
      leesIndex().then((v) => ({ v }), () => ({ fout: true })),
      leesHartslag().then((v) => ({ v }), () => ({ fout: true })),
    ]);
    const indexOk = !indexUitslag.fout;
    const index = indexOk ? indexUitslag.v : { rijen: {} };
    const hartslag = hartslagUitslag.fout ? null : hartslagUitslag.v;
    const oordeel = hartslagUitslag.fout ? { waarschuwing: "onleesbaar", leeftijdUren: null } : beoordeelHartslag(hartslag, nu);
    return json({
      vandaag,
      fataal: { items: b.items, ...telFataal(b.items) },
      taken: { ...takenUitIndex(index.rijen, vandaag), indexOk },
      gezondheid: {
        termijnen: b.gezondheid, onvolledig: b.onvolledig, onleesbaar: b.onleesbaar,
        aantal: b.gezondheid.length + b.onvolledig.length + b.onleesbaar.length,
      },
      hartslag: {
        laatste: hartslag ? { op: hartslag.op ?? null, ok: hartslag.ok ?? null, aantallen: hartslag.aantallen ?? {}, fouten: hartslag.fouten ?? [] } : null,
        leeftijdUren: oordeel.leeftijdUren,
        waarschuwing: oordeel.waarschuwing,
      },
      register: hartslag?.details?.register ? { op: hartslag.op ?? null, afwijkingen: hartslag.details.register } : null,
    });
  }

  // Handmatige run voor de testsite en previews (daar draaien geplande Functions niet). Lege body {}.
  async function dagelijksRun(req, { nu }) {
    const b = await leesBody(req, []);
    if (b.antwoord) return b.antwoord;
    let laatste = null;
    try { laatste = await leesHartslag(); } catch { laatste = null; }
    const t = Date.parse(laatste?.op);
    if (Number.isFinite(t) && nu.getTime() - t < MIN_TUSSEN_RUNS_MS && nu.getTime() >= t) {
      const wacht = Math.ceil((MIN_TUSSEN_RUNS_MS - (nu.getTime() - t)) / 1000);
      return json({ fout: "Te snel opnieuw.", code: "te-snel" }, 429, { "retry-after": String(wacht) });
    }
    const r = await voerDagelijksUit({ nu, regels, handmatig: true });
    if (!r.schrijfOk) return interneFout(Object.assign(new Error("hartslag"), { name: "HartslagNietGeschreven" }), "klanten-dagelijks");
    return json({ ok: r.ok, aantallen: r.aantallen, fouten: r.fouten });
  }

  async function maakNieuweRelatie(req, { wie, nu }) {
    const b = await leesBody(req, ["id", "wijzigingId", "velden", "herkomst"]);
    if (b.antwoord) return b.antwoord;
    const { id, wijzigingId, velden, herkomst } = b.waarde;
    if (!isObj(velden)) return ongeldig({ velden: "verplicht" });
    if (herkomst !== undefined && !herkomstOk(herkomst)) return ongeldig({ herkomst: "ongeldig" });
    const res = await maakRelatie({ id, wijzigingId, velden, ...(herkomst !== undefined ? { herkomst } : {}) }, wie, nu);
    if (!res.ok) return vertaalFout(res);
    if (res.logOk === false) return logNietAf(wijzigingId);
    return json({ record: res.record, bestaatAl: res.bestaatAl === true, etag: etagVan(res.record) }, res.bestaatAl ? 200 : 201);
  }

  async function leesEenRelatie(_req, { id, nu }) {
    const relatie = await leesRelatie(id);
    if (!relatie) return ontbreekt(id);
    const register = await leesRegister();
    const eigen = Object.entries(register.ids ?? {}).filter(([, item]) => item?.relatieId === id).map(([tid]) => tid);
    const gelezen = await inGroepen(eigen, (tid) => leesTraject(tid));
    const dag = vandaagVan(nu);
    const trajecten = [];
    const onvolledig = [];
    const onleesbaar = [];
    gelezen.forEach((g, i) => {
      if (g.status === "rejected") onleesbaar.push({ id: eigen[i], relatieId: id });
      else if (!g.value) {
        // Zelfde grens en vorm als leesAlleTrajecten: jonger dan 10 minuten is nog bezig en telt niet.
        const t = Date.parse(register.ids[eigen[i]]?.aangemaakt);
        if (!Number.isFinite(t) || nu.getTime() - t > ONVOLLEDIG_NA_MS) {
          onvolledig.push({ id: eigen[i], relatieId: id, aangemaakt: register.ids[eigen[i]]?.aangemaakt ?? null });
        }
      }
      else trajecten.push({ record: g.value, termijnen: termijnenVoor(g.value, relatie, regels, dag), etag: etagVan(g.value) });
    });
    trajecten.sort((a, b) => String(a.record.aangemaakt?.op).localeCompare(String(b.record.aangemaakt?.op)) || a.record.id.localeCompare(b.record.id));
    return json({
      relatie, etag: etagVan(relatie), termijnen: termijnenVoor(null, relatie, regels, dag),
      trajecten, onvolledig, onleesbaar,
      gearchiveerd: isGearchiveerd(relatie.status, trajecten.map((t) => t.record.fase)),
      // Alle open taken van deze klant (flow, handmatig, termijn met datum), op datum.
      taken: takenVanRelatie(indexRij(relatie), trajecten.map((t) => t.record), regels, dag)
        .sort((a, b) => (a.datum ?? "9999").localeCompare(b.datum ?? "9999")),
    });
  }

  async function wijzigEenRelatie(req, { id, wie, nu }) {
    const b = await leesBody(req, ["wijzigingId", "velden"]);
    if (b.antwoord) return b.antwoord;
    const res = await wijzigRelatie(id, { wijzigingId: b.waarde.wijzigingId, velden: b.waarde.velden }, wie, nu);
    return wijzigAntwoord(res, b.waarde.wijzigingId);
  }

  function wijzigAntwoord(res, wijzigingId) {
    if (!res.ok) return vertaalFout(res);
    if (res.logOk === false) return logNietAf(wijzigingId);
    return json({ toegepast: res.toegepast ?? [], conflicten: res.conflicten ?? [], record: res.record, etag: etagVan(res.record), ...(res.noop ? { noop: true } : {}) });
  }

  async function tijdlijn(_req, { id }) {
    if (!(await leesRelatie(id))) return ontbreekt(id);
    return json({ regels: await leesTijdlijn(id) });
  }

  async function nieuwTraject(req, { id, wie, nu }) {
    const b = await leesBody(req, ["id", "wijzigingId", "velden"]);
    if (b.antwoord) return b.antwoord;
    const { wijzigingId, velden } = b.waarde;
    if (velden !== undefined && !isObj(velden)) return ongeldig({ velden: "ongeldig" });
    // Een traject dat al gesloten begint, zou de controle op open fatale termijnen (T15) omzeilen.
    if (isObj(velden) && GESLOTEN.includes(velden.fase)) return ongeldig({ fase: "niet-bij-aanmaken" });
    if (isObj(velden) && Object.hasOwn(OUDE_FASES, velden.fase)) return ongeldig({ fase: "geen-keuze" }); // bestaat niet meer
    const res = await maakTraject(id, { id: b.waarde.id, wijzigingId, velden }, wie, nu);
    if (!res.ok) return vertaalFout(res);
    // relatieStatusOk false: de relatie is nog niet op Klant gezet; een herhaling met dezelfde wijzigingId maakt dat af.
    if (res.logOk === false || res.relatieStatusOk === false) return logNietAf(wijzigingId);
    return json({ record: res.record, bestaatAl: res.bestaatAl === true, etag: etagVan(res.record) }, res.bestaatAl ? 200 : 201);
  }

  async function wijzigEenTraject(req, { id, wie, nu }) {
    const b = await leesBody(req, ["wijzigingId", "velden"]);
    if (b.antwoord) return b.antwoord;
    let blokkade = null;
    // Draait binnen de schrijfpoging op het verse record (geen race tussen controle en schrijven).
    const controle = async (nieuw, huidig) => {
      blokkade = null;
      // Vanaf Besluit een verzenddatum, of expliciet onbekend (T5; de opslag controleert dit ook al).
      if (isVanafBesluit(nieuw.fase) && !nieuw.verzenddatumBesluitbrief && nieuw.verzenddatumOnbekend !== true) {
        return { verzenddatumBesluitbrief: "verplicht-vanaf-besluit" };
      }
      // Sluiten (Afgerond/Verloren) mag niet met een blokkerende fatale termijn (T15, zie blokkeertSluiten): eerst afvinken.
      if (GESLOTEN.includes(nieuw.fase) && !GESLOTEN.includes(huidig.fase)) {
        const relatie = await leesRelatie(nieuw.relatieId);
        const open = termijnenVoor(nieuw, relatie, regels, vandaagVan(nu))
          .filter((t) => blokkeertSluiten(t, regels.find((r) => r.id === t.regelId)));
        if (open.length) { blokkade = open; return { fase: "open-fatale-termijn" }; }
      }
      return null;
    };
    const res = await wijzigTraject(id, { wijzigingId: b.waarde.wijzigingId, velden: b.waarde.velden }, wie, nu, { controle });
    if (!res.ok && blokkade && res.fouten?.fase === "open-fatale-termijn") {
      return json({ fout: "Open fatale termijn.", code: "open-fatale-termijn", termijnen: blokkade }, 409);
    }
    return wijzigAntwoord(res, b.waarde.wijzigingId);
  }

  async function afvinken(req, { id, regel, wie, nu }) {
    const b = await leesBody(req, ["actie", "wijzigingId"]);
    if (b.antwoord) return b.antwoord;
    const { actie, wijzigingId } = b.waarde;
    const def = regels.find((r) => r.id === regel);
    if (!def || def.record !== "traject") return nietGevonden();
    if (actie !== undefined && actie !== null && (typeof actie !== "string" || actie.length > MAX_TEKST)) return ongeldig({ actie: "ongeldig" });
    if (def.afvinkActies?.length && !def.afvinkActies.includes(actie ?? null)) {
      return ongeldig({ actie: actie == null ? "actie-verplicht" : "actie-niet-toegestaan" });
    }
    const res = await vinkAf(id, regel, { actie: actie ?? undefined, wijzigingId }, wie, nu, { regels });
    return afvinkAntwoord(res, wijzigingId, nu);
  }

  async function heropenen(req, { id, regel, wie, nu }) {
    const b = await leesBody(req, ["wijzigingId"]);
    if (b.antwoord) return b.antwoord;
    const res = await heropen(id, regel, { wijzigingId: b.waarde.wijzigingId }, wie, nu, { regels });
    return afvinkAntwoord(res, b.waarde.wijzigingId, nu);
  }

  async function afvinkAntwoord(res, wijzigingId, nu) {
    if (!res.ok) {
      const f = res.fouten ?? {};
      if (f.regelId === "onbekende-regel" || f.regelId === "geen-trajectregel") return nietGevonden();
      return vertaalFout(res);
    }
    if (res.logOk === false) return logNietAf(wijzigingId);
    const relatie = await leesRelatie(res.record.relatieId);
    return json({
      record: res.record, etag: etagVan(res.record), termijnen: termijnenVoor(res.record, relatie, regels, vandaagVan(nu)),
      ...(res.noop ? { noop: true } : {}),
    });
  }

  // Klantpijplijn: trajecten per fase (Zoho: Deals-kanban). ?eigenaar=&route=&archief=ja
  async function pijplijn(req, { nu }) {
    const url = new URL(req.url);
    const eigenaar = url.searchParams.get("eigenaar") || null;
    const route = url.searchParams.get("route") || null;
    const archief = url.searchParams.get("archief");
    const f = {};
    if (eigenaar && !EIGENAREN.includes(eigenaar)) f.eigenaar = "geen-keuze";
    if (route && !ROUTES.includes(route)) f.route = "geen-keuze";
    if (archief !== null && archief !== "" && archief !== "ja") f.archief = "geen-keuze";
    if (Object.keys(f).length) return ongeldig(f);
    const vandaag = vandaagVan(nu);
    const [alle, index] = await Promise.all([leesAlleTrajecten(nu), leesIndex()]);
    const p = maakPijplijn(alle.trajecten, index.rijen ?? {}, regels, vandaag, { eigenaar, route, archief: archief === "ja" });
    // Onvolledige en onleesbare trajecten staan niet op het bord; wel het aantal, zodat niets stil ontbreekt.
    return json({ vandaag, ...p, onvolledig: alle.onvolledig.length, onleesbaar: alle.onleesbaar.length });
  }

  // Takenlijst (opdracht Ruben 20-11-2026). ?wie=kevin|ruben|alle (standaard: wie is ingelogd), ?alleen=telling.
  async function taken(req, { nu, wie: sessieWie }) {
    const url = new URL(req.url);
    const gevraagd = url.searchParams.get("wie");
    const alleen = url.searchParams.get("alleen");
    const f = {};
    if (gevraagd !== null && gevraagd !== "" && gevraagd !== "alle" && !EIGENAREN.includes(gevraagd)) f.wie = "geen-keuze";
    if (alleen !== null && alleen !== "telling") f.alleen = "geen-keuze";
    if (Object.keys(f).length) return ongeldig(f);
    const ik = String(sessieWie ?? "").toLowerCase();
    const wie = gevraagd === "alle" ? null : gevraagd || (EIGENAREN.includes(ik) ? ik : null);
    const dag = vandaagVan(nu);
    const [index, alle] = await Promise.all([leesIndex(), leesAlleTrajecten(nu)]);
    const uit = maakTaken(Object.values(index.rijen ?? {}), alle.trajecten, regels, dag, { wie });
    if (alleen === "telling") return json({ vandaag: dag, wie, telling: uit.telling });
    return json({ vandaag: dag, wie, ...uit, onvolledig: alle.onvolledig.length, onleesbaar: alle.onleesbaar.length });
  }

  // Gezamenlijke agenda: afspraken en opnames. ?van=&tot= (standaard deze week, maandag t/m zondag; hoogstens
  // MAX_DAGEN dagen) en ?wie=kevin|ruben (standaard iedereen: het is een gezamenlijke agenda).
  async function agenda(req, { nu }) {
    const url = new URL(req.url);
    const dag = vandaagVan(nu);
    const van = url.searchParams.get("van") || maandagVan(dag);
    const tot = url.searchParams.get("tot") || null;
    const wie = url.searchParams.get("wie") || null;
    const f = {};
    if (!isIsoDatum(van)) f.van = "geen-datum";
    if (tot !== null && !isIsoDatum(tot)) f.tot = "geen-datum";
    if (wie && !EIGENAREN.includes(wie)) f.wie = "geen-keuze";
    if (Object.keys(f).length) return ongeldig(f);
    const totDag = tot ?? new Date(Date.parse(`${van}T12:00:00Z`) + 6 * 86400000).toISOString().slice(0, 10);
    const n = dagenTussen(van, totDag);
    if (n < 0 || n >= MAX_DAGEN) return ongeldig({ tot: "buiten-bereik" });
    const [index, alle] = await Promise.all([leesIndex(), leesAlleTrajecten(nu)]);
    const uit = maakAgenda(Object.values(index.rijen ?? {}), alle.trajecten, { van, tot: totDag, wie });
    return json({ vandaag: dag, wie, ...uit, onvolledig: alle.onvolledig.length, onleesbaar: alle.onleesbaar.length });
  }

  // Leadpijplijn: relaties per leadstatus, uit de index (snel, geen trajecten nodig). ?eigenaar=&bron=&archief=ja
  async function leadpijplijn(req, { nu }) {
    const url = new URL(req.url);
    const eigenaar = url.searchParams.get("eigenaar") || null;
    const bron = url.searchParams.get("bron") || null;
    const archief = url.searchParams.get("archief");
    const f = {};
    if (eigenaar && !EIGENAREN.includes(eigenaar)) f.eigenaar = "geen-keuze";
    if (bron && !BRONNEN.includes(bron)) f.bron = "geen-keuze";
    if (archief !== null && archief !== "" && archief !== "ja") f.archief = "geen-keuze";
    if (Object.keys(f).length) return ongeldig(f);
    const vandaag = vandaagVan(nu);
    const index = await leesIndex();
    return json({ vandaag, ...maakLeadPijplijn(Object.values(index.rijen ?? {}), vandaag, { eigenaar, bron, archief: archief === "ja" }) });
  }

  // Overzichten (Zoho: rapporten). Alleen aantallen en bedragen, geen namen. ?van=YYYY-MM-DD&tot=YYYY-MM-DD
  async function overzicht(req, { nu }) {
    const url = new URL(req.url);
    const van = url.searchParams.get("van") || null;
    const tot = url.searchParams.get("tot") || null;
    const f = {};
    if (van && !isIsoDatum(van)) f.van = "geen-datum";
    if (tot && !isIsoDatum(tot)) f.tot = "geen-datum";
    if (!f.van && !f.tot && van && tot && van > tot) f.tot = "voor-van";
    if (Object.keys(f).length) return ongeldig(f);
    const [alle, index] = await Promise.all([leesAlleTrajecten(nu), leesIndex()]);
    const uit = maakOverzicht(Object.values(index.rijen ?? {}), alle.trajecten, { van, tot }, vandaagVan(nu));
    return json({ vandaag: vandaagVan(nu), ...uit, onvolledig: alle.onvolledig.length, onleesbaar: alle.onleesbaar.length });
  }

  // Contactmoment vastleggen (Zoho: Calls). Wordt een tijdlijnregel; idempotent op wijzigingId (offline wachtrij).
  async function contact(req, { id, wie, nu }) {
    const b = await leesBody(req, ["wijzigingId", "wijze", "datum", "notitie"]);
    if (b.antwoord) return b.antwoord;
    const { wijzigingId, ...invoer } = b.waarde;
    if (typeof wijzigingId !== "string" || !/^[A-Za-z0-9_-]{1,64}$/.test(wijzigingId)) return ongeldig({ wijzigingId: "ongeldig" });
    const v = valideerContact(invoer, vandaagVan(nu));
    if (!v.ok) return ongeldig(v.fouten);
    const res = await legContactVast(id, { wijzigingId, contact: v.waarde }, wie, nu);
    if (!res.ok) return vertaalFout(res);
    return json({ regel: res.regel, ...(res.noop ? { noop: true } : {}) }, res.noop ? 200 : 201);
  }

  async function regelLijst() {
    return json({ regels: regels.map((r) => ({ ...r, bevestigingsstatus: isBevestigd(r) ? "bevestigd" : "niet-bevestigd" })) });
  }

  // Route-tabel: patroon per segment; ":id" = relatie-id, ":tid" = traject-id, ":regel" = regel-id.
  return [
    { pad: ["start"], GET: start },
    { pad: ["dagelijks"], POST: dagelijksRun },
    { pad: ["regels"], GET: regelLijst },
    { pad: ["straten"], GET: straten },
    { pad: ["pijplijn"], GET: pijplijn },
    { pad: ["leadpijplijn"], GET: leadpijplijn },
    { pad: ["taken"], GET: taken },
    { pad: ["agenda"], GET: agenda },
    { pad: ["overzicht"], GET: overzicht },
    { pad: ["relaties"], GET: lijst, POST: maakNieuweRelatie },
    { pad: ["relaties", ":rid"], GET: leesEenRelatie, PATCH: wijzigEenRelatie },
    { pad: ["relaties", ":rid", "tijdlijn"], GET: tijdlijn },
    { pad: ["relaties", ":rid", "contact"], POST: contact },
    { pad: ["relaties", ":rid", "trajecten"], POST: nieuwTraject },
    { pad: ["trajecten", ":tid"], PATCH: wijzigEenTraject },
    { pad: ["trajecten", ":tid", "termijnen", ":regel", "afvinken"], POST: afvinken },
    { pad: ["trajecten", ":tid", "termijnen", ":regel", "heropenen"], POST: heropenen },
  ];
}

const PARAMS = { ":rid": RELATIE_ID, ":tid": TRAJECT_ID, ":regel": REGEL_ID };

// Geeft {route, params} bij een treffer; ongeldige id's en onbekende paden vallen buiten de tabel (404).
function zoekRoute(routes, delen) {
  for (const route of routes) {
    if (route.pad.length !== delen.length) continue;
    const params = {};
    let ok = true;
    route.pad.forEach((p, i) => {
      if (!ok) return;
      if (PARAMS[p]) {
        if (!PARAMS[p].test(delen[i])) { ok = false; return; }
        params[p === ":rid" || p === ":tid" ? "id" : "regel"] = delen[i];
      } else if (p !== delen[i]) ok = false;
    });
    if (ok) return { route, params };
  }
  return null;
}

// Voor tests: eigen regels (testcatalogus) en eigen klok. De standaard-export gebruikt de echte catalogus.
export function maakHandler({ regels = CATALOGUS, nu = () => new Date() } = {}) {
  const routes = maakRoutes({ regels, nu });
  return async function handler(req, context) {
    try {
      zetContext(context);
      const sessie = vereisSessie(req);
      if (!sessie) return fout("Niet ingelogd.", 401);
      storeNaam("klanten"); // geeft een fout (500) als de deploy-context ontbreekt terwijl echte data aan staat
      const delen = new URL(req.url).pathname.split("/").filter(Boolean).slice(3); // na api/dashboard/klanten
      const gevonden = zoekRoute(routes, delen);
      if (!gevonden) return nietGevonden();
      const { route, params } = gevonden;
      const methode = req.method.toUpperCase();
      const toegestaan = ["GET", "POST", "PATCH"].filter((m) => route[m]);
      if (!toegestaan.includes(methode)) return fout("Methode niet toegestaan.", 405, { allow: toegestaan.join(", ") });
      return await route[methode](req, { ...params, wie: sessie.wie, nu: nu() }); // het tijdstip wordt één keer per verzoek vastgelegd
    } catch (err) {
      return interneFout(err, "klanten");
    }
  };
}

export default maakHandler();

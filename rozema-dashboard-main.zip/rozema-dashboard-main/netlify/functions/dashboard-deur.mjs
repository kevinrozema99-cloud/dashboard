// Backend deur-aan-deur: /api/dashboard/deur/*. Opslag in store "deur" (zie dashboard-lib/deur/server.mjs).
// Geen proxy (PDOK staat CORS toe), geen Zoho, geen persoonsgegevens: een afspraak slaat alleen de uitkomst op.
import { json, fout, interneFout, leesJson, BASIS_HEADERS } from "./dashboard-lib/antwoord.mjs";
import { vereisSessie } from "./dashboard-lib/sessie.mjs";
import { store, zetContext } from "./dashboard-lib/opslag.mjs";
import {
  PLAATS_ID, BUURT_CODE, POSTCODE, schoonBezoek, schoonAdres, csv, maakExportRijen, round, stuurtekensWeg,
} from "../../public/dashboard/deur/logica.js";
import {
  leesPlaatsen, leesInstellingen, leesBuurten, leesAdressen, schrijfBezoek, leesBezoeken, volledigeStand, parallel, basis, pad14,
} from "./dashboard-lib/deur/server.mjs";

export const config = { path: "/api/dashboard/deur/*" };

const MAX_DEEL = 1000; // adressen per deel
const VERSIE = /^[a-z0-9]{6,20}$/;
const num = (v) => (typeof v === "number" && Number.isFinite(v) ? v : null);
const pct = (v) => (num(v) !== null && v >= 0 && v <= 100 ? Math.round(v) : null);

export default async function handler(req, context) {
  try {
    zetContext(context);
    const sessie = vereisSessie(req);
    if (!sessie) return fout("Niet ingelogd.", 401);
    const wie = sessie.wie;
    const delen = new URL(req.url).pathname.split("/").filter(Boolean).slice(3); // na api/dashboard/deur
    const m = req.method;
    if (delen[0] !== "plaatsen") return fout("Niet gevonden.", 404);
    const st = store("deur");

    // plaatsen
    if (delen.length === 1) {
      if (m === "GET") return json({ plaatsen: await leesPlaatsen(st) });
      return fout("Niet gevonden.", 404);
    }
    const id = delen[1];
    if (!PLAATS_ID.test(id)) return fout("Niet gevonden.", 404);
    const sub = delen[2];

    if (!sub) {
      if (m === "GET") {
        const meta = await st.get(`plaatsen/${id}`, { type: "json" });
        if (!meta) return fout("Niet gevonden.", 404);
        const inst = await leesInstellingen(st, id);
        const buurten = await leesBuurten(st, meta, inst.keuzes);
        return json({ plaats: meta, buurten, trilling: inst.trilling, opnieuwOphalen: !meta.versie });
      }
      if (m === "PUT") {
        const b = await leesJson(req, 20000);
        if (!b || typeof b.naam !== "string" || !b.naam.trim() || b.naam.length > 80
            || !Array.isArray(b.buurten) || b.buurten.length > 500
            || typeof b.versie !== "string" || !VERSIE.test(b.versie)
            || !b.buurten.every((c) => typeof c === "string" && BUURT_CODE.test(c))) {
          return fout("Ongeldige plaats.", 400);
        }
        const meta = {
          id, naam: stuurtekensWeg(b.naam, 80), versie: b.versie, aantal: Math.max(0, Math.round(Number(b.aantal) || 0)),
          buurten: b.buurten, bijgewerkt: new Date().toISOString(), door: wie,
        };
        await st.setJSON(`plaatsen/${id}`, meta);
        // Wie heeft de plaats (opnieuw) opgehaald en wanneer.
        await st.setJSON(`log/${id}/${pad14(Date.now())}`, { wie, wanneer: meta.bijgewerkt, versie: meta.versie, aantal: meta.aantal });
        return json(meta);
      }
      return fout("Niet gevonden.", 404);
    }

    if (sub === "instellingen" && m === "GET") {
      if (!(await st.get(`plaatsen/${id}`, { type: "json" }))) return fout("Niet gevonden.", 404);
      return json(await leesInstellingen(st, id));
    }

    if (sub === "buurten" && delen[3]) {
      const code = delen[3];
      if (!BUURT_CODE.test(code)) return fout("Niet gevonden.", 404);
      const wat = delen[4];
      const versie = new URL(req.url).searchParams.get("v") || "";
      const schrijft = m === "PUT" && (!wat || wat === "delen");
      if (schrijft && !VERSIE.test(versie)) return fout("Ongeldige versie.", 400);
      if (wat === "keuze" && !(await st.get(`plaatsen/${id}`, { type: "json" }))) return fout("Niet gevonden.", 404);
      if (!wat && m === "PUT") {
        const b = await leesJson(req, 5000);
        if (!b || typeof b.naam !== "string") return fout("Ongeldige buurt.", 400);
        const buurt = {
          code, naam: stuurtekensWeg(b.naam, 80), koop: pct(b.koop), corp: pct(b.corp),
          woningen: num(b.woningen) !== null && b.woningen >= 0 ? Math.round(b.woningen) : null,
          aantal: Math.max(0, Math.round(Number(b.aantal) || 0)),
          delen: Math.min(200, Math.max(0, Math.round(Number(b.delen) || 0))),
        };
        await st.setJSON(`${basis(id, versie)}/buurten/${code}`, buurt);
        return json(buurt);
      }
      if (wat === "delen" && delen[5] !== undefined && m === "PUT") {
        const n = Number(delen[5]);
        if (!Number.isInteger(n) || n < 0 || n >= 200) return fout("Niet gevonden.", 404);
        const b = await leesJson(req, 600000);
        if (!b || !Array.isArray(b.adressen) || b.adressen.length > MAX_DEEL) return fout("Ongeldige adressen.", 400);
        const schoon = b.adressen.map(schoonAdres);
        if (schoon.some((a) => !a)) return fout("Ongeldige adressen.", 400);
        await st.setJSON(`${basis(id, versie)}/adressen/${code}/${n}`, schoon);
        return json({ ok: true, aantal: schoon.length });
      }
      if (wat === "adressen" && m === "GET") {
        const meta = await st.get(`plaatsen/${id}`, { type: "json" });
        if (!meta) return fout("Niet gevonden.", 404);
        const a = await leesAdressen(st, meta, code);
        return a ? json({ adressen: a }) : fout("Niet gevonden.", 404);
      }
      if (wat === "keuze" && m === "PUT") {
        const b = await leesJson(req, 200);
        if (!b || typeof b.aan !== "boolean") return fout("Ongeldige keuze.", 400);
        const k = { aan: b.aan, wie, wanneer: new Date().toISOString() };
        await st.setJSON(`plaats/${id}/keuze/${code}`, k);
        return json(k);
      }
      return fout("Niet gevonden.", 404);
    }

    if (sub === "trilling" && delen[3] && m === "PUT") {
      const pc = String(delen[3]).toUpperCase();
      if (!POSTCODE.test(pc)) return fout("Ongeldige postcode.", 400);
      if (!(await st.get(`plaatsen/${id}`, { type: "json" }))) return fout("Niet gevonden.", 404);
      const b = await leesJson(req, 200);
      if (!b) return fout("Ongeldige waarde.", 400);
      let mms = null;
      if (b.mms !== null && b.mms !== undefined && b.mms !== "") {
        mms = Number(b.mms);
        if (!Number.isFinite(mms) || mms < 0 || mms > 100) return fout("Ongeldige waarde.", 400);
        mms = round(mms, 1);
      }
      const t = { mms, wie, wanneer: new Date().toISOString() };
      await st.setJSON(`plaats/${id}/trilling/${pc}`, t);
      return json(t);
    }

    if (sub === "bezoeken") {
      if (!(await st.get(`plaatsen/${id}`, { type: "json" }))) return fout("Niet gevonden.", 404);
      if (m === "POST") {
        const b = await leesJson(req, 3000);
        const v = schoonBezoek(b, wie);
        if (v.fout) return fout(v.fout, 400);
        const r = await schrijfBezoek(st, id, v.ev);
        return json(r.ev, r.duplicaat ? 200 : 201);
      }
      if (m === "GET") {
        const na = new URL(req.url).searchParams.get("na") || "";
        return json(await leesBezoeken(st, id, na.slice(0, 80)));
      }
    }

    if (sub === "export" && m === "GET") {
      const meta = await st.get(`plaatsen/${id}`, { type: "json" });
      if (!meta) return fout("Niet gevonden.", 404);
      const inst = await leesInstellingen(st, id);
      const buurten = await leesBuurten(st, meta, inst.keuzes);
      const adressen = new Map();
      await parallel(buurten.map((b) => b.code), 5, async (code) => {
        for (const a of (await leesAdressen(st, meta, code)) || []) adressen.set(a.id, a);
      });
      const stand = await volledigeStand(st, id);
      const rijen = maakExportRijen({
        plaats: meta.naam, adressen, buurtNamen: new Map(buurten.map((b) => [b.code, b.naam])), stand,
      });
      // Streamend leveren, in stukken: een grote plaats past anders niet in één antwoord.
      const enc = new TextEncoder();
      const STUK = 500;
      let i = 0;
      const body = new ReadableStream({
        pull(ctl) {
          if (i >= rijen.length) { ctl.close(); return; }
          const deel = rijen.slice(i, i + STUK);
          const tekst = csv(deel).replace(/^\uFEFF/, "");
          ctl.enqueue(enc.encode((i === 0 ? "\uFEFF" : "\r\n") + tekst));
          i += STUK;
        },
      });
      return new Response(body, {
        status: 200,
        headers: {
          ...BASIS_HEADERS,
          "content-type": "text/csv; charset=utf-8",
          "content-disposition": `attachment; filename="deuren-${id}.csv"`,
        },
      });
    }

    return fout("Niet gevonden.", 404);
  } catch (err) {
    return interneFout(err, "deur");
  }
}

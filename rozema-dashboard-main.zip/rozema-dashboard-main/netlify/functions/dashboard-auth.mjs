import { json, fout, interneFout, leesJson } from "./dashboard-lib/antwoord.mjs";
import { zetContext } from "./dashboard-lib/opslag.mjs";
import {
  controleerWachtwoord, maakToken, sessieCookie, wisCookie, vereisSessie,
  clientIp, reserveerPoging, registreerSucces,
  maakApparaatToken, apparaatCookie, controleerApparaatToken, leesCookie, APPARAAT_COOKIE,
} from "./dashboard-lib/sessie.mjs";

export const config = { path: "/api/dashboard/auth/*" };

const ALGEMEEN = "Naam of wachtwoord klopt niet.";

async function inloggen(req) {
  const b = await leesJson(req, 2000);
  if (!b || typeof b.naam !== "string" || typeof b.wachtwoord !== "string"
      || b.naam.length > 50 || b.wachtwoord.length > 200) {
    return fout(ALGEMEEN, 400);
  }
  const ip = clientIp(req);
  const apparaatOk = controleerApparaatToken(leesCookie(req, APPARAAT_COOKIE), b.naam);
  // Eerst reserveren (telt de poging), dan pas het dure pbkdf2.
  const blok = await reserveerPoging(b.naam, ip, process.env, Date.now(), apparaatOk);
  if (blok) {
    return fout("Te veel pogingen. Wacht even en probeer het opnieuw.", 429,
      { "retry-after": String(blok.wachtSeconden) });
  }
  // Altijd een pbkdf2 uitrekenen, ook bij onbekende naam.
  const goed = await controleerWachtwoord(b.naam, b.wachtwoord);
  if (!goed) return fout(ALGEMEEN, 401);
  const token = maakToken(b.naam);
  if (!token) {
    console.error("Sessiegeheim ontbreekt of is te kort");
    return fout("Er ging iets mis. Probeer het zo opnieuw.", 500);
  }
  await registreerSucces(b.naam, ip);
  return json({ naam: b.naam }, 200, {
    "set-cookie": [sessieCookie(token), apparaatCookie(maakApparaatToken(b.naam))],
  });
}

export default async function handler(req, context) {
  try {
    zetContext(context);
    const pad = new URL(req.url).pathname.replace(/\/+$/, "");
    const actie = pad.split("/").pop();
    if (actie === "inloggen" && req.method === "POST") return await inloggen(req);
    if (actie === "uitloggen" && req.method === "POST") {
      return json({ ok: true }, 200, { "set-cookie": wisCookie() });
    }
    if (actie === "ik" && req.method === "GET") {
      const s = vereisSessie(req);
      return s ? json({ naam: s.wie }) : fout("Niet ingelogd.", 401);
    }
    return fout("Niet gevonden.", 404);
  } catch (err) {
    return interneFout(err, "auth");
  }
}

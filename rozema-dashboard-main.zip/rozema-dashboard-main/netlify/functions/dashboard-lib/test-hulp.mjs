// Hulp voor tests (geen test zelf; eindigt niet op .test.mjs).
// In-memory store met dezelfde methodes als een Blobs-store, inclusief etag,
// onlyIfMatch en onlyIfNew (setJSON/set geven {modified, etag}).
export function geheugenStore() {
  const m = new Map();
  let teller = 0;
  const ontleed = (e, opt) => (opt?.type === "json" ? JSON.parse(e.v) : e.v);
  function zet(k, v, opt = {}) {
    const bestaat = m.has(k);
    if (opt.onlyIfNew && bestaat) return { modified: false };
    if (opt.onlyIfMatch !== undefined && (!bestaat || m.get(k).etag !== opt.onlyIfMatch)) {
      return { modified: false };
    }
    const etag = `"e${++teller}"`;
    m.set(k, { v, etag, metadata: opt.metadata || {} });
    return { modified: true, etag };
  }
  return {
    async get(k, opt) { return m.has(k) ? ontleed(m.get(k), opt) : null; },
    async getWithMetadata(k, opt) {
      if (!m.has(k)) return null;
      const e = m.get(k);
      return { data: ontleed(e, opt), etag: e.etag, metadata: e.metadata };
    },
    async set(k, v, opt) { return zet(k, String(v), opt); },
    async setJSON(k, v, opt) { return zet(k, JSON.stringify(v), opt); },
    async delete(k) { m.delete(k); },
    async list({ prefix = "" } = {}) {
      return { blobs: [...m.entries()].filter(([k]) => k.startsWith(prefix)).map(([key, e]) => ({ key, etag: e.etag })) };
    },
  };
}
export function geheugenFabriek() {
  const stores = new Map();
  const fn = (naam) => { if (!stores.has(naam)) stores.set(naam, geheugenStore()); return stores.get(naam); };
  fn.stores = stores;
  return fn;
}

import { test, beforeEach } from "node:test";
import assert from "node:assert/strict";
import { zetStoreFabriek } from "./opslag.mjs";
import { geheugenFabriek } from "./test-hulp.mjs";
import {
  maakWachtwoordHash, controleerWachtwoord, maakToken, controleerToken, vereisSessie,
  sessieCookie, maakApparaatToken, controleerApparaatToken, apparaatCookie, wachttijdMs, reserveerPoging, registreerSucces, GRENS, SESSIE_SECONDEN,
} from "./sessie.mjs";

const GEHEIM = "x".repeat(40);
let env;

beforeEach(async () => {
  zetStoreFabriek(geheugenFabriek());
  env = {
    DASHBOARD_SESSIE_GEHEIM: GEHEIM,
    DASHBOARD_GEBRUIKERS: JSON.stringify({
      Kevin: await maakWachtwoordHash("verzonnen-wachtwoord-a", 1000),
      Ruben: await maakWachtwoordHash("verzonnen-wachtwoord-b", 1000),
    }),
  };
});

test("wachtwoord: goed, fout, onbekende naam, kapotte hash", async () => {
  assert.equal(await controleerWachtwoord("Kevin", "verzonnen-wachtwoord-a", env), true);
  assert.equal(await controleerWachtwoord("Kevin", "verzonnen-wachtwoord-b", env), false);
  assert.equal(await controleerWachtwoord("Piet", "verzonnen-wachtwoord-a", env), false);
  assert.equal(await controleerWachtwoord("__proto__", "x", env), false);
  assert.equal(await controleerWachtwoord("Kevin", 5, env), false);
  const stuk = { ...env, DASHBOARD_GEBRUIKERS: JSON.stringify({ Kevin: "kapot" }) };
  assert.equal(await controleerWachtwoord("Kevin", "x", stuk), false);
});

test("token: rondje, verlopen, versie, geheim, verwijderde gebruiker, geknoei", () => {
  const nu = 1_700_000_000_000;
  const t = maakToken("Kevin", env, nu);
  assert.deepEqual(controleerToken(t, env, nu + 1000), { wie: "Kevin" });
  // verlopen
  assert.equal(controleerToken(t, env, nu + SESSIE_SECONDEN * 1000 + 1), null);
  // verkeerde versie
  assert.equal(controleerToken(t, { ...env, DASHBOARD_SESSIE_VERSIE: "2" }, nu), null);
  // ontbrekend of te kort geheim: maken en controleren weigeren
  assert.equal(maakToken("Kevin", { ...env, DASHBOARD_SESSIE_GEHEIM: undefined }, nu), null);
  assert.equal(maakToken("Kevin", { ...env, DASHBOARD_SESSIE_GEHEIM: "kort" }, nu), null);
  assert.equal(controleerToken(t, { ...env, DASHBOARD_SESSIE_GEHEIM: undefined }, nu), null);
  assert.equal(controleerToken(t, { ...env, DASHBOARD_SESSIE_GEHEIM: "kort" }, nu), null);
  // ander geheim
  assert.equal(controleerToken(t, { ...env, DASHBOARD_SESSIE_GEHEIM: "y".repeat(40) }, nu), null);
  // verwijderde gebruiker
  const zonderKevin = { ...env, DASHBOARD_GEBRUIKERS: JSON.stringify({ Ruben: "pbkdf2$1$AA==$AA==" }) };
  assert.equal(controleerToken(t, zonderKevin, nu), null);
  // geknoei met payload
  const [deel, sig] = t.split(".");
  const vals = Buffer.from(JSON.stringify({ u: "Ruben", exp: 9e9, v: "1" })).toString("base64url");
  assert.equal(controleerToken(`${vals}.${sig}`, env, nu), null);
  assert.equal(controleerToken(`${deel}.`, env, nu), null);
  assert.equal(controleerToken("rommel", env, nu), null);
  assert.equal(controleerToken(undefined, env, nu), null);
});

test("vereisSessie leest de cookie; cookie heeft de juiste vlaggen", () => {
  const t = maakToken("Ruben", env);
  const c = sessieCookie(t);
  for (const v of ["HttpOnly", "Secure", "SameSite=Strict", "Path=/api/dashboard", `Max-Age=${30 * 86400}`]) {
    assert.ok(c.includes(v), v);
  }
  const req = new Request("https://x.test/api/dashboard/ik", { headers: { cookie: `a=b; dashboard_sessie=${t}` } });
  assert.deepEqual(vereisSessie(req, env), { wie: "Ruben" });
  assert.equal(vereisSessie(new Request("https://x.test/"), env), null);
});

test("wachttijd loopt op en is begrensd op 15 minuten (naam: 1 minuut)", () => {
  assert.equal(wachttijdMs(4), 0);
  assert.equal(wachttijdMs(5), 60_000);
  assert.equal(wachttijdMs(6), 120_000);
  assert.equal(wachttijdMs(8), 480_000);
  assert.equal(wachttijdMs(50), 15 * 60_000);
  assert.equal(wachttijdMs(50, 5, 1), 60_000);
});

const poging = (naam, ip, nu, apparaat = false) => reserveerPoging(naam, ip, env, nu, apparaat);

test("inlogbeperking: blokkade na 5 pogingen, ander IP blijft vrij, succes zet terug", async () => {
  const nu = 1_700_000_000_000;
  for (let i = 0; i < GRENS; i++) assert.equal(await poging("Kevin", "1.1.1.1", nu), null, `poging ${i + 1}`);
  const blok = await poging("Kevin", "1.1.1.1", nu + 1000);
  assert.ok(blok && blok.wachtSeconden > 0 && blok.wachtSeconden <= 60);
  // de echte gebruiker vanaf een ander IP wordt niet buitengesloten
  assert.equal(await poging("Kevin", "2.2.2.2", nu + 1000), null);
  // na de wachttijd weer toegestaan
  assert.equal(await poging("Kevin", "1.1.1.1", nu + 61_000), null);
  // succes zet de IP+naam-teller terug
  await registreerSucces("Kevin", "1.1.1.1", env);
  assert.equal(await poging("Kevin", "1.1.1.1", nu + 62_000), null);
});

test("parallel: van 10 gelijktijdige pogingen komen hoogstens GRENS door", async () => {
  const nu = 1_700_000_000_000;
  const uitkomsten = await Promise.all(Array.from({ length: 10 }, () => poging("Kevin", "1.1.1.1", nu)));
  const door = uitkomsten.filter((u) => u === null).length;
  assert.ok(door >= 1 && door <= GRENS, `door: ${door}`);
  assert.equal(uitkomsten.filter((u) => u !== null).length, 10 - door);
});

test("inlogbeperking: onbekende namen tellen op IP en doen dezelfde acties op dummysleutels", async () => {
  const f = geheugenFabriek();
  zetStoreFabriek(f);
  const nu = 1_700_000_000_000;
  for (let i = 0; i < GRENS; i++) await poging("Piet", "3.3.3.3", nu);
  const sleutels = (await f("dashboard-test-auth").list()).blobs.map((b) => b.key).sort();
  assert.deepEqual(sleutels, ["dummy/combi", "dummy/naam", "ip/3.3.3.3"]);
  assert.ok(await poging("Kevin", "3.3.3.3", nu + 1));
  // een dummyteller blokkeert nooit: ander IP, andere onbekende naam
  assert.equal(await poging("Piet", "4.4.4.4", nu + 1), null);
});

test("naamteller is een zachte vertraging: nooit langer dan 1 minuut, ook op een nieuw apparaat", async () => {
  const nu = 1_700_000_000_000;
  // 40 pogingen vanaf steeds een ander IP
  for (let i = 0; i < 40; i++) await poging("Ruben", `9.9.9.${i}`, nu);
  const blok = await poging("Ruben", "8.8.8.8", nu + 1);
  assert.ok(blok && blok.wachtSeconden <= 60, JSON.stringify(blok));
  assert.equal(await poging("Ruben", "8.8.8.8", nu + 61_000), null);
  // met apparaat-cookie telt de naamteller niet mee
  assert.equal(await poging("Ruben", "8.8.8.9", nu + 1, true), null);
  // de IP-teller blijft gelden, ook met apparaat-cookie
  for (let i = 0; i < GRENS; i++) await poging("Ruben", "7.7.7.7", nu + 120_000, true);
  assert.ok(await poging("Ruben", "7.7.7.7", nu + 120_001, true));
});

test("apparaat-token: geldig voor eigen naam, niet voor andere naam, niet als sessie", () => {  const nu = 1_700_000_000_000;
  const a = maakApparaatToken("Kevin", env, nu);
  assert.equal(controleerApparaatToken(a, "Kevin", env, nu + 1000), true);
  assert.equal(controleerApparaatToken(a, "Ruben", env, nu + 1000), false);
  assert.equal(controleerToken(a, env, nu + 1000), null);
  assert.equal(controleerApparaatToken(maakToken("Kevin", env, nu), "Kevin", env, nu), false);
  assert.equal(controleerApparaatToken(a, "Kevin", env, nu + 366 * 86400 * 1000), false);
  assert.equal(controleerApparaatToken(a, "Kevin", { ...env, DASHBOARD_SESSIE_VERSIE: "2" }, nu), false);
  assert.equal(controleerApparaatToken(a, "Kevin", { ...env, DASHBOARD_SESSIE_GEHEIM: undefined }, nu), false);
  assert.equal(controleerApparaatToken(undefined, "Kevin", env, nu), false);
  const c = apparaatCookie(a);
  for (const v of ["HttpOnly", "Secure", "SameSite=Strict", "Path=/api/dashboard/auth", `Max-Age=${365 * 86400}`]) assert.ok(c.includes(v), v);
});

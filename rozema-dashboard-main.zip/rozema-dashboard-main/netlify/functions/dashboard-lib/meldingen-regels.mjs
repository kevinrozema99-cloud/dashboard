// Validatie voor meldingen.
export const SOORTEN = ["wens", "fout"];
export const STATUSSEN = ["nieuw", "opgepakt", "klaar"];
export const MAX_TEKST = 2000;
export const MAX_SCHERM = 200;

const schoon = (s) => String(s).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, "").trim();

// Geeft {waarde} of {fout}.
export function valideerNieuweMelding(b) {
  if (!b || typeof b !== "object") return { fout: "Ongeldig verzoek." };
  if (typeof b.id !== "string" || !ID_PATROON.test(b.id)) return { fout: "Id klopt niet." };
  if (typeof b.tekst !== "string" || !schoon(b.tekst)) return { fout: "Tekst ontbreekt." };
  const tekst = schoon(b.tekst);
  if (tekst.length > MAX_TEKST) return { fout: "Tekst is te lang." };
  if (!SOORTEN.includes(b.soort)) return { fout: "Soort klopt niet." };
  if (typeof b.scherm !== "string" || !b.scherm.startsWith("/") || b.scherm.length > MAX_SCHERM) {
    return { fout: "Scherm klopt niet." };
  }
  const scherm = schoon(b.scherm);
  const i = b.info && typeof b.info === "object" && !Array.isArray(b.info) ? b.info : {};
  const breedte = Number.isFinite(i.breedte) ? Math.max(0, Math.min(10000, Math.round(i.breedte))) : null;
  const versie = typeof i.versie === "string" ? schoon(i.versie).slice(0, 40) : null;
  return { waarde: { id: b.id, scherm, tekst, soort: b.soort, info: { breedte, versie } } };
}

export function valideerStatus(b) {
  if (!b || typeof b !== "object" || !STATUSSEN.includes(b.status)) {
    return { fout: "Status klopt niet." };
  }
  return { waarde: { status: b.status } };
}

// Het id wordt door de browser gemaakt (crypto.randomUUID, versie 4), zodat een
// herhaald verzoek niet twee meldingen oplevert.
export const ID_PATROON = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;

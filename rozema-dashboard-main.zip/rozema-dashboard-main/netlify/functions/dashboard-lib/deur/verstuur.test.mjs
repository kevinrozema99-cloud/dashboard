import { test } from "node:test";
import assert from "node:assert/strict";
import { verstuurWachtrij, isTijdelijk } from "../../../../public/dashboard/deur/verstuur.js";

function omgeving(items, antwoorden, extra = {}) {
  const db = new Map(items.map((x) => [x.id, { ...x }]));
  const verstuurd = [];
  let inlogGevraagd = 0;
  const o = {
    alle: async () => [...db.values()],
    verwijder: async (id) => { db.delete(id); },
    zet: async (item) => { if (extra.zetFaalt) throw new Error("vol"); db.set(item.id, { ...item }); },
    api: async (pad, opt) => { verstuurd.push(opt.body.id); return antwoorden.shift(); },
    vraagInlog: async () => { inlogGevraagd++; return extra.inlogLukt !== false; },
    geheugen: extra.geheugen || [],
    ...(extra.wie ? { wie: () => extra.wie } : {}),
  };
  return { o, db, verstuurd, inlog: () => inlogGevraagd };
}
const item = (id, t, extra = {}) => ({ id, plaats: "p", ev: { id, a: "h1", st: "nietthuis" }, toegevoegd: t, ...extra });
const ok = { ok: true, status: 201, data: { k: "x" } };

test("alles gelukt: wachtrij leeg", async () => {
  const e = omgeving([item("a0000001", 1), item("b0000001", 2)], [ok, ok]);
  const r = await verstuurWachtrij(e.o);
  assert.equal(r.verstuurd, 2);
  assert.equal(e.db.size, 0);
});

test("timeout, 429 en 5xx: niets weggegooid, stopt en probeert later", async () => {
  for (const status of [0, 408, 429, 500, 503]) {
    const e = omgeving([item("a0000001", 1), item("b0000001", 2)], [{ ok: false, status, data: null }]);
    const r = await verstuurWachtrij(e.o);
    assert.equal(r.gestopt, "tijdelijk", String(status));
    assert.equal(e.db.size, 2);
    assert.deepEqual(e.verstuurd, ["a0000001"]);
  }
});

test("401: om inloggen vragen, daarna hetzelfde bezoek opnieuw versturen", async () => {
  const e = omgeving([item("a0000001", 1)], [{ ok: false, status: 401, data: { fout: "Niet ingelogd." } }, ok]);
  const r = await verstuurWachtrij(e.o);
  assert.equal(e.inlog(), 1);
  assert.equal(r.verstuurd, 1);
  assert.equal(e.db.size, 0);
  assert.deepEqual(e.verstuurd, ["a0000001", "a0000001"]);
});

test("401 en niet inloggen: bezoek blijft bewaard; blijvende 401 na inloggen loopt niet eindeloos", async () => {
  const e1 = omgeving([item("a0000001", 1)], [{ ok: false, status: 401, data: null }], { inlogLukt: false });
  assert.equal((await verstuurWachtrij(e1.o)).gestopt, "inlog");
  assert.equal(e1.db.size, 1);
  const e2 = omgeving([item("a0000001", 1)], Array.from({ length: 10 }, () => ({ ok: false, status: 401, data: null })));
  assert.equal((await verstuurWachtrij(e2.o)).gestopt, "inlog");
  assert.ok(e2.verstuurd.length <= 3);
  assert.equal(e2.db.size, 1);
});

test("invoerfout: afgekeurd en bewaard, de rest gaat door; 404 zonder melding is tijdelijk", async () => {
  const e = omgeving([item("a0000001", 1), item("b0000001", 2)], [{ ok: false, status: 400, data: { fout: "Ongeldig bezoek." } }, ok]);
  const gemeld = [];
  e.o.naAfgekeurd = (i) => gemeld.push(i.id);
  const r = await verstuurWachtrij(e.o);
  assert.equal(r.verstuurd, 1);
  assert.equal(e.db.get("a0000001").afgekeurd, "Ongeldig bezoek.");
  assert.deepEqual(gemeld, ["a0000001"]);
  assert.ok(isTijdelijk({ status: 404, data: null }));
  assert.ok(!isTijdelijk({ status: 404, data: { fout: "Niet gevonden." } }));
  const e2 = omgeving([item("c0000001", 1, { afgekeurd: "x" })], []);
  assert.equal((await verstuurWachtrij(e2.o)).verstuurd, 0);
  assert.equal(e2.verstuurd.length, 0);
});

test("bezoek dat alleen in het geheugen stond (opslaan mislukt) wordt toch verstuurd", async () => {
  const e = omgeving([], [ok], { geheugen: [item("m0000001", 1)] });
  const r = await verstuurWachtrij(e.o);
  assert.equal(r.verstuurd, 1);
  assert.deepEqual(e.verstuurd, ["m0000001"]);
  const e2 = omgeving([], [ok], { geheugen: [item("m0000002", 1)], zetFaalt: true });
  assert.equal((await verstuurWachtrij(e2.o)).verstuurd, 1);
});

test("alleen eigen items worden verstuurd; een item van een ander blijft staan", async () => {
  const e = omgeving([item("a0000001", 1, { wie: "Kevin" }), item("b0000001", 2, { wie: "Ruben" }), item("c0000001", 3, { wie: "Kevin" })], [ok, ok], { wie: "Kevin" });
  const r = await verstuurWachtrij(e.o);
  assert.equal(r.verstuurd, 2);
  assert.deepEqual(e.verstuurd, ["a0000001", "c0000001"]);
  assert.deepEqual([...e.db.keys()], ["b0000001"]);
});

test("item zonder wie of zonder bekende gebruiker wordt niet tegengehouden", async () => {
  const e1 = omgeving([item("a0000001", 1)], [ok], { wie: "Kevin" });
  assert.equal((await verstuurWachtrij(e1.o)).verstuurd, 1);
  const e2 = omgeving([item("a0000001", 1, { wie: "Ruben" })], [ok]);
  assert.equal((await verstuurWachtrij(e2.o)).verstuurd, 1);
});

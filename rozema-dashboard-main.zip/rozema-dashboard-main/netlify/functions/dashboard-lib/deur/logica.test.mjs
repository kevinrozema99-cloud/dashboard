import { test } from "node:test";
import assert from "node:assert/strict";
import * as L from "../../../../public/dashboard/deur/logica.js";

// Verzonnen straten en nummers.
const vbo = (over = {}) => ({
  type: "Feature", id: "feat-1",
  geometry: { type: "Point", coordinates: [6.5, 53.3] },
  properties: {
    identificatie: "0000000000000001", openbare_ruimte_naam: "Teststraat", huisnummer: 4, huisletter: null,
    toevoeging: null, postcode: "9999 ZZ", gebruiksdoel: "woonfunctie", status: "Verblijfsobject in gebruik",
    oppervlakte: 100, "pand.href": ["https://api.pdok.nl/kadaster/bag/ogc/v2/collections/pand/items/AAAAAAAA-1111-2222-3333-444444444444"],
    ...over,
  },
});
const blok = (x0, x1) => ({ type: "Polygon", coordinates: [[[x0, 0], [x1, 0], [x1, 1], [x0, 1], [x0, 0]]] });

test("pand-koppeling via uuid uit pand.href", () => {
  const a = L.vboNaarAdres(vbo());
  assert.equal(a.pand, "aaaaaaaa-1111-2222-3333-444444444444");
  assert.equal(a.pc, "9999ZZ");
  assert.equal(L.pandUuid({ "pand.href": "https://x/y/abcd1234-aa?f=json" }), "abcd1234-aa");
  assert.equal(L.pandUuid({}), "");
  assert.equal(L.pandUuid({ "pand.href": ["niet een url met spaties"] }), "");
  const panden = [L.pandNaarInfo({ id: "AAAAAAAA-1111-2222-3333-444444444444", properties: { bouwjaar: 1935, aantal_verblijfsobjecten: 1 }, geometry: blok(0, 1) })];
  const adressen = [a];
  assert.equal(L.koppelPanden(adressen, panden), 1);
  assert.equal(adressen[0].bj, 1935);
  assert.equal(adressen[0].ty, "vrijstaand");
});

test("woningtype uit pandvormen", () => {
  const p = (id, x0, x1, aantal = 1) => ({ id, aantal, bj: 2000, geometry: blok(x0, x1) });
  const t = L.woningtypen([p("a", 0, 1), p("b", 1, 2), p("c", 2, 3), p("d", 10, 11), p("e", 20, 21, 4), p("f", 30, 31), p("g", 31, 32)]);
  assert.equal(t.d, "vrijstaand");
  assert.equal(t.e, "appartement");
  assert.equal(t.f, "2-onder-1-kap");
  assert.equal(t.b, "rij");
  assert.equal(t.a, "2-onder-1-kap"); // hoekhuis in rij: bekende beperking
});

test("isWoning en punt in veelhoek", () => {
  assert.ok(L.isWoning(vbo().properties));
  assert.ok(!L.isWoning(vbo({ gebruiksdoel: "kantoorfunctie" }).properties));
  assert.ok(!L.isWoning(vbo({ status: "Verblijfsobject buiten gebruik" }).properties));
  const gat = { type: "Polygon", coordinates: [[[0, 0], [10, 0], [10, 10], [0, 10], [0, 0]], [[4, 4], [6, 4], [6, 6], [4, 6], [4, 4]]] };
  assert.ok(L.puntInGeometrie(2, 2, gat));
  assert.ok(!L.puntInGeometrie(5, 5, gat));
  assert.ok(!L.puntInGeometrie(11, 5, gat));
  assert.ok(L.puntInGeometrie(20.5, 0.5, { type: "MultiPolygon", coordinates: [[blok(0, 1).coordinates[0]], [blok(20, 21).coordinates[0]]] }));
});

test("buurtcijfers: negatief of ontbrekend is onbekend, nul blijft nul", () => {
  assert.deepEqual(L.buurtCijfers({ percentage_koopwoningen: 84, perc_huurwoningen_in_bezit_woningcorporaties: 0, woningvoorraad: 99 }),
    { koop: 84, corp: 0, woningen: 99 });
  assert.deepEqual(L.buurtCijfers({ percentage_koopwoningen: -99997, perc_huurwoningen_in_bezit_woningcorporaties: -99997, woningvoorraad: -99997 }),
    { koop: null, corp: null, woningen: null });
  assert.deepEqual(L.buurtCijfers({}), { koop: null, corp: null, woningen: null });
  assert.equal(L.standaardAan(null), true);
  assert.equal(L.standaardAan(0), true);
  assert.equal(L.standaardAan(39), true);
  assert.equal(L.standaardAan(40), false);
});

test("koppelBuurten: buurtcode, onbekend en overig", () => {
  const adr = [{ x: 0.5, y: 0.5, bu: "" }, { x: 5.5, y: 0.5, bu: "" }, { x: 99, y: 99, bu: "" }];
  const f = [
    { geometry: blok(0, 1), properties: { buurtcode: "BU1", buurtnaam: "Noord", percentage_koopwoningen: 50, perc_huurwoningen_in_bezit_woningcorporaties: 45, woningvoorraad: 20 } },
    { geometry: blok(5, 6), properties: { buurtcode: "BU2", buurtnaam: "Zuid", percentage_koopwoningen: -99997, perc_huurwoningen_in_bezit_woningcorporaties: -99997, woningvoorraad: 5 } },
  ];
  const b = L.koppelBuurten(adr, f);
  assert.deepEqual(adr.map((a) => a.bu), ["BU1", "BU2", "overig"]);
  assert.equal(b.find((x) => x.code === "BU2").corp, null);
  assert.equal(b.find((x) => x.code === "BU1").corp, 45);
  assert.equal(b.find((x) => x.code === "overig").naam, "overig");
});

test("straatrang: trilling, type en klant", () => {
  const mk = (id, pc, ty, bj = 1980) => ({ id, pc, ty, bj, n: 1 });
  const trilling = { "1111AA": { mms: 9 }, "2222BB": { mms: 6 } };
  const hoog = L.straatRang([mk("a", "1111AA", "rij")], trilling, {});
  const laag = L.straatRang([mk("b", "2222BB", "vrijstaand")], trilling, {});
  assert.equal(hoog.voorrang, 1);
  assert.equal(laag.voorrang, 0);
  assert.equal(L.straatRang([mk("c", "3333CC", "rij")], trilling, {}).onbekend, 1);
  assert.equal(L.trillingKlasse({ pc: "2222BB", bj: 1930 }, trilling), 2); // vóór 1940: drempel 5 mm/s
  assert.equal(L.trillingKlasse({ pc: "2222BB", bj: 1980 }, trilling), 1);
  const stand = {};
  L.pasToe(stand, { id: "ev000001", a: "b", st: "afspraak", ts: "2026-01-01T10:00:00Z", w: "A" });
  assert.equal(L.straatRang([mk("b", "2222BB", "vrijstaand")], trilling, stand).klant, true);
  const s = L.sorteerStraten([
    { naam: "B", rang: laag }, { naam: "A", rang: { ...hoog, type: 2 } },
  ]);
  assert.equal(s[0].naam, "A");
});

test("pasToe: dubbel id, ongedaan maken op id, volgorde", () => {
  const stand = {};
  L.pasToe(stand, { id: "aaaaaaaa", a: "x", st: "nietthuis", ts: "2026-01-01T10:00:00Z", w: "K", wacht: true });
  L.pasToe(stand, { id: "aaaaaaaa", a: "x", st: "nietthuis", ts: "2026-01-01T10:00:00Z", w: "K", wacht: true });
  assert.equal(stand.x.hist.length, 1);
  assert.equal(stand.x.hist[0].wacht, true);
  L.pasToe(stand, { id: "aaaaaaaa", a: "x", st: "nietthuis", ts: "2026-01-01T10:00:00Z", w: "K", k: "00000000000010-aaaaaaaa" });
  assert.equal(stand.x.hist[0].wacht, false);
  L.pasToe(stand, { id: "bbbbbbbb", a: "x", st: "gesprek", ts: "2026-01-01T09:00:00Z", w: "R", wacht: true });
  // wachtend bezoek komt na bezoeken met serversleutel, ook met eerdere telefoontijd
  assert.equal(L.huidige(stand.x).id, "bbbbbbbb");
  // ongedaan maken verwijst naar id van het bezoek, niet naar "het laatste"
  L.pasToe(stand, { id: "cccccccc", a: "x", st: null, ongedaan: "aaaaaaaa", ts: "2026-01-01T11:00:00Z", w: "R", wacht: true });
  assert.deepEqual(L.effectief(stand.x.hist).map((h) => h.id), ["bbbbbbbb"]);
  L.pasToe(stand, { id: "dddddddd", a: "x", st: null, ongedaan: "bbbbbbbb", ts: "2026-01-01T12:00:00Z", w: "R" });
  assert.equal(L.huidige(stand.x), null);
  // ongedaan vóór het bezoek aankomt werkt ook
  const s2 = {};
  L.pasToe(s2, { id: "eeeeeeee", a: "y", st: null, ongedaan: "ffffffff", ts: "2026-01-01T12:00:00Z", w: "R" });
  L.pasToe(s2, { id: "ffffffff", a: "y", st: "gesprek", ts: "2026-01-01T11:00:00Z", w: "R" });
  assert.equal(L.huidige(s2.y), null);
});

test("volgende huis: zelfde kant omhoog, dan overkant terug", () => {
  const adr = [1, 2, 3, 4, 5, 6].map((n) => ({ id: "h" + n, n, l: "", t: "" }));
  const stand = {};
  assert.equal(L.volgendeHuis(adr, adr[0], stand).n, 3);
  L.pasToe(stand, { id: "aaaaaaaa", a: "h3", st: "nietthuis", ts: "2026-01-01T10:00:00Z", w: "K" });
  assert.equal(L.volgendeHuis(adr, adr[0], stand).n, 5);
  assert.equal(L.volgendeHuis(adr, adr[4], stand).n, 6); // overkant, hoogste eerst
  L.pasToe(stand, { id: "bbbbbbbb", a: "h5", st: "nietthuis", ts: "2026-01-01T10:00:00Z", w: "K" });
  assert.equal(L.volgendeHuis(adr, adr[2], stand).n, 6);
  for (const n of [2, 4, 6]) L.pasToe(stand, { id: "x0000000" + n, a: "h" + n, st: "nietthuis", ts: "2026-01-01T10:00:00Z", w: "K" });
  assert.equal(L.volgendeHuis(adr, adr[2], stand), null);
});

test("dichtstbij", () => {
  const adr = [{ id: "a", x: 6.5, y: 53.3 }, { id: "b", x: 6.6, y: 53.3 }];
  assert.equal(L.dichtstbij(adr, 53.30001, 6.50001, {}).adres.id, "a");
  assert.equal(L.dichtstbij(adr, 53.5, 6.9, {}), null);
});

test("csv: formule-injectie, aanhalingstekens en getallen", () => {
  const uit = L.csv([["a", "=1+1", "+x", "-x", "@x", "\tx", 5, -3, null, 'ei"nd', "a;b", "regel\nbreuk"]]);
  assert.equal(uit, '﻿a;\'=1+1;\'+x;\'-x;\'@x;\'\tx;5;-3;;"ei""nd";"a;b";"regel\nbreuk"');
  assert.equal(L.celVeilig("gewoon"), "gewoon");
});

test("maakExportRijen: per bezoek, zonder ongedaan gemaakte, met verrijking", () => {
  const stand = {};
  L.pasToe(stand, { id: "aaaaaaaa", a: "h1", st: "nietthuis", ts: "2026-01-01T10:00:00.000Z", w: "Kevin", k: "00000000000001-aaaaaaaa", bu: "BU1", ty: "rij", bj: 1950, mms: 7.5, koop: 80, corp: 10, no: "=cmd" });
  L.pasToe(stand, { id: "bbbbbbbb", a: "h1", st: "gesprek", ts: "2026-01-01T11:00:00.000Z", w: "Ruben", k: "00000000000002-bbbbbbbb" });
  L.pasToe(stand, { id: "cccccccc", a: "h1", st: null, ongedaan: "bbbbbbbb", ts: "2026-01-01T11:01:00.000Z", w: "Ruben", k: "00000000000003-cccccccc" });
  const rijen = L.maakExportRijen({
    plaats: "Testdorp", adressen: new Map([["h1", { id: "h1", s: "Teststraat", n: 4, l: "", t: "", pc: "9999ZZ", bu: "BU1" }]]),
    buurtNamen: new Map([["BU1", "Noord"]]), stand,
  });
  assert.equal(rijen.length, 2);
  assert.deepEqual(rijen[0], L.EXPORT_KOLOMMEN);
  assert.equal(rijen[1][2], "Noord");
  assert.equal(rijen[1][12], 7.5);
  assert.ok(L.csv(rijen).includes("'=cmd"));
});

test("plaatsLabels: geen overlap, alternatieve positie, vaste items", () => {
  const items = [
    { id: "a", w: 40, h: 30, prio: 1, posities: [{ x: 100, y: 100 }] },
    { id: "b", w: 40, h: 30, prio: 1, posities: [{ x: 110, y: 100 }] },
    { id: "s", w: 100, h: 20, prio: 0, posities: [{ x: 105, y: 100 }, { x: 105, y: 160 }] },
  ];
  const { keuze, bezet } = L.plaatsLabels(items);
  assert.equal(keuze.get("a"), 0);
  assert.equal(keuze.get("b"), null); // raakt a
  assert.equal(keuze.get("s"), 1); // eerste plek bezet, tweede vrij
  assert.equal(bezet.length, 2);
  const vast = L.plaatsLabels([
    { id: "d1", w: 14, h: 14, prio: 1, vast: true, posities: [{ x: 0, y: 0 }] },
    { id: "d2", w: 14, h: 14, prio: 1, vast: true, posities: [{ x: 1, y: 1 }] },
    { id: "t", w: 30, h: 20, prio: 0, posities: [{ x: 0, y: 0 }] },
  ]);
  assert.equal(vast.keuze.get("d2"), 0);
  assert.equal(vast.keuze.get("t"), null);
  // geen enkel paar geplaatste labels overlapt
  for (let i = 0; i < bezet.length; i++) for (let j = i + 1; j < bezet.length; j++) {
    const p = bezet[i], q = bezet[j];
    assert.ok(!(p.x < q.x + q.w && q.x < p.x + p.w && p.y < q.y + q.h && q.y < p.y + p.h));
  }
});

test("schoonBezoek: validatie en begrenzen van telefoontijd", () => {
  const nu = Date.parse("2026-06-01T12:00:00Z");
  const basis = { id: "abcd1234", a: "0000000000000001", st: "nietthuis", ts: "2026-06-01T11:59:00Z", no: "terug na 17:00", bu: "BU1", ty: "rij", bj: 1950, mms: 7.26, koop: 80.4, corp: 9, pc: "9999 zz" };
  const { ev } = L.schoonBezoek(basis, "Kevin", nu);
  assert.equal(ev.w, "Kevin");
  assert.equal(ev.mms, 7.3);
  assert.equal(ev.koop, 80);
  assert.equal(ev.pc, "9999ZZ");
  assert.equal(L.schoonBezoek({ ...basis, ts: "2030-01-01T00:00:00Z" }, "K", nu).ev.ts, new Date(nu + L.TS_TOEKOMST_MS).toISOString());
  assert.equal(L.schoonBezoek({ ...basis, ts: "2020-01-01T00:00:00Z" }, "K", nu).ev.ts, new Date(nu - L.TS_VERLEDEN_MS).toISOString());
  assert.equal(L.schoonBezoek({ ...basis, ts: "onzin" }, "K", nu).ev.ts, new Date(nu).toISOString());
  for (const slecht of [null, {}, { ...basis, id: "x" }, { ...basis, a: "../x" }, { ...basis, st: "anders" }, { ...basis, st: undefined },
    { ...basis, st: undefined, ongedaan: basis.id }]) {
    assert.ok(L.schoonBezoek(slecht, "K", nu).fout, JSON.stringify(slecht));
  }
  const u = L.schoonBezoek({ id: "abcd1234", a: "h1", ongedaan: "zzzz9999" }, "K", nu).ev;
  assert.equal(u.st, null);
  assert.equal(u.ongedaan, "zzzz9999");
  assert.equal(L.schoonBezoek({ ...basis, bu: "../x", ty: "kasteel", mms: 500, bj: 5 }, "K", nu).ev.mms, null);
});

test("handmatig adres: lange straatnaam kapt het nummer niet af", () => {
  const lang = "Heel lange straatnaam die nooit in een identificatie past want te lang";
  const a = L.handmatigId(lang, "12");
  const b = L.handmatigId(lang, "14");
  assert.notEqual(a, b);
  assert.ok(a.endsWith("-12"));
  assert.ok(L.ADRES_ID.test(a));
});

test("schoonAdres", () => {
  assert.equal(L.schoonAdres({ id: "../x" }), null);
  const a = L.schoonAdres({ id: "0000000000000001", s: "Teststraat", n: "4", pc: "9999zz", x: 6.5, y: 53.3, ty: "rij", bu: "BU1" });
  assert.equal(a.n, 4);
  assert.equal(a.pc, "9999ZZ");
  assert.equal(L.schoonAdres({ id: "a1", ty: "raar", bu: "" }).bu, "overig");
});

test("tegelBboxen: alleen vakken met adressen, met marge", () => {
  const adr = [{ x: 6.5001, y: 53.3001 }, { x: 6.5002, y: 53.3002 }, { x: 6.6, y: 53.4 }, { x: null, y: null }];
  const t = L.tegelBboxen(adr, 0.004, 0.0005);
  assert.equal(t.length, 2);
  const [w, s, o, n] = t[0];
  assert.ok(w < 6.5001 && o > 6.5002 && s < 53.3001 && n > 53.3002);
  assert.ok(o - w < 0.006);
});

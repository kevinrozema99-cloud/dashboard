// K10: koppeling deur en klanten, kant van de browser. Alleen verzonnen adressen.
import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import vm from "node:vm";
import * as L from "../../../../public/dashboard/deur/logica.js";

const adres = (o = {}) => ({ id: "0000000000000001", s: "Teststraat", n: 4, l: "A", t: "2", pc: "9999ZZ", bj: 1960, ...o });

test("klantVoorstel: velden voor het nieuw-klant-scherm", () => {
  const v = L.klantVoorstel(adres(), "Plaatsa", "plaatsa", 4.2);
  assert.deepEqual(v, {
    straat: "Teststraat", huisnummer: "4", toevoeging: "A-2", postcode: "9999 ZZ", plaats: "Plaatsa",
    bagId: "0000000000000001", bouwjaar: 1960, trillingMms: 4.2, plaatsId: "plaatsa", adresId: "0000000000000001",
  });
});

test("klantVoorstel: handmatig adres zonder BAG-id of nummer geeft lege velden, geen foute", () => {
  const v = L.klantVoorstel(adres({ id: "straat-12b", n: 0, l: "", t: "", pc: "", bj: null }), "", "plaatsa", null);
  assert.equal(v.bagId, "");
  assert.equal(v.huisnummer, "");
  assert.equal(v.toevoeging, "");
  assert.equal(v.postcode, "");
  assert.equal(v.bouwjaar, "");
  assert.equal(v.trillingMms, "");
  assert.equal(v.adresId, "straat-12b");
  assert.equal(L.klantVoorstel(adres({ n: 1234567 }), "P", "p", null).huisnummer, "");
  assert.equal(L.klantVoorstel(adres({ l: "ABCDEFGH", t: "12345" }), "P", "p", null).toevoeging.length, 10);
});

test("straatRang: klant in de straat volgens de klantenmodule telt mee, ook zonder afspraak in de bezoeken", () => {
  const a = [adres()];
  assert.equal(L.straatRang(a, {}, {}).klant, false);
  assert.equal(L.straatRang(a, {}, {}, true).klant, true);
  assert.equal(L.straatRang(a, {}, {}, "ja").klant, false); // alleen echt true
  const stand = { [a[0].id]: { hist: [{ id: "abcdefgh1", a: a[0].id, st: "afspraak", ts: "2026-11-10T10:00:00Z", w: "Kevin" }] } };
  assert.equal(L.straatRang(a, {}, stand).klant, true);
});

test("sorteerStraten: straat met klant komt voor een gelijke straat zonder klant", () => {
  const rang = { voorrang: 0, type: 2, onbekend: 0 };
  const lijst = [{ naam: "Aa", rang: { ...rang, klant: false } }, { naam: "Bb", rang: { ...rang, klant: true } }];
  assert.deepEqual(L.sorteerStraten(lijst).map((s) => s.naam), ["Bb", "Aa"]);
});

// ---------- deurlink.js (relatiepagina) ----------
function laadDeurlink(query) {
  const bron = readFileSync(new URL("../../../../public/dashboard/klanten/deurlink.js", import.meta.url), "utf8");
  const elementen = { deurbezoeken: { hidden: true }, deurlink: { href: null, setAttribute(k, w) { this[k] = w; } } };
  const venster = {};
  vm.runInNewContext(bron, {
    window: Object.assign(venster, { Dashboard: { api: async () => ({ ok: false }) }, Wachtrij: { kv: { get: async () => null } }, Bewerk: { query: () => query } }),
    document: { addEventListener() {}, getElementById: (id) => elementen[id] },
  });
  return { link: venster.DeurLink, elementen };
}

test("deurHref: alleen met geldige plaats en adres uit herkomst.deur", () => {
  const { link } = laadDeurlink("r_a1");
  assert.equal(link.deurHref({ herkomst: { deur: { eventId: "abcdefgh1", plaats: "plaatsa", adres: "0000000000000001" } } }),
    "/dashboard/deur/?plaats=plaatsa&adres=0000000000000001");
  assert.equal(link.deurHref({ herkomst: { deur: { eventId: "abcdefgh1" } } }), null); // ouder bezoek zonder adres
  assert.equal(link.deurHref({ herkomst: { website: { op: "x" } } }), null);
  assert.equal(link.deurHref({}), null);
  assert.equal(link.deurHref(null), null);
  assert.equal(link.deurHref({ herkomst: { deur: { plaats: "a&b=1", adres: "x" } } }), null);
  assert.equal(link.deurHref({ herkomst: { deur: { plaats: "a", adres: "../x" } } }), null);
});

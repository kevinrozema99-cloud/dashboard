import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import handler from "../../dashboard-deur.mjs";
import { zetStoreFabriek, store } from "../opslag.mjs";
import { geheugenFabriek } from "../test-hulp.mjs";
import { maakToken, COOKIE_NAAM } from "../sessie.mjs";
import { samenvatten, leesBezoeken, schrijfBezoek, alleBezoeken, pad14, SAMENVAT_NA } from "./server.mjs";
import { schoonBezoek, vouwIn, entryNaarHist, effectief } from "../../../../public/dashboard/deur/logica.js";

const oud = { g: process.env.DASHBOARD_SESSIE_GEHEIM, u: process.env.DASHBOARD_GEBRUIKERS };
let fabriek;
before(() => {
  process.env.DASHBOARD_SESSIE_GEHEIM = "x".repeat(40);
  process.env.DASHBOARD_GEBRUIKERS = JSON.stringify({ Kevin: "pbkdf2$1$a$b", Ruben: "pbkdf2$1$a$b" });
  fabriek = geheugenFabriek();
  zetStoreFabriek(fabriek);
});
after(() => {
  zetStoreFabriek(null);
  if (oud.g === undefined) delete process.env.DASHBOARD_SESSIE_GEHEIM; else process.env.DASHBOARD_SESSIE_GEHEIM = oud.g;
  if (oud.u === undefined) delete process.env.DASHBOARD_GEBRUIKERS; else process.env.DASHBOARD_GEBRUIKERS = oud.u;
});

const BASIS = "https://example.test/api/dashboard/deur/";
async function vraag(pad, { methode = "GET", body, wie = "Kevin", zonderSessie = false } = {}) {
  const headers = {};
  if (!zonderSessie) headers.cookie = `${COOKIE_NAAM}=${maakToken(wie)}`;
  if (body !== undefined) headers["content-type"] = "application/json";
  const r = await handler(new Request(BASIS + pad, { method: methode, headers, body: body !== undefined ? JSON.stringify(body) : undefined }), {});
  const tekst = await r.text();
  let data = null;
  try { data = JSON.parse(tekst); } catch { /* geen json */ }
  return { status: r.status, data, tekst, headers: r.headers };
}

const adres = (n, over = {}) => ({ id: `00000000000000${String(n).padStart(2, "0")}`, s: "Teststraat", n, l: "", t: "", pc: "9999ZZ", x: 6.5, y: 53.3, ty: "rij", bu: "BU1", ...over });

test("zonder sessie: 401, ook op elke route", async () => {
  for (const [p, m] of [["plaatsen", "GET"], ["plaatsen/x", "GET"], ["plaatsen/x/bezoeken", "POST"], ["plaatsen/x/export", "GET"]]) {
    assert.equal((await vraag(p, { methode: m, zonderSessie: true, body: m === "POST" ? {} : undefined })).status, 401, p);
  }
});

test("plaats opslaan in delen per buurt en weer laden", async () => {
  const lijst = [adres(1), adres(2), adres(3), adres(4, { bu: "BU2" })];
  assert.equal((await vraag("plaatsen/testdorp/buurten/BU1?v=versie01", { methode: "PUT", body: { naam: "Noord", koop: 80, corp: 5, woningen: 30, aantal: 3, delen: 2 } })).status, 200);
  assert.equal((await vraag("plaatsen/testdorp/buurten/BU1/delen/0?v=versie01", { methode: "PUT", body: { adressen: lijst.slice(0, 2) } })).status, 200);
  assert.equal((await vraag("plaatsen/testdorp/buurten/BU1/delen/1?v=versie01", { methode: "PUT", body: { adressen: lijst.slice(2, 3) } })).status, 200);
  await vraag("plaatsen/testdorp/buurten/BU2?v=versie01", { methode: "PUT", body: { naam: "Zuid", koop: null, corp: 55, woningen: 12, aantal: 1, delen: 1 } });
  await vraag("plaatsen/testdorp/buurten/BU2/delen/0?v=versie01", { methode: "PUT", body: { adressen: [lijst[3]] } });
  // nog niet zichtbaar zolang de meta ontbreekt
  assert.deepEqual((await vraag("plaatsen")).data.plaatsen, []);
  const meta = await vraag("plaatsen/testdorp", { methode: "PUT", body: { naam: "Testdorp", versie: "versie01", aantal: 4, buurten: ["BU1", "BU2"] } });
  assert.equal(meta.status, 200);
  assert.equal((await vraag("plaatsen")).data.plaatsen[0].naam, "Testdorp");

  const p = (await vraag("plaatsen/testdorp")).data;
  assert.equal(p.buurten.length, 2);
  assert.equal(p.buurten.find((b) => b.code === "BU1").aan, true);
  assert.equal(p.buurten.find((b) => b.code === "BU2").aan, false); // 55% corporatie: standaard uit
  const a1 = (await vraag("plaatsen/testdorp/buurten/BU1/adressen")).data.adressen;
  assert.deepEqual(a1.map((a) => a.n), [1, 2, 3]);

  // buurt aan/uit: eigen blob met wie en wanneer; blijft behouden
  const k = await vraag("plaatsen/testdorp/buurten/BU2/keuze", { methode: "PUT", body: { aan: true }, wie: "Ruben" });
  assert.equal(k.data.wie, "Ruben");
  assert.equal((await vraag("plaatsen/testdorp")).data.buurten.find((b) => b.code === "BU2").aan, true);
  assert.equal((await vraag("plaatsen/testdorp/buurten/BU2/keuze", { methode: "PUT", body: { aan: "ja" } })).status, 400);
});

test("onbekend corporatiepercentage: standaard aan met onbekend-vlag", async () => {
  await vraag("plaatsen/onbekend/buurten/BU9?v=versie01", { methode: "PUT", body: { naam: "Klein", koop: null, corp: null, woningen: null, aantal: 0, delen: 0 } });
  await vraag("plaatsen/onbekend", { methode: "PUT", body: { naam: "Onbekend", versie: "versie01", aantal: 0, buurten: ["BU9"] } });
  const b = (await vraag("plaatsen/onbekend")).data.buurten[0];
  assert.equal(b.corp, null);
  assert.equal(b.onbekend, true);
  assert.equal(b.aan, true);
});

test("trilling per postcode met wie en wanneer, en instellingen ophalen", async () => {
  const r = await vraag("plaatsen/testdorp/trilling/9999zz", { methode: "PUT", body: { mms: 7.26 }, wie: "Ruben" });
  assert.equal(r.status, 200);
  assert.equal(r.data.mms, 7.3);
  assert.equal((await vraag("plaatsen/testdorp/trilling/12", { methode: "PUT", body: { mms: 1 } })).status, 400);
  assert.equal((await vraag("plaatsen/testdorp/trilling/9999ZZ", { methode: "PUT", body: { mms: 900 } })).status, 400);
  const i = (await vraag("plaatsen/testdorp/instellingen")).data;
  assert.equal(i.trilling["9999ZZ"].mms, 7.3);
  assert.equal(i.trilling["9999ZZ"].wie, "Ruben");
  assert.equal(i.keuzes.BU2.aan, true);
  assert.equal((await vraag("plaatsen/testdorp/trilling/9999ZZ", { methode: "PUT", body: { mms: null } })).data.mms, null);
  assert.equal((await vraag("plaatsen/testdorp")).data.trilling["9999ZZ"].mms, null);
});

const bezoek = (id, over = {}) => ({ id, a: "0000000000000001", st: "nietthuis", ts: new Date().toISOString(), bu: "BU1", ty: "rij", bj: 1950, mms: 7.5, koop: 80, corp: 5, pc: "9999ZZ", ...over });

test("bezoek opslaan met verrijking; dubbel versturen geeft geen tweede bezoek", async () => {
  const a = await vraag("plaatsen/testdorp/bezoeken", { methode: "POST", body: bezoek("aaaaaaaa1") });
  assert.equal(a.status, 201);
  assert.equal(a.data.w, "Kevin"); // wie komt uit de sessie
  assert.ok(a.data.k.endsWith("-aaaaaaaa1"));
  assert.equal(a.data.mms, 7.5);
  assert.equal(a.data.corp, 5);
  const b = await vraag("plaatsen/testdorp/bezoeken", { methode: "POST", body: bezoek("aaaaaaaa1", { st: "gesprek" }) });
  assert.equal(b.status, 200);
  assert.equal(b.data.k, a.data.k);
  assert.equal(b.data.st, "nietthuis");
  const sl = (await store("deur").list({ prefix: "events/testdorp/" })).blobs;
  assert.equal(sl.length, 1);
  assert.equal((await vraag("plaatsen/testdorp/bezoeken", { methode: "POST", body: bezoek("aaaaaaaa1", { st: "raar" }) })).status, 400);
  assert.equal((await vraag("plaatsen/bestaatniet/bezoeken", { methode: "POST", body: bezoek("zzzzzzzz1") })).status, 404);
});

test("ontbrekend event na marker: hersteld onder verse sleutel, tweede telefoon ziet het", async () => {
  const st = store("deur");
  const nu = Date.now();
  const oudK = `${pad14(nu - 30 * 60000)}-herstel01`;
  await st.setJSON("ids/testdorp/herstel01", { k: oudK, ok: false });
  await st.setJSON("plaatsen/herstel", { id: "herstel", naam: "Herstel", versie: "versie01", buurten: [] });
  await st.setJSON("ids/herstel/herstel01", { k: oudK, ok: false });
  const r = await schrijfBezoek(st, "herstel", schoonBezoek(bezoek("herstel01"), "Kevin").ev, nu);
  assert.equal(r.duplicaat, true);
  assert.ok(r.ev.k > oudK, "nieuwe sleutel, niet de oude");
  assert.ok(r.ev.k.startsWith(pad14(nu)));
  assert.equal((await st.get("ids/herstel/herstel01", { type: "json" })).ok, true);
  // een telefoon die al verder was dan de oude sleutel plus twee minuten ziet het event toch
  const b = await leesBezoeken(st, "herstel", `${pad14(nu - 60000)}-x`, nu + 1000);
  assert.deepEqual(b.nieuw.map((e) => e.id), ["herstel01"]);
  // en een derde poging doet niets meer
  const dubbel = await schrijfBezoek(st, "herstel", schoonBezoek(bezoek("herstel01"), "Kevin").ev, nu + 5000);
  assert.equal(dubbel.ev.k, r.ev.k);
  assert.equal((await st.list({ prefix: "events/herstel/" })).blobs.length, 1);
});

test("ophalen: volledig, en incrementeel met overlap van twee minuten", async () => {
  const nu = Date.now();
  const st = store("deur");
  await st.setJSON("plaatsen/overlap", { id: "overlap", naam: "Overlap", buurten: [] });
  const evk = async (id, ms, a = "0000000000000002") => {
    const k = `${pad14(ms)}-${id}`;
    await st.setJSON(`events/overlap/${k}`, { id, a, st: "nietthuis", w: "Ruben", ts: new Date(ms).toISOString(), k });
    return k;
  };
  const k1 = await evk("ev000001", nu - 300000);
  const k2 = await evk("ev000002", nu - 90000); // binnen overlap van k3
  const k3 = await evk("ev000003", nu - 10000);
  const vol = (await vraag("plaatsen/overlap/bezoeken")).data;
  assert.equal(vol.adressen["0000000000000002"].n, 3);
  assert.equal(vol.tot, k3);
  const inc = (await vraag(`plaatsen/overlap/bezoeken?na=${k3}`)).data;
  assert.deepEqual(inc.nieuw.map((e) => e.id), ["ev000002", "ev000003"]);
  assert.ok(!inc.nieuw.some((e) => e.k === k1));
  const leeg = (await vraag("plaatsen/overlap/bezoeken?na=onzin")).data;
  assert.ok(leeg.adressen); // ongeldige sleutel: volledige stand
});

test("samenvatten: verwerkte bezoeken naar het archief, stand blijft compleet", async () => {
  const nu = Date.now();
  const st = store("deur");
  await st.setJSON("plaatsen/arch", { id: "arch", naam: "Arch", buurten: [] });
  for (let i = 0; i < SAMENVAT_NA + 2; i++) {
    const id = `arch${String(i).padStart(4, "0")}`;
    const ms = nu - 3600000 + i * 1000;
    const k = `${pad14(ms)}-${id}`;
    await st.setJSON(`events/arch/${k}`, { id, a: `adres${i % 5}`, st: "nietthuis", w: "Kevin", ts: new Date(ms).toISOString(), k });
  }
  const verse = `${pad14(nu - 1000)}-vers0001`;
  await st.setJSON(`events/arch/${verse}`, { id: "vers0001", a: "adres0", st: "gesprek", w: "Ruben", ts: new Date(nu).toISOString(), k: verse });
  const r = await samenvatten(st, "arch", nu);
  assert.equal(r.gedaan, true);
  assert.equal((await st.list({ prefix: "events/arch/" })).blobs.length, 1); // alleen het verse bezoek
  const seg = (await st.list({ prefix: "archief/arch/" })).blobs;
  assert.equal(seg.length, 1);
  assert.equal((await st.get(seg[0].key, { type: "json" })).events.length, SAMENVAT_NA + 2);
  const vol = (await leesBezoeken(st, "arch", "", nu));
  const totaal = Object.values(vol.adressen).reduce((s, a) => s + a.n, 0);
  assert.equal(totaal, SAMENVAT_NA + 3);
  // telefoon met een oude sleutel krijgt de volledige stand, niet alleen het verse bezoek
  const oudePeiling = await leesBezoeken(st, "arch", `${pad14(nu - 7200000)}-x`, nu);
  assert.ok(oudePeiling.adressen);
  // telefoon die bij is, krijgt incrementeel
  const bij = await leesBezoeken(st, "arch", vol.tot, nu);
  assert.ok(bij.nieuw);
  // tweede samenvatting zonder nieuwe rijpe bezoeken doet niets
  assert.equal((await samenvatten(st, "arch", nu)).gedaan, false);
});

test("samenvatten met conflict (etag) schrijft niets over", async () => {
  const nu = Date.now();
  const st = store("deur");
  await st.setJSON("plaatsen/conf", { id: "conf", naam: "Conf", buurten: [] });
  for (let i = 0; i < SAMENVAT_NA; i++) {
    const id = `conf${String(i).padStart(4, "0")}`;
    const k = `${pad14(nu - 3600000 + i)}-${id}`;
    await st.setJSON(`events/conf/${k}`, { id, a: "adres1", st: "nietthuis", w: "K", ts: "2026-01-01T00:00:00Z", k });
  }
  const echt = st.setJSON.bind(st);
  st.setJSON = async (k, v, opt) => {
    if (k === "stand/conf") await echt(k, { tot: "", adressen: {} }); // iemand anders schrijft tussendoor
    return echt(k, v, opt);
  };
  const r = await samenvatten(st, "conf", nu);
  assert.equal(r.gedaan, false);
  assert.equal(r.conflict, true);
  assert.equal((await st.list({ prefix: "events/conf/" })).blobs.length, SAMENVAT_NA); // niets gearchiveerd
});

test("ongedaan maken via id komt mee in de stand en export", async () => {
  await vraag("plaatsen/testdorp/bezoeken", { methode: "POST", body: bezoek("exp00001", { a: "0000000000000003", no: "=HYPERLINK(1)" }) });
  await vraag("plaatsen/testdorp/bezoeken", { methode: "POST", body: bezoek("exp00002", { a: "0000000000000003", st: "gesprek" }), wie: "Ruben" });
  await vraag("plaatsen/testdorp/bezoeken", { methode: "POST", body: { id: "exp00003", a: "0000000000000003", ongedaan: "exp00002", ts: new Date().toISOString() } });
  const r = await vraag("plaatsen/testdorp/export");
  assert.equal(r.status, 200);
  assert.match(r.headers.get("content-type"), /text\/csv/);
  assert.ok(r.tekst.includes("'=HYPERLINK(1)"));
  assert.ok(r.tekst.includes("Teststraat"));
  assert.ok(r.tekst.includes("Noord"));
  const regels = r.tekst.split("\r\n");
  assert.ok(!regels.some((l) => l.includes(";gesprek;"))); // ongedaan gemaakt
  assert.ok(regels[0].includes("trilling_mms"));
});

test("onjuiste verzoeken", async () => {
  assert.equal((await vraag("plaatsen/Ongeldig!")).status, 404);
  assert.equal((await vraag("onbekend")).status, 404);
  const r = await handler(new Request(BASIS + "plaatsen/testdorp/bezoeken", {
    method: "POST", headers: { cookie: `${COOKIE_NAAM}=${maakToken("Kevin")}`, "content-type": "text/plain" }, body: "{}",
  }), {});
  assert.equal(r.status, 415);
  assert.equal((await vraag("plaatsen/testdorp/buurten/BU1/delen/0?v=versie01", { methode: "PUT", body: { adressen: [{ id: "../x" }] } })).status, 400);
});

// ---- gelijktijdigheid en crashes ----
const evk = async (st, plaats, id, ms, a = "adres1", extra = {}) => {
  const k = `${pad14(ms)}-${id}`;
  await st.setJSON(`events/${plaats}/${k}`, { id, a, st: "nietthuis", w: "Kevin", ts: new Date(ms).toISOString(), k, ...extra });
  return k;
};

test("samenvatten tussen list en get van een incrementele lezer: geen event kwijt", async () => {
  const st = store("deur");
  const nu = Date.now();
  await st.setJSON("plaatsen/gelijk", { id: "gelijk", naam: "Gelijk", versie: "versie01", buurten: [] });
  const basisMs = nu - 3600000;
  const ks = [];
  for (let i = 0; i < SAMENVAT_NA + 5; i++) ks.push(await evk(st, "gelijk", `gl${String(i).padStart(6, "0")}`, basisMs + i * 1000, "a" + i));
  const echtGet = st.get.bind(st);
  let eenmaal = false;
  st.get = async (k, o) => {
    if (k.startsWith("events/gelijk/") && !eenmaal) { eenmaal = true; await samenvatten(st, "gelijk", nu); }
    return echtGet(k, o);
  };
  const r = await leesBezoeken(st, "gelijk", ks[0], nu);
  st.get = echtGet;
  assert.ok(r.adressen, "valt terug op de volledige stand");
  assert.equal(Object.values(r.adressen).reduce((s, a) => s + a.n, 0), SAMENVAT_NA + 5);
});

test("list die achterloopt: een nieuw event is er bij de volgende peiling met overlap", async () => {
  const st = store("deur");
  const nu = Date.now();
  await st.setJSON("plaatsen/achter", { id: "achter", naam: "Achter", versie: "versie01", buurten: [] });
  const k1 = await evk(st, "achter", "ac000001", nu - 5000);
  const echtList = st.list.bind(st);
  st.list = async (o) => { const r = await echtList(o); return { blobs: r.blobs.filter((b) => !b.key.includes("ac000002")) }; };
  await evk(st, "achter", "ac000002", nu - 4000); // schrijven gelukt, list ziet het nog niet
  const eerste = await leesBezoeken(st, "achter", k1, nu);
  st.list = echtList;
  assert.ok(!eerste.nieuw.some((e) => e.id === "ac000002"));
  const tweede = await leesBezoeken(st, "achter", eerste.tot, nu + 20000);
  assert.ok(tweede.nieuw.some((e) => e.id === "ac000002"), "gevonden dankzij de overlap van twee minuten");
});

test("crash tussen stand en archief: dubbel verwerken telt niet dubbel", async () => {
  const st = store("deur");
  const nu = Date.now();
  await st.setJSON("plaatsen/crash", { id: "crash", naam: "Crash", versie: "versie01", buurten: [] });
  for (let i = 0; i < SAMENVAT_NA; i++) await evk(st, "crash", `cr${String(i).padStart(6, "0")}`, nu - 3600000 + i * 1000, "a" + (i % 4));
  const echtDel = st.delete.bind(st);
  st.delete = async () => { throw new Error("crash na stand"); };
  await assert.rejects(samenvatten(st, "crash", nu));
  st.delete = echtDel;
  const vol = await leesBezoeken(st, "crash", "", nu);
  assert.equal(Object.values(vol.adressen).reduce((s, a) => s + a.n, 0), SAMENVAT_NA);
  await samenvatten(st, "crash", nu);
  assert.equal(Object.values((await st.get("stand/crash", { type: "json" })).adressen).reduce((s, a) => s + a.n, 0), SAMENVAT_NA);
  assert.equal((await st.list({ prefix: "events/crash/" })).blobs.length, 0);
});

test("scheve servertijd: telefoontijd wordt begrensd, volgorde volgt de servertijd", () => {
  const nu = Date.now();
  const r = schoonBezoek({ id: "scheef001", a: "h1", st: "nietthuis", ts: new Date(nu + 86400000 * 3).toISOString() }, "K", nu);
  assert.equal(Date.parse(r.ev.ts), nu + 5 * 60 * 1000);
  const stand = { adressen: {} };
  vouwIn(stand, { id: "bbbbbbbb", a: "h1", st: "gesprek", w: "R", ts: new Date(nu - 100000).toISOString(), k: `${pad14(nu)}-bbbbbbbb` });
  vouwIn(stand, { id: "aaaaaaaa", a: "h1", st: "nietthuis", w: "K", ts: new Date(nu + 100000).toISOString(), k: `${pad14(nu - 1000)}-aaaaaaaa` });
  assert.equal(stand.adressen.h1.s, "G");
  assert.equal(stand.adressen.h1.v[0], "N");
});

test("compacte stand: ongedaan maken, weg-lijst en omzetten naar bezoeken", () => {
  const stand = { adressen: {} };
  const e = (id, st, ms, over = {}) => ({ id, a: "h1", st, w: "K", ts: new Date(ms).toISOString(), k: `${pad14(ms)}-${id}`, ...over });
  vouwIn(stand, e("aaaaaaaa", "nietthuis", 1000000));
  vouwIn(stand, e("bbbbbbbb", "gesprek", 2000000));
  assert.equal(stand.adressen.h1.n, 2);
  vouwIn(stand, { id: "cccccccc", a: "h1", st: null, ongedaan: "bbbbbbbb", w: "K", ts: "2026-01-01T00:00:00Z", k: `${pad14(3000000)}-cccccccc` });
  assert.equal(stand.adressen.h1.s, "N");
  assert.equal(stand.adressen.h1.n, 1);
  vouwIn(stand, { id: "dddddddd", a: "h2", st: null, ongedaan: "eeeeeeee", w: "K", ts: "2026-01-01T00:00:00Z", k: `${pad14(4000000)}-dddddddd` });
  vouwIn(stand, e("eeeeeeee", "gesprek", 3500000, { a: "h2" }));
  assert.equal(stand.adressen.h2.s, undefined);
  assert.equal(stand.adressen.h2.n, 0);
  const hist = entryNaarHist("h1", stand.adressen.h1);
  assert.deepEqual(effectief(hist).map((h) => h.id), ["aaaaaaaa"]);
});

test("omvang van de stand bij 50.000 bezoeken blijft ruim onder 6 MB", () => {
  const stand = { tot: "x", adressen: {}, vorigeIds: [] };
  const N = 50000;
  for (let i = 0; i < N; i++) {
    const adres = "0" + String(1000000000000000 + (i % 25000));
    const ms = 1762790000000 + i * 1000;
    const id = "x" + i.toString(36).padStart(10, "0");
    vouwIn(stand, { id, a: adres, st: "nietthuis", w: "Kevin", ts: new Date(ms).toISOString(), k: `${pad14(ms)}-${id}` });
  }
  const mb = JSON.stringify(stand).length / 1e6;
  assert.ok(mb < 4.5, "stand is " + mb.toFixed(2) + " MB");
});

test("export na archiveren bevat de volledige geschiedenis, in delen geleverd", async () => {
  const st = store("deur");
  const nu = Date.now();
  await st.setJSON("plaatsen/hist", { id: "hist", naam: "Hist", versie: "versie01", buurten: ["BU1"] });
  await st.setJSON("plaats/hist/versie/versie01/buurten/BU1", { code: "BU1", naam: "Noord", koop: 50, corp: 10, woningen: 10, aantal: 1, delen: 1 });
  await st.setJSON("plaats/hist/versie/versie01/adressen/BU1/0", [{ id: "h1", s: "Teststraat", n: 1, l: "", t: "", pc: "9999ZZ", x: 6.5, y: 53.3, ty: "rij", bu: "BU1" }]);
  for (let i = 0; i < SAMENVAT_NA + 5; i++) await evk(st, "hist", `hi${String(i).padStart(6, "0")}`, nu - 3600000 + i * 1000, "h1");
  await samenvatten(st, "hist", nu);
  assert.equal((await alleBezoeken(st, "hist")).length, SAMENVAT_NA + 5);
  const r = await vraag("plaatsen/hist/export");
  assert.equal(r.status, 200);
  assert.equal(r.tekst.split("\r\n").length - 1, SAMENVAT_NA + 5);
  assert.ok(r.tekst.startsWith("plaats;"));
});

test("opnieuw ophalen van een plaats: oude versie blijft leesbaar tot de meta wisselt, wie het deed staat in het log", async () => {
  await vraag("plaatsen/versie/buurten/BU1?v=aaaaaaaa", { methode: "PUT", body: { naam: "Oud\u0007", koop: 1, corp: 1, woningen: 1, aantal: 1, delen: 1 } });
  await vraag("plaatsen/versie/buurten/BU1/delen/0?v=aaaaaaaa", { methode: "PUT", body: { adressen: [adres(1)] } });
  await vraag("plaatsen/versie", { methode: "PUT", body: { naam: "Versie", versie: "aaaaaaaa", aantal: 1, buurten: ["BU1"] }, wie: "Ruben" });
  await vraag("plaatsen/versie/buurten/BU1?v=bbbbbbbb", { methode: "PUT", body: { naam: "Nieuw", koop: 2, corp: 2, woningen: 2, aantal: 2, delen: 1 } });
  await vraag("plaatsen/versie/buurten/BU1/delen/0?v=bbbbbbbb", { methode: "PUT", body: { adressen: [adres(1), adres(2)] } });
  assert.equal((await vraag("plaatsen/versie/buurten/BU1/adressen")).data.adressen.length, 1);
  assert.equal((await vraag("plaatsen/versie")).data.buurten[0].naam, "Oud");
  await vraag("plaatsen/versie", { methode: "PUT", body: { naam: "Versie", versie: "bbbbbbbb", aantal: 2, buurten: ["BU1"] }, wie: "Kevin" });
  assert.equal((await vraag("plaatsen/versie/buurten/BU1/adressen")).data.adressen.length, 2);
  const log = (await store("deur").list({ prefix: "log/versie/" })).blobs;
  assert.equal(log.length, 2);
  assert.equal((await store("deur").get(log[0].key, { type: "json" })).wie, "Ruben");
  assert.equal((await vraag("plaatsen/versie/buurten/BU1?v=..x", { methode: "PUT", body: { naam: "x" } })).status, 400);
  assert.equal((await vraag("plaatsen/versie/buurten/BU1", { methode: "PUT", body: { naam: "x" } })).status, 400);
});

test("keuze en trilling op een niet bestaande plaats: 404, en er wordt niets geschreven", async () => {
  assert.equal((await vraag("plaatsen/nergens/buurten/BU1/keuze", { methode: "PUT", body: { aan: true } })).status, 404);
  assert.equal((await vraag("plaatsen/nergens/trilling/9999ZZ", { methode: "PUT", body: { mms: 3 } })).status, 404);
  assert.equal((await store("deur").list({ prefix: "plaats/nergens/" })).blobs.length, 0);
});

test("pad-injectie: elke sleutelparameter weigert vreemde tekens en er wordt niets geschreven", async () => {
  const voor = (await store("deur").list({ prefix: "" })).blobs.length;
  const vies = ["..", "%2e%2e", "a%2Fb", "a%252Fb", "..%2F..%2Fx", "BU1%00", "BU1;x", "a%20b", "%E2%80%AE"];
  for (const v of vies) {
    for (const [pad, m, body] of [
      [`plaatsen/${v}`, "GET"],
      [`plaatsen/${v}`, "PUT", { naam: "x", versie: "aaaaaaaa", aantal: 0, buurten: [] }],
      [`plaatsen/testdorp/buurten/${v}/keuze`, "PUT", { aan: true }],
      [`plaatsen/testdorp/buurten/${v}?v=aaaaaaaa`, "PUT", { naam: "x" }],
      [`plaatsen/testdorp/buurten/BU1/delen/${v}?v=aaaaaaaa`, "PUT", { adressen: [] }],
      [`plaatsen/testdorp/buurten/BU1?v=${v}`, "PUT", { naam: "x" }],
      [`plaatsen/testdorp/trilling/${v}`, "PUT", { mms: 1 }],
      [`plaatsen/${v}/bezoeken`, "POST", bezoek("pad00001")],
    ]) {
      const r = await vraag(pad, { methode: m, body });
      assert.ok([400, 404].includes(r.status), `${m} ${pad} gaf ${r.status}`);
    }
  }
  assert.equal((await store("deur").list({ prefix: "" })).blobs.length, voor);
});

// ---- hercontrole ----
const wacht0 = () => new Promise((r) => setTimeout(r, 0));

test("twee samenvattingen tegelijk: het archief wordt niet kleiner", async () => {
  const st = store("deur");
  const nu = Date.now();
  await st.setJSON("plaatsen/tegelijk", { id: "tegelijk", naam: "Tegelijk", versie: "versie01", buurten: [] });
  for (let i = 0; i < 50; i++) await evk(st, "tegelijk", "tg" + String(i).padStart(6, "0"), nu - 60 * 60000 + i * 60000, "a" + i);
  const echt = st.getWithMetadata.bind(st);
  let poort; const klaar = new Promise((r) => (poort = r));
  let eerste = true;
  st.getWithMetadata = async (k, o) => { if (k === "stand/tegelijk" && eerste) { eerste = false; await klaar; } return echt(k, o); };
  const pB = samenvatten(st, "tegelijk", nu - 5 * 60000); // B blijft hangen vlak voor het lezen van de stand
  for (let i = 0; i < 25; i++) await wacht0();
  await samenvatten(st, "tegelijk", nu); // A doet alles
  poort();
  await pB;
  st.getWithMetadata = echt;
  assert.equal((await alleBezoeken(st, "tegelijk")).length, 50);
  const stand = await st.get("stand/tegelijk", { type: "json" });
  assert.equal(Object.values(stand.adressen).reduce((s, a) => s + a.n, 0), 50);
});

test("twee tabs sturen hetzelfde bezoek tegelijk: één event, en ongedaan maken werkt", async () => {
  const st = store("deur");
  const nu = Date.now();
  await st.setJSON("plaatsen/tabs", { id: "tabs", naam: "Tabs", versie: "versie01", buurten: [] });
  const echt = st.setJSON.bind(st);
  let houd = true; let los; const poort = new Promise((r) => (los = r));
  st.setJSON = async (k, v, o) => { if (houd && k.startsWith("events/tabs/")) { houd = false; await poort; } return echt(k, v, o); };
  const e = schoonBezoek({ id: "dubbel01", a: "x1", st: "gesprek", ts: new Date(nu).toISOString() }, "Kevin", nu).ev;
  const p1 = schrijfBezoek(st, "tabs", e, nu);
  for (let i = 0; i < 5; i++) await wacht0();
  const p2 = schrijfBezoek(st, "tabs", e, nu + 50);
  await new Promise((r) => setTimeout(r, 1500)); // tab 2 wacht kort op tab 1 en herstelt dan zelf
  los();
  await Promise.all([p1, p2]);
  st.setJSON = echt;
  const sl = (await st.list({ prefix: "events/tabs/" })).blobs;
  assert.equal(sl.length, 1, "één event met dit id");
  const u = schoonBezoek({ id: "undo0001", a: "x1", ongedaan: "dubbel01", ts: new Date(nu).toISOString() }, "Kevin", nu).ev;
  await schrijfBezoek(st, "tabs", u, nu + 1000);
  const vol = await leesBezoeken(st, "tabs", "", nu + 2000);
  assert.equal(vol.adressen.x1.s, undefined, "geen status meer na ongedaan maken");
});

test("dubbele events met hetzelfde id tellen in de stand één keer", () => {
  const stand = { adressen: {} };
  const ev = (k, id) => ({ id, a: "x", st: "nietthuis", w: "K", ts: "2026-01-01T00:00:00Z", k: `${pad14(k)}-${id}` });
  vouwIn(stand, ev(1000, "aaaaaaaa"));
  vouwIn(stand, ev(2000, "aaaaaaaa"));
  assert.equal(stand.adressen.x.n, 1);
  vouwIn(stand, ev(3000, "bbbbbbbb"));
  vouwIn(stand, ev(4000, "bbbbbbbb"));
  vouwIn(stand, ev(3500, "aaaaaaaa"));
  assert.equal(stand.adressen.x.n, 2);
});

test("plaats zonder versie (oude data): geen undefined-sleutels, wel een melding om opnieuw op te halen", async () => {
  const st = store("deur");
  await st.setJSON("plaatsen/oudedata", { id: "oudedata", naam: "Oude data", aantal: 3, buurten: ["BU1"] });
  const r = await vraag("plaatsen/oudedata");
  assert.equal(r.status, 200);
  assert.equal(r.data.opnieuwOphalen, true);
  assert.deepEqual(r.data.buurten, []);
  assert.equal((await vraag("plaatsen/oudedata/buurten/BU1/adressen")).status, 404);
  assert.equal((await vraag("plaatsen/oudedata/export")).status, 200);
  assert.equal((await st.list({ prefix: "plaats/oudedata/undefined" })).blobs.length, 0);
});

test("een versie die 'trilling' of 'keuze' heet botst niet met instellingen", async () => {
  const p = "plaatsen/vers";
  await vraag(`${p}/buurten/BU1?v=trilling`, { methode: "PUT", body: { naam: "N", koop: 1, corp: 1, woningen: 1, aantal: 1, delen: 1 } });
  await vraag(`${p}/buurten/BU1/delen/0?v=trilling`, { methode: "PUT", body: { adressen: [adres(1)] } });
  await vraag(p, { methode: "PUT", body: { naam: "Vers", versie: "trilling", aantal: 1, buurten: ["BU1"] } });
  await vraag(`${p}/trilling/9999ZZ`, { methode: "PUT", body: { mms: 5 } });
  const i = (await vraag(`${p}/instellingen`)).data;
  assert.deepEqual(Object.keys(i.trilling), ["9999ZZ"]);
  assert.equal((await vraag(`${p}/buurten/BU1/adressen`)).data.adressen.length, 1);
});

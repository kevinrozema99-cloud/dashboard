// Deur-aan-deur: opslaglogica op de server (zonder HTTP), los te testen met een in-memory store.
//
// Sleutels in store "deur":
//   plaatsen/<id>                          meta van een plaats (wordt pas geschreven als alle delen er staan)
//   plaats/<id>/versie/<v>/buurten/<code>  buurtcijfers en aantal delen (per versie; de meta wijst de actuele versie aan)
//   plaats/<id>/versie/<v>/adressen/<code>/<n>  adressen, in delen
//   plaats/<id>/keuze/<code>               buurt aan/uit, met wie en wanneer
//   plaats/<id>/trilling/<postcode>        trillingssnelheid, met wie en wanneer
//   events/<id>/<ms14>-<clientId>          één bezoek
//   ids/<id>/<clientId>                    marker (onlyIfNew): dubbel versturen geeft nooit een tweede bezoek
//   stand/<id>, standtot/<id>              compacte samenvatting (per adres laatste en voorlaatste bezoek en aantal)
//   archief/<id>/<eerste>-<laatste>-<run>  segment met verwerkte bezoeken (volledige geschiedenis, voor de export)
//   log/<id>/<ms14>                        wie een plaats opnieuw heeft opgehaald
import { pasToe, vouwIn, standaardAan } from "../../../../public/dashboard/deur/logica.js";

export const OVERLAP_MS = 2 * 60 * 1000;
export const RIJP_MS = 10 * 60 * 1000;
export const SAMENVAT_NA = 40;
export const GROEP = 20;
export const MAX_RUN = 500;

export const pad14 = (ms) => String(Math.max(0, Math.floor(ms))).padStart(14, "0");

// Voert fn uit voor alle items, in groepen van `groep` tegelijk.
export async function parallel(items, groep, fn) {
  const uit = [];
  for (let i = 0; i < items.length; i += groep) {
    uit.push(...(await Promise.all(items.slice(i, i + groep).map(fn))));
  }
  return uit;
}

async function sleutelsMetPrefix(st, prefix) {
  const { blobs } = await st.list({ prefix });
  return blobs.map((b) => b.key.slice(prefix.length));
}

// ---- plaatsen ----
// Versies staan onder een vast voorvoegsel, zodat een versienaam nooit botst met keuze/ of trilling/.
export const basis = (plaats, versie) => `plaats/${plaats}/versie/${versie}`;

export async function leesPlaatsen(st) {
  const sl = await sleutelsMetPrefix(st, "plaatsen/");
  const rijen = await parallel(sl, GROEP, (k) => st.get(`plaatsen/${k}`, { type: "json" }));
  return rijen.filter(Boolean).sort((a, b) => a.naam.localeCompare(b.naam, "nl"));
}

export async function leesInstellingen(st, plaats) {
  const kPrefix = `plaats/${plaats}/keuze/`;
  const tPrefix = `plaats/${plaats}/trilling/`;
  const [kSl, tSl] = await Promise.all([sleutelsMetPrefix(st, kPrefix), sleutelsMetPrefix(st, tPrefix)]);
  const [k, t] = await Promise.all([
    parallel(kSl, GROEP, async (s) => [s, await st.get(kPrefix + s, { type: "json" })]),
    parallel(tSl, GROEP, async (s) => [s, await st.get(tPrefix + s, { type: "json" })]),
  ]);
  return {
    keuzes: Object.fromEntries(k.filter(([, v]) => v)),
    trilling: Object.fromEntries(t.filter(([, v]) => v)),
  };
}

// Buurten met cijfers en actuele keuze (opgeslagen keuze, anders de standaard).
export async function leesBuurten(st, meta, keuzes) {
  if (!meta.versie) return []; // oude plaatsdata zonder versie: opnieuw ophalen
  const lijst = await parallel(meta.buurten || [], GROEP, (code) =>
    st.get(`${basis(meta.id, meta.versie)}/buurten/${code}`, { type: "json" }));
  return lijst.filter(Boolean).map((b) => {
    const k = keuzes[b.code];
    return {
      ...b,
      onbekend: b.corp == null,
      aan: k ? !!k.aan : standaardAan(b.corp),
      aanDoor: k ? k.wie : null,
      aanOp: k ? k.wanneer : null,
    };
  });
}

export async function leesAdressen(st, meta, code) {
  if (!meta.versie) return null;
  const b = await st.get(`${basis(meta.id, meta.versie)}/buurten/${code}`, { type: "json" });
  if (!b) return null;
  const delen = await parallel(
    Array.from({ length: b.delen || 0 }, (_, i) => i), GROEP,
    (i) => st.get(`${basis(meta.id, meta.versie)}/adressen/${code}/${i}`, { type: "json" }),
  );
  return delen.filter(Array.isArray).flat();
}

// ---- bezoeken ----
// Volgorde: marker (ok:false), event, marker (ok:true). Een marker met ok:false betekent een onderbroken
// schrijfactie: dan wordt het event onder een verse sleutel (nu) hersteld, zodat andere telefoons het nog zien.
export const JONG_MS = 5000;
const slaap = (ms) => new Promise((r) => setTimeout(r, ms));

export async function schrijfBezoek(st, plaats, ev, nu = Date.now()) {
  const markerSleutel = `ids/${plaats}/${ev.id}`;
  const k = `${pad14(nu)}-${ev.id}`;
  const nieuw = await st.setJSON(markerSleutel, { k, ok: false }, { onlyIfNew: true });
  if (!nieuw || nieuw.modified !== false) {
    const opgeslagen = { ...ev, k };
    await st.setJSON(`events/${plaats}/${k}`, opgeslagen, { onlyIfNew: true });
    // Alleen bijwerken als de marker nog de onze is; anders heeft een ander verzoek het bezoek hersteld.
    const w = await st.setJSON(markerSleutel, { k, ok: true }, nieuw && nieuw.etag ? { onlyIfMatch: nieuw.etag } : undefined);
    if (w && w.modified === false) {
      await st.delete(`events/${plaats}/${k}`);
      const m = await st.get(markerSleutel, { type: "json", consistency: "strong" });
      const live = m && m.k ? await st.get(`events/${plaats}/${m.k}`, { type: "json", consistency: "strong" }) : null;
      return { duplicaat: true, ev: live || { ...ev, k: (m && m.k) || k } };
    }
    return { duplicaat: false, ev: opgeslagen };
  }
  let m = await st.getWithMetadata(markerSleutel, { type: "json", consistency: "strong" });
  let data = m && m.data;
  if (data && data.ok === true) {
    const live = await st.get(`events/${plaats}/${data.k}`, { type: "json", consistency: "strong" });
    return { duplicaat: true, ev: live || { ...ev, k: data.k } }; // is gearchiveerd of live; in beide gevallen binnen
  }
  // Marker zonder ok: een ander verzoek is bezig, of het is onderbroken. Is de marker jong, dan eerst even wachten.
  const gestart = sleutelTijd(data && data.k);
  if (gestart !== null && Math.abs(nu - gestart) < JONG_MS) {
    for (let i = 0; i < 4; i++) {
      await slaap(250);
      const live = await st.get(`events/${plaats}/${data.k}`, { type: "json", consistency: "strong" });
      if (live) return { duplicaat: true, ev: live };
    }
    m = await st.getWithMetadata(markerSleutel, { type: "json", consistency: "strong" });
    data = m && m.data;
    if (data && data.ok === true) {
      const live = await st.get(`events/${plaats}/${data.k}`, { type: "json", consistency: "strong" });
      return { duplicaat: true, ev: live || { ...ev, k: data.k } };
    }
  }
  const oud = data && data.k ? await st.get(`events/${plaats}/${data.k}`, { type: "json", consistency: "strong" }) : null;
  if (oud) {
    if (m && m.etag) await st.setJSON(markerSleutel, { k: data.k, ok: true }, { onlyIfMatch: m.etag });
    return { duplicaat: true, ev: oud };
  }
  const hersteld = { ...ev, k };
  const w = m && m.etag ? await st.setJSON(markerSleutel, { k, ok: true }, { onlyIfMatch: m.etag }) : { modified: true };
  if (w && w.modified === false) return { duplicaat: true, ev: { ...ev, k } }; // een ander verzoek was ons voor
  await st.setJSON(`events/${plaats}/${k}`, hersteld, { onlyIfNew: true });
  return { duplicaat: true, ev: hersteld };
}

const sleutelTijd = (k) => {
  const m = /^(\d{14})/.exec(k || "");
  return m ? Number(m[1]) : null;
};

async function leesLive(st, plaats, sleutels) {
  const prefix = `events/${plaats}/`;
  return parallel(sleutels, GROEP, (k) => st.get(prefix + k, { type: "json", consistency: "strong" }));
}

function standMetLive(stand, events) {
  const skip = new Set(stand.vorigeIds || []);
  for (const ev of events.slice().sort((a, b) => a.k.localeCompare(b.k))) {
    if (skip.has(ev.id)) continue;
    skip.add(ev.id); // twee events met hetzelfde id tellen één keer
    vouwIn(stand, ev);
  }
  return stand;
}

// na = sleutel waarvan de telefoon alles heeft. Geeft {tot, nieuw} of {tot, adressen}.
export async function leesBezoeken(st, plaats, na, nu = Date.now()) {
  const standTot = ((await st.get(`standtot/${plaats}`, { type: "json", consistency: "strong" })) || {}).tot || "";
  const prefix = `events/${plaats}/`;
  const alle = (await sleutelsMetPrefix(st, prefix)).sort();
  const naTijd = sleutelTijd(na);
  let incrementeel = naTijd !== null && na >= standTot;
  const drempel = incrementeel ? pad14(naTijd - OVERLAP_MS) : "";
  const gewenst = alle.filter((k) => k >= drempel);
  const gelezen = await leesLive(st, plaats, gewenst);
  const events = gelezen.filter(Boolean);
  // Een sleutel die intussen is gearchiveerd geeft null: dan mist een incrementele lezer iets, dus volledige stand.
  if (incrementeel && events.length < gewenst.length) incrementeel = false;
  const hoogste = [standTot, alle[alle.length - 1] || ""].sort().pop();

  let antwoord;
  if (incrementeel) {
    antwoord = { tot: hoogste, nieuw: events };
  } else {
    // De stand wordt pas nu gelezen: wat intussen is gearchiveerd, staat er al in.
    const stand = (await st.get(`stand/${plaats}`, { type: "json", consistency: "strong" })) || { adressen: {} };
    standMetLive(stand, events);
    antwoord = { tot: hoogste, adressen: stand.adressen };
  }
  const rijp = pad14(nu - RIJP_MS);
  if (alle.filter((k) => k < rijp).length >= SAMENVAT_NA) {
    try { await samenvatten(st, plaats, nu); } catch { /* samenvatten mag het ophalen nooit laten mislukken */ }
  }
  return antwoord;
}

// Alle bezoeken ooit (archiefsegmenten plus wat nog live staat), voor de export. Geen dubbelen op id.
export async function alleBezoeken(st, plaats) {
  const aPrefix = `archief/${plaats}/`;
  const segmenten = await sleutelsMetPrefix(st, aPrefix);
  const per = await parallel(segmenten, 5, (k) => st.get(aPrefix + k, { type: "json", consistency: "strong" }));
  const live = (await leesLive(st, plaats, await sleutelsMetPrefix(st, `events/${plaats}/`))).filter(Boolean);
  const gezien = new Set();
  const uit = [];
  for (const ev of [...per.flatMap((x) => (x && x.events) || []), ...live]) {
    if (gezien.has(ev.id)) continue;
    gezien.add(ev.id);
    uit.push(ev);
  }
  return uit;
}
export async function volledigeStand(st, plaats) {
  const stand = {};
  for (const ev of await alleBezoeken(st, plaats)) pasToe(stand, ev);
  return stand;
}

// Verwerkt de oudste bezoeken (ouder dan RIJP_MS, maximaal MAX_RUN per keer): eerst een archiefsegment,
// dan de compacte stand (met etag-controle), pas daarna de originelen verwijderen.
export async function samenvatten(st, plaats, nu = Date.now()) {
  const prefix = `events/${plaats}/`;
  const rijp = pad14(nu - RIJP_MS);
  const oud = (await sleutelsMetPrefix(st, prefix)).sort().filter((k) => k < rijp);
  if (oud.length < SAMENVAT_NA) return { gedaan: false };
  const batch = oud.slice(0, MAX_RUN);
  const events = (await leesLive(st, plaats, batch)).filter(Boolean);
  if (!events.length) return { gedaan: false };
  const huidig = await st.getWithMetadata(`stand/${plaats}`, { type: "json", consistency: "strong" });
  const stand = huidig ? huidig.data : { tot: "", adressen: {}, vorigeIds: [] };
  standMetLive(stand, events);
  stand.vorigeIds = events.map((e) => e.id);
  stand.tot = [stand.tot || "", batch[batch.length - 1]].sort().pop();
  // Eerst de stand met etag-controle: verliest deze run, dan is er niets geschreven en is er niets op te ruimen.
  const w = await st.setJSON(`stand/${plaats}`, stand, huidig ? { onlyIfMatch: huidig.etag } : { onlyIfNew: true });
  if (w && w.modified === false) return { gedaan: false, conflict: true };
  // Dan het segment, onder een sleutel die uniek is voor deze run (nooit een ander segment overschrijven).
  const run = Math.random().toString(36).slice(2, 10);
  await st.setJSON(`archief/${plaats}/${batch[0]}-${batch[batch.length - 1]}-${run}`, { events }, { onlyIfNew: true });
  await st.setJSON(`standtot/${plaats}`, { tot: stand.tot });
  await parallel(events, GROEP, (ev) => st.delete(prefix + ev.k));
  return { gedaan: true, aantal: events.length };
}

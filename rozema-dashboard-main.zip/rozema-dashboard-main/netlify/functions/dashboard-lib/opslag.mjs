// Opslag: één plek die de Blobs-store maakt, altijd met vaste regio.
import { getStore } from "@netlify/blobs";

export const REGIO = "eu-central-1";

// Deploy-context van de huidige Function (production, deploy-preview, branch-deploy, dev).
// Elke handler roept zetContext(context) aan het begin aan. De context is per
// deploy vast, dus een gedeelde variabele is veilig.
let huidigeContext = null;

export function zetContext(context) {
  const c = context?.deploy?.context ?? globalThis.Netlify?.context?.deploy?.context;
  huidigeContext = typeof c === "string" ? c : null;
}

// Witte lijst: alleen met DASHBOARD_ECHTE_DATA === "aan" EN de deploy-context
// production de echte store. Een andere context: teststore. Staat de variabele op
// "aan" maar ontbreekt de context, dan een fout (de handler geeft een 500).
export function storeNaam(naam, env = process.env, deployContext = huidigeContext) {
  if (typeof naam !== "string" || !/^[a-z0-9-]{1,40}$/.test(naam)) {
    throw new Error("Ongeldige store-naam");
  }
  if (env.DASHBOARD_ECHTE_DATA === "aan" && (deployContext === undefined || deployContext === null)) {
    // Geen stille teststore: dan zou echt gebruik onzichtbaar in testdata terechtkomen.
    // Alleen de contextwaarde in de log, geen persoonsgegevens.
    console.error("Deploy-context ontbreekt terwijl DASHBOARD_ECHTE_DATA aan staat:", String(deployContext));
    throw new Error("Deploy-context ontbreekt");
  }
  const echt = env.DASHBOARD_ECHTE_DATA === "aan" && deployContext === "production";
  return echt ? `dashboard-${naam}` : `dashboard-test-${naam}`;
}

const standaardFabriek = (volledigeNaam) =>
  getStore({ name: volledigeNaam, region: REGIO, consistency: "strong" });

let fabriek = standaardFabriek;

// Voor tests: fn(volledigeNaam) geeft een store met get/getWithMetadata/setJSON/delete/list.
export function zetStoreFabriek(fn) {
  fabriek = fn || standaardFabriek;
}

export function store(naam) {
  return fabriek(storeNaam(naam));
}

// Lezen-wijzigen-schrijven met controle op etag (onlyIfMatch, of onlyIfNew bij
// een nieuwe sleutel), maximaal `pogingen` keer.
// fn(huidigeWaarde | null) geeft de nieuwe waarde, of undefined om niets te schrijven.
// Geeft {geschreven, waarde, conflict?}. conflict = alle pogingen verloren.
export async function bijwerk(st, sleutel, fn, pogingen = 3) {
  for (let i = 0; i < pogingen; i++) {
    const r = await st.getWithMetadata(sleutel, { type: "json", consistency: "strong" });
    const nieuw = fn(r ? r.data : null);
    if (nieuw === undefined) return { geschreven: false, waarde: r ? r.data : null };
    const res = await st.setJSON(sleutel, nieuw, r ? { onlyIfMatch: r.etag } : { onlyIfNew: true });
    if (!res || res.modified !== false) return { geschreven: true, waarde: nieuw };
  }
  return { geschreven: false, waarde: null, conflict: true };
}

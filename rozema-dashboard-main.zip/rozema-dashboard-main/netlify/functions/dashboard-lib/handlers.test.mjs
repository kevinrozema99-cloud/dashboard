import { test, beforeEach } from "node:test";
import assert from "node:assert/strict";
import { zetStoreFabriek } from "./opslag.mjs";
import { geheugenFabriek } from "./test-hulp.mjs";
import { maakWachtwoordHash, maakToken } from "./sessie.mjs";
import meldingen from "../dashboard-meldingen.mjs";
import auth from "../dashboard-auth.mjs";

const GEBRUIKER = "verzonnen-wachtwoord-a";
let fabriek, cookie;

beforeEach(async () => {
  fabriek = geheugenFabriek();
  zetStoreFabriek(fabriek);
  process.env.DASHBOARD_SESSIE_GEHEIM = "z".repeat(40);
  process.env.DASHBOARD_GEBRUIKERS = JSON.stringify({
    Kevin: await maakWachtwoordHash(GEBRUIKER, 1000),
    Ruben: await maakWachtwoordHash("verzonnen-wachtwoord-b", 1000),
  });
  delete process.env.DASHBOARD_SESSIE_VERSIE;
  cookie = `dashboard_sessie=${maakToken("Kevin")}`;
});

const melding = (id = crypto.randomUUID()) =>
  ({ id, scherm: "/dashboard/", tekst: "Test", soort: "wens", info: { breedte: 390, versie: "1" } });

function m(method, pad, body, { c = cookie, headers = {} } = {}) {
  return meldingen(new Request(`https://x.test/api/dashboard/meldingen${pad}`, {
    method,
    headers: { ...(body !== undefined ? { "content-type": "application/json" } : {}), ...(c ? { cookie: c } : {}), ...headers },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  }), { deploy: { context: "deploy-preview" } });
}
function a(method, actie, body, { c, ip = "5.5.5.5", headers = {} } = {}) {
  return auth(new Request(`https://x.test/api/dashboard/auth/${actie}`, {
    method,
    headers: { "x-nf-client-connection-ip": ip, ...(body !== undefined ? { "content-type": "application/json" } : {}), ...(c ? { cookie: c } : {}), ...headers },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  }));
}
const alsCookie = (r, naam) => r.headers.getSetCookie().find((x) => x.startsWith(`${naam}=`));

test("meldingen: zonder sessie 401, onbekende route en methode 404", async () => {
  assert.equal((await m("GET", "/", undefined, { c: "" })).status, 401);
  assert.equal((await m("POST", "/", melding(), { c: "" })).status, 401);
  assert.equal((await m("DELETE", "/")).status, 404);
  assert.equal((await m("PUT", "/", melding())).status, 404);
  assert.equal((await m("GET", `/${crypto.randomUUID()}`)).status, 404);
});

test("meldingen: opslaan, herhaald verzoek is 200, lijst, status wijzigen", async () => {
  const body = melding();
  const r = await m("POST", "/", body);
  assert.equal(r.status, 201);
  assert.equal(r.headers.get("x-robots-tag"), "noindex, nofollow");
  assert.equal(r.headers.get("cache-control"), "no-store");
  const opgeslagen = await r.json();
  assert.equal(opgeslagen.wie, "Kevin");
  assert.equal(opgeslagen.status, "nieuw");
  const nog = await m("POST", "/", body);
  assert.equal(nog.status, 200);
  assert.equal((await nog.json()).wanneer, opgeslagen.wanneer);
  // zelfde id, andere gebruiker: 409
  const ruben = `dashboard_sessie=${maakToken("Ruben")}`;
  assert.equal((await m("POST", "/", body, { c: ruben })).status, 409);
  // wie komt uit de sessie, niet uit het verzoek
  const m2 = await (await m("POST", "/", { ...melding(), wie: "Ruben" })).json();
  assert.equal(m2.wie, "Kevin");
  const lijst = (await (await m("GET", "/")).json()).meldingen;
  assert.equal(lijst.length, 2);
  assert.ok(lijst[0].wanneer >= lijst[1].wanneer);
  const p = await m("PATCH", `/${body.id}`, { status: "opgepakt" });
  assert.equal(p.status, 200);
  const pm = await p.json();
  assert.equal(pm.status, "opgepakt");
  assert.equal(pm.gewijzigdDoor, "Kevin");
  assert.equal((await m("PATCH", `/${body.id}`, { status: "raar" })).status, 400);
  assert.equal((await m("POST", "/", { ...melding(), soort: "x" })).status, 400);
});

test("auth: van 10 gelijktijdige foute pogingen komen hoogstens 5 tot het wachtwoord", async () => {
  const r = await Promise.all(Array.from({ length: 10 }, () =>
    a("POST", "inloggen", { naam: "Kevin", wachtwoord: "fout" }, { ip: "4.4.4.4" })));
  const s = r.map((x) => x.status);
  assert.ok(s.filter((x) => x === 401).length <= 5, s.join());
  assert.equal(s.filter((x) => x === 401).length + s.filter((x) => x === 429).length, 10);
});

test("meldingen: PATCH met ongeldige of onbekende id geeft 404", async () => {
  assert.equal((await m("PATCH", "/0000000000000-aaaaa", { status: "klaar" })).status, 404);
  assert.equal((await m("PATCH", "/..%2Fx", { status: "klaar" })).status, 404);
  assert.equal((await m("PATCH", `/${crypto.randomUUID()}`, { status: "klaar" })).status, 404);
});

test("meldingen: 415 zonder JSON content-type en 403 bij vreemde Sec-Fetch-Site", async () => {
  const zonderType = await meldingen(new Request("https://x.test/api/dashboard/meldingen/", {
    method: "POST", headers: { cookie, "content-type": "text/plain" }, body: JSON.stringify(melding()),
  }), {});
  assert.equal(zonderType.status, 415);
  const geenType = await meldingen(new Request("https://x.test/api/dashboard/meldingen/", {
    method: "POST", headers: { cookie }, body: JSON.stringify(melding()),
  }), {});
  assert.equal(geenType.status, 415);
  assert.equal((await m("POST", "/", melding(), { headers: { "sec-fetch-site": "cross-site" } })).status, 403);
  assert.equal((await m("POST", "/", melding(), { headers: { "sec-fetch-site": "same-site" } })).status, 403);
  assert.equal((await m("POST", "/", melding(), { headers: { "sec-fetch-site": "same-origin" } })).status, 201);
});

test("meldingen: lijst nieuwste eerst, sleutel met tijd vooraan, ook bij meer dan 500", async () => {
  const st = fabriek("dashboard-test-meldingen");
  for (let i = 0; i < 510; i++) {
    const t = new Date(1_700_000_000_000 + i * 1000).toISOString();
    await st.setJSON(`melding/${t.replace(/[-:.]/g, "")}-x${i}`, { id: String(i), wanneer: t, tekst: "t", soort: "wens", status: "nieuw", wie: "Kevin", scherm: "/" });
  }
  const nieuw = melding();
  const r = await m("POST", "/", nieuw);
  assert.equal(r.status, 201);
  const lijst = (await (await m("GET", "/")).json()).meldingen;
  assert.equal(lijst.length, 500);
  assert.equal(lijst[0].id, nieuw.id);
  const sleutels = (await st.list({ prefix: "melding/" })).blobs.map((b) => b.key);
  assert.ok(sleutels.some((k) => /^melding\/\d{8}T\d{9}Z-/.test(k) && k.endsWith(nieuw.id)));
});

test("meldingen: herhaling na half mislukt schrijven (index er wel, melding niet) maakt de melding alsnog", async () => {
  const st = fabriek("dashboard-test-meldingen");
  const body = melding();
  await st.setJSON(`index/${body.id}`, { sleutel: `melding/20260101T000000000Z-${body.id}`, wie: "Kevin" });
  const r = await m("POST", "/", body);
  assert.equal(r.status, 201);
  assert.equal((await m("POST", "/", body)).status, 200);
  assert.equal((await (await m("GET", "/")).json()).meldingen.length, 1);
});

test("meldingen: schrijft in de teststore buiten production", async () => {
  await m("POST", "/", melding());
  assert.deepEqual([...fabriek.stores.keys()], ["dashboard-test-meldingen"]);
});

test("DASHBOARD_ECHTE_DATA aan zonder deploy-context: 500 met algemene melding, geen teststore", async () => {
  process.env.DASHBOARD_ECHTE_DATA = "aan";
  const eerder = console.error;
  const logs = [];
  console.error = (...x) => logs.push(x.join(" "));
  try {
    const r = await meldingen(new Request("https://x.test/api/dashboard/meldingen/", { headers: { cookie } }), {});
    assert.equal(r.status, 500);
    assert.deepEqual(await r.json(), { fout: "Er ging iets mis. Probeer het zo opnieuw." });
    assert.ok(logs.some((l) => l.includes("Deploy-context ontbreekt")));
    assert.equal(fabriek.stores.size, 0);
    // met context production wel de echte store
    const ok = await meldingen(new Request("https://x.test/api/dashboard/meldingen/", { headers: { cookie } }), { deploy: { context: "production" } });
    assert.equal(ok.status, 200);
    assert.deepEqual([...fabriek.stores.keys()], ["dashboard-meldingen"]);
  } finally {
    console.error = eerder;
    delete process.env.DASHBOARD_ECHTE_DATA;
  }
});

test("auth: routering, ik, inloggen, uitloggen, cookies", async () => {
  assert.equal((await a("GET", "ik")).status, 401);
  assert.equal((await a("GET", "onbekend")).status, 404);
  assert.equal((await a("GET", "inloggen")).status, 404);
  assert.equal((await a("POST", "ik")).status, 404);
  assert.equal((await a("POST", "inloggen", { naam: "Kevin", wachtwoord: "fout" })).status, 401);
  assert.equal((await a("POST", "inloggen", { naam: "Piet", wachtwoord: "fout" })).status, 401);
  assert.equal((await a("POST", "inloggen", { naam: 5, wachtwoord: "x" })).status, 400);
  const ok = await a("POST", "inloggen", { naam: "Kevin", wachtwoord: GEBRUIKER });
  assert.equal(ok.status, 200);
  assert.match(alsCookie(ok, "dashboard_sessie"), /HttpOnly; Secure; SameSite=Strict; Path=\/api\/dashboard;/);
  assert.match(alsCookie(ok, "dashboard_apparaat"), /HttpOnly; Secure; SameSite=Strict; Path=\/api\/dashboard\/auth;/);
  const token = alsCookie(ok, "dashboard_sessie").split(";")[0];
  assert.deepEqual(await (await a("GET", "ik", undefined, { c: token })).json(), { naam: "Kevin" });
  assert.match((await a("POST", "uitloggen")).headers.get("set-cookie"), /Max-Age=0/);
});

test("auth: retry-after na 5 fouten; apparaat-cookie helpt niet tegen IP-blokkade", async () => {
  const ok = await a("POST", "inloggen", { naam: "Kevin", wachtwoord: GEBRUIKER });
  const apparaat = alsCookie(ok, "dashboard_apparaat").split(";")[0];
  for (let i = 0; i < 5; i++) assert.equal((await a("POST", "inloggen", { naam: "Kevin", wachtwoord: "fout" }, { ip: "6.6.6.6" })).status, 401);
  const geblokkeerd = await a("POST", "inloggen", { naam: "Kevin", wachtwoord: GEBRUIKER }, { ip: "6.6.6.6", c: apparaat });
  assert.equal(geblokkeerd.status, 429);
  assert.ok(Number(geblokkeerd.headers.get("retry-after")) > 0);
  // ander IP: gewoon toegestaan
  assert.equal((await a("POST", "inloggen", { naam: "Kevin", wachtwoord: GEBRUIKER }, { ip: "7.7.7.7" })).status, 200);
});

test("auth: 415 en 403 bij inloggen; geen geheim geeft 500 zonder details", async () => {
  const r415 = await auth(new Request("https://x.test/api/dashboard/auth/inloggen", {
    method: "POST", headers: { "content-type": "text/plain" }, body: "{}",
  }), {});
  assert.equal(r415.status, 415);
  assert.equal((await a("POST", "inloggen", { naam: "Kevin", wachtwoord: GEBRUIKER }, { headers: { "sec-fetch-site": "cross-site" } })).status, 403);
  delete process.env.DASHBOARD_SESSIE_GEHEIM;
  const r = await a("POST", "inloggen", { naam: "Kevin", wachtwoord: GEBRUIKER }, { ip: "8.8.4.4" });
  assert.equal(r.status, 500);
  assert.deepEqual(await r.json(), { fout: "Er ging iets mis. Probeer het zo opnieuw." });
});

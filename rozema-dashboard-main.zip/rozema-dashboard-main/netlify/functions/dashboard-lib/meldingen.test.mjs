import { test } from "node:test";
import assert from "node:assert/strict";
import { valideerNieuweMelding, valideerStatus, ID_PATROON, MAX_TEKST } from "./meldingen-regels.mjs";

const id = "3f2b8c1e-9a4d-4b7e-8c21-5d6e7f8a9b0c";
const basis = { id, scherm: "/dashboard/", tekst: "Knop is te klein", soort: "wens", info: { breedte: 390, versie: "1" } };

test("validatie nieuwe melding", () => {
  assert.deepEqual(valideerNieuweMelding(basis).waarde, basis);
  for (const slecht of [
    null, {}, { ...basis, tekst: "" }, { ...basis, tekst: "   " }, { ...basis, tekst: 5 },
    { ...basis, tekst: "a".repeat(MAX_TEKST + 1) }, { ...basis, soort: "idee" },
    { ...basis, scherm: "http://evil" }, { ...basis, scherm: "/" + "a".repeat(300) }, { ...basis, scherm: 3 },
    { ...basis, id: undefined }, { ...basis, id: "../x" }, { ...basis, id: id.toUpperCase() },
  ]) assert.ok(valideerNieuweMelding(slecht).fout, JSON.stringify(slecht).slice(0, 60));
  const r = valideerNieuweMelding({ ...basis, info: { breedte: "x", versie: 5 } });
  assert.deepEqual(r.waarde.info, { breedte: null, versie: null });
  assert.equal(valideerNieuweMelding({ ...basis, info: { breedte: 1e9, versie: "v".repeat(100) } }).waarde.info.versie.length, 40);
});

test("validatie status en id", () => {
  assert.ok(valideerStatus({ status: "klaar" }).waarde);
  assert.ok(valideerStatus({ status: "weg" }).fout);
  assert.ok(valideerStatus(null).fout);
  assert.match(crypto.randomUUID(), ID_PATROON);
});

// Antwoorden met vaste headers.
export const BASIS_HEADERS = {
  "content-type": "application/json; charset=utf-8",
  "cache-control": "no-store",
  "x-content-type-options": "nosniff",
  "x-robots-tag": "noindex, nofollow",
};

// extraHeaders: waarde mag een array zijn (bijv. twee set-cookie headers).
export function json(data, status = 200, extraHeaders = {}) {
  const headers = new Headers(BASIS_HEADERS);
  for (const [k, v] of Object.entries(extraHeaders)) {
    for (const w of Array.isArray(v) ? v : [v]) headers.append(k, w);
  }
  return new Response(JSON.stringify(data), { status, headers });
}

export function fout(bericht, status = 400, extraHeaders = {}) {
  return json({ fout: bericht }, status, extraHeaders);
}

// Wordt gegooid door leesJson; interneFout geeft dan het bijbehorende antwoord.
export class Weiger extends Error {
  constructor(antwoord) {
    super("Verzoek geweigerd");
    this.name = "Weiger";
    this.antwoord = antwoord;
  }
}

// Interne fout: algemene melding naar de client, alleen de soort fout in de log.
export function interneFout(err, context = "") {
  if (err instanceof Weiger) return err.antwoord;
  console.error("Interne fout", context, err && err.name ? err.name : "onbekend");
  return fout("Er ging iets mis. Probeer het zo opnieuw.", 500);
}

// Leest een JSON-body met een maximale grootte; geeft een object, of null bij
// ongeldige inhoud. Gooit Weiger (415 of 403) als het verzoek niet van de eigen
// pagina komt: content-type moet application/json zijn en Sec-Fetch-Site, als
// aanwezig, same-origin.
export async function leesJson(req, maxTekens = 10000) {
  const type = (req.headers.get("content-type") || "").toLowerCase();
  if (!type.startsWith("application/json")) {
    throw new Weiger(fout("Verzoek wordt niet ondersteund.", 415));
  }
  const site = req.headers.get("sec-fetch-site");
  if (site !== null && site !== "same-origin") {
    throw new Weiger(fout("Niet toegestaan.", 403));
  }
  try {
    const tekst = await req.text();
    if (tekst.length > maxTekens) return null;
    const data = JSON.parse(tekst);
    return data && typeof data === "object" && !Array.isArray(data) ? data : null;
  } catch {
    return null;
  }
}

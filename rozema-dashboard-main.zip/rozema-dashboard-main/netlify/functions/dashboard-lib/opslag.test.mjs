import { test } from "node:test";
import assert from "node:assert/strict";
import { storeNaam, store, zetStoreFabriek, zetContext, bijwerk } from "./opslag.mjs";
import { geheugenFabriek, geheugenStore } from "./test-hulp.mjs";

test("storeNaam: echt alleen met DASHBOARD_ECHTE_DATA 'aan' EN context production", () => {
  const aan = { DASHBOARD_ECHTE_DATA: "aan" };
  assert.equal(storeNaam("auth", aan, "production"), "dashboard-auth");
  assert.equal(storeNaam("auth", aan, "deploy-preview"), "dashboard-test-auth");
  assert.equal(storeNaam("auth", aan, "branch-deploy"), "dashboard-test-auth");
  assert.equal(storeNaam("auth", aan, "dev"), "dashboard-test-auth");
  assert.equal(storeNaam("auth", {}, undefined), "dashboard-test-auth");
  assert.equal(storeNaam("auth", {}, "production"), "dashboard-test-auth");
  assert.equal(storeNaam("auth", { DASHBOARD_ECHTE_DATA: "ja" }, "production"), "dashboard-test-auth");
  assert.equal(storeNaam("auth", { DASHBOARD_ECHTE_DATA: "AAN" }, "production"), "dashboard-test-auth");
});

test("storeNaam: aan zonder deploy-context is een fout, geen stille teststore", () => {
  const eerder = console.error;
  const logs = [];
  console.error = (...x) => logs.push(x.join(" "));
  try {
    assert.throws(() => storeNaam("auth", { DASHBOARD_ECHTE_DATA: "aan" }, undefined));
    assert.throws(() => storeNaam("auth", { DASHBOARD_ECHTE_DATA: "aan" }, null));
  } finally { console.error = eerder; }
  assert.equal(logs.length, 2);
  assert.ok(logs.every((l) => l.includes("Deploy-context ontbreekt")));
});

test("storeNaam weigert vreemde namen", () => {
  assert.throws(() => storeNaam("../x", {}));
  assert.throws(() => storeNaam("", {}));
  assert.throws(() => storeNaam(5, {}));
});

test("zetContext leest context.deploy.context; ontbrekende context met aan is een fout", () => {
  const f = geheugenFabriek();
  zetStoreFabriek(f);
  const oud = process.env.DASHBOARD_ECHTE_DATA;
  const eerder = console.error;
  console.error = () => {};
  process.env.DASHBOARD_ECHTE_DATA = "aan";
  try {
    zetContext(undefined);
    assert.throws(() => store("a"));
    zetContext({});
    assert.throws(() => store("d"));
    zetContext({ deploy: { context: "deploy-preview" } }); store("b");
    zetContext({ deploy: { context: "production" } }); store("c");
    delete process.env.DASHBOARD_ECHTE_DATA;
    zetContext(undefined); store("e"); // variabele uit: teststore, ook zonder context
  } finally {
    console.error = eerder;
    if (oud === undefined) delete process.env.DASHBOARD_ECHTE_DATA; else process.env.DASHBOARD_ECHTE_DATA = oud;
    zetContext(undefined);
    zetStoreFabriek(null);
  }
  assert.deepEqual([...f.stores.keys()], ["dashboard-test-b", "dashboard-c", "dashboard-test-e"]);
});

test("geheugenstore: etag, onlyIfNew, onlyIfMatch, getWithMetadata", async () => {
  const s = geheugenStore();
  assert.equal(await s.getWithMetadata("k", { type: "json" }), null);
  const a = await s.setJSON("k", { n: 1 }, { onlyIfNew: true });
  assert.equal(a.modified, true);
  assert.equal((await s.setJSON("k", { n: 2 }, { onlyIfNew: true })).modified, false);
  const r = await s.getWithMetadata("k", { type: "json" });
  assert.deepEqual(r.data, { n: 1 });
  assert.equal((await s.setJSON("k", { n: 3 }, { onlyIfMatch: "fout" })).modified, false);
  assert.equal((await s.setJSON("k", { n: 3 }, { onlyIfMatch: r.etag })).modified, true);
  assert.deepEqual(await s.get("k", { type: "json" }), { n: 3 });
});

test("bijwerk: schrijft, herhaalt bij conflict, geeft op na 3 pogingen", async () => {
  const s = geheugenStore();
  assert.deepEqual((await bijwerk(s, "t", (h) => ({ n: (h?.n ?? 0) + 1 }))).waarde, { n: 1 });
  assert.deepEqual((await bijwerk(s, "t", (h) => ({ n: h.n + 1 }))).waarde, { n: 2 });
  // een andere schrijver komt er tussen bij de eerste poging
  let eerste = true;
  const lastig = { ...s, async setJSON(k, v, o) { if (eerste) { eerste = false; await s.setJSON(k, { n: 10 }); } return s.setJSON(k, v, o); } };
  assert.deepEqual((await bijwerk(lastig, "t", (h) => ({ n: h.n + 1 }))).waarde, { n: 11 });
  // blijft mislukken
  const altijd = { ...s, async setJSON(k, v, o) { await s.setJSON(k, { n: 99 }); return s.setJSON(k, v, o); } };
  const r = await bijwerk(altijd, "t", (h) => ({ n: h.n + 1 }), 3);
  assert.equal(r.conflict, true);
  // undefined = niets schrijven
  assert.equal((await bijwerk(s, "bestaatniet", () => undefined)).geschreven, false);
});

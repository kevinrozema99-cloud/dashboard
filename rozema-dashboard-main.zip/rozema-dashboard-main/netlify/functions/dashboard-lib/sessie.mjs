// Wachtwoorden, sessietokens en inlogbeperking.
import { createHmac, pbkdf2, randomBytes, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";
import { store, bijwerk } from "./opslag.mjs";

const pbkdf2Async = promisify(pbkdf2);

export const COOKIE_NAAM = "dashboard_sessie";
export const SESSIE_SECONDEN = 30 * 24 * 60 * 60;
const MIN_GEHEIM = 32;
const DUMMY_ITER = 210000;

function gelijk(a, b) {
  const x = Buffer.from(String(a));
  const y = Buffer.from(String(b));
  if (x.length !== y.length) return false;
  return timingSafeEqual(x, y);
}

function geheim(env = process.env) {
  const g = env.DASHBOARD_SESSIE_GEHEIM;
  return typeof g === "string" && g.length >= MIN_GEHEIM ? g : null;
}

const heeft = (o, k) => Object.prototype.hasOwnProperty.call(o, k);

export function gebruikers(env = process.env) {
  try {
    const o = JSON.parse(env.DASHBOARD_GEBRUIKERS || "{}");
    return o && typeof o === "object" && !Array.isArray(o) ? o : {};
  } catch {
    return {};
  }
}

// ---- wachtwoord ----
export async function maakWachtwoordHash(wachtwoord, iteraties = 210000) {
  const salt = randomBytes(16);
  const hash = await pbkdf2Async(wachtwoord, salt, iteraties, 32, "sha256");
  return `pbkdf2$${iteraties}$${salt.toString("base64")}$${hash.toString("base64")}`;
}

// Rekent altijd een pbkdf2 uit (dummy bij onbekende naam of kapotte hash),
// zodat er geen timingverschil is tussen bekende en onbekende namen.
export async function controleerWachtwoord(naam, wachtwoord, env = process.env) {
  const lijst = gebruikers(env);
  const bekend = typeof naam === "string" && heeft(lijst, naam);
  const delen = bekend && typeof lijst[naam] === "string" ? lijst[naam].split("$") : [];
  const goedGevormd =
    delen.length === 4 &&
    delen[0] === "pbkdf2" &&
    Number.isInteger(+delen[1]) &&
    +delen[1] > 0;
  const iter = goedGevormd ? Math.min(+delen[1], 2000000) : DUMMY_ITER;
  const salt = goedGevormd ? Buffer.from(delen[2], "base64") : Buffer.alloc(16);
  const verwacht = goedGevormd ? Buffer.from(delen[3], "base64") : Buffer.alloc(32);
  const pw = typeof wachtwoord === "string" ? wachtwoord : "";
  const berekend = await pbkdf2Async(pw, salt, iter, 32, "sha256");
  const gelijkHash =
    berekend.length === verwacht.length ? timingSafeEqual(berekend, verwacht) : false;
  return goedGevormd && gelijkHash;
}

// ---- token ----
// Twee soorten, beide HMAC-ondertekend met hetzelfde geheim maar met een eigen
// soort (k), zodat het ene nooit voor het andere doorgaat:
//   "s" = sessie (30 dagen), "a" = apparaat (1 jaar, voor de inlogbeperking).
export const APPARAAT_SECONDEN = 365 * 24 * 60 * 60;
const versie = (env) => String(env.DASHBOARD_SESSIE_VERSIE || "1");

function maakSoortToken(soort, naam, seconden, env, nu) {
  const g = geheim(env);
  if (!g) return null;
  const payload = { k: soort, u: naam, exp: Math.floor(nu / 1000) + seconden, v: versie(env) };
  const deel = Buffer.from(JSON.stringify(payload)).toString("base64url");
  const sig = createHmac("sha256", g).update(deel).digest("base64url");
  return `${deel}.${sig}`;
}

function leesSoortToken(soort, token, env, nu) {
  const g = geheim(env);
  if (!g || typeof token !== "string") return null;
  const delen = token.split(".");
  if (delen.length !== 2) return null;
  const [deel, sig] = delen;
  const verwacht = createHmac("sha256", g).update(deel).digest("base64url");
  if (!gelijk(sig, verwacht)) return null;
  let p;
  try {
    p = JSON.parse(Buffer.from(deel, "base64url").toString("utf8"));
  } catch {
    return null;
  }
  if (!p || p.k !== soort || typeof p.u !== "string" || typeof p.exp !== "number") return null;
  if (p.exp * 1000 <= nu) return null;
  if (!gelijk(p.v, versie(env))) return null;
  if (!heeft(gebruikers(env), p.u)) return null;
  return p;
}

export function maakToken(naam, env = process.env, nu = Date.now()) {
  return maakSoortToken("s", naam, SESSIE_SECONDEN, env, nu);
}

// Geeft {wie} of null.
export function controleerToken(token, env = process.env, nu = Date.now()) {
  const p = leesSoortToken("s", token, env, nu);
  return p ? { wie: p.u } : null;
}

export function maakApparaatToken(naam, env = process.env, nu = Date.now()) {
  return maakSoortToken("a", naam, APPARAAT_SECONDEN, env, nu);
}

// Is dit een geldig apparaat-token voor deze naam?
export function controleerApparaatToken(token, naam, env = process.env, nu = Date.now()) {
  const p = leesSoortToken("a", token, env, nu);
  return !!p && gelijk(p.u, naam);
}

// ---- cookie ----
export function sessieCookie(token) {
  return `${COOKIE_NAAM}=${token}; HttpOnly; Secure; SameSite=Strict; Path=/api/dashboard; Max-Age=${SESSIE_SECONDEN}`;
}
export function wisCookie() {
  return `${COOKIE_NAAM}=; HttpOnly; Secure; SameSite=Strict; Path=/api/dashboard; Max-Age=0`;
}

export const APPARAAT_COOKIE = "dashboard_apparaat";
export function apparaatCookie(token) {
  return `${APPARAAT_COOKIE}=${token}; HttpOnly; Secure; SameSite=Strict; Path=/api/dashboard/auth; Max-Age=${APPARAAT_SECONDEN}`;
}

export function leesCookie(req, naam = COOKIE_NAAM) {
  const kop = req.headers.get("cookie") || "";
  for (const stuk of kop.split(";")) {
    const i = stuk.indexOf("=");
    if (i > 0 && stuk.slice(0, i).trim() === naam) return stuk.slice(i + 1).trim();
  }
  return null;
}

// Geeft {wie} of null.
export function vereisSessie(req, env = process.env, nu = Date.now()) {
  return controleerToken(leesCookie(req), env, nu);
}

// ---- inlogbeperking ----
// Tellers in store "auth": per IP, per IP+naam en per naam (alleen bestaande
// namen). Elke poging wordt VÓÓR het uitrekenen van pbkdf2 gereserveerd (teller
// met etag ophogen), zodat parallelle pogingen niet allemaal door de controle
// glippen. Lukt reserveren na 3 conflicten niet, dan wordt de poging geweigerd.
// Bij succes worden de tellers van die gebruiker gewist.
// Na GRENS pogingen loopt de wachttijd op: 1, 2, 4, 8 minuten, maximaal
// MAX_MINUTEN, voor de IP- en IP+naam-tellers.
// De teller per naam is alleen een zachte vertraging: begint pas na NAAM_EXTRA
// extra pogingen en laat nooit langer dan NAAM_MAX_MINUTEN wachten, en geldt niet
// voor een apparaat met een geldig apparaat-cookie. Zo kan een aanvaller de echte
// gebruiker, ook op een nieuw apparaat, nooit langer dan een minuut tegenhouden.
// Voor onbekende namen worden dezelfde lees- en schrijfacties op dummysleutels
// gedaan, zodat er geen timingverschil is tussen bekende en onbekende namen.
export const GRENS = 5;
export const MAX_MINUTEN = 15;
export const NAAM_MAX_MINUTEN = 1;
const NAAM_EXTRA = 15;
const VENSTER_MS = 60 * 60 * 1000;
const CONFLICT_WACHT_S = 5;

export function wachttijdMs(fouten, grens = GRENS, maxMinuten = MAX_MINUTEN) {
  if (fouten < grens) return 0;
  return Math.min(2 ** (fouten - grens), maxMinuten) * 60 * 1000;
}

export function clientIp(req) {
  const ip = req.headers.get("x-nf-client-connection-ip") || "";
  return /^[0-9a-fA-F:.]{3,45}$/.test(ip) ? ip : "onbekend";
}

// dummy: true = blokkeert nooit (alleen om dezelfde acties uit te voeren).
function tellers(naam, ip, env) {
  const t = [{ sl: `ip/${ip}`, grens: GRENS, max: MAX_MINUTEN, soort: "ip" }];
  if (typeof naam === "string" && heeft(gebruikers(env), naam)) {
    t.push({ sl: `combi/${ip}/${naam}`, grens: GRENS, max: MAX_MINUTEN, soort: "combi" });
    t.push({ sl: `naam/${naam}`, grens: GRENS + NAAM_EXTRA, max: NAAM_MAX_MINUTEN, soort: "naam" });
  } else {
    t.push({ sl: "dummy/combi", grens: GRENS, max: MAX_MINUTEN, soort: "combi", dummy: true });
    t.push({ sl: "dummy/naam", grens: GRENS + NAAM_EXTRA, max: NAAM_MAX_MINUTEN, soort: "naam", dummy: true });
  }
  return t;
}

const LEEG = { fouten: 0, laatste: 0 };

// Reserveert een poging. Geeft null als de poging door mag, anders {wachtSeconden}.
// apparaatOk: geldig apparaat-cookie voor deze naam, dan blokkeert de naamteller niet.
export async function reserveerPoging(naam, ip, env = process.env, nu = Date.now(), apparaatOk = false) {
  const st = store("auth");
  for (const { sl, grens, max, soort, dummy } of tellers(naam, ip, env)) {
    let wacht = 0;
    const res = await bijwerk(st, sl, (t) => {
      const huidig = t && nu - t.laatste <= VENSTER_MS ? t : LEEG;
      const blokkeert = !dummy && !(soort === "naam" && apparaatOk);
      wacht = blokkeert ? huidig.laatste + wachttijdMs(huidig.fouten, grens, max) - nu : 0;
      if (wacht > 0) return undefined; // geweigerd: niet ophogen
      return { fouten: huidig.fouten + 1, laatste: nu };
    });
    if (wacht > 0) return { wachtSeconden: Math.ceil(wacht / 1000) };
    if (res.conflict && !dummy) return { wachtSeconden: CONFLICT_WACHT_S };
  }
  return null;
}

// Na een geslaagde login: de tellers van IP, IP+naam en naam wissen (de reservering
// van deze poging gaat daarmee ook weg).
export async function registreerSucces(naam, ip, env = process.env) {
  const st = store("auth");
  for (const { sl, dummy } of tellers(naam, ip, env)) if (!dummy) await st.delete(sl);
}

// Tests voor flow.mjs en taken.mjs: de vaste flow van lead tot uitbetaling en de takenlijst. Alleen fictieve data.
import { test } from "node:test";
import assert from "node:assert/strict";
import { leadTaak, klantTaak, plusDagen, LEAD_FLOW, KLANT_FLOW, alsLead } from "./flow.mjs";
import { maakTaken, volgendeTaakVan } from "./taken.mjs";
import { LEAD_STATUSSEN, FASES } from "./model.mjs";
import { testCatalogus } from "./test-regels.mjs";

const V = "2026-11-20";
const REGELS = testCatalogus();
const g = (fase, van) => ({ fase, van, wie: "Kevin" });

test("elke leadstatus behalve Afgevallen en elke fase behalve Verloren heeft een volgende stap", () => {
  for (const s of LEAD_STATUSSEN.filter((x) => x !== "Afgevallen")) assert.ok(LEAD_FLOW[s], s);
  for (const f of FASES.filter((x) => x !== "Verloren")) assert.ok(KLANT_FLOW[f], f);
  assert.equal(leadTaak({ status: "Afgevallen" }, V), null);
  assert.equal(klantTaak({ fase: "Verloren" }, V), null);
});

test("leadflow: datum = begin status + dagen; follow-up op de terugbeldatum; afspraak vervangt de flow-taak", () => {
  assert.deepEqual(leadTaak({ status: "Poging 1", statusSinds: "2026-11-18" }, V), { stap: "lead-poging-1", datum: "2026-11-19" });
  assert.deepEqual(leadTaak({ status: "Nieuw", statusSinds: null }, V), { stap: "lead-nieuw", datum: V });
  assert.deepEqual(leadTaak({ status: "Later opnieuw", statusSinds: "2026-11-01", terugbeldatum: "2027-01-15" }, V), { stap: "lead-later", datum: "2027-01-15" });
  assert.deepEqual(leadTaak({ status: "Later opnieuw", statusSinds: "2026-11-01" }, V), { stap: "lead-later", datum: "2026-12-01" });
  assert.equal(leadTaak({ status: "Afspraak gepland", openTaken: [{ soort: "afspraak" }] }, V), null);
  assert.equal(leadTaak({ status: "Afspraak gepland", openTaken: [{ soort: "taak" }] }, V).stap, "lead-afspraak");
});

test("klantflow: per fase de volgende stap; opname op de opnamedatum; factuur sturen en daarna betaling", () => {
  assert.deepEqual(klantTaak({ fase: "Getekend", fasegeschiedenis: [g("Getekend", "2026-11-10")] }, V), { stap: "klant-getekend", datum: "2026-11-12" });
  assert.deepEqual(klantTaak({ fase: "Opname gepland", opnamedatum: "2026-12-03" }, V), { stap: "klant-opname", datum: "2026-12-03" });
  assert.equal(klantTaak({ fase: "Opname gepland" }, V).stap, "klant-opnamedatum");
  assert.equal(klantTaak({ fase: "Schaderapport" }, V).stap, "klant-adviesrapport", "oude fase telt als Adviesrapport");
  assert.deepEqual(klantTaak({ fase: "Uitbetaald", fasegeschiedenis: [g("Uitbetaald", "2026-11-19")] }, V), { stap: "klant-factuur", datum: "2026-11-20" });
  assert.deepEqual(klantTaak({ fase: "Uitbetaald", factuurVerstuurdOp: "2026-11-01" }, V), { stap: "klant-betaling", datum: "2026-11-15" });
  assert.equal(klantTaak({ fase: "Afgerond", factuurVerstuurdOp: "2026-11-01", factuurVoldaanOp: "2026-11-10" }, V), null);
});

test("plusDagen en alsLead (record of indexrij)", () => {
  assert.equal(plusDagen("2026-12-31", 1), "2027-01-01");
  assert.equal(plusDagen("onzin", 1), null);
  const l = alsLead({ status: "Poging 2", statusgeschiedenis: [{ status: "Nieuw", van: "2026-11-01" }, { status: "Poging 2", van: "2026-11-05" }], taken: { a: { soort: "afspraak" }, b: { soort: "taak", klaar: { wie: "Kevin", op: "x" } } } });
  assert.deepEqual(l, { status: "Poging 2", statusSinds: "2026-11-05", terugbeldatum: null, openTaken: [{ soort: "afspraak" }] });
});

const rijen = [
  { id: "r_1", voornaam: "Piet", achternaam: "Proef", plaats: "Dorp", status: "Poging 1", statusSinds: "2026-11-18", eigenaar: "kevin", telefoon: "0600000000" },
  { id: "r_2", achternaam: "Nieuwkomer", status: "Nieuw", eigenaar: null, bron: "Website", aangemaakt: "2026-11-20" },
  { id: "r_3", achternaam: "Klant", status: "Klant", eigenaar: "ruben", openTaken: [{ id: "k1", titel: "Stukken ophalen", datum: "2026-11-25", soort: "taak" }] },
  { id: "r_4", achternaam: "Weg", status: "Afgevallen", eigenaar: null },
];
const trajecten = [{ id: "t_3", relatieId: "r_3", fase: "Getekend", fasegeschiedenis: [g("Getekend", "2026-11-17")] }];

test("takenlijst: toewijzen, flow, handmatig, op datum; Afgevallen niet toewijzen; filter op eigenaar", () => {
  const t = maakTaken(rijen, trajecten, REGELS, V);
  assert.deepEqual(t.toewijzen.map((x) => x.relatieId), ["r_2"]);
  assert.deepEqual(t.taken.map((x) => [x.relatieId, x.bron, x.stap ?? x.titel, x.datum]), [
    ["r_3", "flow", "klant-getekend", "2026-11-19"], // zelfde datum: op naam ("Klant" voor "Piet Proef")
    ["r_1", "flow", "lead-poging-1", "2026-11-19"],
    ["r_3", "handmatig", "Stukken ophalen", "2026-11-25"],
  ]);
  assert.equal(t.taken[1].naam, "Piet Proef");
  assert.equal(t.taken[1].telefoon, "0600000000");
  assert.equal(t.taken[2].taakId, "k1");
  assert.deepEqual(t.telling, { toewijzen: 1, teLaat: 2, vandaag: 0, totaal: 3 });
  assert.deepEqual(maakTaken(rijen, trajecten, REGELS, V, { wie: "ruben" }).taken.map((x) => x.relatieId), ["r_3", "r_3"]);
});

test("takenlijst: een lead zonder eigenaar krijgt nog geen flow-taak (eerst toewijzen)", () => {
  const t = maakTaken(rijen, trajecten, REGELS, V);
  assert.ok(!t.taken.some((x) => x.relatieId === "r_2"));
});

test("takenlijst: een bevestigde termijn met einddatum is een taak (bron termijn)", () => {
  const besluit = { id: "t_b", relatieId: "r_3", fase: "Besluit", verzenddatumBesluitbrief: "2026-11-02", fasegeschiedenis: [g("Besluit", "2026-11-03")] };
  const t = maakTaken([rijen[2]], [besluit], REGELS, V);
  const termijn = t.taken.filter((x) => x.bron === "termijn");
  assert.ok(termijn.length >= 1, JSON.stringify(t.taken));
  assert.ok(termijn.every((x) => /^\d{4}-\d{2}-\d{2}$/.test(x.datum)));
});

test("volgende taak voor de lijst: de vroegste van alle bronnen", () => {
  assert.deepEqual(volgendeTaakVan(rijen[2], trajecten, REGELS, V), { bron: "flow", stap: "klant-getekend", titel: null, datum: "2026-11-19", tijd: null });
  assert.equal(volgendeTaakVan(rijen[1], [], REGELS, V), null, "zonder eigenaar nog geen flow-taak");
});

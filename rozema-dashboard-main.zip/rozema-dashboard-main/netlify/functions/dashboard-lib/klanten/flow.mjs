// De vaste flow van lead tot uitbetaling (opdracht Ruben 20-11-2026): bij elke leadstatus en elke trajectfase hoort
// precies één volgende taak, zodat er niets gemist kan worden. Pure functies.
//
// - Afgeleid, niet opgeslagen: de taak volgt uit de status of fase en de datum waarop die begon. Verschuif je de
//   kaart, dan verdwijnt de oude taak en verschijnt de volgende vanzelf ("klaar" = de kaart verder zetten).
// - De dagen zijn een WERKAFSPRAAK (planning), geen wettelijke termijn. Pas ze hier aan; de wettelijke termijnen
//   (bezwaar, zienswijze) blijven in termijnregels.mjs en komen pas als taak met datum als K1 ze bevestigt.
// - De titels staan niet hier maar in de teksten (klanten.flow.<stap>): tekst en code gescheiden.
// - Een lead of klant zonder eigenaar krijgt nog geen taak: die staat eerst bij "Toewijzen".
import { normFase, isIsoDatum } from "./model.mjs";

// Leadstatus -> stap. datumVeld: een datum op de relatie die de taakdatum bepaalt (anders begin status + dagen).
export const LEAD_FLOW = Object.freeze({
  "Nieuw": { stap: "lead-nieuw", dagen: 0 },
  "Poging 1": { stap: "lead-poging-1", dagen: 1 },
  "Poging 2": { stap: "lead-poging-2", dagen: 2 },
  "Poging 3": { stap: "lead-poging-3", dagen: 0 },
  "WhatsApp verstuurd": { stap: "lead-whatsapp", dagen: 3 },
  "Contact gehad": { stap: "lead-contact", dagen: 1 },
  // Bij een geplande afspraak is de afspraak zelf de taak (aangemaakt bij het slepen); staat er geen, dan deze.
  "Afspraak gepland": { stap: "lead-afspraak", dagen: 0, alleenZonderAfspraak: true },
  "Keukentafelgesprek gedaan": { stap: "lead-keukentafel", dagen: 3 },
  // Follow-up: bel opnieuw op de terugbeldatum (gevraagd bij het slepen), anders na 30 dagen.
  "Later opnieuw": { stap: "lead-later", dagen: 30, datumVeld: "terugbeldatum" },
  "Niet gekwalificeerd": { stap: "lead-niet-gekwalificeerd", dagen: 2 },
});

// Trajectfase -> stap(pen). Bij Uitbetaald en Afgerond hangt de stap af van de factuur.
export const KLANT_FLOW = Object.freeze({
  "Getekend": { stap: "klant-getekend", dagen: 2 },
  "Aanvraag ingediend": { stap: "klant-aanvraag", dagen: 14 },
  // Opname bijwonen op de opnamedatum (gevraagd bij het slepen); zonder datum: opnamedatum invullen.
  "Opname gepland": { stap: "klant-opname", datumVeld: "opnamedatum", zonderDatum: { stap: "klant-opnamedatum", dagen: 0 } },
  "Opname gedaan": { stap: "klant-opname-gedaan", dagen: 21 },
  "Adviesrapport": { stap: "klant-adviesrapport", dagen: 3 },
  "Besluit": { stap: "klant-besluit", dagen: 2 },
  "Bezwaar": { stap: "klant-bezwaar", dagen: 28 },
  "Uitbetaald": { factuur: true },
  "Afgerond": { factuur: true },
});
export const FACTUUR = Object.freeze({ sturen: { stap: "klant-factuur", dagen: 1 }, betaling: { stap: "klant-betaling", dagen: 14 } });

const DAG_MS = 86400000;
export function plusDagen(datum, n) {
  if (!isIsoDatum(datum)) return null;
  return new Date(Date.parse(`${datum}T12:00:00Z`) + n * DAG_MS).toISOString().slice(0, 10);
}

// Laatste keer dat de relatie in haar huidige status kwam (YYYY-MM-DD), of null.
export function statusSinds(r) {
  const g = Array.isArray(r?.statusgeschiedenis) ? r.statusgeschiedenis : [];
  for (let i = g.length - 1; i >= 0; i--) if (g[i]?.status === r.status && typeof g[i]?.van === "string") return g[i].van;
  return null;
}
function faseSinds(t) {
  const g = Array.isArray(t?.fasegeschiedenis) ? t.fasegeschiedenis : [];
  const fase = normFase(t.fase);
  for (let i = g.length - 1; i >= 0; i--) if (normFase(g[i]?.fase) === fase && isIsoDatum(g[i]?.van)) return g[i].van;
  return null;
}

// lead: {status, statusSinds, terugbeldatum, openTaken:[{soort}]}. Geeft {stap, datum} of null.
export function leadTaak(lead, vandaag) {
  const s = LEAD_FLOW[lead?.status];
  if (!s) return null;
  if (s.alleenZonderAfspraak && (lead.openTaken || []).some((t) => t?.soort === "afspraak")) return null;
  const basis = isIsoDatum(lead.statusSinds) ? lead.statusSinds : vandaag;
  const veld = s.datumVeld && isIsoDatum(lead[s.datumVeld]) ? lead[s.datumVeld] : null;
  return { stap: s.stap, datum: veld ?? plusDagen(basis, s.dagen) };
}

// traject: record. Geeft {stap, datum} of null (Verloren, of factuur betaald).
export function klantTaak(traject, vandaag) {
  const fase = normFase(traject?.fase);
  const s = KLANT_FLOW[fase];
  if (!s) return null;
  const basis = faseSinds(traject) ?? vandaag;
  if (s.factuur) {
    if (!isIsoDatum(traject.factuurVerstuurdOp)) return { stap: FACTUUR.sturen.stap, datum: plusDagen(basis, FACTUUR.sturen.dagen) };
    if (!isIsoDatum(traject.factuurVoldaanOp)) return { stap: FACTUUR.betaling.stap, datum: plusDagen(traject.factuurVerstuurdOp, FACTUUR.betaling.dagen) };
    return null;
  }
  if (s.datumVeld) {
    if (isIsoDatum(traject[s.datumVeld])) return { stap: s.stap, datum: traject[s.datumVeld] };
    return { stap: s.zonderDatum.stap, datum: plusDagen(basis, s.zonderDatum.dagen) };
  }
  return { stap: s.stap, datum: plusDagen(basis, s.dagen) };
}

// Vorm van een relatierecord (of indexrij) voor leadTaak.
export const alsLead = (r) => ({
  status: r?.status ?? null, statusSinds: r?.statusSinds ?? statusSinds(r), terugbeldatum: r?.terugbeldatum ?? null,
  openTaken: Array.isArray(r?.openTaken) ? r.openTaken
    : Object.values(r?.taken || {}).filter((t) => t && !t.klaar).map((t) => ({ soort: t.soort ?? null })),
});

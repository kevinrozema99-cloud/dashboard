// Klantenmodule K11: volledige export (JSON en CSV) en AVG-verwijderen van een relatie.
// Leest via de exports van ./opslag.mjs; schrijft en verwijdert alleen in eigen sleutels
// (exportlog/, tombstone/) en bij het verwijderen in de sleutels van die ene relatie.
// Geen console.log en geen persoonsgegevens in logs, logregels of tombstones.
import { store, bijwerk } from "../opslag.mjs";
import { leesIndex, leesRelatie, leesTraject, leesTijdlijn, leesAlleTrajecten, leesRegister, isVerwijderd } from "./opslag.mjs";
import { weergavenaam } from "./model.mjs";
import { verwijderClaimVoorRelatie } from "./instroom.mjs";

const STORE = "klanten";
const RELATIE_ID = /^r_[A-Za-z0-9_-]{1,62}$/;
const GROEP = 20;
const st = () => store(STORE);
const isObj = (v) => v !== null && typeof v === "object" && !Array.isArray(v);

async function inGroepen(lijst, fn) {
  const uit = [];
  for (let i = 0; i < lijst.length; i += GROEP) uit.push(...(await Promise.allSettled(lijst.slice(i, i + GROEP).map(fn))));
  return uit;
}

// ---------- CSV ----------
// Formule-injectie: een tekst die met = + - @ (of tab/CR) begint krijgt een ' ervoor. Geldt voor strings en voor
// de JSON-tekst van geneste waarden; echte getallen blijven ongemoeid.
const FORMULE_START = /^[=+\-@\t\r]/;
export function csvCel(waarde) {
  if (waarde === null || waarde === undefined) return "";
  let t = typeof waarde === "string" ? waarde : typeof waarde === "object" ? JSON.stringify(waarde) : String(waarde);
  if (typeof waarde !== "number" && FORMULE_START.test(t)) t = `'${t}`;
  return /[",\r\n;]/.test(t) ? `"${t.replaceAll('"', '""')}"` : t;
}

// Kolommen: eerst id, dan de overige sleutels alfabetisch (vereniging van alle records). Geneste waarden als JSON.
export function maakCsv(records) {
  const kolommen = [...new Set(records.flatMap((r) => Object.keys(r)))].sort((a, b) => (a === "id" ? -1 : b === "id" ? 1 : a.localeCompare(b)));
  const regels = [kolommen.map(csvCel).join(",")];
  for (const r of records) regels.push(kolommen.map((k) => csvCel(r[k])).join(","));
  return `﻿${regels.join("\r\n")}\r\n`;
}

// ---------- export ----------
const KEY_RELATIE = /^relatie\/(r_[A-Za-z0-9_-]{1,62})$/;
const KEY_TRAJECT = /^traject\/(t_[A-Za-z0-9_-]{1,62})$/;

async function lijstIds(s, prefix, patroon) {
  const { blobs } = await s.list({ prefix });
  return blobs.map((b) => patroon.exec(b.key)?.[1]).filter(Boolean);
}

// Ids komen uit index, register en een list() van relatie/ en traject/; elk record wordt strong gelezen en
// moet zelf het eigen id dragen (filter). onleesbaar: de read mislukte of het record klopt niet met zijn sleutel.
// Records van een verwijderde relatie (tombstone) worden niet meegenomen.
export async function verzamelAlles(nu = new Date(), opties = {}) {
  const s = st();
  const [index, reg, alle, relatieKeys, trajectKeys] = await Promise.all([
    leesIndex(), leesRegister(), leesAlleTrajecten(nu), lijstIds(s, "relatie/", KEY_RELATIE), lijstIds(s, "traject/", KEY_TRAJECT),
  ]);
  const ids = new Set([...Object.keys(index.rijen ?? {}), ...relatieKeys]);
  for (const t of alle.trajecten) if (t.relatieId) ids.add(t.relatieId);
  for (const x of Object.values(reg.ids ?? {})) if (x?.relatieId) ids.add(x.relatieId);
  const lijst = [...ids].filter((id) => RELATIE_ID.test(id)).sort();
  const gelezen = await inGroepen(lijst, (id) => leesRelatie(id));
  const relaties = [];
  const onleesbaar = [];
  gelezen.forEach((g, i) => {
    if (g.status === "rejected") onleesbaar.push({ soort: "relatie", id: lijst[i] });
    else if (g.value) {
      if (g.value.id === lijst[i]) relaties.push(g.value);
      else onleesbaar.push({ soort: "relatie", id: lijst[i] });
    }
  });
  alle.onleesbaar.forEach((x) => onleesbaar.push({ soort: "traject", id: x.id }));
  // Trajecten die wel in list() staan maar nog niet in register of leesAlleTrajecten.
  const bekend = new Set([...alle.trajecten.map((t) => t.id), ...alle.onleesbaar.map((x) => x.id), ...alle.onvolledig.map((x) => x.id)]);
  const extra = trajectKeys.filter((id) => !bekend.has(id));
  const extraGelezen = await inGroepen(extra, (id) => leesTraject(id));
  const trajecten = [...alle.trajecten];
  extraGelezen.forEach((g, i) => {
    if (g.status === "rejected") onleesbaar.push({ soort: "traject", id: extra[i] });
    else if (g.value) {
      if (g.value.id === extra[i]) trajecten.push(g.value);
      else onleesbaar.push({ soort: "traject", id: extra[i] });
    }
  });
  const weg = new Set();
  for (const rid of new Set(trajecten.map((t) => t.relatieId).filter(Boolean))) if (await isVerwijderd(rid)) weg.add(rid);
  const schoon = trajecten.filter((t) => !weg.has(t.relatieId)).sort((a, b) => String(a.id).localeCompare(String(b.id)));
  const uit = { relaties, trajecten: schoon, onvolledig: alle.onvolledig.length, onleesbaar };
  if (opties.tijdlijnen) {
    const tl = await inGroepen(relaties, (r) => leesTijdlijn(r.id));
    uit.tijdlijnen = {};
    tl.forEach((g, i) => {
      if (g.status === "fulfilled") uit.tijdlijnen[relaties[i].id] = g.value;
      else onleesbaar.push({ soort: "tijdlijn", id: relaties[i].id });
    });
  }
  return uit;
}

// Codes voor de waarschuwing (CSV: response-header, JSON: veld). Leeg als alles leesbaar was.
export function waarschuwingen(a) {
  const w = [];
  if (a.onleesbaar.length) w.push(`onleesbaar:${a.onleesbaar.length}`);
  if (a.onvolledig) w.push(`onvolledig:${a.onvolledig}`);
  return w;
}

// Elke export wordt gelogd: wie, wanneer, welk formaat en aantallen. Geen inhoud.
export async function logExport({ wie, nu, formaat, soort, aantallen }) {
  try {
    await st().setJSON(`exportlog/${nu.toISOString()}-${Math.random().toString(36).slice(2, 8)}`, { wie, op: nu.toISOString(), formaat, soort, ...aantallen });
    return true;
  } catch {
    return false;
  }
}

// ---------- AVG-verwijderen ----------
// TODO(Ruben): welke bewaartermijn geldt voor klantgegevens (en voor de tombstone) na afronding of verlies van een
// traject? Tot dat besluit valt wordt hier NIETS automatisch opgeruimd: verwijderen gebeurt alleen op verzoek.
const vouw = (s) => String(s ?? "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/\s+/g, " ").trim();

// Wat de gebruiker moet intypen: de achternaam van de relatie (zonder achternaam: de weergavenaam).
export function bevestigingsWaarde(relatie) {
  const a = typeof relatie.achternaam === "string" && relatie.achternaam.trim() ? relatie.achternaam : weergavenaam(relatie);
  return typeof a === "string" ? a : "";
}

// Tijdsbudget: einde is een tijdstip in ms (Date.now()-schaal) of ontbreekt. Verstreken = de rest laten liggen voor de dagelijkse run.
const verstreken = (einde) => Number.isFinite(einde) && Date.now() >= einde;
export const OPRUIM_BUDGET_MS = 8000;
const TOMBSTONE_TERMIJN_MS = 7 * 24 * 3600 * 1000;

async function wisPrefix(s, prefix, einde) {
  let n = 0;
  // list is niet strong: een tweede ronde vangt wat net daarvoor is geschreven.
  for (let ronde = 0; ronde < 2; ronde++) {
    const { blobs } = await s.list({ prefix });
    for (let i = 0; i < blobs.length; i += GROEP) {
      if (verstreken(einde)) return n;
      await Promise.all(blobs.slice(i, i + GROEP).map((b) => s.delete(b.key)));
      n += Math.min(GROEP, blobs.length - i);
    }
    if (!blobs.length) break;
  }
  return n;
}

// Idempotent: wist alles van één relatie behalve het relatierecord en de tombstone. Veilig om te herhalen.
// Ook de instroomclaims van K9 (ontdubbel/instroom/...) die naar deze relatie wijzen; een tweede keer vindt er geen meer (0).
// Omdat verwijderRelatie, de herhaling daarvan en ruimTombstoneOp (dagelijkse run) allemaal via hier gaan, doen ze dit alle drie.
// Trajecten per relatie, één keer te lezen en door meerdere ruimOp-aanroepen te delen (de dagelijkse run leest de lijst
// dan één keer, niet per tombstone). Geeft Map traject-id -> relatieId; een onleesbaar traject staat erin met null.
// Een traject dat al verwijderd is leest als null en wordt niet meer meegeteld.
export async function trajectOverzicht(s = st()) {
  const sleutels = await lijstIds(s, "traject/", KEY_TRAJECT);
  const gelezen = await inGroepen(sleutels, async (t) => [t, await leesTraject(t)]);
  const kaart = new Map();
  for (const g of gelezen) if (g.status === "fulfilled" && g.value[1]?.relatieId) kaart.set(g.value[0], g.value[1].relatieId);
  return kaart;
}

// opties.overzicht: uit trajectOverzicht(); opties.einde: tijdstip (ms) waarna de rest blijft liggen (resultaat .deels = true).
export async function ruimOp(s, id, nu, opties = {}) {
  const { einde } = opties;
  const reg = await leesRegister();
  const trajectIds = new Set(Object.entries(reg.ids ?? {}).filter(([, x]) => x?.relatieId === id).map(([tid]) => tid));
  // Ook trajecten zonder registeritem: list() van traject/, strong gelezen en gefilterd op relatieId.
  const overzicht = opties.overzicht ?? await trajectOverzicht(s);
  for (const [tid, rid] of overzicht) if (rid === id) trajectIds.add(tid);
  const lijst = [...trajectIds];
  // Eerst register en index (snel, en zichtbaar voor lijsten), ook als het budget daarna op raakt.
  const r1 = await bijwerk(s, "register/trajecten", (cur) => {
    const ids = { ...(cur?.ids ?? {}) };
    let geraakt = false;
    for (const [tid, x] of Object.entries(ids)) if (x?.relatieId === id) { delete ids[tid]; geraakt = true; }
    return geraakt ? { ids } : undefined;
  });
  const r2 = await bijwerk(s, "index/relaties", (cur) => {
    if (!isObj(cur?.rijen) || !Object.hasOwn(cur.rijen, id)) return undefined;
    const rijen = { ...cur.rijen };
    delete rijen[id];
    return { rijen };
  });
  if (r1.conflict || r2.conflict) return null;
  // Alleen de ids van de trajecten, zodat een wijziging daarna 410 geeft in plaats van 404.
  for (let i = 0; i < lijst.length; i += GROEP) await Promise.all(lijst.slice(i, i + GROEP).map((tid) => s.setJSON(`tombstone-traject/${tid}`, { id: tid })));
  let deels = false;
  for (let i = 0; i < lijst.length; i += GROEP) {
    if (verstreken(einde)) { deels = true; break; }
    await Promise.all(lijst.slice(i, i + GROEP).map((tid) => s.delete(`traject/${tid}`)));
  }
  const logs = await wisPrefix(s, `log/${id}/`, einde);
  const journalen = await wisPrefix(s, `logwacht/${id}/`, einde);
  // Time-out in wisPrefix of ervoor: de rest (claims) doet de dagelijkse run; de tombstone staat er al.
  if (deels || verstreken(einde)) return { trajecten: lijst.length, logs, journalen, claims: 0, deels: true };
  const claims = await verwijderClaimVoorRelatie(id);
  return { trajecten: lijst.length, logs, journalen, claims };
}

// Geeft {ok:true, tombstone, verwijderd, alVerwijderd?} of {ok:false, fouten}.
// Volgorde: bevestiging controleren, tombstone schrijven, relatierecord wissen, daarna de rest idempotent opruimen.
// Na de tombstone weigeren aanmaken en logschrijven voor dit id (zie isVerwijderd in opslag.mjs).
// Bestaat de tombstone al en de relatie niet meer, dan is dit een herhaling: zonder bevestiging verder opruimen en ok.
// opties.budgetMs: hoeveel ms het opruimen mag duren (standaard OPRUIM_BUDGET_MS). Is het werk dan niet af, dan staat
// `deels: true` in het resultaat; de dagelijkse run maakt het af, omdat de tombstone er al staat.
export async function verwijderRelatie(id, bevestig, wie, nu = new Date(), opties = {}) {
  const einde = Date.now() + (Number.isFinite(opties.budgetMs) ? opties.budgetMs : OPRUIM_BUDGET_MS);
  if (typeof id !== "string" || !RELATIE_ID.test(id)) return { ok: false, fouten: { id: "geen-id" } };
  if (typeof wie !== "string" || !wie.trim()) return { ok: false, fouten: { _: "wie-verplicht" } };
  const s = st();
  const relatie = await leesRelatie(id);
  const bestaand = await s.get(`tombstone/${id}`, { type: "json", consistency: "strong" });
  if (!relatie) {
    if (!bestaand) return { ok: false, fouten: { id: "niet-gevonden" } };
    const v = await ruimOp(s, id, nu, { einde });
    if (!v) return { ok: false, fouten: { _: "gelijktijdig-probeer-opnieuw" } };
    return { ok: true, alVerwijderd: true, tombstone: bestaand, verwijderd: v, ...(v.deels ? { deels: true } : {}) };
  }
  const verwacht = vouw(bevestigingsWaarde(relatie));
  if (typeof bevestig !== "string" || !verwacht || vouw(bevestig) !== verwacht) {
    return { ok: false, fouten: { bevestig: "komt-niet-overeen" } };
  }
  // Alleen id, datum en wie. Geen naam, adres of reden.
  const tombstone = bestaand ?? { id, verwijderdOp: nu.toISOString(), wie };
  if (!bestaand) await s.setJSON(`tombstone/${id}`, tombstone);
  await s.delete(`relatie/${id}`);
  const v = await ruimOp(s, id, nu, { einde });
  if (!v) return { ok: false, fouten: { _: "gelijktijdig-probeer-opnieuw" } };
  return { ok: true, tombstone, verwijderd: v, ...(v.deels ? { deels: true } : {}) };
}

// Voor de dagelijkse run: ruimt na een race alles op van een relatie met een tombstone, ook een opnieuw aangemaakt
// relatierecord. Geeft null bij een gelijktijdig conflict (de volgende run probeert opnieuw), {overgeslagen:true} als de
// tombstone al langer dan 7 dagen geleden is opgeruimd (veld opgeruimdOp), anders het resultaat van ruimOp.
// opgeruimdOp wordt gezet bij de eerste geslaagde opruiming en daarna niet meer verschoven; de race-marge is dus 7 dagen.
// opties.overzicht: gedeeld trajectOverzicht() voor de hele run.
export async function ruimTombstoneOp(id, nu = new Date(), opties = {}) {
  const s = st();
  const tombstone = await s.get(`tombstone/${id}`, { type: "json", consistency: "strong" });
  const eerder = Date.parse(tombstone?.opgeruimdOp);
  if (Number.isFinite(eerder) && nu.getTime() - eerder >= TOMBSTONE_TERMIJN_MS) return { overgeslagen: true };
  await s.delete(`relatie/${id}`);
  const v = await ruimOp(s, id, nu, { overzicht: opties.overzicht });
  if (v && !v.deels && tombstone && !tombstone.opgeruimdOp) await s.setJSON(`tombstone/${id}`, { ...tombstone, opgeruimdOp: nu.toISOString() });
  return v;
}

export async function lijstTombstones() {
  return lijstIds(st(), "tombstone/", /^tombstone\/(r_[A-Za-z0-9_-]{1,62})$/);
}

// Pijplijn (trajecten per fase, zoals Zoho's Deals-kanban) en overzichten (zoals Zoho's rapporten).
// Pure functies: de route in dashboard-klanten.mjs leest index en trajecten en geeft ze hier door.
// Geen namen of adressen in de overzichten: alleen aantallen en bedragen. De pijplijn toont wel
// achternaam en plaats (uit de index), net als de lijst.
import { FASES, ROUTES, BRONNEN, STATUSSEN, EIGENAREN, REDENEN_VERLIES, LEAD_STATUSSEN, ARCHIEF_STATUSSEN, ARCHIEF_FASES, isIsoDatum, normFase } from "./model.mjs";
import { STATUS, termijnenVoor } from "./termijnen.mjs";

export const GESLOTEN_FASES = ["Afgerond", "Verloren"];
export const ONBEKEND = "onbekend";
const DAG_MS = 86400000;

const isObj = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
const getal = (v) => (typeof v === "number" && Number.isFinite(v) ? v : null);
const dagenTussen = (van, tot) => Math.round((Date.parse(`${tot}T12:00:00Z`) - Date.parse(`${van}T12:00:00Z`)) / DAG_MS);
const rond = (n) => Math.round(n * 100) / 100;

// Laatste keer dat het traject in zijn huidige fase kwam (YYYY-MM-DD), of null.
export function sindsInFase(traject) {
  const g = Array.isArray(traject?.fasegeschiedenis) ? traject.fasegeschiedenis : [];
  const fase = normFase(traject.fase);
  for (let i = g.length - 1; i >= 0; i--) if (normFase(g[i]?.fase) === fase && isIsoDatum(g[i]?.van)) return g[i].van;
  return null;
}

// Aantal fatale termijnen die aandacht vragen (open, te herbevestigen of datum ontbreekt).
// Een fout in de engine telt mee: liever een vals signaal dan een verborgen termijn.
const AANDACHT = new Set([STATUS.OPEN, STATUS.HERBEVESTIGEN, STATUS.DATUM_ONTBREEKT, STATUS.KON_NIET_BEREKENEN]);
function fataalAantal(traject, regels, vandaag) {
  try {
    return termijnenVoor(traject, null, regels, vandaag).filter((t) => t.fataal && AANDACHT.has(t.status)).length;
  } catch {
    return 1;
  }
}

// ---------- klantpijplijn ----------
// trajecten: lijst records; rijen: index-rijen per relatie-id; filters: {eigenaar?, route?, archief?: bool}.
// Geeft {kolommen: [{fase, aantal, fee, gearchiveerd, kaarten:[...]}], totaal}. Kaarten binnen een kolom: langst in de
// fase eerst. Alle fases zijn kolommen (ook om naartoe te slepen); Uitbetaald, Afgerond en Verloren zijn archief: hun
// kaarten alleen met archief:true, anders alleen het aantal (gearchiveerd).
export function maakPijplijn(trajecten, rijen, regels, vandaag, filters = {}) {
  const kolommen = new Map(FASES.map((f) => [f, { fase: f, aantal: 0, fee: 0, gearchiveerd: 0, archief: ARCHIEF_FASES.includes(f), kaarten: [] }]));
  let totaal = 0;
  for (const t of trajecten) {
    if (!isObj(t) || !kolommen.has(normFase(t.fase))) continue;
    const fase = normFase(t.fase);
    const rij = isObj(rijen) && Object.hasOwn(rijen, t.relatieId) ? rijen[t.relatieId] : null;
    const eigenaar = rij?.eigenaar ?? null;
    if (filters.eigenaar && eigenaar !== filters.eigenaar) continue;
    if (filters.route && t.route !== filters.route) continue;
    if (ARCHIEF_FASES.includes(fase) && !filters.archief) { kolommen.get(fase).gearchiveerd++; continue; }
    const sinds = sindsInFase(t);
    const kaart = {
      id: t.id, relatieId: t.relatieId ?? null,
      achternaam: rij?.achternaam ?? null, naam: rij?.naam ?? null, plaats: rij?.plaats ?? null,
      eigenaar, route: t.route ?? null, fee: getal(t.fee),
      opnamedatum: t.opnamedatum ?? null, opnametijd: t.opnametijd ?? null, verzenddatumBesluitbrief: t.verzenddatumBesluitbrief ?? null,
      sinds, dagenInFase: sinds && isIsoDatum(vandaag) ? Math.max(0, dagenTussen(sinds, vandaag)) : null,
      fataal: fataalAantal(t, regels, vandaag),
    };
    const k = kolommen.get(fase);
    k.kaarten.push(kaart);
    k.aantal++;
    if (kaart.fee !== null) k.fee = rond(k.fee + kaart.fee);
    totaal++;
  }
  for (const k of kolommen.values()) {
    k.kaarten.sort((a, b) => (b.dagenInFase ?? -1) - (a.dagenInFase ?? -1) || String(a.id).localeCompare(String(b.id)));
  }
  return { kolommen: [...kolommen.values()], totaal };
}

// ---------- leadpijplijn ----------
// rijen: index-rijen (array); filters: {eigenaar?, bron?, archief?: bool}. Kolommen = LEAD_STATUSSEN, plus de
// kolom "Contract getekend" (doel: "traject"): daar neerzetten start een traject in fase Getekend, en dan staat de
// relatie op Klant en verdwijnt ze van dit bord. Afgevallen is archief: kaarten alleen met archief:true.
// Kaarten: eerstvolgende taak eerst, dan langst in de status.
export const LEAD_DOEL_TRAJECT = "Contract getekend";
export function maakLeadPijplijn(rijen, vandaag, filters = {}) {
  const kolommen = new Map(LEAD_STATUSSEN.map((st) => [st, { status: st, aantal: 0, gearchiveerd: 0, archief: ARCHIEF_STATUSSEN.includes(st), kaarten: [] }]));
  let totaal = 0;
  for (const r of Array.isArray(rijen) ? rijen : []) {
    if (!isObj(r) || !kolommen.has(r.status)) continue;
    if (filters.eigenaar && r.eigenaar !== filters.eigenaar) continue;
    if (filters.bron && r.bron !== filters.bron) continue;
    const k = kolommen.get(r.status);
    if (k.archief && !filters.archief) { k.gearchiveerd++; continue; }
    const sinds = isIsoDatum(r.statusSinds) ? r.statusSinds : null;
    k.kaarten.push({
      id: r.id, achternaam: r.achternaam ?? null, naam: r.naam ?? null, plaats: r.plaats ?? null,
      eigenaar: r.eigenaar ?? null, bron: r.bron ?? null, contactvoorkeur: r.contactvoorkeur ?? null, soortWoning: r.soortWoning ?? null,
      terugbeldatum: r.terugbeldatum ?? null,
      sinds, dagenInStatus: sinds && isIsoDatum(vandaag) ? Math.max(0, dagenTussen(sinds, vandaag)) : null,
      volgendeTaak: isObj(r.volgendeTaak) ? { titel: r.volgendeTaak.titel ?? null, datum: r.volgendeTaak.datum ?? null } : null,
    });
    k.aantal++;
    totaal++;
  }
  for (const k of kolommen.values()) {
    k.kaarten.sort((a, b) => (a.volgendeTaak?.datum ?? "9999").localeCompare(b.volgendeTaak?.datum ?? "9999")
      || (b.dagenInStatus ?? -1) - (a.dagenInStatus ?? -1) || String(a.id).localeCompare(String(b.id)));
  }
  const uit = [...kolommen.values()];
  uit.push({ status: LEAD_DOEL_TRAJECT, doel: "traject", aantal: 0, gearchiveerd: 0, archief: false, kaarten: [] });
  return { kolommen: uit, totaal };
}

// ---------- overzichten ----------
// Periode {van?, tot?} (YYYY-MM-DD, tot en met). Leeg = alles.
export function inPeriode(datum, { van, tot } = {}) {
  if (!isIsoDatum(datum)) return !van && !tot; // zonder datum alleen meetellen als er geen periode is
  if (van && datum < van) return false;
  if (tot && datum > tot) return false;
  return true;
}

// Telt per waarde; vaste volgorde uit `lijst`, onbekende waarden onder ONBEKEND (achteraan).
function tel(items, waardeVan, lijst) {
  const uit = Object.fromEntries(lijst.map((w) => [w, 0]));
  for (const it of items) {
    const w = waardeVan(it);
    const k = lijst.includes(w) ? w : ONBEKEND;
    uit[k] = (uit[k] ?? 0) + 1;
  }
  return uit;
}

// Eerste keer dat het traject fase `fase` bereikte (YYYY-MM-DD), of null.
function bereikt(traject, fase) {
  const g = Array.isArray(traject?.fasegeschiedenis) ? traject.fasegeschiedenis : [];
  const e = g.find((x) => x?.fase === fase && isIsoDatum(x?.van));
  return e ? e.van : null;
}

// Gemiddeld aantal dagen per fase, uit de fasegeschiedenis (tijd tot de volgende fase; de huidige fase telt tot vandaag
// niet mee: die is nog niet af). Geeft {<fase>: {gemiddeld, aantal}} voor fases met minstens één afgeronde periode.
export function doorlooptijden(trajecten) {
  const som = {};
  for (const t of trajecten) {
    const g = (Array.isArray(t?.fasegeschiedenis) ? t.fasegeschiedenis : []).filter((x) => x && isIsoDatum(x.van));
    for (let i = 0; i + 1 < g.length; i++) {
      const d = dagenTussen(g[i].van, g[i + 1].van);
      const f = normFase(g[i].fase);
      if (d < 0 || !FASES.includes(f)) continue;
      const s = (som[f] ??= { totaal: 0, aantal: 0 });
      s.totaal += d;
      s.aantal++;
    }
  }
  const uit = {};
  for (const f of FASES) if (som[f]) uit[f] = { gemiddeld: Math.round(som[f].totaal / som[f].aantal), aantal: som[f].aantal };
  return uit;
}

// rijen: index-rijen (array); trajecten: records; periode: {van?, tot?}; vandaag: YYYY-MM-DD.
export function maakOverzicht(rijen, trajecten, periode = {}, vandaag = null) {
  const alleRijen = (Array.isArray(rijen) ? rijen : []).filter(isObj);
  const alleTrajecten = (Array.isArray(trajecten) ? trajecten : []).filter(isObj);
  const leads = alleRijen.filter((r) => inPeriode(r.aangemaakt, periode));
  const metTraject = new Set(alleTrajecten.map((t) => t.relatieId));

  // Instroom per maand (YYYY-MM), oplopend; alleen maanden met een datum.
  const perMaand = {};
  for (const r of leads) if (isIsoDatum(r.aangemaakt)) perMaand[r.aangemaakt.slice(0, 7)] = (perMaand[r.aangemaakt.slice(0, 7)] ?? 0) + 1;

  // Conversie per bron: van de leads in de periode, hoeveel hebben (nu) een traject.
  const conversie = {};
  for (const b of [...BRONNEN, ONBEKEND]) conversie[b] = { leads: 0, klanten: 0 };
  for (const r of leads) {
    const b = BRONNEN.includes(r.bron) ? r.bron : ONBEKEND;
    conversie[b].leads++;
    if (metTraject.has(r.id)) conversie[b].klanten++;
  }

  const open = alleTrajecten.filter((t) => !GESLOTEN_FASES.includes(t.fase));
  const getekend = alleTrajecten.filter((t) => inPeriode(t.getekendOp ?? bereikt(t, "Getekend") ?? t.aangemaakt?.op?.slice(0, 10), periode));
  const verloren = alleTrajecten.filter((t) => t.fase === "Verloren" && inPeriode(bereikt(t, "Verloren"), periode));
  const afgerond = alleTrajecten.filter((t) => t.fase === "Afgerond" && inPeriode(bereikt(t, "Afgerond"), periode));

  // Geld. Fee "in de pijplijn": open trajecten zonder verstuurde factuur. "Gefactureerd": verstuurd, nog niet voldaan
  // (ongeacht periode: dat is wat nu openstaat). "Voldaan": voldaan binnen de periode.
  let feePijplijn = 0, feePijplijnAantal = 0, feeOpen = 0, feeOpenAantal = 0, feeVoldaan = 0, feeVoldaanAantal = 0, uitkering = 0, uitkeringAantal = 0;
  for (const t of alleTrajecten) {
    const fee = getal(t.fee);
    if (fee !== null && !GESLOTEN_FASES.includes(t.fase) && !t.factuurVerstuurdOp) { feePijplijn += fee; feePijplijnAantal++; }
    if (fee !== null && t.factuurVerstuurdOp && !t.factuurVoldaanOp) { feeOpen += fee; feeOpenAantal++; }
    if (fee !== null && t.factuurVoldaanOp && inPeriode(t.factuurVoldaanOp, periode)) { feeVoldaan += fee; feeVoldaanAantal++; }
    const u = getal(t.uitkeringImg);
    if (u !== null && inPeriode(bereikt(t, "Uitbetaald") ?? t.factuurVerstuurdOp, periode)) { uitkering += u; uitkeringAantal++; }
  }
  // Openstaande facturen ouder dan 30 dagen (alleen aantal; welke staat in de pijplijn).
  const factuurOud = isIsoDatum(vandaag)
    ? alleTrajecten.filter((t) => t.factuurVerstuurdOp && !t.factuurVoldaanOp && isIsoDatum(t.factuurVerstuurdOp) && dagenTussen(t.factuurVerstuurdOp, vandaag) > 30).length
    : 0;

  return {
    periode: { van: periode.van ?? null, tot: periode.tot ?? null },
    leads: {
      totaal: leads.length,
      perBron: tel(leads, (r) => r.bron, BRONNEN),
      perStatus: tel(leads, (r) => r.status, STATUSSEN),
      perEigenaar: tel(leads, (r) => r.eigenaar, EIGENAREN),
      perMaand: Object.fromEntries(Object.keys(perMaand).sort().map((k) => [k, perMaand[k]])),
      zonderDatum: leads.filter((r) => !isIsoDatum(r.aangemaakt)).length,
    },
    conversie,
    trajecten: {
      open: open.length,
      perFase: tel(open, (t) => normFase(t.fase), FASES.filter((f) => !GESLOTEN_FASES.includes(f))),
      perRoute: tel(open, (t) => t.route, ROUTES),
      getekend: getekend.length,
      afgerond: afgerond.length,
      verloren: verloren.length,
      redenVerlies: tel(verloren, (t) => t.redenVerlies, REDENEN_VERLIES),
      doorlooptijd: doorlooptijden(alleTrajecten),
    },
    geld: {
      feePijplijn: { bedrag: rond(feePijplijn), aantal: feePijplijnAantal },
      feeGefactureerd: { bedrag: rond(feeOpen), aantal: feeOpenAantal, ouderDan30Dagen: factuurOud },
      feeVoldaan: { bedrag: rond(feeVoldaan), aantal: feeVoldaanAantal },
      uitkeringImg: { bedrag: rond(uitkering), aantal: uitkeringAantal },
    },
  };
}

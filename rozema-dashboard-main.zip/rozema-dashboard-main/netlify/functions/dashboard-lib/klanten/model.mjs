// Klantenmodule K1: velden, keuzelijsten en validatie van relatie en traject.
// Bron: dashboard/KLANTEN-ARCHITECTUUR.md §1 + Aanvulling. Pure functies, geen opslag.
//
// Foutmeldingen zijn codes (bijv. "verplicht", "geen-datum"), geen zinnen: de schermen
// zetten die om in tekst uit de content-bestanden.
//
// Bewust weggelaten Zoho-velden: zie ZOHO_WEGGELATEN onderaan (met reden per veld).

// ---------- keuzelijsten ----------
// Zonder "-None-" (leeg = null).
export const AANHEFFEN = ["Dhr.", "Mevr.", "Dokter.", "Mw.", "Prof."]; // Zoho-lijst
export const BRONNEN = ["Website", "Deur", "Niet thuis", "Instagram", "Facebook", "Google Ads", "Verwijzing", "Anders"]; // architectuur vraag 9
export const VOOR_WIE = ["Eigenaar", "Helpt een eigenaar"]; // uit v2 (zoho-velden.mjs)
// Soort woning (opdracht Ruben 20-11-2026): vervangt voorWie in de schermen; voorWie blijft voor de website-instroom.
export const SOORTEN_WONING = ["Eigen woning", "Woning van iemand die klant helpt", "Huurwoning"];
export const CONTACTVOORKEUREN = ["Bellen", "WhatsApp"]; // uit v2
// Zoho Lead_Status + "Klant" (automatisch bij eerste traject).
export const STATUSSEN = [
  "Nieuw", "Poging 1", "Poging 2", "Poging 3", "WhatsApp verstuurd", "Contact gehad", "Afspraak gepland",
  "Keukentafelgesprek gedaan", "Later opnieuw", "Niet gekwalificeerd", "Afgevallen", "Klant",
];
// Zoho-lijst plus twee waarden uit v2 die in Zoho ontbreken.
export const SITUATIES = [
  "Nooit gemeld", "Historie, geen lopende zaak", "Lopend, opname moet nog komen", "Wacht op rapport of besluit",
  "Adres afgesloten", "Huurder of geen woonhuis", "Herstel met aannemer gehad", "Anders",
  "Vaste vergoeding gehad", "Besluit genomen",
];
export const KWALIFICATIES = ["Ja", "Later", "Nee", "Twijfel", "Vaste vergoeding of AVV adviseren"];
export const REDENEN_AFGEVALLEN = [
  "Niet bereikt", "Geen interesse", "Huurder of geen woonhuis", "Geen bewijsvermoeden", "Adres afgesloten",
  "Vaste vergoeding gunstiger", "Kiest herstel", "Anders",
];
export const EIGENAREN = ["kevin", "ruben"];
export const TAAK_SOORTEN = ["taak", "afspraak"];
// Volgorde = verloop van het traject. "Verloren" staat apart (geen voortgang).
export const FASES = [
  "Getekend", "Aanvraag ingediend", "Opname gepland", "Opname gedaan", "Adviesrapport",
  "Besluit", "Bezwaar", "Uitbetaald", "Afgerond", "Verloren",
];
// Fases die niet meer bestaan (opdracht Ruben 20-11-2026: Schaderapport en Adviesrapport samen als Adviesrapport).
// Een bestaand record met zo'n fase blijft geldig en telt overal als de nieuwe fase; kiezen kan niet meer.
export const OUDE_FASES = Object.freeze({ Schaderapport: "Adviesrapport" });
export const normFase = (fase) => (Object.hasOwn(OUDE_FASES, fase) ? OUDE_FASES[fase] : fase);
const FASES_GELDIG = [...FASES, ...Object.keys(OUDE_FASES)];
export const FASES_VANAF_BESLUIT = ["Besluit", "Bezwaar", "Uitbetaald", "Afgerond"];

// ---------- twee pijplijnen en archief (opdracht Ruben 20-11-2026) ----------
// Leadpijplijn: de statussen van een lead, in deze volgorde. "Klant" hoort er niet bij: zodra het contract is getekend
// (eerste traject) gaat de relatie naar de klantpijplijn.
export const LEAD_STATUSSEN = [
  "Nieuw", "Poging 1", "Poging 2", "Poging 3", "WhatsApp verstuurd", "Contact gehad", "Afspraak gepland",
  "Keukentafelgesprek gedaan", "Later opnieuw", "Niet gekwalificeerd", "Afgevallen",
];
// Archief is afgeleid, geen opgeslagen vlag: een lead met status Afgevallen, of een klant van wie elk traject
// Uitbetaald, Afgerond of Verloren is. Nooit verwijderd; termijnen blijven op het startscherm.
export const ARCHIEF_STATUSSEN = ["Afgevallen"];
export const ARCHIEF_FASES = ["Uitbetaald", "Afgerond", "Verloren"];
// fases: de fases van de trajecten van deze relatie (lijst, mag leeg zijn).
export function isGearchiveerd(status, fases) {
  if (ARCHIEF_STATUSSEN.includes(status)) return true;
  return Array.isArray(fases) && fases.length > 0 && fases.every((f) => ARCHIEF_FASES.includes(f));
}
export const ROUTES = ["Maatwerk met onderzoek", "Herstel met aannemer", "Vaste vergoeding", "AVV"];
// Zoho-lijst zonder de standaardwaarden van Zoho (Concurrentie, Prijs, enz.): niet van toepassing.
export const REDENEN_VERLIES = ["Herstel gekozen", "Vaste vergoeding of AVV gekozen", "Afgewezen door IMG", "Klant haakt af", "Anders"];

// Zijn we vanaf fase "Besluit"? (Verloren en onbekende fases: nee.)
export const isVanafBesluit = (fase) => FASES_VANAF_BESLUIT.includes(fase);
// Positie in het traject; Verloren/onbekend = -1.
export const faseIndex = (fase) => (fase === "Verloren" ? -1 : FASES.indexOf(normFase(fase)));

// ---------- basiscontroles ----------
export function isIsoDatum(s) {
  if (typeof s !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const d = new Date(`${s}T12:00:00Z`);
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === s;
}
// Tijdstip: geldige kalenderdatum + tijd + Z of offset (zonder tijdzone is het niet eenduidig).
const TIJDSTIP = /^(\d{4}-\d{2}-\d{2})T([01]\d|2[0-3]):[0-5]\d(:[0-5]\d(\.\d{1,9})?)?(Z|[+-](?:[01]\d|2[0-3]):[0-5]\d)$/;
export function isIsoTijdstip(s) {
  if (typeof s !== "string") return false;
  const m = TIJDSTIP.exec(s);
  return !!m && isIsoDatum(m[1]) && !Number.isNaN(Date.parse(s));
}
const isObject = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
const leeg = (v) => v === null || v === undefined || (typeof v === "string" && v.trim() === "");
const BEHEERTEKEN = /[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g;

// Controleert één waarde tegen een spec. Geeft {waarde} (genormaliseerd, null = leeg) of {fout}.
function controleer(spec, v) {
  if (leeg(v)) return { waarde: null };
  switch (spec.type) {
    case "tekst": {
      if (typeof v !== "string") return { fout: "geen-tekst" };
      const t = spec.meerregelig ? v.replace(BEHEERTEKEN, "").trim() : v.replace(BEHEERTEKEN, "").replace(/\s+/g, " ").trim();
      if (t.length > spec.max) return { fout: "te-lang" };
      if (spec.patroon && !spec.patroon.test(t)) return { fout: spec.code || "ongeldig" };
      return { waarde: t };
    }
    case "keuze":
      return spec.lijst.includes(v) ? { waarde: v } : { fout: "geen-keuze" };
    case "datum":
      return isIsoDatum(v) ? { waarde: v } : { fout: "geen-datum" };
    case "postcode": {
      if (typeof v !== "string") return { fout: "geen-postcode" };
      const m = /^([1-9]\d{3})\s?([A-Za-z]{2})$/.exec(v.trim());
      return m ? { waarde: `${m[1]} ${m[2].toUpperCase()}` } : { fout: "geen-postcode" };
    }
    case "telefoon": {
      if (typeof v !== "string") return { fout: "geen-telefoon" };
      const t = v.trim();
      const cijfers = t.replace(/\D/g, "").length;
      return /^\+?[0-9 ()\-]{6,25}$/.test(t) && cijfers >= 8 && cijfers <= 15 ? { waarde: t } : { fout: "geen-telefoon" };
    }
    case "email": {
      if (typeof v !== "string") return { fout: "geen-email" };
      const t = v.trim();
      return t.length <= 254 && /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(t) ? { waarde: t } : { fout: "geen-email" };
    }
    case "geheel": {
      if (typeof v !== "number" || !Number.isInteger(v)) return { fout: "geen-geheel-getal" };
      return v >= spec.min && v <= spec.max ? { waarde: v } : { fout: "buiten-bereik" };
    }
    case "getal": {
      if (typeof v !== "number" || !Number.isFinite(v)) return { fout: "geen-getal" };
      return v >= spec.min && v <= spec.max ? { waarde: v } : { fout: "buiten-bereik" };
    }
    case "bool":
      return typeof v === "boolean" ? { waarde: v } : { fout: "geen-boolean" };
    case "id":
      return typeof v === "string" && spec.patroon.test(v) ? { waarde: v } : { fout: "geen-id" };
    default:
      return { fout: "ongeldig" }; // onbekend spec-type: veldfout, geen uitzondering
  }
}

const ID = /^[A-Za-z0-9_-]{1,64}$/;
// Sleutels die een object-prototype raken: nooit toestaan als id.
const VERBODEN_ID = new Set(["__proto__", "constructor", "prototype"]);
const isVeiligId = (k) => typeof k === "string" && ID.test(k) && !VERBODEN_ID.has(k);
const wieSpec = { type: "tekst", max: 40 };

// Alleen voor tests: één waarde tegen een spec.
export const controleerWaarde = controleer;

// ---------- specificaties ----------
// Velden die de client mag zetten.
const RELATIE_VELDEN = {
  aanhef: { type: "keuze", lijst: AANHEFFEN },
  voornaam: { type: "tekst", max: 100 },
  achternaam: { type: "tekst", max: 100 },
  telefoon: { type: "telefoon" },
  mobiel: { type: "telefoon" },
  email: { type: "email" },
  straat: { type: "tekst", max: 120 },
  huisnummer: { type: "tekst", max: 6, patroon: /^[0-9]{1,6}$/ },
  toevoeging: { type: "tekst", max: 10, patroon: /^[A-Za-z0-9][A-Za-z0-9 \-]{0,9}$/ },
  postcode: { type: "postcode" },
  plaats: { type: "tekst", max: 80 },
  bagId: { type: "tekst", max: 16, patroon: /^[0-9]{16}$/ },
  bron: { type: "keuze", lijst: BRONNEN },
  voorWie: { type: "keuze", lijst: VOOR_WIE },
  soortWoning: { type: "keuze", lijst: SOORTEN_WONING },
  contactvoorkeur: { type: "keuze", lijst: CONTACTVOORKEUREN },
  status: { type: "keuze", lijst: STATUSSEN },
  terugbeldatum: { type: "datum" },
  situatie: { type: "keuze", lijst: SITUATIES },
  kwalificatie: { type: "keuze", lijst: KWALIFICATIES },
  redenAfgevallen: { type: "keuze", lijst: REDENEN_AFGEVALLEN },
  trillingMms: { type: "getal", min: 0, max: 1000 },
  bouwjaar: { type: "geheel", min: 1500, max: 2100 },
  ruimtesMetSchade: { type: "geheel", min: 0, max: 99 },
  eerderOntvangen: { type: "getal", min: 0, max: 10000000 },
  bkoZone: { type: "bool" },
  eigenaar: { type: "keuze", lijst: EIGENAREN },
  // Alleen een mapnaam, nooit een bestand of pad.
  dossier: { type: "tekst", max: 100, patroon: /^(?!\.)[A-Za-z0-9 _.\-]{1,100}$/ },
  notitie: { type: "tekst", max: 5000, meerregelig: true },
};
const RELATIE_SYSTEEM = ["id", "versie", "afgevinkt", "statusgeschiedenis", "herkomst", "aangemaakt", "gewijzigd", "toegepast"];
const RELATIE_COMPLEX = ["taken"];

const TRAJECT_VELDEN = {
  relatieId: { type: "id", patroon: /^r_[A-Za-z0-9_-]{1,62}$/ },
  fase: { type: "keuze", lijst: FASES_GELDIG },
  route: { type: "keuze", lijst: ROUTES },
  getekendOp: { type: "datum" },
  aanvraagdatum: { type: "datum" },
  opnamedatum: { type: "datum" },
  // Tijd van de opname (uu:mm), voor de gezamenlijke agenda. Mag leeg: dan staat de opname er de hele dag.
  opnametijd: { type: "tekst", max: 5, patroon: /^([01]\d|2[0-3]):[0-5]\d$/ },
  datumSchaderapport: { type: "datum" },
  datumAdviesrapport: { type: "datum" },
  verzenddatumBesluitbrief: { type: "datum" },
  verzenddatumOnbekend: { type: "bool" },
  uitkeringImg: { type: "getal", min: 0, max: 100000000 },
  fee: { type: "getal", min: 0, max: 100000000 },
  factuurVerstuurdOp: { type: "datum" },
  factuurVoldaanOp: { type: "datum" },
  redenVerlies: { type: "keuze", lijst: REDENEN_VERLIES },
  machtigingGetekendOp: { type: "datum" }, // alleen de datum, nooit het document
};
const TRAJECT_SYSTEEM = ["id", "klantGezet", "afgevinkt", "fasegeschiedenis", "aangemaakt", "gewijzigd", "toegepast"];

// ---------- systeemvelden ----------
function controleerWieOp(v) {
  return isObject(v) && !wieFout(v.wie) && isIsoTijdstip(v.op);
}
const wieFout = (w) => controleer({ ...wieSpec }, w).fout || leeg(w);
function controleerToegepast(v) {
  return Array.isArray(v) && v.length <= 50 && v.every((x) => typeof x === "string" && ID.test(x));
}
function controleerGeschiedenis(v, sleutel, lijst) {
  return Array.isArray(v) && v.length <= 500 && v.every((e) => isObject(e) && lijst.includes(e[sleutel]) && isIsoDatum(e.van) && !wieFout(e.wie));
}
// herkomst.deur (K10): precies eventId (verplicht), plaats en adres (optioneel); geen andere sleutels.
const DEUR_EVENT = /^[a-z0-9]{8,40}$/;
const DEUR_ID = /^[A-Za-z0-9._-]{1,60}$/;
export function deurHerkomstOk(w) {
  if (!isObject(w) || Object.keys(w).some((k) => !["eventId", "plaats", "adres"].includes(k))) return false;
  if (typeof w.eventId !== "string" || !DEUR_EVENT.test(w.eventId)) return false;
  return ["plaats", "adres"].every((k) => w[k] === undefined || (typeof w[k] === "string" && DEUR_ID.test(w[k])));
}
function controleerHerkomst(v) {
  return isObject(v) && Object.keys(v).every((k) => ["zoho", "website", "deur"].includes(k))
    && Object.entries(v).every(([k, w]) => isObject(w) && (k !== "deur" || deurHerkomstOk(w)));
}
// actie mag null zijn (niet-fatale regels); bij fatale regels dwingt maakAfvinkRecord (termijnen.mjs) een actie af.
function controleerAfgevinkt(v) {
  return isObject(v) && Object.entries(v).every(([k, e]) => isVeiligId(k) && isObject(e) && (e.actie === null || (typeof e.actie === "string" && e.actie.length <= 100)) && isIsoDatum(e.brondatum) && !wieFout(e.wie) && isIsoTijdstip(e.op));
}
const SYSTEEM_CHECK = {
  versie: (v) => Number.isInteger(v) && v >= 0 && v <= 1e9, // teller per relatie, voor de index (opslag.mjs)
  klantGezet: (v) => typeof v === "boolean", // traject: de Klant-stap van maakTraject is gedaan
  id: (v) => typeof v === "string" && ID.test(v),
  aangemaakt: controleerWieOp,
  gewijzigd: controleerWieOp,
  toegepast: controleerToegepast,
  herkomst: controleerHerkomst,
  statusgeschiedenis: (v) => controleerGeschiedenis(v, "status", STATUSSEN),
  fasegeschiedenis: (v) => controleerGeschiedenis(v, "fase", FASES_GELDIG),
  afgevinkt: controleerAfgevinkt,
};

// ---------- taken (op de relatie) ----------
const TAAK_VELDEN = {
  soort: { type: "keuze", lijst: TAAK_SOORTEN },
  titel: { type: "tekst", max: 200 },
  datum: { type: "datum" },
  tijd: { type: "tekst", max: 5, patroon: /^([01]\d|2[0-3]):[0-5]\d$/ },
  eigenaar: { type: "keuze", lijst: EIGENAREN },
};
function controleerTaken(taken, fouten) {
  if (!isObject(taken)) { fouten.taken = "geen-object"; return undefined; }
  const uit = Object.create(null);
  for (const [id, t] of Object.entries(taken)) {
    if (!isVeiligId(id) || !isObject(t)) { fouten[`taken.${id}`] = "ongeldig"; continue; }
    const rij = {};
    for (const [k, v] of Object.entries(t)) {
      if (k === "klaar") {
        if (v === null || controleerWieOp(v)) rij.klaar = v === null ? null : { wie: v.wie, op: v.op };
        else fouten[`taken.${id}.klaar`] = "ongeldig";
      } else if (TAAK_VELDEN[k]) {
        const r = controleer(TAAK_VELDEN[k], v);
        if (r.fout) fouten[`taken.${id}.${k}`] = r.fout; else rij[k] = r.waarde;
      } else fouten[`taken.${id}.${k}`] = "onbekend-veld";
    }
    if (!rij.soort) fouten[`taken.${id}.soort`] ||= "verplicht";
    if (!rij.titel) fouten[`taken.${id}.titel`] ||= "verplicht";
    uit[id] = rij;
  }
  return { ...uit };
}

// ---------- hoofdfuncties ----------
function valideer(invoer, velden, systeemVelden, complex, vereist, opties, kruisregels) {
  const { deel = false, systeem = false, zonderWissel = false } = opties || {};
  if (!isObject(invoer)) return { ok: false, fouten: { _: "geen-object" } };
  const fouten = {};
  const waarde = {};
  for (const [k, v] of Object.entries(invoer)) {
    // status/fase wijzigen alleen via wisselStatus/wisselFase (geschiedenis in dezelfde stap).
    if (zonderWissel && (k === "status" || k === "fase")) { fouten[k] = "alleen-via-wissel"; continue; }
    if (velden[k]) {
      const r = controleer(velden[k], v);
      if (r.fout) fouten[k] = r.fout; else waarde[k] = r.waarde;
    } else if (complex.includes(k)) {
      const t = controleerTaken(v, fouten);
      if (t) waarde[k] = t;
    } else if (systeemVelden.includes(k)) {
      if (!systeem) fouten[k] = "niet-wijzigbaar";
      else if (!SYSTEEM_CHECK[k](v)) fouten[k] = "ongeldig";
      else waarde[k] = v;
    } else fouten[k] = "onbekend-veld";
  }
  if (!deel) {
    for (const k of vereist) if (leeg(waarde[k])) fouten[k] ||= "verplicht";
    kruisregels(waarde, fouten);
  }
  return Object.keys(fouten).length ? { ok: false, fouten } : { ok: true, waarde };
}

// Relatie: achternaam en status verplicht (volledig record).
// Regel: reden verplicht bij status Afgevallen.
// deel:true = alleen de aanwezige velden (kruisregels draaien dan NIET: valideer na samenvoegen het hele record
// met {systeem:true}); systeem:true = ook systeemvelden toestaan; zonderWissel:true = status/fase weigeren
// (die gaan via wisselStatus/wisselFase).
export function valideerRelatie(invoer, opties) {
  return valideer(invoer, RELATIE_VELDEN, RELATIE_SYSTEEM, RELATIE_COMPLEX, ["achternaam", "status"], opties, (w, f) => {
    if (w.status === "Afgevallen" && leeg(w.redenAfgevallen)) f.redenAfgevallen ||= "verplicht-bij-afgevallen";
  });
}

// Traject: relatieId en fase verplicht. Regel: fase vanaf Besluit vereist verzenddatumBesluitbrief,
// tenzij verzenddatumOnbekend === true (dan geeft de termijnengine een fataal signaal). Staat beide er,
// dan wint de datum.
export function valideerTraject(invoer, opties) {
  return valideer(invoer, TRAJECT_VELDEN, TRAJECT_SYSTEEM, [], ["relatieId", "fase"], opties, (w, f) => {
    if (isVanafBesluit(w.fase) && leeg(w.verzenddatumBesluitbrief) && w.verzenddatumOnbekend !== true) {
      f.verzenddatumBesluitbrief ||= "verplicht-vanaf-besluit";
    }
  });
}

// ---------- contactmoment (Zoho: Calls/activiteiten) ----------
// Een contactmoment is geen veld op de relatie maar een regel in de tijdlijn (soort "contact").
// De status verandert er niet door: de leadketen loopt via de statusknoppen (wisselStatus).
export const CONTACT_WIJZEN = ["Gebeld", "Geen gehoor", "WhatsApp", "E-mail", "Gesprek aan huis", "Anders"];
const CONTACT_VELDEN = {
  wijze: { type: "keuze", lijst: CONTACT_WIJZEN },
  datum: { type: "datum" },
  notitie: { type: "tekst", max: 1000, meerregelig: true },
};
// Geeft {ok, waarde:{wijze, datum, notitie}} of {ok:false, fouten}. Wijze verplicht; datum niet in de toekomst
// (ten opzichte van `vandaag`, YYYY-MM-DD); zonder datum geldt vandaag.
export function valideerContact(invoer, vandaag) {
  if (!isObject(invoer)) return { ok: false, fouten: { _: "geen-object" } };
  const fouten = {};
  const waarde = {};
  for (const [k, v] of Object.entries(invoer)) {
    if (!CONTACT_VELDEN[k]) { fouten[k] = "onbekend-veld"; continue; }
    const r = controleer(CONTACT_VELDEN[k], v);
    if (r.fout) fouten[k] = r.fout; else waarde[k] = r.waarde;
  }
  if (leeg(waarde.wijze)) fouten.wijze ||= "verplicht";
  if (waarde.datum && isIsoDatum(vandaag) && waarde.datum > vandaag) fouten.datum ||= "in-de-toekomst";
  if (Object.keys(fouten).length) return { ok: false, fouten };
  return { ok: true, waarde: { wijze: waarde.wijze, datum: waarde.datum ?? vandaag ?? null, notitie: waarde.notitie ?? null } };
}

// `<achternaam> - <straat huisnummer[toevoeging]>, <plaats>`; ontbrekende delen vervallen.
export function weergavenaam(relatie) {
  const r = relatie || {};
  const nr = `${r.huisnummer ?? ""}${r.toevoeging ?? ""}`;
  const adres = [r.straat, nr].filter((x) => x && String(x).trim()).join(" ");
  const plaats = [adres, r.plaats].filter((x) => x && String(x).trim()).join(", ");
  return plaats ? `${r.achternaam ?? ""} - ${plaats}` : String(r.achternaam ?? "");
}

// ---------- kwalificatievoorstel ----------
// Drempel uit Zoho-regels Ruben (Kwalificatie-regels, 10-11-2026; staan in Zoho uit en doen daar niets).
export const TRILLING_DREMPEL_MMS = 2;
const NEE_SITUATIES = ["Huurder of geen woonhuis", "Adres afgesloten"];

// Alleen een VOORSTEL; wordt nooit automatisch opgeslagen. Volgorde: Nee (situatie), Later, Nee (bewijs), Ja.
// Geeft {waarde: "Ja"|"Later"|"Nee"|null, reden, redenAfgevallen}; reden is een code
// ("nee-situatie" | "later" | "nee-geen-bewijsvermoeden" | "ja" | null). redenAfgevallen is de bijpassende
// waarde uit REDENEN_AFGEVALLEN bij Nee, anders null. Ontbrekende trilling zonder BKO-zone: null.
export function kwalificatieVoorstel(relatie) {
  const r = relatie || {};
  const trilling = typeof r.trillingMms === "number" ? r.trillingMms : null;
  const bko = r.bkoZone === true;
  const sterk = bko || (trilling !== null && trilling >= TRILLING_DREMPEL_MMS);
  const antwoord = (waarde, reden, redenAfgevallen = null) => ({ waarde, reden, redenAfgevallen });
  if (NEE_SITUATIES.includes(r.situatie)) return antwoord("Nee", "nee-situatie", r.situatie);
  if (r.situatie === "Wacht op rapport of besluit" && sterk) return antwoord("Later", "later");
  if (!bko && trilling !== null && trilling < TRILLING_DREMPEL_MMS) return antwoord("Nee", "nee-geen-bewijsvermoeden", "Geen bewijsvermoeden");
  if (r.situatie !== "Wacht op rapport of besluit" && sterk) return antwoord("Ja", "ja");
  return antwoord(null, null);
}

// ---------- status- en fasewissel (pure helpers) ----------
// Wisselt de status en werkt statusgeschiedenis bij in dezelfde stap. `van` = datum YYYY-MM-DD.
// Geeft {waarde, wijzigingen, logregel} (één logregel per wissel) of {fouten}. Gelijke status = no-op.
export function wisselStatus(relatie, status, { reden, wie, van } = {}) {
  if (!STATUSSEN.includes(status)) return { fouten: { status: "geen-keuze" } };
  if (!isIsoDatum(van) || leeg(wie)) return { fouten: { _: "van-en-wie-verplicht" } };
  if (relatie.status === status) return { waarde: relatie, wijzigingen: [], logregel: null };
  const nieuw = structuredClone(relatie);
  const wijzigingen = [{ veld: "status", oud: relatie.status ?? null, nieuw: status }];
  nieuw.status = status;
  if (status === "Afgevallen" && !leeg(reden)) {
    wijzigingen.push({ veld: "redenAfgevallen", oud: relatie.redenAfgevallen ?? null, nieuw: reden });
    nieuw.redenAfgevallen = reden;
  }
  nieuw.statusgeschiedenis = [...(relatie.statusgeschiedenis || []), { status, van, wie }];
  const r = valideerRelatie(nieuw, { systeem: true });
  if (!r.ok) return { fouten: r.fouten };
  return { waarde: nieuw, wijzigingen, logregel: { soort: "statuswissel", record: "relatie", wie, van, wijzigingen } };
}

export function wisselFase(traject, fase, { wie, van } = {}) {
  if (!FASES.includes(fase)) return { fouten: { fase: "geen-keuze" } };
  if (!isIsoDatum(van) || leeg(wie)) return { fouten: { _: "van-en-wie-verplicht" } };
  if (traject.fase === fase) return { waarde: traject, wijzigingen: [], logregel: null };
  const nieuw = structuredClone(traject);
  nieuw.fase = fase;
  nieuw.fasegeschiedenis = [...(traject.fasegeschiedenis || []), { fase, van, wie }];
  const r = valideerTraject(nieuw, { systeem: true });
  if (!r.ok) return { fouten: r.fouten };
  const wijzigingen = [{ veld: "fase", oud: traject.fase ?? null, nieuw: fase }];
  return { waarde: nieuw, wijzigingen, logregel: { soort: "fasewissel", record: "traject", wie, van, wijzigingen } };
}

// ---------- dekking van de Zoho-velden ----------
// Leads/Contacts -> relatie, Deals -> traject. Elk veld uit dashboard/zoho-export/velden-*.json staat
// in precies één van de twee lijsten (bewaakt door model.test.mjs).
export const ZOHO_NAAR_MODEL = {
  Owner: "relatie.eigenaar / traject (eigenaar via relatie)", First_Name: "relatie.voornaam", Last_Name: "relatie.achternaam",
  Email: "relatie.email", Phone: "relatie.telefoon", Mobile: "relatie.mobiel", Lead_Source: "relatie.bron",
  Lead_Status: "relatie.status", Salutation: "relatie.aanhef", Description: "relatie.notitie",
  Terugbeldatum: "relatie.terugbeldatum", Trillingssnelheid_mm_s: "relatie.trillingMms", Bouwjaar: "relatie.bouwjaar",
  Ruimtes_met_schade: "relatie.ruimtesMetSchade", Eerder_ontvangen_bedrag: "relatie.eerderOntvangen",
  Situatie: "relatie.situatie", Kwalificatie: "relatie.kwalificatie", Reden_afgevallen: "relatie.redenAfgevallen",
  City: "relatie.plaats", Street: "relatie.straat + huisnummer + toevoeging", Zip_Code: "relatie.postcode",
  BKO_6_km_zone_of_IEDB: "relatie.bkoZone", Lead_Status_Modified_Time: "relatie.statusgeschiedenis",
  Created_By: "aangemaakt.wie", Created_Time: "aangemaakt.op", Modified_By: "gewijzigd.wie", Modified_Time: "gewijzigd.op",
  id: "herkomst.zoho.id",
  // Deals
  Stage: "traject.fase", Amount: "traject.uitkeringImg", Aanvraagdatum: "traject.aanvraagdatum", Route: "traject.route",
  Opnamedatum: "traject.opnamedatum", Datum_schaderapport: "traject.datumSchaderapport",
  Datum_adviesrapport: "traject.datumAdviesrapport", Verzenddatum_besluitbrief: "traject.verzenddatumBesluitbrief",
  Fee: "traject.fee", Factuur_voldaan_op: "traject.factuurVoldaanOp", Reason_For_Loss__s: "traject.redenVerlies",
  Stage_Modified_Time: "traject.fasegeschiedenis", Contact_Name: "traject.relatieId",
  Machtigingsformulier: "traject.machtigingGetekendOp (alleen de datum; bestand blijft in het dossier)",
};
export const ZOHO_WEGGELATEN = {
  Latitude: "coordinaten: niet nagebouwd (architectuur §1)", Longitude: "coordinaten: niet nagebouwd",
  Coordinates: "coordinaten: niet nagebouwd", Address: "samengesteld uit straat/postcode/plaats",
  Country: "altijd Nederland", State: "provincie niet nodig", Full_Name: "afgeleid uit voor- en achternaam",
  Last_Activity_Time: "afgeleid uit de tijdlijn", Tag: "tags niet gebruikt",
  Converted_Date_Time: "leadconversie bestaat niet meer (klant = status)", Lead_Conversion_Time: "idem",
  Converted_Contact: "idem", Converted_Deal: "idem", Converted__s: "idem",
  Unsubscribed_Mode: "campagnes niet nagebouwd", Unsubscribed_Time: "campagnes niet nagebouwd",
  Change_Log_Time__s: "Zoho-systeemveld", Locked__s: "Zoho-systeemveld", Record_Status__s: "Zoho-systeemveld",
  Last_Enriched_Time__s: "verrijking niet nagebouwd", Enrich_Status__s: "verrijking niet nagebouwd",
  Deal_Name: "wordt getoond als weergavenaam, niet opgeslagen", Sales_Cycle_Duration: "Zoho-rapportage, niet nodig",
  Overall_Sales_Duration: "Zoho-rapportage, niet nodig", Overeenkomst_Intermediair: "bestand: blijft in het klantdossier",
  // Zoho-deal-Description: het traject heeft geen notitieveld (architectuur §1); notities staan bij de relatie.
  // Lead_Source van Deals: staat al bij de relatie (bron).
  // Contacts (adresvelden Mailing_*/Other_*, Email_Opt_Out, coordinaten): tweede adres en campagnes niet nagebouwd.
};
export const ZOHO_WEGGELATEN_VOORVOEGSELS = ["Mailing_", "Other_", "Email_Opt_Out"];
// Events/Tasks -> relatie.taken; niet veld voor veld gedekt: Subject -> titel, Due_Date/Start_DateTime -> datum/tijd,
// Owner -> eigenaar, Status/Closed_Time -> klaar. Herhaling, herinneringen, check-in en deelnemers vervallen.

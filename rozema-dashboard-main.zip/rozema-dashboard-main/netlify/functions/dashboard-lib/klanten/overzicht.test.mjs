// Tests voor overzicht.mjs (pijplijn en overzichten) en valideerContact. Alleen fictieve data.
import { test } from "node:test";
import assert from "node:assert/strict";
import { maakPijplijn, maakLeadPijplijn, maakOverzicht, doorlooptijden, sindsInFase, inPeriode, ONBEKEND, LEAD_DOEL_TRAJECT } from "./overzicht.mjs";
import { valideerContact, CONTACT_WIJZEN, isGearchiveerd, LEAD_STATUSSEN } from "./model.mjs";
import { testCatalogus } from "./test-regels.mjs";

const REGELS = testCatalogus();
const VANDAAG = "2026-11-19";
const g = (...paren) => paren.map(([fase, van]) => ({ fase, van, wie: "Kevin" }));
const rijen = {
  r_1: { id: "r_1", achternaam: "Eén", naam: "Eén - Straat 1, Plaats", plaats: "Plaats", eigenaar: "kevin", status: "Klant", bron: "Website", aangemaakt: "2026-10-01" },
  r_2: { id: "r_2", achternaam: "Twee", naam: "Twee", plaats: "Dorp", eigenaar: "ruben", status: "Klant", bron: "Deur", aangemaakt: "2026-11-02" },
  r_3: { id: "r_3", achternaam: "Drie", naam: "Drie", plaats: "Dorp", eigenaar: "ruben", status: "Poging 1", bron: "Deur", aangemaakt: "2026-11-10" },
  r_4: { id: "r_4", achternaam: "Vier", naam: "Vier", plaats: null, eigenaar: null, status: "Nieuw" }, // oude rij: geen bron/datum
};
const trajecten = [
  { id: "t_1", relatieId: "r_1", fase: "Opname gepland", route: "Maatwerk met onderzoek", fee: 1200, getekendOp: "2026-10-05",
    fasegeschiedenis: g(["Getekend", "2026-10-05"], ["Aanvraag ingediend", "2026-10-15"], ["Opname gepland", "2026-11-01"]) },
  { id: "t_2", relatieId: "r_2", fase: "Opname gepland", route: "AVV", fee: 800.5, getekendOp: "2026-11-03",
    fasegeschiedenis: g(["Getekend", "2026-11-03"], ["Opname gepland", "2026-11-17"]) },
  { id: "t_3", relatieId: "r_2", fase: "Afgerond", route: "Maatwerk met onderzoek", fee: 1000, uitkeringImg: 20000,
    factuurVerstuurdOp: "2026-09-01", factuurVoldaanOp: "2026-09-20",
    fasegeschiedenis: g(["Getekend", "2026-06-01"], ["Uitbetaald", "2026-08-30"], ["Afgerond", "2026-09-20"]) },
  { id: "t_4", relatieId: "r_1", fase: "Verloren", redenVerlies: "Klant haakt af", fasegeschiedenis: g(["Getekend", "2026-10-01"], ["Verloren", "2026-11-05"]) },
  { id: "t_5", relatieId: "r_1", fase: "Uitbetaald", fee: 500, factuurVerstuurdOp: "2026-10-01", fasegeschiedenis: g(["Uitbetaald", "2026-09-28"]) },
];

test("klantpijplijn: alle fases als kolom, archief (Uitbetaald, Afgerond, Verloren) alleen als aantal, langst in fase eerst", () => {
  const p = maakPijplijn(trajecten, rijen, REGELS, VANDAAG);
  assert.equal(p.kolommen.length, 10); // Schaderapport is opgegaan in Adviesrapport
  const archief = Object.fromEntries(p.kolommen.filter((k) => k.archief).map((k) => [k.fase, [k.kaarten.length, k.gearchiveerd]]));
  assert.deepEqual(archief, { Uitbetaald: [0, 1], Afgerond: [0, 1], Verloren: [0, 1] });
  const opname = p.kolommen.find((k) => k.fase === "Opname gepland");
  assert.equal(opname.aantal, 2);
  assert.equal(opname.fee, 2000.5);
  assert.deepEqual(opname.kaarten.map((k) => k.id), ["t_1", "t_2"]);
  assert.equal(opname.kaarten[0].dagenInFase, 18);
  assert.equal(opname.kaarten[0].achternaam, "Eén");
  assert.equal(opname.kaarten[0].eigenaar, "kevin");
  assert.equal(p.totaal, 2); // t_1, t_2; t_5 (Uitbetaald) is archief
});

test("klantpijplijn: filters op eigenaar en route, archief op verzoek", () => {
  assert.equal(maakPijplijn(trajecten, rijen, REGELS, VANDAAG, { eigenaar: "ruben" }).totaal, 1);
  assert.equal(maakPijplijn(trajecten, rijen, REGELS, VANDAAG, { route: "AVV" }).totaal, 1);
  const alle = maakPijplijn(trajecten, rijen, REGELS, VANDAAG, { archief: true });
  assert.equal(alle.totaal, 5);
  assert.equal(alle.kolommen.at(-1).fase, "Verloren");
  assert.equal(alle.kolommen.at(-1).kaarten[0].id, "t_4");
});

test("leadpijplijn: kolommen per leadstatus plus Contract getekend, klanten en archief niet als kaart", () => {
  const leadRijen = [
    { id: "r_n1", achternaam: "Nieuw1", status: "Nieuw", bron: "Deur", eigenaar: "kevin", statusSinds: "2026-11-10", contactvoorkeur: "WhatsApp" },
    { id: "r_n2", achternaam: "Nieuw2", status: "Nieuw", bron: "Website", eigenaar: "ruben", statusSinds: "2026-11-18", volgendeTaak: { titel: "Bellen", datum: "2026-11-19" } },
    { id: "r_p1", achternaam: "Poging", status: "Poging 1", bron: "Deur", eigenaar: "kevin" },
    { id: "r_af", achternaam: "Weg", status: "Afgevallen", bron: "Deur", eigenaar: "kevin" },
    { id: "r_kl", achternaam: "Klant", status: "Klant", bron: "Deur", eigenaar: "kevin" },
  ];
  const p = maakLeadPijplijn(leadRijen, VANDAAG);
  assert.deepEqual(p.kolommen.map((k) => k.status), [...LEAD_STATUSSEN, LEAD_DOEL_TRAJECT]);
  assert.equal(p.kolommen.at(-1).doel, "traject");
  assert.equal(p.totaal, 3);
  const nieuw = p.kolommen[0];
  assert.deepEqual(nieuw.kaarten.map((k) => k.id), ["r_n2", "r_n1"], "eerstvolgende taak eerst");
  assert.equal(nieuw.kaarten[1].dagenInStatus, 9);
  assert.equal(nieuw.kaarten[1].contactvoorkeur, "WhatsApp");
  const af = p.kolommen.find((k) => k.status === "Afgevallen");
  assert.deepEqual([af.kaarten.length, af.gearchiveerd, af.archief], [0, 1, true]);
  assert.ok(!JSON.stringify(p).includes("r_kl"), "een klant staat niet op het leadbord");
  assert.equal(maakLeadPijplijn(leadRijen, VANDAAG, { archief: true }).totaal, 4);
  assert.equal(maakLeadPijplijn(leadRijen, VANDAAG, { eigenaar: "ruben" }).totaal, 1);
  assert.equal(maakLeadPijplijn(leadRijen, VANDAAG, { bron: "Deur" }).totaal, 2);
});

test("isGearchiveerd: Afgevallen, of klant met alleen Uitbetaald/Afgerond/Verloren", () => {
  assert.equal(isGearchiveerd("Afgevallen", []), true);
  assert.equal(isGearchiveerd("Nieuw", []), false);
  assert.equal(isGearchiveerd("Klant", []), false);
  assert.equal(isGearchiveerd("Klant", ["Uitbetaald"]), true);
  assert.equal(isGearchiveerd("Klant", ["Uitbetaald", "Verloren"]), true);
  assert.equal(isGearchiveerd("Klant", ["Uitbetaald", "Besluit"]), false, "een tweede lopend traject houdt de klant actief");
});

test("pijplijn: traject zonder indexrij of fasegeschiedenis valt niet weg", () => {
  const p = maakPijplijn([{ id: "t_x", relatieId: "r_onbekend", fase: "Getekend" }], {}, REGELS, VANDAAG);
  assert.equal(p.totaal, 1);
  const k = p.kolommen[0].kaarten[0];
  assert.equal(k.achternaam, null);
  assert.equal(k.dagenInFase, null);
});

test("pijplijn: fatale termijn in Besluit zonder datum telt als aandacht", () => {
  const t = { id: "t_b", relatieId: "r_1", fase: "Besluit", verzenddatumOnbekend: true, fasegeschiedenis: g(["Besluit", "2026-11-01"]) };
  const k = maakPijplijn([t], rijen, REGELS, VANDAAG).kolommen.find((x) => x.fase === "Besluit").kaarten[0];
  assert.ok(k.fataal >= 1);
});

test("sindsInFase: laatste keer in de huidige fase (ook na terugzetten)", () => {
  assert.equal(sindsInFase({ fase: "Getekend", fasegeschiedenis: g(["Getekend", "2026-01-01"], ["Opname gepland", "2026-02-01"], ["Getekend", "2026-03-01"]) }), "2026-03-01");
  assert.equal(sindsInFase({ fase: "Getekend" }), null);
});

test("inPeriode: grenzen tot en met, zonder datum alleen zonder periode", () => {
  assert.equal(inPeriode("2026-11-01", { van: "2026-11-01", tot: "2026-11-30" }), true);
  assert.equal(inPeriode("2026-12-01", { van: "2026-11-01", tot: "2026-11-30" }), false);
  assert.equal(inPeriode(null, {}), true);
  assert.equal(inPeriode(null, { van: "2026-01-01" }), false);
});

test("overzicht zonder periode: leads per bron/status, conversie, geld", () => {
  const o = maakOverzicht(Object.values(rijen), trajecten, {}, VANDAAG);
  assert.equal(o.leads.totaal, 4);
  assert.equal(o.leads.perBron.Deur, 2);
  assert.equal(o.leads.perBron[ONBEKEND], 1);
  assert.equal(o.leads.perStatus.Klant, 2);
  assert.equal(o.leads.zonderDatum, 1);
  assert.deepEqual(o.leads.perMaand, { "2026-10": 1, "2026-11": 2 });
  assert.deepEqual(o.conversie.Deur, { leads: 2, klanten: 1 });
  assert.deepEqual(o.conversie.Website, { leads: 1, klanten: 1 });
  assert.equal(o.trajecten.open, 3);
  assert.equal(o.trajecten.perFase["Opname gepland"], 2);
  assert.equal(o.trajecten.verloren, 1);
  assert.equal(o.trajecten.redenVerlies["Klant haakt af"], 1);
  assert.deepEqual(o.geld.feePijplijn, { bedrag: 2000.5, aantal: 2 });
  assert.equal(o.geld.feeGefactureerd.bedrag, 500);
  assert.equal(o.geld.feeGefactureerd.ouderDan30Dagen, 1);
  assert.deepEqual(o.geld.feeVoldaan, { bedrag: 1000, aantal: 1 });
  assert.deepEqual(o.geld.uitkeringImg, { bedrag: 20000, aantal: 1 });
});

test("overzicht met periode: alleen november", () => {
  const o = maakOverzicht(Object.values(rijen), trajecten, { van: "2026-11-01", tot: "2026-11-30" }, VANDAAG);
  assert.equal(o.leads.totaal, 2); // r_2 en r_3; r_4 zonder datum valt erbuiten
  assert.equal(o.trajecten.getekend, 1); // t_2
  assert.equal(o.trajecten.verloren, 1);
  assert.equal(o.geld.feeVoldaan.aantal, 0);
  assert.equal(o.trajecten.open, 3); // stand van nu, los van de periode
});

test("doorlooptijden: gemiddelde per afgeronde fase, huidige fase telt niet", () => {
  const d = doorlooptijden(trajecten);
  assert.deepEqual(d.Getekend, { gemiddeld: Math.round((10 + 14 + 90 + 35) / 4), aantal: 4 });
  assert.equal(d["Opname gepland"], undefined);
});

test("valideerContact: wijze verplicht, datum standaard vandaag, niet in de toekomst", () => {
  assert.deepEqual(valideerContact({ wijze: "Gebeld" }, VANDAAG), { ok: true, waarde: { wijze: "Gebeld", datum: VANDAAG, notitie: null } });
  assert.equal(valideerContact({}, VANDAAG).fouten.wijze, "verplicht");
  assert.equal(valideerContact({ wijze: "Fax" }, VANDAAG).fouten.wijze, "geen-keuze");
  assert.equal(valideerContact({ wijze: "Gebeld", datum: "2026-11-20" }, VANDAAG).fouten.datum, "in-de-toekomst");
  assert.equal(valideerContact({ wijze: "Gebeld", extra: 1 }, VANDAAG).fouten.extra, "onbekend-veld");
  assert.equal(valideerContact({ wijze: "Gebeld", notitie: "x".repeat(1001) }, VANDAAG).fouten.notitie, "te-lang");
  assert.ok(CONTACT_WIJZEN.includes("Geen gehoor"));
});

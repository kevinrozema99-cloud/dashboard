// Klantenmodule K5: gedeelde logica voor GET /klanten/start en de dagelijkse Function.
// Geen tekst voor bezoekers: alleen codes en data. Geen persoonsgegevens in de hartslag (alleen aantallen en ids).
import { store } from "../opslag.mjs";
import { leesAlleTrajecten, leesRelatie } from "./opslag.mjs";
import { STATUS, maakFataalBlok } from "./termijnen.mjs";
import { plusDagen } from "./datum.mjs";
import { weergavenaam } from "./model.mjs";

export const STATUS_ONLEESBAAR = "onleesbaar";
export const STATUS_ONVOLLEDIG = "onvolledig";

export const HARTSLAG_SLEUTEL = "status/dagelijks"; // KLANTEN-ARCHITECTUUR.md §1
export const HARTSLAG_OUD_NA_MS = 26 * 60 * 60 * 1000;
const GROEP = 20;
export const MAX_DETAILS = 200;

async function inGroepen(lijst, fn) {
  const uit = [];
  for (let i = 0; i < lijst.length; i += GROEP) uit.push(...(await Promise.allSettled(lijst.slice(i, i + GROEP).map(fn))));
  return uit;
}

// Het fatale blok, live: register (strong) -> alle trajecten -> engine. Nooit gefilterd, nooit uit een cache.
// Geeft {items, gezondheid, onvolledig, onleesbaar, trajecten, relaties}. opties.bereken: alleen voor tests.
export async function berekenFataalBlok(regels, vandaag, nu, opties = {}) {
  const { trajecten, onvolledig, onleesbaar } = await leesAlleTrajecten(nu);
  const relatieIds = [...new Set([...trajecten, ...onvolledig, ...onleesbaar].map((t) => t.relatieId).filter(Boolean))];
  const gelezen = await inGroepen(relatieIds, (id) => leesRelatie(id));
  const relaties = new Map();
  gelezen.forEach((g, i) => { if (g.status === "fulfilled" && g.value) relaties.set(relatieIds[i], g.value); });
  // Alleen relaties met een traject: de leadregels zijn niet fataal en horen niet in het blok.
  const { items, gezondheid } = maakFataalBlok(trajecten, relaties, regels, vandaag, opties.bereken ? { bereken: opties.bereken } : {});
  // Onleesbare en onvolledige trajecten zijn zelf een fataal signaal (§2.4): ze kunnen een termijn verbergen.
  // Losse velden, zodat de schermen de weergavenaam niet hoeven te splitsen.
  const losseNaam = (rid) => {
    const r = rid && relaties.has(rid) ? relaties.get(rid) : null;
    return { achternaam: r?.achternaam ?? null, plaats: r?.plaats ?? null };
  };
  const naamVan = (rid) => (rid && relaties.has(rid) ? weergavenaam(relaties.get(rid)) : null);
  const signaal = (status, x) => ({
    regelId: null, zoho: null, titel: null, status, fataal: true, record: "traject", recordId: x.id, relatieId: x.relatieId ?? null,
    brondatum: null, einddatum: null, dagenOver: null, vervolgActie: null, afvinkActies: [], regelIds: [], naam: naamVan(x.relatieId), ...losseNaam(x.relatieId),
    ...(x.aangemaakt !== undefined ? { aangemaakt: x.aangemaakt } : {}),
  });
  const extra = [...onleesbaar.map((x) => signaal(STATUS_ONLEESBAAR, x)), ...onvolledig.map((x) => signaal(STATUS_ONVOLLEDIG, x))]
    .sort((a, c) => String(a.recordId).localeCompare(String(c.recordId)));
  // Rang 0: direct na de verlopen open termijnen, vóór de rest.
  const eerste = items.findIndex((i) => !(i.status === STATUS.OPEN && i.dagenOver < 0));
  const kop = eerste === -1 ? items.length : eerste;
  const metNaam = (x) => ({ ...x, ...losseNaam(x.relatieId) });
  const alles = [...items.slice(0, kop).map(metNaam), ...extra, ...items.slice(kop).map(metNaam)];
  return { items: alles, gezondheid: gezondheid.map(metNaam), onvolledig, onleesbaar, trajecten: trajecten.length, relaties: relaties.size };
}

export function telFataal(items) {
  const open = items.filter((i) => i.status === STATUS.OPEN);
  return {
    aantal: items.length,
    verlopen: open.filter((i) => i.dagenOver < 0).length,
    eerstvolgendeDagen: open.length ? Math.min(...open.map((i) => i.dagenOver)) : null,
    signalen: items.length - open.length,
  };
}

// Taken van vandaag (inclusief achterstallige) en van de komende 7 dagen, uit de index (eerstvolgende open taak per relatie).
export function takenUitIndex(rijen, vandaag) {
  const einde = plusDagen(vandaag, 7);
  const vandaagLijst = [];
  const weekLijst = [];
  for (const r of Object.values(rijen || {})) {
    const t = r?.volgendeTaak;
    if (!t?.datum) continue;
    const item = { relatieId: r.id, naam: r.naam ?? null, achternaam: r.achternaam ?? null, plaats: r.plaats ?? null, taakId: t.id, titel: t.titel ?? null, datum: t.datum, tijd: t.tijd ?? null, achterstallig: t.datum < vandaag };
    if (t.datum <= vandaag) vandaagLijst.push(item);
    else if (t.datum <= einde) weekLijst.push(item);
  }
  const volgorde = (a, b) => a.datum.localeCompare(b.datum) || (a.tijd ?? "").localeCompare(b.tijd ?? "") || String(a.relatieId).localeCompare(String(b.relatieId));
  return { vandaag: vandaagLijst.sort(volgorde), dezeWeek: weekLijst.sort(volgorde) };
}

export async function leesHartslag() {
  return (await store("klanten").get(HARTSLAG_SLEUTEL, { type: "json", consistency: "strong" })) ?? null;
}

export async function schrijfHartslag(hartslag) {
  await store("klanten").setJSON(HARTSLAG_SLEUTEL, hartslag);
}

// Codes, geen tekst: "ontbreekt" | "ongeldig" | "ouder-dan-26-uur" | "laatste-run-met-fouten" | null.
export function beoordeelHartslag(hartslag, nu) {
  if (!hartslag) return { waarschuwing: "ontbreekt", leeftijdUren: null };
  const t = Date.parse(hartslag.op);
  if (!Number.isFinite(t)) return { waarschuwing: "ongeldig", leeftijdUren: null };
  const ms = nu.getTime() - t;
  if (ms < -3600000) return { waarschuwing: "ongeldig", leeftijdUren: null }; // tijd meer dan een uur in de toekomst
  const leeftijdUren = Math.round((ms / 3600000) * 10) / 10;
  if (ms > HARTSLAG_OUD_NA_MS) return { waarschuwing: "ouder-dan-26-uur", leeftijdUren };
  if (hartslag.ok === false) return { waarschuwing: "laatste-run-met-fouten", leeftijdUren };
  return { waarschuwing: null, leeftijdUren };
}

export const beperk = (lijst) => lijst.slice(0, MAX_DETAILS);
export const isAfgekapt = (lijst) => lijst.length > MAX_DETAILS;

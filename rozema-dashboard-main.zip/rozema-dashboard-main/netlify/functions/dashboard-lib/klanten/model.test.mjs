import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import {
  valideerRelatie, valideerTraject, weergavenaam, wisselStatus, wisselFase, isIsoDatum, STATUSSEN, SITUATIES, FASES,
  ZOHO_NAAR_MODEL, ZOHO_WEGGELATEN, ZOHO_WEGGELATEN_VOORVOEGSELS, BRONNEN, AANHEFFEN,
} from "./model.mjs";

const basis = { achternaam: "Test", status: "Nieuw" };
const trajectBasis = { relatieId: "r_1", fase: "Aanvraag ingediend" };

test("relatie: geldig record, strings worden opgeschoond, postcode genormaliseerd", () => {
  const r = valideerRelatie({ ...basis, achternaam: "  De  Vries ", postcode: "9201ab", huisnummer: "12", toevoeging: "A", mobiel: "06 12345678", email: "a@b.nl", terugbeldatum: "2026-12-01", bouwjaar: 1965, trillingMms: 4.5, bkoZone: true, eigenaar: "ruben", telefoon: "" });
  assert.equal(r.ok, true);
  assert.equal(r.waarde.achternaam, "De Vries");
  assert.equal(r.waarde.postcode, "9201 AB");
  assert.equal(r.waarde.telefoon, null);
});

test("relatie: ongeldige waarden geven een code per veld", () => {
  const r = valideerRelatie({ ...basis, postcode: "0123 AB", email: "x", terugbeldatum: "2026-02-30", bron: "Radio", bouwjaar: "1965", huisnummer: "12a", mobiel: "12", achternaam: "x".repeat(101), onzin: 1 });
  assert.equal(r.ok, false);
  assert.deepEqual(r.fouten, {
    postcode: "geen-postcode", email: "geen-email", terugbeldatum: "geen-datum", bron: "geen-keuze", bouwjaar: "geen-geheel-getal",
    huisnummer: "ongeldig", mobiel: "geen-telefoon", achternaam: "te-lang", onzin: "onbekend-veld",
  });
});

test("relatie: achternaam en status verplicht; deel slaat dat over", () => {
  assert.deepEqual(valideerRelatie({}).fouten, { achternaam: "verplicht", status: "verplicht" });
  assert.equal(valideerRelatie({ plaats: "Drachten" }, { deel: true }).ok, true);
});

test("relatie: reden verplicht bij Afgevallen", () => {
  assert.equal(valideerRelatie({ ...basis, status: "Afgevallen" }).fouten.redenAfgevallen, "verplicht-bij-afgevallen");
  assert.equal(valideerRelatie({ ...basis, status: "Afgevallen", redenAfgevallen: "Niet bereikt" }).ok, true);
  assert.equal(valideerRelatie({ ...basis, status: "Afgevallen", redenAfgevallen: "Wat anders" }).fouten.redenAfgevallen, "geen-keuze");
});

test("relatie: systeemvelden alleen met systeem:true", () => {
  const rec = { ...basis, aangemaakt: { wie: "kevin", op: "2026-11-10T10:00:00Z" } };
  assert.equal(valideerRelatie(rec).fouten.aangemaakt, "niet-wijzigbaar");
  assert.equal(valideerRelatie(rec, { systeem: true }).ok, true);
  assert.equal(valideerRelatie({ ...basis, toegepast: [1] }, { systeem: true }).fouten.toegepast, "ongeldig");
});

test("relatie: taken gevalideerd", () => {
  assert.equal(valideerRelatie({ ...basis, taken: { x1: { soort: "afspraak", titel: "Bezoek", datum: "2026-11-12", tijd: "14:30", eigenaar: "kevin" } } }).ok, true);
  const f = valideerRelatie({ ...basis, taken: { x1: { soort: "mail", datum: "morgen", tijd: "25:00" } } }).fouten;
  assert.equal(f["taken.x1.soort"], "geen-keuze");
  assert.equal(f["taken.x1.datum"], "geen-datum");
  assert.equal(f["taken.x1.tijd"], "ongeldig");
  assert.equal(f["taken.x1.titel"], "verplicht");
});

test("relatie: dossier is alleen een mapnaam", () => {
  assert.equal(valideerRelatie({ ...basis, dossier: "Test 12" }).ok, true);
  assert.equal(valideerRelatie({ ...basis, dossier: "../geheim" }).fouten.dossier, "ongeldig");
  assert.equal(valideerRelatie({ ...basis, dossier: "a/b" }).fouten.dossier, "ongeldig");
});

test("keuzelijsten: situatie bevat v2-waarden, geen -None-", () => {
  assert.ok(SITUATIES.includes("Vaste vergoeding gehad") && SITUATIES.includes("Besluit genomen"));
  assert.ok(STATUSSEN.includes("Klant"));
  assert.ok(BRONNEN.includes("Niet thuis"));
  for (const l of [SITUATIES, STATUSSEN, BRONNEN, FASES, AANHEFFEN]) assert.ok(!l.includes("-None-"));
  assert.equal(valideerRelatie({ ...basis, situatie: "Besluit genomen" }).ok, true);
});

test("datum: alleen echte YYYY-MM-DD", () => {
  assert.ok(isIsoDatum("2026-02-28"));
  for (const s of ["2026-02-30", "2026-2-3", "26-02-03", "2026-13-01", null, 20260101]) assert.equal(isIsoDatum(s), false);
});

test("traject: geldig; fase en relatieId verplicht", () => {
  assert.equal(valideerTraject(trajectBasis).ok, true);
  assert.deepEqual(valideerTraject({}).fouten, { relatieId: "verplicht", fase: "verplicht" });
  assert.equal(valideerTraject({ ...trajectBasis, relatieId: "x_1" }).fouten.relatieId, "geen-id");
  assert.equal(valideerTraject({ ...trajectBasis, fee: -1 }).fouten.fee, "buiten-bereik");
});

test("T5: fase vanaf Besluit zonder verzenddatum is ongeldig, tenzij expliciet onbekend", () => {
  for (const fase of ["Besluit", "Bezwaar", "Uitbetaald", "Afgerond"]) {
    assert.equal(valideerTraject({ ...trajectBasis, fase }).fouten.verzenddatumBesluitbrief, "verplicht-vanaf-besluit", fase);
    assert.equal(valideerTraject({ ...trajectBasis, fase, verzenddatumOnbekend: true }).ok, true, fase);
    assert.equal(valideerTraject({ ...trajectBasis, fase, verzenddatumBesluitbrief: "2026-11-01" }).ok, true, fase);
  }
  for (const fase of ["Adviesrapport", "Verloren", "Getekend"]) assert.equal(valideerTraject({ ...trajectBasis, fase }).ok, true, fase);
  assert.equal(valideerTraject({ ...trajectBasis, fase: "Besluit", verzenddatumOnbekend: "ja" }).ok, false);
});

test("weergavenaam", () => {
  assert.equal(weergavenaam({ achternaam: "Jansen", straat: "Dorpsstraat", huisnummer: "12", toevoeging: "A", plaats: "Loppersum" }), "Jansen - Dorpsstraat 12A, Loppersum");
  assert.equal(weergavenaam({ achternaam: "Jansen", straat: "Dorpsstraat", huisnummer: "12", plaats: "Loppersum" }), "Jansen - Dorpsstraat 12, Loppersum");
  assert.equal(weergavenaam({ achternaam: "Jansen" }), "Jansen");
  assert.equal(weergavenaam({ achternaam: "Jansen", plaats: "Loppersum" }), "Jansen - Loppersum");
});

test("wisselStatus: geschiedenis in dezelfde stap, invoer ongemoeid", () => {
  const r0 = { ...basis, statusgeschiedenis: [{ status: "Nieuw", van: "2026-11-01", wie: "kevin" }] };
  const r = wisselStatus(r0, "Poging 1", { wie: "kevin", van: "2026-11-02" });
  assert.equal(r.waarde.status, "Poging 1");
  assert.equal(r.waarde.statusgeschiedenis.length, 2);
  assert.equal(r0.status, "Nieuw");
  assert.equal(r0.statusgeschiedenis.length, 1);
  assert.equal(wisselStatus(r.waarde, "Poging 1", { wie: "kevin", van: "2026-11-03" }).logregel, null);
  assert.deepEqual(wisselStatus(r0, "Afgevallen", { wie: "kevin", van: "2026-11-02" }).fouten, { redenAfgevallen: "verplicht-bij-afgevallen" });
  assert.ok(wisselStatus(r0, "Bestaat niet", { wie: "kevin", van: "2026-11-02" }).fouten.status);
});

test("T24: afsluiten zet Afgevallen met reden Niet bereikt, één logregel", () => {
  const r0 = { ...basis, status: "WhatsApp verstuurd", statusgeschiedenis: [] };
  const r = wisselStatus(r0, "Afgevallen", { reden: "Niet bereikt", wie: "ruben", van: "2026-11-09" });
  assert.equal(r.waarde.status, "Afgevallen");
  assert.equal(r.waarde.redenAfgevallen, "Niet bereikt");
  assert.equal(r.waarde.statusgeschiedenis.at(-1).status, "Afgevallen");
  assert.equal(r.logregel.soort, "statuswissel");
  assert.equal(r.logregel.wijzigingen.length, 2);
});

test("wisselFase: vanaf Besluit alleen met datum", () => {
  const t = { ...trajectBasis, fasegeschiedenis: [] };
  assert.equal(wisselFase(t, "Besluit", { wie: "ruben", van: "2026-11-09" }).fouten.verzenddatumBesluitbrief, "verplicht-vanaf-besluit");
  const r = wisselFase({ ...t, verzenddatumBesluitbrief: "2026-11-01" }, "Besluit", { wie: "ruben", van: "2026-11-09" });
  assert.equal(r.waarde.fase, "Besluit");
  assert.deepEqual(r.waarde.fasegeschiedenis, [{ fase: "Besluit", van: "2026-11-09", wie: "ruben" }]);
});

test("dekking: elk Zoho-veld uit de export is gedekt of bewust weggelaten", () => {
  const map = new URL("../../../../dashboard/zoho-export/", import.meta.url);
  const alle = new Set();
  for (const m of ["Leads", "Deals", "Contacts"]) for (const v of JSON.parse(readFileSync(new URL(`velden-${m}.json`, map), "utf8"))) alle.add(v.api);
  const ongedekt = [...alle].filter((a) => !(a in ZOHO_NAAR_MODEL) && !(a in ZOHO_WEGGELATEN) && !ZOHO_WEGGELATEN_VOORVOEGSELS.some((p) => a.startsWith(p)));
  assert.deepEqual(ongedekt, []);
  for (const a of Object.keys(ZOHO_NAAR_MODEL)) assert.ok(!(a in ZOHO_WEGGELATEN), `${a} dubbel`);
});

import { kwalificatieVoorstel, TRILLING_DREMPEL_MMS, REDENEN_AFGEVALLEN } from "./model.mjs";

test("kwalificatievoorstel: elke tak en de grens van 2 mm/s", () => {
  assert.equal(TRILLING_DREMPEL_MMS, 2);
  const k = (r) => kwalificatieVoorstel(r);
  // Nee (situatie) gaat voor alles
  for (const situatie of ["Huurder of geen woonhuis", "Adres afgesloten"]) {
    const v = k({ situatie, trillingMms: 5, bkoZone: true });
    assert.deepEqual(v, { waarde: "Nee", reden: "nee-situatie", redenAfgevallen: situatie });
    assert.ok(REDENEN_AFGEVALLEN.includes(v.redenAfgevallen));
  }
  // Later
  assert.equal(k({ situatie: "Wacht op rapport of besluit", trillingMms: 2 }).waarde, "Later");
  assert.equal(k({ situatie: "Wacht op rapport of besluit", bkoZone: true }).reden, "later");
  // Nee (geen bewijsvermoeden), ook bij Wacht op rapport met lage trilling
  const nee = k({ situatie: "Wacht op rapport of besluit", trillingMms: 1.99 });
  assert.deepEqual(nee, { waarde: "Nee", reden: "nee-geen-bewijsvermoeden", redenAfgevallen: "Geen bewijsvermoeden" });
  assert.ok(REDENEN_AFGEVALLEN.includes(nee.redenAfgevallen));
  assert.equal(k({ trillingMms: 0, bkoZone: false }).waarde, "Nee");
  // Ja
  assert.equal(k({ situatie: "Nooit gemeld", trillingMms: 2 }).waarde, "Ja");
  assert.equal(k({ situatie: "Nooit gemeld", trillingMms: 2.01 }).reden, "ja");
  assert.equal(k({ trillingMms: 1, bkoZone: true }).waarde, "Ja");
  assert.equal(k({ situatie: "Anders", bkoZone: true }).waarde, "Ja");
  // Onbekend
  assert.deepEqual(k({ situatie: "Nooit gemeld" }), { waarde: null, reden: null, redenAfgevallen: null });
  assert.equal(k({ bkoZone: false }).waarde, null);
  assert.equal(k(null).waarde, null);
  // Slaat niets op
  const r = { situatie: "Nooit gemeld", trillingMms: 3 };
  k(r);
  assert.deepEqual(r, { situatie: "Nooit gemeld", trillingMms: 3 });
});

test("systeemvelden relatie.versie (teller) en traject.klantGezet (boolean)", () => {
  const rel = { id: "r_1", achternaam: "T", status: "Nieuw", versie: 2 };
  assert.equal(valideerRelatie(rel, { systeem: true }).ok, true);
  assert.equal(valideerRelatie(rel).fouten.versie, "niet-wijzigbaar");
  for (const slecht of [-1, 1.5, "2", null]) assert.equal(valideerRelatie({ ...rel, versie: slecht }, { systeem: true }).ok === true && slecht !== null, false);
  const t = { relatieId: "r_1", fase: "Getekend", klantGezet: true };
  assert.equal(valideerTraject(t, { systeem: true }).ok, true);
  assert.equal(valideerTraject(t).fouten.klantGezet, "niet-wijzigbaar");
  assert.equal(valideerTraject({ ...t, klantGezet: "ja" }, { systeem: true }).fouten.klantGezet, "ongeldig");
});

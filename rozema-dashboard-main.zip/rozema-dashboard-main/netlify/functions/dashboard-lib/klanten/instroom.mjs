// Klantenmodule K9: een aanvraag van het websiteformulier wordt een nieuwe relatie (lead) in de klantenopslag.
// Bron: dashboard/KLANTEN-ARCHITECTUUR.md §4 (Website-instroom, optie A) en §6 K9.
// Pure vertaling (vertaalAanvraag) plus idempotent aanmaken (neemAanvraagOp). Alle opslag via opslag.mjs
// en ../opslag.mjs, dus de teststore/echte-datakeuze (DASHBOARD_ECHTE_DATA=aan + context production) geldt hier ook.
//
// Ontdubbelen: een claim `ontdubbel/instroom/<hmac>` (24 uur) met de relatie, het Zoho-id en een tweede hash over de
// overige velden. De hash is een HMAC-sha256 met DASHBOARD_INSTROOM_GEHEIM; zonder geheim doet de instroom niets
// (neemAanvraagOp geeft {ok:false}, gooit niet). Claims bevatten geen persoonsgegevens, maar zijn per relatie
// terug te vinden (verwijderClaimVoorRelatie, voor AVG-verwijderen in K11) en worden dagelijks opgeruimd.
//
// Geen console.log: aanvragen bevatten persoonsgegevens. Fouten zijn codes, geen zinnen.
// Er staat geen tekst in dit bestand die een bezoeker leest.
import { createHmac, randomUUID } from "node:crypto";
import { store, storeNaam } from "../opslag.mjs";
import { maakRelatie, wijzigRelatie, leesRelatie, voegTijdlijnregelToe, isVerwijderd } from "./opslag.mjs";
import { valideerRelatie } from "./model.mjs";
import { vandaagAmsterdam } from "./datum.mjs";

export const WIE = "website"; // `wie` in tijdlijn en stempels
export const ONTDUBBEL_MS = 24 * 60 * 60 * 1000;
export const MIN_GEHEIM = 16;
const STORE = "klanten";
const VOORVOEGSEL = "ontdubbel/instroom/";
// Velden die niet in de eerste hash zitten en die bij een herhaling met andere waarden de relatie bijwerken.
const OVERIGE = ["voornaam", "achternaam", "email", "straat", "plaats", "bron", "voorWie", "contactvoorkeur"];

// Dezelfde waarden als netlify/lib/zoho-velden.mjs op herbouw-v2 (VOOR_WIE, CONTACTVOORKEUR, LEAD_SOURCE).
const VOOR_WIE = { eigenaar: "Eigenaar", helper: "Helpt een eigenaar" };
// Zelfde keuze in de nieuwe vorm (soort woning). Een huurder krijgt op de website geen contactblok (uitkomst H).
const SOORT_WONING = { eigenaar: "Eigen woning", helper: "Woning van iemand die klant helpt" };
const CONTACTVOORKEUR = { bellen: "Bellen", whatsapp: "WhatsApp" };
const BRON = { nfc: "Deur", kaart: "Deur", "niet-thuis": "Niet thuis" };
const BRON_STANDAARD = "Website";

const tekst = (v) => (typeof v === "string" ? v.trim() : "");
const geheim = () => (typeof process.env.DASHBOARD_INSTROOM_GEHEIM === "string" && process.env.DASHBOARD_INSTROOM_GEHEIM.length >= MIN_GEHEIM ? process.env.DASHBOARD_INSTROOM_GEHEIM : null);
export const instroomGeheimIngesteld = () => geheim() !== null;

// Is dit de echte store (DASHBOARD_ECHTE_DATA=aan en context production)? Gooit als de context ontbreekt terwijl echte data aan staat.
export const isEchteStore = () => storeNaam(STORE) === `dashboard-${STORE}`;

// "12a", "12 A", "12-3" -> {huisnummer:"12", toevoeging:"a"}. Past het niet, dan null.
export function splitsHuisnummer(invoer) {
  const m = /^(\d{1,6})\s*[-\s]?\s*([A-Za-z0-9][A-Za-z0-9 \-]{0,9})?$/.exec(tekst(invoer));
  return m ? { huisnummer: m[1], toevoeging: m[2] ? m[2].trim() : null } : null;
}

// Vertaalt de gelezen aanvraag (vorm van leesAanvraag() in netlify/lib/aanvraag.mjs op herbouw-v2) naar relatievelden.
// Geeft {ok:true, velden, herkomst} of {ok:false, fouten:{veld:code}}.
export function vertaalAanvraag(a) {
  if (a === null || typeof a !== "object" || Array.isArray(a)) return { ok: false, fouten: { _: "ongeldig" } };
  const hn = splitsHuisnummer(a.huisnummer);
  if (!hn) return { ok: false, fouten: { huisnummer: "ongeldig" } };
  const voorWie = VOOR_WIE[a.voorWie];
  const voorkeur = CONTACTVOORKEUR[a.contactvoorkeur];
  const fouten = {};
  if (!voorWie) fouten.voorWie = "geen-keuze";
  if (!voorkeur) fouten.contactvoorkeur = "geen-keuze";
  if (Object.keys(fouten).length) return { ok: false, fouten };
  const velden = {
    voornaam: tekst(a.voornaam) || null,
    achternaam: tekst(a.achternaam),
    mobiel: tekst(a.telefoon), // zelfde keuze als de website: telefoon gaat in Mobile
    email: tekst(a.email) || null,
    straat: tekst(a.straat),
    huisnummer: hn.huisnummer,
    toevoeging: hn.toevoeging,
    postcode: tekst(a.postcode),
    plaats: tekst(a.plaats),
    bron: BRON[a.bron] ?? BRON_STANDAARD,
    voorWie,
    soortWoning: SOORT_WONING[a.voorWie],
    contactvoorkeur: voorkeur,
    status: "Nieuw",
  };
  // Alleen de herkomstsleutel; geen persoonsgegevens. `kanaal` is de ?bron= van de website (of leeg).
  const herkomst = { website: { formulier: "aanvraag", ...(BRON[a.bron] ? { kanaal: String(a.bron) } : {}) } };
  return { ok: true, velden, herkomst };
}

const hmac = (sleutel, soort, tekstDeel) => createHmac("sha256", sleutel).update(`${soort}\n${tekstDeel}`).digest("hex").slice(0, 32);

// Hash 1 voor ontdubbelen: postcode + huisnummer (met toevoeging) + telefooncijfers, genormaliseerd.
export function ontdubbelHash(a, sleutel = geheim()) {
  if (!sleutel) return null;
  const pc = tekst(a.postcode).replace(/\s/g, "").toUpperCase();
  const hn = tekst(a.huisnummer).replace(/[\s-]/g, "").toLowerCase();
  const tel = tekst(a.telefoon).replace(/\D/g, "").replace(/^(0031|31)/, "0");
  return hmac(sleutel, "instroom", `${pc}\n${hn}\n${tel}`);
}
// Per veld een HMAC van de overige velden (hv) en één hash over alles (h2): zo zien we bij een herhaling welke velden
// de bezoeker nu anders invult dan de vorige aanvraag, zonder de waarden zelf te bewaren.
function veldHashes(velden, sleutel) {
  const hv = {};
  for (const k of OVERIGE) hv[k] = hmac(sleutel, `veld:${k}`, JSON.stringify(velden[k] ?? null));
  return { hv, h2: hmac(sleutel, "overig", JSON.stringify(OVERIGE.map((k) => hv[k]))), velden };
}

// Hoe lang een Zoho-poging van een ander verzoek als lopend telt, en hoe lang een tweede verzoek erop wacht.
export const ZOHO_BEZIG_MS = 30 * 1000;
export const ZOHO_WACHT_MS = 2000;
const recent = (iso, nu) => Number.isFinite(Date.parse(iso)) && Date.parse(iso) + ZOHO_BEZIG_MS > nu.getTime() && Date.parse(iso) <= nu.getTime() + 60000;

// Claimt hash 1. Geeft {sleutel, claim, nieuw}. onlyIfNew / onlyIfMatch, zodat twee gelijktijdige verzoeken dezelfde
// relatie krijgen. Een verlopen claim wordt vervangen. Een nieuwe claim draagt meteen zohoBezig: wie de claim zet, maakt de Zoho-lead.
// K11: wijst een claim naar een AVG-verwijderde relatie (tombstone; de claim is na een race blijven staan), dan telt hij
// als verlopen: de claim wordt met onlyIfMatch vervangen en de aanvraag wordt een nieuwe relatie met een nieuw id.
async function claim(s, hash, hashes, nu) {
  const sleutel = `${VOORVOEGSEL}${hash}`;
  for (let i = 0; i < 4; i++) {
    const r = await s.getWithMetadata(sleutel, { type: "json", consistency: "strong" });
    if (r && Date.parse(r.data?.op) + ONTDUBBEL_MS > nu.getTime() && !(await isVerwijderd(r.data?.relatieId))) {
      return { sleutel, claim: r.data, etag: r.etag, nieuw: false };
    }
    const nieuw = { relatieId: `r_w${randomUUID().replace(/-/g, "")}`, op: nu.toISOString(), h2: hashes.h2, hv: hashes.hv, zohoBezig: nu.toISOString() };
    const res = await s.setJSON(sleutel, nieuw, r ? { onlyIfMatch: r.etag } : { onlyIfNew: true });
    if (!res || res.modified !== false) return { sleutel, claim: nieuw, nieuw: true };
  }
  return null;
}

// Werkt de claim bij met onlyIfMatch (meerdere pogingen). `fn(claim)` geeft de nieuwe claim, undefined (niets te doen: true) of null (niet van toepassing: false).
async function pasClaimAan(s, sleutel, fn) {
  for (let i = 0; i < 4; i++) {
    const r = await s.getWithMetadata(sleutel, { type: "json", consistency: "strong" });
    if (!r) return false;
    const nieuw = fn(r.data);
    if (nieuw === null) return false;
    if (nieuw === undefined) return true;
    const res = await s.setJSON(sleutel, nieuw, { onlyIfMatch: r.etag });
    if (!res || res.modified !== false) return true;
  }
  return false;
}

// Neemt een aanvraag op. Idempotent: dezelfde aanvraag (zie ontdubbelHash) binnen 24 uur geeft dezelfde relatie terug.
// Een herhaling krijgt een tijdlijnregel (soort "herhaling", datum en kanaal, geen inhoud); de frontend toont die met
// `[[TEKST: klanten.tl.herhaling]]` (nu valt hij onder tl.overig).
// Geeft {ok:true, relatieId, bestaatAl, echt, zohoId, zohoBezig, bijgewerkt} of {ok:false, fouten}.
// - echt: de relatie staat in de echte store (anders in de teststore); de aanroeper telt alleen een echte store als gelukt.
// - zohoId: het Zoho-id van een eerdere poging (zie bewaarZohoId), of null. Alleen dan hoeft Zoho niet opnieuw. Wijken de
//   overige gegevens af van de vorige aanvraag, dan is zohoId altijd null (ook als het bijwerken mislukte): Zoho gaat wel.
// - zohoBezig: een ander verzoek is nu bezig met Zoho en het id is er nog niet; wacht met wachtOpZohoId en ga bij een
//   time-out toch naar Zoho (een dubbele lead is beter dan een verloren lead). Het verzoek dat zohoBezig niet krijgt
//   (false) maakt zelf de Zoho-lead.
// Zonder DASHBOARD_INSTROOM_GEHEIM (minstens 16 tekens): {ok:false, fouten:{_:"geen-geheim"}}, er wordt niets opgeslagen.
export async function neemAanvraagOp(aanvraag, nu = new Date()) {
  const sleutel = geheim();
  if (!sleutel) return { ok: false, fouten: { _: "geen-geheim" } };
  const v = vertaalAanvraag(aanvraag);
  if (!v.ok) return v;
  // Eerst valideren, zodat een aanvraag die het model weigert geen claim achterlaat.
  let controle;
  try { controle = valideerRelatie(v.velden); } catch { controle = { ok: false, fouten: { _: "ongeldig" } }; }
  if (!controle.ok) return { ok: false, fouten: controle.fouten };
  const echt = isEchteStore();
  const hashes = veldHashes(v.velden, sleutel);
  const s = store(STORE);
  const c = await claim(s, ontdubbelHash(aanvraag, sleutel), hashes, nu);
  if (!c) return { ok: false, fouten: { _: "gelijktijdig-probeer-opnieuw" } };
  const relatieId = c.claim.relatieId;
  // Dezelfde wijzigingId bij elke poging voor dezelfde claim: een herhaling na een onderbreking maakt niets dubbel.
  const r = await maakRelatie({ id: relatieId, wijzigingId: `w-${relatieId.slice(2)}`, velden: v.velden, herkomst: v.herkomst }, WIE, nu);
  if (!r.ok) return r;
  const bestaatAl = !c.nieuw || r.bestaatAl === true;
  // Herhaalde aanvraag: een tijdlijnregel bij de bestaande relatie met alleen datum en kanaal (geen inhoud); niet samenvoegen.
  if (!c.nieuw && r.bestaatAl === true) {
    const kanaal = v.herkomst.website.kanaal ?? "website";
    await voegTijdlijnregelToe(relatieId, { soort: "herhaling", nieuw: { kanaal, datum: vandaagAmsterdam(nu) }, wijzigingId: `herh-${randomUUID().slice(0, 12)}` }, WIE, nu);
  }
  const afwijkend = !c.nieuw && c.claim.h2 !== hashes.h2;
  let bijgewerkt = false;
  if (afwijkend) bijgewerkt = await werkRelatieBij(s, c.sleutel, relatieId, hashes, nu);
  let zohoId = afwijkend ? null : (c.claim.zohoId ?? null);
  let zohoBezig = false;
  if (!c.nieuw && !afwijkend && !zohoId) {
    if (recent(c.claim.zohoBezig, nu)) zohoBezig = true;
    else await pasClaimAan(s, c.sleutel, (cl) => (cl.zohoId || recent(cl.zohoBezig, nu) ? undefined : { ...cl, zohoBezig: nu.toISOString() })).catch(() => false); // wij maken de Zoho-lead
  }
  return { ok: true, relatieId, bestaatAl, echt, zohoId, zohoBezig, bijgewerkt };
}

// Zelfde adres en telefoon, andere overige gegevens: werk alleen de velden bij waarvan de formulierwaarde afwijkt van de
// vorige aanvraag (hv in de claim), zodat handmatige correcties van de rest blijven staan. De claim krijgt de nieuwe hashes met
// onlyIfMatch op de etag die vóór wijzigRelatie is gelezen; bij een conflict opnieuw lezen en nog eens (3 pogingen).
// Mislukt het bijwerken, dan blijft de oude claim staan en is de volgende herhaling een nieuwe kans.
async function werkRelatieBij(s, claimSleutel, relatieId, hashes, nu) {
  const velden = hashes.velden;
  for (let i = 0; i < 3; i++) {
    const r = await s.getWithMetadata(claimSleutel, { type: "json", consistency: "strong" });
    if (!r) return false;
    const cl = r.data;
    if (cl.h2 === hashes.h2) return false; // een gelijktijdig verzoek heeft dit al verwerkt
    const rec = await leesRelatie(relatieId);
    if (!rec) return false;
    const wijz = {};
    for (const k of OVERIGE) {
      if (cl.hv?.[k] === hashes.hv[k]) continue; // niet anders ingevuld dan vorige keer: handmatige correctie blijft staan
      const nieuw = velden[k] ?? null;
      const oud = rec[k] ?? null;
      if (nieuw !== oud) wijz[k] = { oud, nieuw };
    }
    if (Object.keys(wijz).length) {
      const w = await wijzigRelatie(relatieId, { wijzigingId: `herh-${randomUUID().slice(0, 12)}`, velden: wijz }, WIE, nu);
      if (!w.ok) return false;
    }
    const res = await s.setJSON(claimSleutel, { ...cl, h2: hashes.h2, hv: hashes.hv }, { onlyIfMatch: r.etag });
    if (!res || res.modified !== false) return Object.keys(wijz).length > 0;
  }
  return false;
}

// Wacht (hoogstens ~2 s) tot een ander verzoek het Zoho-id in de claim heeft gezet. Geeft het id of null.
export async function wachtOpZohoId(aanvraag, { maxMs = ZOHO_WACHT_MS, stapMs = 200 } = {}) {
  try {
    const sleutel = geheim();
    if (!sleutel) return null;
    const s = store(STORE);
    const key = `${VOORVOEGSEL}${ontdubbelHash(aanvraag, sleutel)}`;
    const eind = Date.now() + maxMs;
    for (;;) {
      const cl = await s.get(key, { type: "json", consistency: "strong" });
      if (cl?.zohoId) return cl.zohoId;
      if (!cl || Date.now() + stapMs > eind) return null;
      await new Promise((klaar) => setTimeout(klaar, stapMs));
    }
  } catch {
    return null;
  }
}

// Bewaart het Zoho-id na een geslaagde maakLead, in de claim van deze aanvraag (onlyIfMatch). Geeft true bij gelukt.
// Gooit niet. Is de claim weg of verlopen (meer dan 24 uur), dan false.
export async function bewaarZohoId(aanvraag, zohoId, nu = new Date()) {
  try {
    const sleutel = geheim();
    if (!sleutel || typeof zohoId !== "string" || !/^[A-Za-z0-9_-]{1,64}$/.test(zohoId)) return false;
    const s = store(STORE);
    return await pasClaimAan(s, `${VOORVOEGSEL}${ontdubbelHash(aanvraag, sleutel)}`, (cl) => (Date.parse(cl.op) + ONTDUBBEL_MS > nu.getTime() ? { ...cl, zohoId } : null));
  } catch {
    return false;
  }
}

// Voor AVG-verwijderen (K11): haalt alle claims weg die naar deze relatie verwijzen. Geeft het aantal verwijderde claims.
export async function verwijderClaimVoorRelatie(relatieId) {
  const s = store(STORE);
  const { blobs } = await s.list({ prefix: VOORVOEGSEL });
  let n = 0;
  for (const { key } of blobs) {
    const cl = await s.get(key, { type: "json", consistency: "strong" }).catch(() => null);
    if (cl && cl.relatieId === relatieId) { await s.delete(key); n++; }
  }
  return n;
}

// Voor de dagelijkse run: verwijdert claims ouder dan 24 uur, maar alleen als het lezen gelukt is, de claim aantoonbaar
// verlopen is en een nieuwe lezing vlak voor het verwijderen dezelfde etag geeft (anders is de claim net vernieuwd).
// Geeft {verwijderd, over, overgeslagen}.
export async function ruimVerlopenClaimsOp(nu = new Date()) {
  const s = store(STORE);
  const { blobs } = await s.list({ prefix: VOORVOEGSEL });
  let verwijderd = 0;
  let over = 0;
  let overgeslagen = 0;
  for (const { key } of blobs) {
    let r;
    try { r = await s.getWithMetadata(key, { type: "json", consistency: "strong" }); } catch { r = undefined; }
    if (r === undefined) { overgeslagen++; continue; } // lezen mislukt: niet verwijderen
    if (r === null) continue; // al weg
    const t = Date.parse(r.data?.op);
    if (!Number.isFinite(t)) { overgeslagen++; continue; }
    if (t + ONTDUBBEL_MS > nu.getTime()) { over++; continue; }
    try {
      const opnieuw = await s.getWithMetadata(key, { type: "json", consistency: "strong" });
      if (!opnieuw || opnieuw.etag !== r.etag) { overgeslagen++; continue; }
      await s.delete(key);
      verwijderd++;
    } catch {
      overgeslagen++;
    }
  }
  return { verwijderd, over, overgeslagen };
}

// Zet Situatie op een relatie die uit het formulier kwam (voor lead-bijwerken). `situatie` is al de waarde uit de
// SITUATIE-tabel van de website; null maakt het veld leeg. Alleen als Situatie leeg is of de status nog Nieuw is
// (daarna heeft een mens het overgenomen): anders {ok:true, overgeslagen:true}. Niet gevonden: {ok:false, fouten:{_:"niet-gevonden"}}.
export async function zetSituatie(relatieId, situatie, nu = new Date()) {
  const rec = await leesRelatie(relatieId);
  if (!rec || !rec.herkomst?.website) return { ok: false, fouten: { _: "niet-gevonden" } };
  if (rec.situatie && rec.status !== "Nieuw") return { ok: true, overgeslagen: true };
  const wijziging = { wijzigingId: `sit-${randomUUID().slice(0, 12)}`, velden: { situatie: { oud: rec.situatie ?? null, nieuw: situatie } } };
  const r = await wijzigRelatie(relatieId, wijziging, WIE, nu);
  return r.ok ? { ok: true } : r;
}

import { test, beforeEach } from "node:test";
import assert from "node:assert/strict";
import { zetStoreFabriek } from "../opslag.mjs";
import { geheugenStore } from "../test-hulp.mjs";
import {
  maakRelatie, wijzigRelatie, maakTraject, wijzigTraject, vinkAf, heropen, leesRelatie, leesTraject,
  leesRegister, leesAlleTrajecten, leesIndex, leesTijdlijn, herbouwIndex, vergelijkRegister, verwijderOnvolledig, leverOpenJournalen,
} from "./opslag.mjs";
import { testCatalogus } from "./test-regels.mjs";

const NU = new Date("2026-11-10T10:00:00.000Z");
const na = (ms) => new Date(NU.getTime() + ms);
const R1 = "r_abc";
const T1 = "t_abc";

// Wrapper om de geheugenstore: haken vóór setJSON en een filter voor list.
let basis; let haken;
function wrap(b) {
  return {
    ...b,
    getWithMetadata: (...a) => b.getWithMetadata(...a),
    async get(k, o) {
      if (haken.faalGet(k)) throw new Error("leesfout");
      if (haken.nulGet(k)) return null;
      return b.get(k, o);
    },
    async setJSON(k, v, opt) {
      for (const h of haken.voorSet) {
        const uit = await h(k, v, opt); // een haak mag een resultaat teruggeven (bijv. {modified:false})
        if (uit !== undefined) return uit;
      }
      return b.setJSON(k, v, opt);
    },
    async list(o) {
      const r = await b.list(o);
      return { blobs: r.blobs.filter((x) => !haken.verberg(x.key)) };
    },
  };
}
beforeEach(() => {
  basis = geheugenStore();
  haken = { voorSet: [], verberg: () => false, faalGet: () => false, nulGet: () => false };
  const w = wrap(basis);
  zetStoreFabriek(() => w);
});

const nieuweRelatie = (extra = {}) => maakRelatie({ id: R1, wijzigingId: "w1", velden: { achternaam: "Test", status: "Nieuw", straat: "Teststraat", huisnummer: "1", plaats: "Plaats", ...extra } }, "kevin", NU);
const nieuwTraject = (extra = {}) => maakTraject(R1, { id: T1, wijzigingId: "w-t1", velden: { fase: "Aanvraag ingediend", ...extra } }, "kevin", NU);
const w = (id, velden) => ({ wijzigingId: id, velden });

test("maakRelatie: record, statusgeschiedenis, logregel, index", async () => {
  const r = await nieuweRelatie();
  assert.equal(r.ok, true);
  const rec = await leesRelatie(R1);
  assert.deepEqual(rec.statusgeschiedenis, [{ status: "Nieuw", van: "2026-11-10", wie: "kevin" }]);
  assert.deepEqual(rec.toegepast, ["w1"]);
  assert.equal((await leesTijdlijn(R1)).length, 1);
  assert.equal((await leesIndex()).rijen[R1].naam, "Test - Teststraat 1, Plaats");
});

test("maakRelatie: ongeldig geweigerd, niets geschreven", async () => {
  const r = await maakRelatie({ id: R1, wijzigingId: "w1", velden: { status: "Nieuw" } }, "kevin", NU);
  assert.equal(r.ok, false);
  assert.equal(r.fouten.achternaam, "verplicht");
  assert.equal(await leesRelatie(R1), null);
});

test("idempotent aanmaken: zelfde wijzigingId = succes, geen tweede logregel; ander id = bestaat-al", async () => {
  await nieuweRelatie();
  const nog = await nieuweRelatie();
  assert.equal(nog.ok, true);
  assert.equal(nog.bestaatAl, true);
  assert.equal((await leesTijdlijn(R1)).length, 1);
  const ander = await maakRelatie({ id: R1, wijzigingId: "w9", velden: { achternaam: "X", status: "Nieuw" } }, "ruben", NU);
  assert.equal(ander.ok, false);
  assert.equal(ander.fouten.id, "bestaat-al");
});

test("T10: gelijktijdig, verschillende velden: beide toegepast, 2 logregels (race gesimuleerd)", async () => {
  await nieuweRelatie();
  let eenmaal = true;
  // Vlak voor de eerste schrijfactie op de relatie schrijft de ander eerst: de etag klopt dan niet meer.
  haken.voorSet.push(async (k, v, opt) => {
    if (eenmaal && k === `relatie/${R1}` && opt?.onlyIfMatch) {
      eenmaal = false;
      const h = await wijzigRelatie(R1, w("w-b", { plaats: { oud: "Plaats", nieuw: "Drachten" } }), "ruben", na(1000));
      assert.equal(h.ok, true);
    }
  });
  const a = await wijzigRelatie(R1, w("w-a", { telefoon: { oud: null, nieuw: "0512 123456" } }), "kevin", na(2000));
  assert.deepEqual(a.toegepast, ["telefoon"]);
  assert.deepEqual(a.conflicten, []);
  const rec = await leesRelatie(R1);
  assert.equal(rec.telefoon, "0512 123456");
  assert.equal(rec.plaats, "Drachten");
  const tijdlijn = await leesTijdlijn(R1);
  assert.equal(tijdlijn.filter((l) => l.soort === "wijziging").length, 2);
  assert.equal(eenmaal, false);
});

test("T10b: echt parallel, verschillende velden", async () => {
  await nieuweRelatie();
  await Promise.all([
    wijzigRelatie(R1, w("w-a", { telefoon: { oud: null, nieuw: "0512 123456" } }), "kevin", na(1000)),
    wijzigRelatie(R1, w("w-b", { plaats: { oud: "Plaats", nieuw: "Drachten" } }), "ruben", na(1000)),
  ]);
  const rec = await leesRelatie(R1);
  assert.equal(rec.telefoon, "0512 123456");
  assert.equal(rec.plaats, "Drachten");
});

test("T11: zelfde veld, zelfde oud: één toegepast, één conflict met huidige waarde", async () => {
  await nieuweRelatie();
  const a = await wijzigRelatie(R1, w("w-a", { plaats: { oud: "Plaats", nieuw: "Drachten" } }), "kevin", na(1000));
  const b = await wijzigRelatie(R1, w("w-b", { plaats: { oud: "Plaats", nieuw: "Groningen" } }), "ruben", na(2000));
  assert.deepEqual(a.toegepast, ["plaats"]);
  assert.deepEqual(b.toegepast, []);
  assert.deepEqual(b.conflicten, [{ veld: "plaats", huidig: "Drachten", oud: "Plaats", nieuw: "Groningen" }]);
  assert.equal((await leesRelatie(R1)).plaats, "Drachten");
});

test("T12: zelfde wijzigingId twee keer = no-op, één logregel", async () => {
  await nieuweRelatie();
  const wij = w("w-a", { plaats: { oud: "Plaats", nieuw: "Drachten" } });
  await wijzigRelatie(R1, wij, "kevin", na(1000));
  const tweede = await wijzigRelatie(R1, wij, "kevin", na(2000));
  assert.equal(tweede.noop, true);
  assert.equal((await leesTijdlijn(R1)).filter((l) => l.soort === "wijziging").length, 1);
});

test("veld dat al de nieuwe waarde heeft: geen conflict, geen logregel", async () => {
  await nieuweRelatie();
  await wijzigRelatie(R1, w("w-a", { plaats: { oud: "Plaats", nieuw: "Drachten" } }), "kevin", na(1000));
  const b = await wijzigRelatie(R1, w("w-b", { plaats: { oud: "Plaats", nieuw: "Drachten" } }), "ruben", na(2000));
  assert.deepEqual(b.conflicten, []);
  assert.deepEqual(b.toegepast, []);
});

test("ongeldige waarde en onbekend veld: fout, niets geschreven", async () => {
  await nieuweRelatie();
  const r = await wijzigRelatie(R1, w("w-a", { email: { oud: null, nieuw: "geen" }, systeem: { oud: null, nieuw: 1 } }), "kevin", na(1000));
  assert.equal(r.ok, false);
  assert.equal(r.fouten.email, "geen-email");
  assert.equal((await leesRelatie(R1)).toegepast.length, 1);
});

test("statuswissel via wijzigRelatie: geschiedenis en één logregel; Afgevallen vraagt reden", async () => {
  await nieuweRelatie();
  const zonder = await wijzigRelatie(R1, w("w-a", { status: { oud: "Nieuw", nieuw: "Afgevallen" } }), "kevin", na(1000));
  assert.equal(zonder.ok, false);
  const met = await wijzigRelatie(R1, w("w-b", { redenAfgevallen: { oud: null, nieuw: "Niet bereikt" }, status: { oud: "Nieuw", nieuw: "Afgevallen" } }), "kevin", na(2000));
  assert.equal(met.ok, true);
  const rec = await leesRelatie(R1);
  assert.equal(rec.statusgeschiedenis.at(-1).status, "Afgevallen");
  assert.equal((await leesTijdlijn(R1)).filter((l) => l.soort === "statuswissel").length, 1);
});

test("taken.<id>.<veld>: taak aanmaken en afronden, index toont eerstvolgende taak", async () => {
  await nieuweRelatie();
  const a = await wijzigRelatie(R1, w("w-a", {
    "taken.k1.soort": { oud: null, nieuw: "taak" }, "taken.k1.titel": { oud: null, nieuw: "Bel terug" }, "taken.k1.datum": { oud: null, nieuw: "2026-11-12" },
  }), "kevin", na(1000));
  assert.equal(a.ok, true);
  assert.equal((await leesIndex()).rijen[R1].volgendeTaak.id, "k1");
  const b = await wijzigRelatie(R1, w("w-b", { "taken.k1.klaar": { oud: null, nieuw: { wie: "kevin", op: "2026-11-11T09:00:00.000Z" } } }), "kevin", na(2000));
  assert.deepEqual(b.toegepast, ["taken.k1.klaar"]);
  assert.equal((await leesIndex()).rijen[R1].volgendeTaak, null);
  const half = await wijzigRelatie(R1, w("w-c", { "taken.k2.soort": { oud: null, nieuw: "taak" } }), "kevin", na(3000));
  assert.equal(half.ok, false);
});

test("maakTraject: relatie wordt Klant (statusgeschiedenis, logregel), tweede traject laat status staan", async () => {
  await nieuweRelatie();
  const t = await nieuwTraject();
  assert.equal(t.ok, true);
  const rel = await leesRelatie(R1);
  assert.equal(rel.status, "Klant");
  assert.deepEqual(rel.statusgeschiedenis.map((s) => s.status), ["Nieuw", "Klant"]);
  assert.equal((await leesIndex()).rijen[R1].status, "Klant");
  const t2 = await maakTraject(R1, { id: "t_def", wijzigingId: "w-t2", velden: { fase: "Getekend" } }, "kevin", na(1000));
  assert.equal(t2.ok, true);
  assert.equal((await leesRelatie(R1)).statusgeschiedenis.length, 2);
  assert.equal((await leesTijdlijn(R1)).filter((l) => l.soort === "statuswissel").length, 1);
});

test("maakTraject: register eerst, dan record; herhaling idempotent", async () => {
  await nieuweRelatie();
  let registerAlBij = null;
  haken.voorSet.push(async (k) => {
    if (k === `traject/${T1}`) registerAlBij = !!(await basis.get("register/trajecten", { type: "json" }))?.ids?.[T1];
  });
  await nieuwTraject();
  assert.equal(registerAlBij, true);
  assert.equal((await leesRegister()).ids[T1].relatieId, R1);
  const nog = await nieuwTraject();
  assert.equal(nog.bestaatAl, true);
  assert.equal(Object.keys((await leesRegister()).ids).length, 1);
});

test("maakTraject zonder bestaande relatie: fout", async () => {
  const r = await nieuwTraject();
  assert.equal(r.fouten.relatieId, "niet-gevonden");
  assert.equal(Object.keys((await leesRegister()).ids).length, 0);
});

test("T9: traject staat in het register, list laat het weg: toch in leesAlleTrajecten", async () => {
  await nieuweRelatie();
  await nieuwTraject();
  haken.verberg = (k) => k.startsWith("traject/");
  const { trajecten, onvolledig } = await leesAlleTrajecten(na(1000));
  assert.deepEqual(trajecten.map((t) => t.id), [T1]);
  assert.deepEqual(onvolledig, []);
});

test("onvolledig traject: registeritem zonder record, pas na 10 minuten", async () => {
  await nieuweRelatie();
  await nieuwTraject();
  await basis.delete(`traject/${T1}`);
  assert.deepEqual((await leesAlleTrajecten(na(5 * 60 * 1000))).onvolledig, []);
  const laat = await leesAlleTrajecten(na(11 * 60 * 1000));
  assert.deepEqual(laat.trajecten, []);
  assert.equal(laat.onvolledig[0].id, T1);
});

test("leesAlleTrajecten: meer dan 20 trajecten", async () => {
  await nieuweRelatie();
  for (let i = 0; i < 45; i++) {
    const r = await maakTraject(R1, { id: `t_n${i}`, wijzigingId: `wn${i}`, velden: { fase: "Getekend" } }, "kevin", NU);
    assert.equal(r.ok, true);
  }
  assert.equal((await leesAlleTrajecten(na(1000))).trajecten.length, 45);
});

test("fase vanaf Besluit zonder datum geweigerd; met datum of 'onbekend' toegestaan", async () => {
  await nieuweRelatie();
  await nieuwTraject();
  const f = await wijzigTraject(T1, w("w-a", { fase: { oud: "Aanvraag ingediend", nieuw: "Besluit" } }), "kevin", na(1000));
  assert.equal(f.ok, false);
  assert.equal(f.fouten.verzenddatumBesluitbrief, "verplicht-vanaf-besluit");
  assert.equal((await leesTraject(T1)).fase, "Aanvraag ingediend");
  const ok = await wijzigTraject(T1, w("w-b", { verzenddatumBesluitbrief: { oud: null, nieuw: "2026-11-01" }, fase: { oud: "Aanvraag ingediend", nieuw: "Besluit" } }), "kevin", na(2000));
  assert.equal(ok.ok, true);
  assert.deepEqual((await leesTraject(T1)).fasegeschiedenis.map((x) => x.fase), ["Aanvraag ingediend", "Besluit"]);
  const wis = await wijzigTraject(T1, w("w-c", { verzenddatumBesluitbrief: { oud: "2026-11-01", nieuw: null } }), "kevin", na(3000));
  assert.equal(wis.ok, false);
  const onb = await wijzigTraject(T1, w("w-d", { verzenddatumOnbekend: { oud: null, nieuw: true }, verzenddatumBesluitbrief: { oud: "2026-11-01", nieuw: null } }), "kevin", na(4000));
  assert.equal(onb.ok, true);
});

test("fasewissel conflict en traject-logregel onder het relatie-id", async () => {
  await nieuweRelatie();
  await nieuwTraject();
  await wijzigTraject(T1, w("w-a", { fase: { oud: "Aanvraag ingediend", nieuw: "Opname gepland" } }), "kevin", na(1000));
  const b = await wijzigTraject(T1, w("w-b", { fase: { oud: "Aanvraag ingediend", nieuw: "Verloren" } }), "ruben", na(2000));
  assert.equal(b.conflicten[0].huidig, "Opname gepland");
  const tl = await leesTijdlijn(R1);
  assert.ok(tl.some((l) => l.soort === "fasewissel" && l.record === "traject" && l.recordId === T1));
  assert.deepEqual(tl.map((l) => l.op), [...tl.map((l) => l.op)].sort().reverse());
});

const REGELS = testCatalogus({ "deal-zienswijze": { afvinkActies: ["Zienswijze ingediend"] } });
const klaarVoorAfvinken = async () => {
  await nieuweRelatie();
  await nieuwTraject();
  await wijzigTraject(T1, w("w-a", { datumAdviesrapport: { oud: null, nieuw: "2026-11-02" }, fase: { oud: "Aanvraag ingediend", nieuw: "Adviesrapport" } }), "kevin", na(500));
};

test("afvinken fatale regel zonder actie geweigerd; met actie ok; heropenen", async () => {
  await klaarVoorAfvinken();
  const zonder = await vinkAf(T1, "deal-zienswijze", { wijzigingId: "w-v1" }, "kevin", na(1000), { regels: REGELS });
  assert.equal(zonder.ok, false);
  assert.equal(zonder.fouten.actie, "actie-verplicht");
  const fout = await vinkAf(T1, "deal-zienswijze", { actie: "iets", wijzigingId: "w-v2" }, "kevin", na(1000), { regels: REGELS });
  assert.equal(fout.fouten.actie, "actie-niet-toegestaan");
  const ok = await vinkAf(T1, "deal-zienswijze", { actie: "Zienswijze ingediend", wijzigingId: "w-v3" }, "kevin", na(2000), { regels: REGELS });
  assert.equal(ok.ok, true);
  assert.equal((await leesTraject(T1)).afgevinkt["deal-zienswijze"].brondatum, "2026-11-02");
  assert.equal((await vinkAf(T1, "deal-zienswijze", { actie: "Zienswijze ingediend", wijzigingId: "w-v3" }, "kevin", na(3000), { regels: REGELS })).noop, true);
  // Daarna blijft een wijziging (fasewissel valideert het hele record) mogelijk.
  const w2 = await wijzigTraject(T1, w("w-b", { route: { oud: null, nieuw: "AVV" } }), "kevin", na(3500));
  assert.equal(w2.ok, true);
  const h = await heropen(T1, "deal-zienswijze", { wijzigingId: "w-h1" }, "kevin", na(4000), { regels: REGELS });
  assert.equal(h.ok, true);
  assert.equal((await leesTraject(T1)).afgevinkt["deal-zienswijze"], undefined);
  const h2 = await heropen(T1, "deal-zienswijze", { wijzigingId: "w-h2" }, "kevin", na(5000), { regels: REGELS });
  assert.equal(h2.ok, true); // al open: no-op
  assert.equal(h2.noop, true);
  // Tweede keer afvinken met dezelfde actie (andere wijzigingId): no-op, geen tweede logregel; andere actie: wel een wijziging.
  const v1 = await vinkAf(T1, "deal-zienswijze", { actie: "Zienswijze ingediend", wijzigingId: "w-n1" }, "kevin", na(5100), { regels: REGELS });
  assert.equal(v1.ok, true);
  assert.notEqual(v1.noop, true);
  const v2 = await vinkAf(T1, "deal-zienswijze", { actie: "Zienswijze ingediend", wijzigingId: "w-n2" }, "kevin", na(5200), { regels: REGELS });
  assert.equal(v2.ok, true);
  assert.equal(v2.noop, true);
  assert.equal((await leesTijdlijn(R1)).filter((l) => l.soort === "afvinken" && l.wijzigingId === "w-n2").length, 0);
  const soorten = (await leesTijdlijn(R1)).map((l) => l.soort);
  assert.ok(soorten.includes("afvinken") && soorten.includes("heropenen"));
});

test("toegepast bewaart hoogstens 50 wijzigingIds", async () => {
  await nieuweRelatie();
  let huidig = "Plaats";
  for (let i = 0; i < 55; i++) {
    const nieuw = i % 2 ? "Plaats" : "Drachten";
    await wijzigRelatie(R1, w(`w${100 + i}`, { plaats: { oud: huidig, nieuw } }), "kevin", na(i * 10));
    huidig = nieuw;
  }
  assert.equal((await leesRelatie(R1)).toegepast.length, 50);
});

test("herbouwIndex en vergelijkRegister melden en herstellen afwijkingen", async () => {
  await nieuweRelatie();
  await nieuwTraject();
  await basis.delete("index/relaties");
  const h = await herbouwIndex();
  assert.deepEqual(h.afwijkingen, [{ id: R1, soort: "ontbrak-in-index" }]);
  assert.equal((await leesIndex()).rijen[R1].status, "Klant");
  await basis.setJSON("register/trajecten", { ids: {} });
  const v = await vergelijkRegister(NU);
  assert.equal(v.afwijkingen[0].soort, "ontbrak-in-register");
  assert.equal((await leesRegister()).ids[T1].relatieId, R1);
  assert.deepEqual((await vergelijkRegister(NU)).afwijkingen, []);
});

// ---------- review-punten ----------
const schoon = () => { assert.equal(({}).afgevinkt, undefined); assert.equal(({}).toegepast, undefined); assert.equal(({}).x, undefined); };

test("prototype-vervuiling: taken.__proto__.<veld> en varianten geweigerd, Object.prototype blijft schoon", async () => {
  await nieuweRelatie();
  await nieuwTraject();
  for (const veld of ["taken.__proto__.afgevinkt", "taken.__proto__.toegepast", "taken.constructor.prototype", "__proto__.x", "taken.k1.__proto__", "taken.k1.afgevinkt", "constructor", "taken.toString.titel"]) {
    const r = await wijzigRelatie(R1, w("w-p", { [veld]: { oud: null, nieuw: { x: 1 } } }), "kevin", na(1000));
    assert.equal(r.ok, false, veld);
    assert.equal(r.fouten[veld], "ongeldig", veld);
    schoon();
  }
  const j = JSON.parse('{"__proto__":{"oud":null,"nieuw":"x"},"taken.__proto__.toegepast":{"oud":null,"nieuw":"x"}}');
  const r = await wijzigTraject(T1, { wijzigingId: "w-q", velden: j }, "kevin", na(1000));
  assert.equal(r.ok, false);
  const waarde = await wijzigRelatie(R1, w("w-r", { "taken.k1.titel": { oud: null, nieuw: JSON.parse('{"__proto__":{"afgevinkt":1}}') } }), "kevin", na(1000));
  assert.equal(waarde.ok, false);
  const m = await maakRelatie({ id: "r_zz", wijzigingId: "w-z", velden: JSON.parse('{"achternaam":"T","status":"Nieuw","taken":{"__proto__":{"soort":"taak","titel":"x"}}}') }, "kevin", NU);
  assert.equal(m.ok, false);
  const m2 = await maakRelatie({ id: "r_zy", wijzigingId: "w-y", velden: JSON.parse('{"__proto__":{"afgevinkt":1},"achternaam":"T","status":"Nieuw"}') }, "kevin", NU);
  assert.equal(m2.ok, false);
  schoon();
  assert.deepEqual((await leesRelatie(R1)).toegepast, ["w1"]); // alleen de aanmaak, niets erbij
});

test("deel-conflict: herhaling met dezelfde wijzigingId toont het conflict opnieuw", async () => {
  await nieuweRelatie();
  await wijzigRelatie(R1, w("w-a", { plaats: { oud: "Plaats", nieuw: "Drachten" } }), "kevin", na(1000));
  const wij = w("w-b", { plaats: { oud: "Plaats", nieuw: "Groningen" }, telefoon: { oud: null, nieuw: "0512 123456" } });
  const eerste = await wijzigRelatie(R1, wij, "ruben", na(2000));
  assert.deepEqual(eerste.toegepast, ["telefoon"]);
  assert.equal(eerste.conflicten.length, 1);
  const herhaling = await wijzigRelatie(R1, wij, "ruben", na(3000));
  assert.equal(herhaling.noop, true);
  assert.deepEqual(herhaling.conflicten, eerste.conflicten);
});

const faalLog = (aan) => haken.voorSet.push(async (k) => { if (aan.aan && k.startsWith("log/")) throw new Error("schrijffout"); });
const aantal = async (soort) => (await leesTijdlijn(R1)).filter((l) => l.soort === soort).length;

test("log mislukt, herhaling levert de logregel alsnog, precies één keer (wijzig, maakRelatie)", async () => {
  const f = { aan: true }; faalLog(f);
  const m = await nieuweRelatie();
  assert.equal(m.logOk, false);
  assert.equal(await aantal("aanmaak"), 0);
  f.aan = false;
  const m2 = await nieuweRelatie();
  assert.equal(m2.bestaatAl, true);
  assert.equal(m2.logOk, true);
  assert.equal(await aantal("aanmaak"), 1);
  await nieuweRelatie();
  assert.equal(await aantal("aanmaak"), 1);

  f.aan = true;
  const wij = w("w-a", { plaats: { oud: "Plaats", nieuw: "Drachten" } });
  const a = await wijzigRelatie(R1, wij, "kevin", na(1000));
  assert.equal(a.ok, true);
  assert.equal(a.logOk, false);
  assert.equal(await aantal("wijziging"), 0);
  f.aan = false;
  const b = await wijzigRelatie(R1, wij, "kevin", na(2000));
  assert.equal(b.noop, true);
  assert.equal(b.logOk, true);
  assert.equal(await aantal("wijziging"), 1);
  await wijzigRelatie(R1, wij, "kevin", na(3000));
  assert.equal(await aantal("wijziging"), 1);
  assert.deepEqual((await basis.list({ prefix: "logwacht/" })).blobs, []);
});

test("log mislukt, herhaling levert alsnog: maakTraject, vinkAf en heropen", async () => {
  await nieuweRelatie();
  const f = { aan: true }; faalLog(f);
  const t = await nieuwTraject();
  assert.equal(t.logOk, false);
  f.aan = false;
  const t2 = await nieuwTraject();
  assert.equal(t2.logOk, true);
  assert.equal(await aantal("aanmaak"), 2); // relatie + traject
  assert.equal(await aantal("statuswissel"), 1);
  await nieuwTraject();
  assert.equal(await aantal("statuswissel"), 1);

  await wijzigTraject(T1, w("w-a", { datumAdviesrapport: { oud: null, nieuw: "2026-11-02" }, fase: { oud: "Aanvraag ingediend", nieuw: "Adviesrapport" } }), "kevin", na(500));
  f.aan = true;
  const v = { actie: "Zienswijze ingediend", wijzigingId: "w-v" };
  assert.equal((await vinkAf(T1, "deal-zienswijze", v, "kevin", na(1000), { regels: REGELS })).logOk, false);
  f.aan = false;
  assert.equal((await vinkAf(T1, "deal-zienswijze", v, "kevin", na(2000), { regels: REGELS })).logOk, true);
  assert.equal(await aantal("afvinken"), 1);
  f.aan = true;
  const h = { wijzigingId: "w-h" };
  assert.equal((await heropen(T1, "deal-zienswijze", h, "kevin", na(3000), { regels: REGELS })).logOk, false);
  f.aan = false;
  assert.equal((await heropen(T1, "deal-zienswijze", h, "kevin", na(4000), { regels: REGELS })).logOk, true);
  assert.equal(await aantal("heropenen"), 1);
});

test("index valt niet terug: een nieuwere rij blijft staan als een oudere schrijfpoging verliest", async () => {
  await nieuweRelatie();
  let eenmaal = true;
  haken.voorSet.push(async (k, v, opt) => {
    if (eenmaal && k === "index/relaties" && opt?.onlyIfMatch) {
      eenmaal = false;
      await wijzigRelatie(R1, w("w-b", { plaats: { oud: "Plaats", nieuw: "Drachten" } }), "ruben", na(5000));
    }
  });
  await wijzigRelatie(R1, w("w-a", { telefoon: { oud: null, nieuw: "0512 123456" } }), "kevin", na(1000));
  assert.equal(eenmaal, false);
  const rij = (await leesIndex()).rijen[R1];
  assert.equal(rij.plaats, "Drachten");
  assert.equal(rij.versie, 3);
  // Direct een nieuwere rij neerzetten: een oudere upsert schrijft er niet overheen.
  await basis.setJSON("index/relaties", { rijen: { [R1]: { ...rij, plaats: "Nieuwer", versie: 99 } } });
  await wijzigRelatie(R1, w("w-c", { telefoon: { oud: "0512 123456", nieuw: "0512 654321" } }), "kevin", na(6000));
  assert.equal((await leesIndex()).rijen[R1].plaats, "Nieuwer");
});

test("herbouwIndex: rij blijft bij een list die de relatie mist, verdwijnt alleen als de relatie echt weg is", async () => {
  await nieuweRelatie();
  await maakRelatie({ id: "r_twee", wijzigingId: "w2", velden: { achternaam: "Twee", status: "Nieuw" } }, "kevin", NU);
  haken.verberg = (k) => k === `relatie/${R1}`;
  const h = await herbouwIndex();
  assert.deepEqual(h.afwijkingen, []);
  assert.ok((await leesIndex()).rijen[R1]);
  await basis.delete("relatie/r_twee");
  const h2 = await herbouwIndex();
  assert.deepEqual(h2.afwijkingen, [{ id: "r_twee", soort: "geen-record" }]);
  assert.equal((await leesIndex()).rijen.r_twee, undefined);
  assert.ok((await leesIndex()).rijen[R1]);
});

test("herbouwIndex: nieuwere rij die tijdens de herbouw is geschreven blijft staan", async () => {
  await nieuweRelatie();
  let eenmaal = true;
  haken.voorSet.push(async (k, v, opt) => {
    if (eenmaal && k === "index/relaties" && opt?.onlyIfMatch) {
      eenmaal = false;
      await wijzigRelatie(R1, w("w-b", { plaats: { oud: "Plaats", nieuw: "Drachten" } }), "ruben", na(5000));
    }
  });
  await herbouwIndex();
  assert.equal(eenmaal, false);
  assert.equal((await leesIndex()).rijen[R1].plaats, "Drachten");
});

test("leesAlleTrajecten: een mislukte read legt alleen dat traject in onleesbaar", async () => {
  await nieuweRelatie();
  await nieuwTraject();
  await maakTraject(R1, { id: "t_def", wijzigingId: "w-t2", velden: { fase: "Getekend" } }, "kevin", NU);
  haken.faalGet = (k) => k === "traject/t_def";
  const r = await leesAlleTrajecten(na(1000));
  assert.deepEqual(r.trajecten.map((t) => t.id), [T1]);
  assert.deepEqual(r.onleesbaar, [{ id: "t_def", relatieId: R1 }]);
});

test("herhaalde maakTraject zet de status niet opnieuw op Klant", async () => {
  await nieuweRelatie();
  await nieuwTraject();
  await wijzigRelatie(R1, w("w-a", { status: { oud: "Klant", nieuw: "Later opnieuw" } }), "kevin", na(1000));
  const nog = await nieuwTraject();
  assert.equal(nog.bestaatAl, true);
  assert.equal((await leesRelatie(R1)).status, "Later opnieuw");
  assert.equal(await aantal("statuswissel"), 2); // Klant, Later opnieuw
});

test("herhaalde maakTraject: mislukt registerherstel geeft een fout", async () => {
  await nieuweRelatie();
  await nieuwTraject();
  await basis.setJSON("register/trajecten", { ids: {} });
  haken.voorSet.push(async (k) => (k === "register/trajecten" ? { modified: false } : undefined));
  const r = await nieuwTraject();
  assert.equal(r.ok, false);
  assert.equal(r.fouten._, "gelijktijdig-probeer-opnieuw");
});

test("gelijk: objecten met andere sleutelvolgorde zijn gelijk", async () => {
  await nieuweRelatie();
  const taak = { "taken.k1.soort": { oud: null, nieuw: "taak" }, "taken.k1.titel": { oud: null, nieuw: "Bel" } };
  await wijzigRelatie(R1, w("w-a", taak), "kevin", na(1000));
  await wijzigRelatie(R1, w("w-b", { "taken.k1.klaar": { oud: null, nieuw: { wie: "kevin", op: "2026-11-11T09:00:00.000Z" } } }), "kevin", na(2000));
  const b = await wijzigRelatie(R1, w("w-c", { "taken.k1.klaar": { oud: { op: "2026-11-11T09:00:00.000Z", wie: "kevin" }, nieuw: null } }), "ruben", na(3000));
  assert.deepEqual(b.conflicten, []);
  assert.deepEqual(b.toegepast, ["taken.k1.klaar"]);
});

test("maximaal 100 velden per wijziging; volgnummer in de logsleutel heeft 3 cijfers", async () => {
  await nieuweRelatie();
  const veel = Object.fromEntries(Array.from({ length: 101 }, (_, i) => [`taken.k${i}.titel`, { oud: null, nieuw: "x" }]));
  const r = await wijzigRelatie(R1, w("w-a", veel), "kevin", na(1000));
  assert.equal(r.fouten.velden, "te-veel");
  const sleutels = (await basis.list({ prefix: `log/${R1}/` })).blobs.map((b) => b.key);
  assert.match(sleutels[0], /-000$/);
});

test("controle(nieuwRecord, huidigRecord) draait in de schrijfpoging; een fout betekent niets schrijven", async () => {
  await nieuweRelatie();
  await nieuwTraject();
  let gezien = null;
  const geweigerd = await wijzigTraject(T1, w("w-a", { route: { oud: null, nieuw: "AVV" } }), "kevin", na(1000), {
    controle: (nieuw, huidig) => { gezien = [nieuw.route, huidig.route]; return { route: "niet-toegestaan" }; },
  });
  assert.equal(geweigerd.ok, false);
  assert.equal(geweigerd.fouten.route, "niet-toegestaan");
  assert.deepEqual(gezien, ["AVV", undefined]);
  assert.equal((await leesTraject(T1)).route, undefined);
  assert.equal((await basis.list({ prefix: "logwacht/" })).blobs.length, 0);
  const goed = await wijzigTraject(T1, w("w-b", { route: { oud: null, nieuw: "AVV" } }), "kevin", na(2000), { controle: () => null });
  assert.equal(goed.ok, true);
  const tekst = await wijzigTraject(T1, w("w-c", { route: { oud: "AVV", nieuw: "Vaste vergoeding" } }), "kevin", na(3000), { controle: () => "nee" });
  assert.equal(tekst.fouten._, "nee");
});

test("verwijderOnvolledig: alleen een registeritem zonder record; logt", async () => {
  await nieuweRelatie();
  await nieuwTraject();
  assert.equal((await verwijderOnvolledig(T1, "kevin", na(1000))).fouten.id, "record-bestaat");
  assert.equal((await verwijderOnvolledig("t_onbekend", "kevin", na(1000))).fouten.id, "niet-in-register");
  await basis.delete(`traject/${T1}`);
  const r = await verwijderOnvolledig(T1, "kevin", na(2000));
  assert.equal(r.ok, true);
  assert.equal(r.logOk, true);
  assert.deepEqual((await leesRegister()).ids, {});
  assert.equal(await aantal("verwijder-onvolledig"), 1);
});

// ---------- tweede review ----------
test("verwijderOnvolledig midden in maakTraject: het traject blijft in het register", async () => {
  await nieuweRelatie();
  let etagVoor = null;
  haken.voorSet.push(async (k, v, opt) => {
    if (k === `traject/${T1}` && opt?.onlyIfNew) {
      etagVoor = (await basis.getWithMetadata("register/trajecten")).etag;
      // V ziet het record nog niet en haalt het registeritem weg.
      haken.nulGet = (x) => x === `traject/${T1}`;
      const v2 = await verwijderOnvolledig(T1, "kevin", na(500));
      haken.nulGet = () => false;
      assert.equal(v2.ok, true);
    }
  });
  const t = await nieuwTraject();
  assert.equal(t.ok, true);
  const { trajecten } = await leesAlleTrajecten(na(1000));
  assert.deepEqual(trajecten.map((x) => x.id), [T1]);
  assert.ok((await leesRegister()).ids[T1].bevestigd);
});

test("na maakTraject is een oude etag van het register waardeloos (een late verwijderOnvolledig verliest)", async () => {
  await nieuweRelatie();
  let etag = null;
  haken.voorSet.push(async (k, v, opt) => { if (k === `traject/${T1}` && opt?.onlyIfNew) etag = (await basis.getWithMetadata("register/trajecten")).etag; });
  await nieuwTraject();
  const res = await basis.setJSON("register/trajecten", { ids: {} }, { onlyIfMatch: etag });
  assert.equal(res.modified, false);
});

test("herhaalde maakTraject zet een ontbrekend registeritem terug", async () => {
  await nieuweRelatie();
  await nieuwTraject();
  await basis.setJSON("register/trajecten", { ids: {} });
  const r = await nieuwTraject();
  assert.equal(r.ok, true);
  assert.equal((await leesAlleTrajecten(na(1000))).trajecten.length, 1);
});

test("Klant: relatie was al Klant, later Afgevallen, herhaling zet niet terug; geen marker in toegepast", async () => {
  await maakRelatie({ id: R1, wijzigingId: "w1", velden: { achternaam: "Test", status: "Klant" } }, "kevin", NU);
  await nieuwTraject();
  assert.equal((await leesTraject(T1)).klantGezet, true);
  const a = await wijzigRelatie(R1, w("w-a", { redenAfgevallen: { oud: null, nieuw: "Anders" }, status: { oud: "Klant", nieuw: "Afgevallen" } }), "kevin", na(1000));
  assert.equal(a.ok, true);
  const nog = await nieuwTraject();
  assert.equal(nog.bestaatAl, true);
  assert.equal((await leesRelatie(R1)).status, "Afgevallen");
  assert.ok(!(await leesRelatie(R1)).toegepast.some((x) => x.startsWith("k_")));
});

test("Klant: na meer dan 50 wijzigingen zet een herhaling de status niet terug", async () => {
  await nieuweRelatie();
  await nieuwTraject();
  await wijzigRelatie(R1, w("w-s", { status: { oud: "Klant", nieuw: "Later opnieuw" } }), "kevin", na(100));
  let huidig = "Plaats";
  for (let i = 0; i < 55; i++) {
    const nieuw = i % 2 ? "Plaats" : "Drachten";
    await wijzigRelatie(R1, w(`w${200 + i}`, { plaats: { oud: huidig, nieuw } }), "kevin", na(200 + i));
    huidig = nieuw;
  }
  await nieuwTraject();
  assert.equal((await leesRelatie(R1)).status, "Later opnieuw");
});

test("Klant: een client-wijzigingId k_<nr> blokkeert de Klant-stap niet", async () => {
  await nieuweRelatie();
  await wijzigRelatie(R1, w("k_abc", { plaats: { oud: "Plaats", nieuw: "Drachten" } }), "kevin", na(100));
  await nieuwTraject();
  assert.equal((await leesRelatie(R1)).status, "Klant");
});

test("dubbel verstuurde wijziging: de verliezer wist het journaal van de winnaar niet", async () => {
  await nieuweRelatie();
  let binnen = false;
  let verliezer = null;
  haken.voorSet.push(async (k, v, opt) => {
    if (k !== `relatie/${R1}` || !opt?.onlyIfMatch) return undefined;
    if (!binnen) {
      binnen = true; // eerste schrijfpoging (X): Y loopt er nu doorheen en verliest alle pogingen
      haken.forceer = true;
      verliezer = await wijzigRelatie(R1, w("w-dubbel", { plaats: { oud: "Plaats", nieuw: "Drachten" } }), "kevin", na(1));
      haken.forceer = false;
      return undefined;
    }
    return haken.forceer ? { modified: false } : undefined;
  });
  const x = await wijzigRelatie(R1, w("w-dubbel", { plaats: { oud: "Plaats", nieuw: "Drachten" } }), "kevin", na(2000));
  assert.equal(verliezer.ok, false);
  assert.equal(x.ok, true);
  assert.equal(x.logOk, true);
  assert.equal(await aantal("wijziging"), 1);
  assert.deepEqual((await basis.list({ prefix: "logwacht/" })).blobs, []);
});

test("veld __proto__ uit JSON: geweigerd, niet stil ok", async () => {
  await nieuweRelatie();
  const r = await wijzigRelatie(R1, { wijzigingId: "w-p", velden: JSON.parse('{"__proto__":{"oud":null,"nieuw":"x"}}') }, "kevin", na(100));
  assert.equal(r.ok, false);
  schoon();
});

test("fasewissel controleert afgevinkt weer, en een niet-fataal afvinkrecord (actie null) is geldig", async () => {
  await nieuweRelatie();
  await nieuwTraject();
  await wijzigTraject(T1, w("w-a", { opnamedatum: { oud: null, nieuw: "2026-11-02" }, fase: { oud: "Aanvraag ingediend", nieuw: "Opname gepland" } }), "kevin", na(100));
  const v = await vinkAf(T1, "deal-opname", { wijzigingId: "w-v" }, "kevin", na(200), { regels: REGELS });
  assert.equal(v.ok, true);
  assert.equal((await leesTraject(T1)).afgevinkt["deal-opname"].actie, null);
  const ok = await wijzigTraject(T1, w("w-b", { fase: { oud: "Opname gepland", nieuw: "Opname gedaan" } }), "kevin", na(300));
  assert.equal(ok.ok, true);
  const t = await leesTraject(T1);
  await basis.setJSON(`traject/${T1}`, { ...t, afgevinkt: { x: { actie: 5 } } });
  const kapot = await wijzigTraject(T1, w("w-c", { fase: { oud: "Opname gedaan", nieuw: "Adviesrapport" } }), "kevin", na(400));
  assert.equal(kapot.ok, false);
  assert.equal(kapot.fouten.afgevinkt, "ongeldig");
});

test("relatie.versie is een teller die bij elke schrijfactie stijgt (ook Klant) en in de index staat", async () => {
  await nieuweRelatie();
  assert.equal((await leesRelatie(R1)).versie, 1);
  await wijzigRelatie(R1, w("w-a", { plaats: { oud: "Plaats", nieuw: "Drachten" } }), "kevin", na(100));
  assert.equal((await leesRelatie(R1)).versie, 2);
  await nieuwTraject();
  assert.equal((await leesRelatie(R1)).versie, 3);
  assert.equal((await leesIndex()).rijen[R1].versie, 3);
});

test("leverOpenJournalen: levert toegepaste af, gooit weesjournalen weg, laat recente staan", async () => {
  await nieuweRelatie();
  const f = { aan: true }; faalLog(f);
  await wijzigRelatie(R1, w("w-a", { plaats: { oud: "Plaats", nieuw: "Drachten" } }), "kevin", na(1000));
  f.aan = false;
  await basis.setJSON(`logwacht/${R1}/${R1}.w-wees@x#y`, { op: na(1000).toISOString(), wijzigingId: "w-wees", regels: [{ soort: "wijziging", record: "relatie", recordId: R1, veld: "plaats", oud: "a", nieuw: "b" }] });
  assert.equal(await aantal("wijziging"), 0);
  const vroeg = await leverOpenJournalen(na(60 * 1000));
  assert.deepEqual(vroeg, { geleverd: 0, weggegooid: 0, mislukt: 0, overgeslagen: 2 });
  const laat = await leverOpenJournalen(na(15 * 60 * 1000));
  assert.deepEqual(laat, { geleverd: 1, weggegooid: 1, mislukt: 0, overgeslagen: 0 });
  assert.equal(await aantal("wijziging"), 1);
  assert.deepEqual((await basis.list({ prefix: "logwacht/" })).blobs, []);
});

// ---------- derde review: journaal ----------
test("list verbergt nieuwe logwacht-sleutels: de logregels staan toch direct in de tijdlijn", async () => {
  haken.verberg = (k) => k.startsWith("logwacht/");
  const m = await nieuweRelatie();
  assert.equal(m.logOk, true);
  const t = await nieuwTraject();
  assert.equal(t.logOk, true);
  const a = await wijzigRelatie(R1, w("w-a", { plaats: { oud: "Plaats", nieuw: "Drachten" } }), "kevin", na(1000));
  assert.equal(a.logOk, true);
  await wijzigTraject(T1, w("w-b", { datumAdviesrapport: { oud: null, nieuw: "2026-11-02" }, fase: { oud: "Aanvraag ingediend", nieuw: "Adviesrapport" } }), "kevin", na(1100));
  const v = await vinkAf(T1, "deal-zienswijze", { actie: "Zienswijze ingediend", wijzigingId: "w-v" }, "kevin", na(1200), { regels: REGELS });
  assert.equal(v.logOk, true);
  assert.equal(await aantal("aanmaak"), 2);
  assert.equal(await aantal("statuswissel"), 1);
  assert.equal(await aantal("wijziging"), 2);
  assert.equal(await aantal("fasewissel"), 1);
  assert.equal(await aantal("afvinken"), 1);
  assert.deepEqual((await basis.list({ prefix: "logwacht/" })).blobs, []);
});

test("zelfde nu: een noop-herhaling wist het journaal van de eerdere poging niet", async () => {
  await nieuweRelatie();
  const f = { aan: true }; faalLog(f);
  const wij = w("w-a", { plaats: { oud: "Plaats", nieuw: "Drachten" } });
  assert.equal((await wijzigRelatie(R1, wij, "kevin", na(1000))).logOk, false);
  const sleutels = (await basis.list({ prefix: "logwacht/" })).blobs.map((b) => b.key);
  assert.equal(sleutels.length, 1);
  assert.match(sleutels[0], /@.+#[0-9a-f-]{36}$/);
  f.aan = false;
  const herhaling = await wijzigRelatie(R1, wij, "kevin", na(1000)); // precies dezelfde nu
  assert.equal(herhaling.noop, true);
  assert.equal(herhaling.logOk, true);
  assert.equal(await aantal("wijziging"), 1);
});

test("leverOpenJournalen: per wijzigingId één set logregels (die van het record), de rest wordt gewist", async () => {
  await nieuweRelatie();
  const f = { aan: true }; faalLog(f);
  await wijzigRelatie(R1, w("w-a", { plaats: { oud: "Plaats", nieuw: "Drachten" } }), "kevin", na(1000));
  f.aan = false;
  const regel = (nieuw) => ({ soort: "wijziging", record: "relatie", recordId: R1, wie: "ruben", veld: "plaats", oud: "Plaats", nieuw });
  await basis.setJSON(`logwacht/${R1}/${R1}.w-a@${na(500).toISOString()}#aaaa`, { op: na(500).toISOString(), regels: [regel("Verliezer")], wijzigingId: "w-a" });
  const r = await leverOpenJournalen(na(15 * 60 * 1000));
  assert.deepEqual(r, { geleverd: 1, weggegooid: 1, mislukt: 0, overgeslagen: 0 });
  const regels = (await leesTijdlijn(R1)).filter((l) => l.wijzigingId === "w-a");
  assert.equal(regels.length, 1);
  assert.equal(regels[0].nieuw, "Drachten");
  assert.equal(regels[0].op, na(1000).toISOString());
  assert.deepEqual((await basis.list({ prefix: "logwacht/" })).blobs, []);
});

test("leverOpenJournalen: een Klant-journaal alleen bij een passende Klant-regel in de statusgeschiedenis", async () => {
  await nieuweRelatie();
  const f = { aan: true }; faalLog(f);
  await nieuwTraject();
  f.aan = false;
  // Een onschuldig weesjournaal van een andere wie: de relatie is wel ooit Klant geweest, maar niet door hem.
  await basis.setJSON(`logwacht/${R1}/${R1}.klant.fout@${NU.toISOString()}#bbbb`, {
    op: NU.toISOString(), wijzigingId: "klant.fout", regels: [{ soort: "statuswissel", record: "relatie", recordId: R1, wie: "ruben", van: "2026-11-10", wijzigingen: [] }],
  });
  const r = await leverOpenJournalen(na(15 * 60 * 1000));
  assert.deepEqual(r, { geleverd: 2, weggegooid: 1, mislukt: 0, overgeslagen: 0 }); // traject-aanmaak + Klant; wees weg
  assert.equal(await aantal("statuswissel"), 1);
  assert.equal(await aantal("aanmaak"), 2);
});

// ---------- vierde review: logsleutel ----------
test("dezelfde wijzigingId op relatie en traject van één relatie: beide krijgen hun logregel", async () => {
  await nieuweRelatie();
  await nieuwTraject();
  const f = { aan: true }; faalLog(f);
  await wijzigRelatie(R1, w("w-gelijk", { plaats: { oud: "Plaats", nieuw: "Drachten" } }), "kevin", na(1000));
  await wijzigTraject(T1, w("w-gelijk", { route: { oud: null, nieuw: "AVV" } }), "kevin", na(1000));
  f.aan = false;
  const r = await leverOpenJournalen(na(15 * 60 * 1000));
  assert.deepEqual(r, { geleverd: 2, weggegooid: 0, mislukt: 0, overgeslagen: 0 });
  const regels = (await leesTijdlijn(R1)).filter((l) => l.wijzigingId === "w-gelijk");
  assert.deepEqual(regels.map((l) => l.record).sort(), ["relatie", "traject"]);
  // Direct aangeleverd (zonder fout) botst het ook niet.
  const a = await wijzigRelatie(R1, w("w-dubbel", { telefoon: { oud: null, nieuw: "0512 123456" } }), "kevin", na(2000));
  const b = await wijzigTraject(T1, w("w-dubbel", { factuurVerstuurdOp: { oud: null, nieuw: "2026-11-01" } }), "kevin", na(2000));
  assert.equal(a.logOk && b.logOk, true);
  assert.equal((await leesTijdlijn(R1)).filter((l) => l.wijzigingId === "w-dubbel").length, 2);
});

test("een echte nieuwe toepassing van dezelfde wijzigingId (na het toegepast-venster) krijgt een eigen logregel", async () => {
  await nieuweRelatie();
  const wij = w("w-oud", { plaats: { oud: "Plaats", nieuw: "Drachten" } });
  await wijzigRelatie(R1, wij, "kevin", na(1000));
  let huidig = "Drachten";
  for (let i = 0; i < 52; i++) { // schuift w-oud uit de laatste 50
    const nieuw = i % 2 ? "Drachten" : "Groningen";
    await wijzigRelatie(R1, w(`w${300 + i}`, { plaats: { oud: huidig, nieuw } }), "kevin", na(1100 + i));
    huidig = nieuw;
  }
  assert.ok(!(await leesRelatie(R1)).toegepast.includes("w-oud"));
  // Nu is plaats weer "Drachten" en de herhaling past opnieuw toe, met een eigen logregel.
  const opnieuw = await wijzigRelatie(R1, w("w-oud", { plaats: { oud: huidig, nieuw: "Assen" } }), "kevin", na(5000));
  assert.deepEqual(opnieuw.toegepast, ["plaats"]);
  assert.equal(opnieuw.logOk, true);
  assert.equal((await leesTijdlijn(R1)).filter((l) => l.wijzigingId === "w-oud").length, 2);
});

test("tijdlijn: de Klant-wissel staat na de aanmaak van het traject, ook bij dezelfde tijd", async () => {
  await nieuweRelatie();
  await nieuwTraject();
  const tl = await leesTijdlijn(R1); // nieuwste eerst
  const i = (soort, record) => tl.findIndex((l) => l.soort === soort && (!record || l.record === record));
  assert.ok(i("statuswissel") < i("aanmaak", "traject"));
});

// K10: GET /straten op de klanten-API en de koppeling met een deurbezoek (herkomst.deur). Alleen verzonnen data.
import { test, beforeEach, afterEach } from "node:test";
import assert from "node:assert/strict";
import { zetStoreFabriek } from "../../opslag.mjs";
import { geheugenStore } from "../../test-hulp.mjs";
import { maakWachtwoordHash, maakToken } from "../../sessie.mjs";
import { testCatalogus } from "../test-regels.mjs";
import { klantRijenInPlaats, maakStraten, vouwNaam } from "../straten.mjs";
import { maakHandler } from "../../../dashboard-klanten.mjs";

const NU = new Date("2026-11-10T10:00:00.000Z");
const CTX = { deploy: { context: "deploy-preview" } };
const BASIS = "https://x.test/api/dashboard/klanten";
let h; let kevin; let tik; let store;

beforeEach(async () => {
  process.env.DASHBOARD_GEBRUIKERS = JSON.stringify({ Kevin: await maakWachtwoordHash("verzonnen-a", 1000) });
  process.env.DASHBOARD_SESSIE_GEHEIM = "z".repeat(40);
  delete process.env.DASHBOARD_SESSIE_VERSIE;
  delete process.env.DASHBOARD_ECHTE_DATA;
  store = geheugenStore();
  zetStoreFabriek(() => store);
  tik = 0;
  h = maakHandler({ regels: testCatalogus(), nu: () => new Date(NU.getTime() + 1000 * tik++) });
  kevin = `dashboard_sessie=${maakToken("Kevin")}`;
});
afterEach(() => { delete process.env.DASHBOARD_ECHTE_DATA; });

async function vraag(method, pad, body, c = kevin) {
  const res = await h(new Request(`${BASIS}${pad}`, {
    method,
    headers: { ...(body !== undefined ? { "content-type": "application/json" } : {}), ...(c ? { cookie: c } : {}) },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  }), CTX);
  const tekst = await res.text();
  let data = null;
  try { data = JSON.parse(tekst); } catch { /* geen json */ }
  return { status: res.status, data, tekst };
}
const maakR = (id, velden, herkomst) => vraag("POST", "/relaties", { id, wijzigingId: `w-${id}`, velden: { achternaam: "Test", status: "Nieuw", ...velden }, ...(herkomst ? { herkomst } : {}) });
const maakT = (rid, id) => vraag("POST", `/relaties/${rid}/trajecten`, { id, wijzigingId: `w-${id}`, velden: { fase: "Aanvraag ingediend" } });

// ---------- puur ----------
test("vouwNaam: hoofdletters, accenten en dubbele spaties tellen niet mee", () => {
  assert.equal(vouwNaam("  Éénstraat   Noord "), "eenstraat noord");
  assert.equal(vouwNaam(null), "");
});

test("klantRijenInPlaats en maakStraten: alleen klanten en trajecten, uniek per straat, onvolledig geteld", () => {
  const rijen = [
    { id: "r_1", plaats: "Plaatsa", status: "Klant" },
    { id: "r_2", plaats: "plaatsa", status: "Nieuw" }, // geen klant, geen traject
    { id: "r_3", plaats: "Plaatsa", status: "Afspraak gepland" }, // wel een traject
    { id: "r_4", plaats: "Plaatsb", status: "Klant" },
    { id: "r_5", plaats: "PLAATSA", status: "Klant" },
  ];
  const register = { ids: { t_1: { relatieId: "r_3" } } };
  const hier = klantRijenInPlaats(rijen, register, "plaatsa");
  assert.deepEqual(hier.map((r) => r.id), ["r_1", "r_3", "r_5"]);
  const m = maakStraten(hier, (r) => ({ r_1: "Teststraat", r_3: "teststraat" })[r.id]);
  assert.deepEqual(m, { straten: [{ straat: "Teststraat", klant: true }], onvolledig: 1 });
  assert.deepEqual(maakStraten([], () => null), { straten: [], onvolledig: 0 });
  assert.deepEqual(klantRijenInPlaats(rijen, null, "Nergens"), []);
});

// ---------- route ----------
test("GET /straten: 401 zonder cookie, 405 bij POST, 422 zonder of met lege of te lange plaats", async () => {
  assert.equal((await vraag("GET", "/straten?plaats=x", undefined, null)).status, 401);
  assert.equal((await vraag("POST", "/straten", {})).status, 405);
  for (const q of ["", "?plaats=", "?plaats=%20", `?plaats=${"x".repeat(101)}`]) {
    assert.equal((await vraag("GET", `/straten${q}`)).status, 422, q);
  }
});

test("GET /straten?plaats=: alleen straten met een klant of traject, als {straat, klant:true}, geen namen of aantallen", async () => {
  await maakR("r_a1", { straat: "Teststraat", huisnummer: "1", plaats: "Plaatsa", achternaam: "Verzonnenachternaam" });
  await maakR("r_a2", { straat: "Teststraat", huisnummer: "2", plaats: "Plaatsa" });
  await maakR("r_a3", { straat: "Laan", huisnummer: "9", plaats: "Plaatsa" });
  await maakR("r_a5", { straat: "Zijweg", huisnummer: "3", plaats: "Plaatsa" });
  await maakR("r_b1", { straat: "Anderestraat", huisnummer: "5", plaats: "Plaatsb" });
  await maakT("r_a1", "t_a1"); // r_a1 wordt Klant
  await maakT("r_a3", "t_a3"); // r_a3 ook
  await maakT("r_b1", "t_b1");
  const r = await vraag("GET", "/straten?plaats=PLAATSA");
  assert.equal(r.status, 200);
  assert.deepEqual(r.data, { plaats: "PLAATSA", straten: [{ straat: "Laan", klant: true }, { straat: "Teststraat", klant: true }], onvolledig: 0 });
  assert.ok(!r.tekst.includes("Verzonnenachternaam") && !r.tekst.includes("r_a1") && !r.tekst.includes("Zijweg") && !r.tekst.includes("Anderestraat"));
  const onbekend = await vraag("GET", "/straten?plaats=Nergens");
  assert.deepEqual(onbekend.data, { plaats: "Nergens", straten: [], onvolledig: 0 });
});

test("GET /straten?plaats=: een relatie die niet te lezen is telt als onvolledig", async () => {
  await maakR("r_a1", { straat: "Teststraat", huisnummer: "1", plaats: "Plaatsa" });
  await maakT("r_a1", "t_a1");
  await maakR("r_a2", { straat: "Laan", huisnummer: "2", plaats: "Plaatsa" });
  await maakT("r_a2", "t_a2");
  const echt = store.get.bind(store);
  store.get = async (k, ...rest) => { if (k === "relatie/r_a2") throw new Error("lezen mislukt"); return echt(k, ...rest); };
  store.getWithMetadata = async (k, ...rest) => { if (k === "relatie/r_a2") throw new Error("lezen mislukt"); return Object.getPrototypeOf(store).getWithMetadata?.call(store, k, ...rest); };
  const r = await vraag("GET", "/straten?plaats=Plaatsa");
  assert.equal(r.status, 200);
  assert.equal(r.data.onvolledig, 1);
  assert.deepEqual(r.data.straten, [{ straat: "Teststraat", klant: true }]);
});

// ---------- koppeling met een deurbezoek ----------
test("nieuwe klant uit een deurbezoek: herkomst.deur met event-id, idempotent, ongeldige herkomst 422", async () => {
  const herkomst = { deur: { eventId: "abcd1234efgh", plaats: "plaatsa", adres: "0000000000000001" } };
  const velden = { straat: "Teststraat", huisnummer: "1", plaats: "Plaatsa", bron: "Deur", bagId: "0000000000000001" };
  const r = await maakR("r_d1", velden, herkomst);
  assert.equal(r.status, 201, r.tekst);
  assert.deepEqual(r.data.record.herkomst, herkomst);
  assert.equal(r.data.record.bron, "Deur");
  const lees = await vraag("GET", "/relaties/r_d1");
  assert.deepEqual(lees.data.relatie.herkomst.deur.eventId, "abcd1234efgh");
  const nog = await maakR("r_d1", velden, herkomst);
  assert.equal(nog.status, 200);
  assert.equal(nog.data.bestaatAl, true);
  const slecht = await maakR("r_d2", velden, { deur: { eventId: "x".repeat(101) } });
  assert.equal(slecht.status, 422);
});

test("herkomst.deur: streng: precies eventId (verplicht), plaats en adres (optioneel), geen andere sleutels of vormen", async () => {
  const velden = { straat: "Teststraat", huisnummer: "1", plaats: "Plaatsa" };
  const goed = [{ deur: { eventId: "abcdefgh" } }, { deur: { eventId: "a1".repeat(20), plaats: "plaats-a_1.x", adres: "A.b_c-1" } }];
  let n = 0;
  for (const hk of goed) assert.equal((await maakR(`r_ok${n++}`, velden, hk)).status, 201, JSON.stringify(hk));
  const slecht = [
    { deur: {} }, { deur: { plaats: "plaatsa" } }, { deur: "abcdefgh" }, { deur: [] }, { deur: null },
    { deur: { eventId: "abcdefg" } }, { deur: { eventId: "a".repeat(41) } }, { deur: { eventId: "ABCDEFGH" } }, { deur: { eventId: 12345678 } },
    { deur: { eventId: "abcdefgh", extra: "x" } }, { deur: { eventId: "abcdefgh", naam: "Verzonnen" } },
    { deur: { eventId: "abcdefgh", plaats: "a b" } }, { deur: { eventId: "abcdefgh", plaats: "" } }, { deur: { eventId: "abcdefgh", plaats: "x".repeat(61) } },
    { deur: { eventId: "abcdefgh", adres: "a/b" } }, { deur: { eventId: "abcdefgh", adres: 5 } }, { deur: { eventId: "abcdefgh", plaats: { a: "b" } } },
    { onbekend: { a: "b" } }, "deur",
  ];
  for (const hk of slecht) assert.equal((await maakR(`r_x${n++}`, velden, hk)).status, 422, JSON.stringify(hk));
  // andere herkomsten blijven werken zoals eerst
  assert.equal((await maakR("r_zoho", velden, { zoho: { module: "Leads", id: "123" } })).status, 201);
});

test("deterministisch id uit het bezoek: een tweede aanmaak geeft bestaatAl en dezelfde relatie", async () => {
  const hk = { deur: { eventId: "abcdefgh1", plaats: "plaatsa", adres: "0000000000000001" } };
  const id = "r_deur_abcdefgh1";
  const een = await vraag("POST", "/relaties", { id, wijzigingId: "deur-abcdefgh1", velden: { achternaam: "Test", status: "Nieuw", straat: "Teststraat" }, herkomst: hk });
  const twee = await vraag("POST", "/relaties", { id, wijzigingId: "deur-abcdefgh1", velden: { achternaam: "Test", status: "Nieuw", straat: "Teststraat" }, herkomst: hk });
  assert.equal(een.status, 201, een.tekst);
  assert.equal(twee.status, 200);
  assert.equal(twee.data.bestaatAl, true);
  assert.equal(twee.data.record.id, id);
  assert.equal((await vraag("GET", "/relaties")).data.totaal, 1);
});

// Tests voor dashboard-klanten-dagelijks.mjs (K5). Alleen fictieve data, nep-store.
import { test, beforeEach, afterEach } from "node:test";
import assert from "node:assert/strict";
import { zetStoreFabriek } from "../../opslag.mjs";
import { geheugenStore } from "../../test-hulp.mjs";
import { maakRelatie, maakTraject, wijzigTraject, wijzigRelatie, leesTijdlijn } from "../opslag.mjs";
import { testCatalogus } from "../test-regels.mjs";
import handler, { config } from "../../../dashboard-klanten-dagelijks.mjs";
import { voerDagelijksUit } from "../dagelijks.mjs";

const NU = new Date("2026-11-10T03:00:00.000Z");
const REGELS = testCatalogus();
const R1 = "r_aaa1";
const T1 = "t_aaa1";
let basis;

beforeEach(() => {
  basis = geheugenStore();
  const w = {
    get: (...a) => basis.get(...a), getWithMetadata: (...a) => basis.getWithMetadata(...a), set: (...a) => basis.set(...a),
    setJSON: (...a) => basis.setJSON(...a), delete: (...a) => basis.delete(...a), list: (...a) => basis.list(...a),
  };
  zetStoreFabriek(() => w);
  delete process.env.DASHBOARD_ECHTE_DATA;
});
afterEach(() => { delete process.env.DASHBOARD_ECHTE_DATA; });

async function zaai() {
  const a = await maakRelatie({ id: R1, wijzigingId: "w-r1", velden: { achternaam: "Test", status: "Nieuw", straat: "Teststraat", huisnummer: "1", plaats: "Plaats", postcode: "9999 ZZ" } }, "kevin", new Date(NU.getTime() - 86400000));
  assert.equal(a.ok, true, JSON.stringify(a));
  const b = await maakTraject(R1, { id: T1, wijzigingId: "w-t1", velden: { fase: "Aanvraag ingediend" } }, "kevin", new Date(NU.getTime() - 86400000));
  assert.equal(b.ok, true, JSON.stringify(b));
  const c = await wijzigTraject(T1, { wijzigingId: "w-b", velden: { verzenddatumBesluitbrief: { oud: null, nieuw: "2026-11-02" }, fase: { oud: "Aanvraag ingediend", nieuw: "Besluit" } } }, "kevin", new Date(NU.getTime() - 3600000));
  assert.equal(c.ok, true, JSON.stringify(c));
}
const hartslag = async () => basis.get("status/dagelijks", { type: "json" });

test("schema: één keer per dag, UTC", () => {
  assert.equal(config.schedule, "0 3 * * *");
});

test("run zonder fouten: hartslag met aantallen en ids, zonder persoonsgegevens", async () => {
  await zaai();
  const r = await voerDagelijksUit({ nu: NU, regels: REGELS });
  assert.equal(r.ok, true);
  assert.deepEqual(r.fouten, []);
  const h = await hartslag();
  assert.equal(h.op, NU.toISOString());
  assert.equal(h.ok, true);
  assert.equal(h.aantallen.trajecten, 1);
  assert.equal(h.aantallen.fataalItems, 4);
  assert.equal(h.aantallen.indexRijen, 1);
  assert.ok(h.details.fataal.every((i) => i.recordId === T1));
  const tekst = JSON.stringify(h);
  for (const geheim of ["Test", "Teststraat", "9999", "Plaats"]) assert.ok(!tekst.includes(geheim), geheim);
});

test("levert open journalen af: logschrijven mislukte, de run levert de logregel alsnog en wist het journaal", async () => {
  await zaai();
  const origSet = basis.setJSON;
  let kapot = true;
  basis.setJSON = async (k, ...r) => { if (kapot && k.startsWith("log/")) throw new Error("schrijffout"); return origSet.call(basis, k, ...r); };
  const wijz = await wijzigRelatie(R1, { wijzigingId: "w-plaats", velden: { plaats: { oud: "Plaats", nieuw: "Elders" } } }, "kevin", new Date(NU.getTime() - 3600000));
  kapot = false;
  assert.equal(wijz.logOk, false);
  assert.equal((await basis.list({ prefix: "logwacht/" })).blobs.length, 1);
  const voor = (await leesTijdlijn(R1)).filter((l) => l.wijzigingId === "w-plaats").length;
  assert.equal(voor, 0);
  const r = await voerDagelijksUit({ nu: NU, regels: REGELS });
  basis.setJSON = origSet;
  assert.equal(r.aantallen.journalenGeleverd, 1);
  assert.equal(r.aantallen.journalenMislukt, 0);
  assert.equal((await leesTijdlijn(R1)).filter((l) => l.wijzigingId === "w-plaats").length, 1);
  assert.equal((await basis.list({ prefix: "logwacht/" })).blobs.length, 0);
  assert.equal((await hartslag()).aantallen.journalenGeleverd, 1);
});

test("één stap faalt: de andere stappen draaien, de fout staat in de hartslag, ok false", async () => {
  await zaai();
  const origList = basis.list;
  basis.list = async (o) => { if (o?.prefix === "logwacht/") throw new Error("Jansma belde 0612345678"); return origList.call(basis, o); };
  const r = await voerDagelijksUit({ nu: NU, regels: REGELS });
  basis.list = origList;
  assert.equal(r.ok, false);
  assert.deepEqual(r.fouten, [{ stap: "journalen", soort: "Error" }]);
  assert.equal(r.aantallen.trajecten, 1); // termijnen draaide gewoon
  assert.equal(r.aantallen.indexRijen, 1);
  const h = await hartslag();
  assert.equal(h.ok, false);
  assert.ok(!JSON.stringify(h).includes("Jansma")); // de foutmelding zelf komt niet in de hartslag
  assert.ok(!JSON.stringify(h).includes("0612"));
});

test("elke stap kan falen zonder de rest te stoppen; hartslag wordt altijd geschreven", async () => {
  await zaai();
  const origList = basis.list;
  basis.list = async () => { throw new TypeError("kapot"); }; // journalen, register, index en instroomClaims gebruiken list
  const r = await voerDagelijksUit({ nu: NU, regels: REGELS });
  basis.list = origList;
  assert.deepEqual(r.fouten.map((f) => f.stap), ["journalen", "register", "index", "instroomClaims"]);
  assert.ok(r.fouten.every((f) => f.soort === "TypeError"));
  assert.equal(r.aantallen.fataalItems, 4); // termijnen is niet afhankelijk van list (T9)
  assert.equal((await hartslag()).ok, false);
});

test("fout in de termijnberekening zelf: genoteerd, andere stappen gedaan", async () => {
  await zaai();
  const r = await voerDagelijksUit({ nu: NU, regels: REGELS, opties: { bereken: () => { throw new RangeError("x"); } } });
  // maakFataalBlok vangt een engine-fout per record op (T18): het blok bevat 'kon niet berekenen', geen stapfout
  assert.equal(r.ok, true);
  assert.equal(r.aantallen.konNietBerekenen, 2); // traject en relatie
  assert.equal(r.aantallen.indexRijen, 1);
});

test("registerafwijking wordt gemeld met ids en hersteld; onvolledig en onleesbaar in de hartslag", async () => {
  await zaai();
  const reg = await basis.get("register/trajecten", { type: "json" });
  await basis.setJSON("register/trajecten", { ids: { ...reg.ids, t_weg: { relatieId: R1, aangemaakt: "2026-11-09T00:00:00.000Z" } } });
  const r = await voerDagelijksUit({ nu: NU, regels: REGELS });
  assert.equal(r.aantallen.onvolledig, 1);
  assert.deepEqual(r.details.onvolledig, [{ id: "t_weg", relatieId: R1 }]);
  assert.deepEqual(r.details.register, [{ id: "t_weg", relatieId: R1, soort: "record-ontbreekt-in-list" }]);
  // ontbrekend in het register: wordt bijgezet
  await basis.setJSON("register/trajecten", { ids: {} });
  const r2 = await voerDagelijksUit({ nu: NU, regels: REGELS });
  assert.deepEqual(r2.details.register.map((a) => [a.id, a.soort, a.hersteld]), [[T1, "ontbrak-in-register", true]]);
  assert.equal(r2.aantallen.trajecten, 1);
});

test("herbouwt de index als die ontbreekt", async () => {
  await zaai();
  await basis.delete("index/relaties");
  const r = await voerDagelijksUit({ nu: NU, regels: REGELS });
  assert.equal(r.aantallen.indexRijen, 1);
  assert.deepEqual(r.details.index, [{ id: R1, soort: "ontbrak-in-index" }]);
  assert.ok((await basis.get("index/relaties", { type: "json" })).rijen[R1]);
});

test("handler: 500 bij echte data zonder deploy-context, geen hartslag; met context 200 en hartslag", async () => {
  process.env.DASHBOARD_ECHTE_DATA = "aan";
  const orig = console.error;
  console.error = () => {};
  try {
    const res = await handler(new Request("https://x.test/"), {});
    assert.equal(res.status, 500);
  } finally { console.error = orig; }
  assert.equal(await hartslag(), null);
  delete process.env.DASHBOARD_ECHTE_DATA;
  const ok = await handler(new Request("https://x.test/"), { deploy: { context: "deploy-preview" } });
  assert.equal(ok.status, 200);
  assert.ok(await hartslag());
});

test("handler: hartslag kan niet geschreven worden: 500", async () => {
  const origSet = basis.setJSON;
  basis.setJSON = async (k, ...r) => { if (k === "status/dagelijks") throw new Error("nee"); return origSet.call(basis, k, ...r); };
  const orig = console.error;
  console.error = () => {};
  try {
    const res = await handler(new Request("https://x.test/"), { deploy: { context: "deploy-preview" } });
    assert.equal(res.status, 500);
  } finally { console.error = orig; basis.setJSON = origSet; }
});

test("vals alarm: registeritem jonger dan 10 minuten dat list nog niet kent geeft geen afwijking; ouder wel", async () => {
  await zaai();
  const reg = await basis.get("register/trajecten", { type: "json" });
  const min = (n) => new Date(NU.getTime() - n * 60000).toISOString();
  await basis.setJSON("register/trajecten", { ids: { ...reg.ids, t_jong: { relatieId: R1, aangemaakt: min(5) }, t_oud: { relatieId: R1, aangemaakt: min(20) } } });
  const r = await voerDagelijksUit({ nu: NU, regels: REGELS });
  assert.deepEqual(r.details.register.map((a) => a.id), ["t_oud"]);
  assert.equal(r.aantallen.registerAfwijkingen, 1);
  assert.equal(r.aantallen.registerJong, 1);
});

test("afgekapt: meer dan 200 ids in een lijst zet afgekapt:true; anders false; handmatig standaard false", async () => {
  await zaai();
  const r0 = await voerDagelijksUit({ nu: NU, regels: REGELS });
  assert.equal(r0.afgekapt, false);
  assert.equal(r0.handmatig, false);
  const reg = await basis.get("register/trajecten", { type: "json" });
  const extra = {};
  for (let i = 0; i < 250; i++) extra[`t_w${i}`] = { relatieId: R1, aangemaakt: "2026-11-01T00:00:00.000Z" };
  await basis.setJSON("register/trajecten", { ids: { ...reg.ids, ...extra } });
  const r = await voerDagelijksUit({ nu: NU, regels: REGELS, handmatig: true });
  assert.equal(r.afgekapt, true);
  assert.equal(r.handmatig, true);
  assert.equal(r.details.register.length, 200);
  assert.equal(r.aantallen.registerAfwijkingen, 250); // het aantal blijft volledig
  assert.equal((await hartslag()).afgekapt, true);
});

// Tests voor dashboard-klanten.mjs (K4). Alleen fictieve data; handler aangeroepen met Request-objecten.
import { test, beforeEach, afterEach } from "node:test";
import assert from "node:assert/strict";
import { zetStoreFabriek } from "../../opslag.mjs";
import { geheugenStore } from "../../test-hulp.mjs";
import { maakWachtwoordHash, maakToken } from "../../sessie.mjs";
import { testCatalogus } from "../test-regels.mjs";
import standaard, { maakHandler, config } from "../../../dashboard-klanten.mjs";

const NU = new Date("2026-11-10T10:00:00.000Z");
const CTX = { deploy: { context: "deploy-preview" } };
const BASIS = "https://x.test/api/dashboard/klanten";
// Echte catalogus, traject in Besluit: zienswijze (datum ontbreekt), de samengevatte besluitregels en bezwaar (niet bevestigd).
const EXACT_ECHT = 3;
const R1 = "r_aaa1";
const R2 = "r_bbb2";
const T1 = "t_aaa1";

let gebruikers;
let tik;
let basis; let haken; let kevin; let ruben; let h; let hStandaard;
const REGELS = testCatalogus();

function wrap(b) {
  // Delegeert dynamisch, zodat een test basis.get of basis.list kan vervangen (nep-list, mislukte read).
  return {
    get: (...a) => b.get(...a),
    getWithMetadata: (...a) => b.getWithMetadata(...a),
    set: (...a) => b.set(...a),
    delete: (...a) => b.delete(...a),
    list: (...a) => b.list(...a),
    async setJSON(k, v, opt) {
      for (const hk of haken.voorSet) { const uit = await hk(k, v, opt); if (uit !== undefined) return uit; }
      return b.setJSON(k, v, opt);
    },
  };
}

beforeEach(async () => {
  gebruikers ??= JSON.stringify({ Kevin: await maakWachtwoordHash("verzonnen-a", 1000), Ruben: await maakWachtwoordHash("verzonnen-b", 1000) });
  process.env.DASHBOARD_GEBRUIKERS = gebruikers;
  basis = geheugenStore();
  haken = { voorSet: [] };
  tik = 0;
  // Testklok: één tik (een seconde) per verzoek. De handler legt `nu` één keer per verzoek vast, dus elk verzoek
  // heeft een eigen tijdstip, zoals in productie.
  const klok = () => new Date(NU.getTime() + 1000 * tik++);
  const w = wrap(basis);
  zetStoreFabriek(() => w);
  process.env.DASHBOARD_SESSIE_GEHEIM = "z".repeat(40);
  delete process.env.DASHBOARD_SESSIE_VERSIE;
  delete process.env.DASHBOARD_ECHTE_DATA;
  kevin = `dashboard_sessie=${maakToken("Kevin")}`;
  ruben = `dashboard_sessie=${maakToken("Ruben")}`;
  h = maakHandler({ regels: REGELS, nu: klok });
  hStandaard = maakHandler({ nu: klok }); // echte catalogus: niets bevestigd
});
afterEach(() => { delete process.env.DASHBOARD_ECHTE_DATA; });

async function vraag(method, pad, body, { c = kevin, headers = {}, handler = h, context = CTX, ruw } = {}) {
  const res = await handler(new Request(`${BASIS}${pad}`, {
    method,
    headers: { ...(body !== undefined || ruw !== undefined ? { "content-type": "application/json" } : {}), ...(c ? { cookie: c } : {}), ...headers },
    body: ruw !== undefined ? ruw : body !== undefined ? JSON.stringify(body) : undefined,
  }), context);
  const tekst = await res.text();
  let data = null;
  try { data = JSON.parse(tekst); } catch { /* geen json */ }
  return { status: res.status, data, headers: res.headers };
}

const relatieVelden = (extra = {}) => ({ achternaam: "Test", status: "Nieuw", straat: "Teststraat", huisnummer: "1", plaats: "Plaats", postcode: "9999 ZZ", ...extra });
const maakR = (id = R1, extra = {}, wid = `w-${id}`, opties) => vraag("POST", "/relaties", { id, wijzigingId: wid, velden: relatieVelden(extra) }, opties);
const maakT = (rid = R1, id = T1, velden = { fase: "Aanvraag ingediend" }, wid = `w-${id}`) => vraag("POST", `/relaties/${rid}/trajecten`, { id, wijzigingId: wid, velden });
const patchT = (id, velden, wid, opties) => vraag("PATCH", `/trajecten/${id}`, { wijzigingId: wid, velden }, opties);
// Traject in fase Besluit met besluitbrief 2026-11-02: fatale termijnen open.
async function trajectInBesluit(handler = h) {
  await maakR(R1, {}, "w-r1", { handler });
  await maakT();
  const r = await patchT(T1, {
    verzenddatumBesluitbrief: { oud: null, nieuw: "2026-11-02" },
    fase: { oud: "Aanvraag ingediend", nieuw: "Besluit" },
  }, "w-besluit", { handler });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  assert.deepEqual(r.data.toegepast.sort(), ["fase", "verzenddatumBesluitbrief"]);
}

// ---------- toegang en algemeen ----------
test("401 zonder cookie, op elke route en methode, ook onbekende", async () => {
  const routes = [
    ["GET", "/regels"], ["GET", "/relaties"], ["POST", "/relaties"], ["GET", `/relaties/${R1}`], ["PATCH", `/relaties/${R1}`],
    ["GET", `/relaties/${R1}/tijdlijn`], ["POST", `/relaties/${R1}/trajecten`], ["PATCH", `/trajecten/${T1}`],
    ["POST", `/trajecten/${T1}/termijnen/deal-bezwaar/afvinken`], ["POST", `/trajecten/${T1}/termijnen/deal-bezwaar/heropenen`],
    ["GET", "/onbekend"], ["GET", "/start"], ["DELETE", "/relaties"],
  ];
  for (const [m, p] of routes) {
    const r = await vraag(m, p, m === "GET" || m === "DELETE" ? undefined : {}, { c: null });
    assert.equal(r.status, 401, `${m} ${p}`);
    assert.equal(r.headers.get("x-robots-tag"), "noindex, nofollow");
    assert.equal(r.headers.get("cache-control"), "no-store");
  }
  const slecht = await vraag("GET", "/relaties", undefined, { c: "dashboard_sessie=onzin" });
  assert.equal(slecht.status, 401);
});

test("config.path en standaard-export", () => {
  assert.equal(config.path, "/api/dashboard/klanten/*");
  assert.equal(typeof standaard, "function");
});

test("echte data aan zonder deploy-context: 500, geen persoonsgegevens in de log", async () => {
  process.env.DASHBOARD_ECHTE_DATA = "aan";
  const log = [];
  const orig = console.error;
  console.error = (...a) => log.push(a.join(" "));
  try {
    const r = await vraag("GET", "/relaties", undefined, { context: {} });
    assert.equal(r.status, 500);
  } finally { console.error = orig; }
  assert.ok(!log.join(" ").includes("Test"));
});

test("onbekende routes: 404; verkeerde methode: 405 met Allow; kapotte id's: 404; later-routes: 404", async () => {
  for (const p of ["", "/onzin", "/relaties/onzin", "/relaties/r_%2e%2e", `/relaties/${R1}/onzin`, "/trajecten", "/trajecten/r_aaa1",
    `/trajecten/${T1}/termijnen/BOVEN/afvinken`, `/trajecten/${T1}/termijnen/x/onbekend`, "/export", "/import", `/relaties/${R1}/verwijderen`]) {
    const r = await vraag("GET", p);
    assert.equal(r.status, 404, p);
  }
  const m1 = await vraag("DELETE", "/relaties");
  assert.equal(m1.status, 405);
  assert.equal(m1.headers.get("allow"), "GET, POST");
  assert.equal((await vraag("POST", "/regels", {})).status, 405);
  assert.equal((await vraag("GET", `/trajecten/${T1}`)).status, 405);
  assert.equal((await vraag("PUT", `/relaties/${R1}`, {})).status, 405);
  assert.equal((await vraag("GET", `/trajecten/${T1}/termijnen/deal-bezwaar/afvinken`)).status, 405);
});

// ---------- invoer ----------
test("body: geen json, array, verkeerd content-type, andere herkomst, te groot, onbekende sleutel", async () => {
  assert.equal((await vraag("POST", "/relaties", undefined, { ruw: "{kapot" })).status, 422);
  assert.equal((await vraag("POST", "/relaties", undefined, { ruw: "[]" })).status, 422);
  assert.equal((await vraag("POST", "/relaties", undefined, { ruw: "" })).status, 422);
  const ct = await h(new Request(`${BASIS}/relaties`, { method: "POST", headers: { cookie: kevin, "content-type": "text/plain" }, body: "{}" }), CTX);
  assert.equal(ct.status, 415);
  const site = await vraag("POST", "/relaties", {}, { headers: { "sec-fetch-site": "cross-site" } });
  assert.equal(site.status, 403);
  // lengte via header
  const groot = await vraag("POST", "/relaties", undefined, { ruw: JSON.stringify({ id: R1, wijzigingId: "w", velden: { notitie: "x".repeat(70 * 1024) } }), headers: { "content-length": String(70 * 1024 + 60) } });
  assert.equal(groot.status, 413);
  // zonder content-length-kop, wel te groot
  const groot2 = await vraag("POST", "/relaties", undefined, { ruw: JSON.stringify({ id: R1, wijzigingId: "w", velden: { notitie: "x".repeat(70 * 1024) } }) });
  assert.equal(groot2.status, 413);
  assert.equal(groot2.headers.get("content-length"), null);
  assert.equal(await basis.get(`relatie/${R1}`), null);
  const extra = await vraag("POST", "/relaties", { id: R1, wijzigingId: "w", velden: relatieVelden(), wie: "ruben" });
  assert.equal(extra.status, 422);
  assert.equal(extra.data.fouten.wie, "onbekend-veld");
  assert.equal(await basis.get(`relatie/${R1}`), null);
});

test("wie komt uit de sessie, nooit uit de body; nu van de server", async () => {
  const r = await maakR(R1, {}, "w1", { c: ruben });
  assert.equal(r.status, 201);
  assert.equal(r.data.record.aangemaakt.wie, "Ruben");
  assert.match(r.data.record.aangemaakt.op, /^2026-11-10T10:00:0\d\.000Z$/); // server-klok, niet uit de body
  const p = await vraag("PATCH", `/relaties/${R1}`, { wijzigingId: "w2", velden: { plaats: { oud: "Plaats", nieuw: "Drachten" } }, nu: "2000-01-01" });
  assert.equal(p.status, 422);
  const ok = await vraag("PATCH", `/relaties/${R1}`, { wijzigingId: "w2", velden: { plaats: { oud: "Plaats", nieuw: "Drachten" } } }, { c: kevin });
  assert.equal(ok.data.record.gewijzigd.wie, "Kevin");
  assert.match(ok.data.record.gewijzigd.op, /^2026-11-10T10:00:0\d\.000Z$/);
});

// ---------- relaties ----------
test("POST /relaties: 201, herhaling zelfde wijzigingId 200, ander wijzigingId 409, ongeldig 422, te veel velden 422", async () => {
  const a = await maakR(R1, {}, "w1");
  assert.equal(a.status, 201);
  assert.equal(a.data.bestaatAl, false);
  assert.match(a.data.etag, /^"[0-9a-f]{24}"$/);
  const nog = await maakR(R1, {}, "w1");
  assert.equal(nog.status, 200);
  assert.equal(nog.data.bestaatAl, true);
  assert.equal((await vraag("GET", `/relaties/${R1}/tijdlijn`)).data.regels.length, 1);
  assert.equal((await maakR(R1, {}, "w9")).status, 409);
  const slecht = await vraag("POST", "/relaties", { id: R2, wijzigingId: "w3", velden: { status: "Nieuw" } });
  assert.equal(slecht.status, 422);
  assert.equal(slecht.data.fouten.achternaam, "verplicht");
  assert.equal((await vraag("POST", "/relaties", { id: "geen-id", wijzigingId: "w3", velden: relatieVelden() })).status, 422);
  assert.equal((await vraag("POST", "/relaties", { id: R2, wijzigingId: "w3" })).status, 422);
  const veel = Object.fromEntries(Array.from({ length: 101 }, (_, i) => [`veld${i}`, "x"]));
  const te = await vraag("PATCH", `/relaties/${R1}`, { wijzigingId: "w4", velden: Object.fromEntries(Object.keys(veel).map((k) => [k, { oud: null, nieuw: "x" }])) });
  assert.equal(te.status, 422);
  assert.equal(te.data.fouten.velden, "te-veel");
  // herkomst: alleen bekende sleutels
  const hk = await vraag("POST", "/relaties", { id: R2, wijzigingId: "w5", velden: relatieVelden(), herkomst: { onzin: 1 } });
  assert.equal(hk.status, 422);
  const hk2 = await vraag("POST", "/relaties", { id: R2, wijzigingId: "w5", velden: relatieVelden(), herkomst: { deur: { eventId: "abcdefgh1" } } });
  assert.equal(hk2.status, 201);
  assert.deepEqual(hk2.data.record.herkomst, { deur: { eventId: "abcdefgh1" } });
  for (const lang of [{ deur: { eventId: "x".repeat(101) } }, { website: "x".repeat(101) }, { zoho: { id: 5 } }, { deur: ["a"] }, { zoho: { a: { b: "c" } } }]) {
    assert.equal((await vraag("POST", "/relaties", { id: "r_hk3", wijzigingId: "w6", velden: relatieVelden(), herkomst: lang })).status, 422, JSON.stringify(lang).slice(0, 30));
  }
});

test("GET /relaties: lijst uit index, filters, zoeken, ongeldige filter 422", async () => {
  await maakR(R1, { achternaam: "Jansma", eigenaar: "kevin", straat: "Dorpsweg", huisnummer: "3", postcode: "9201 AB", plaats: "Drachten" }, "w1");
  await maakR(R2, { achternaam: "Bakker", eigenaar: "ruben", status: "Poging 1", straat: "Kerkpad", huisnummer: "7", postcode: "9301 CD", plaats: "Roden" }, "w2");
  const alles = await vraag("GET", "/relaties");
  assert.equal(alles.status, 200);
  assert.equal(alles.data.totaal, 2);
  assert.equal(alles.data.relaties.length, 2);
  assert.equal((await vraag("GET", "/relaties?eigenaar=ruben")).data.relaties[0].id, R2);
  assert.equal((await vraag("GET", "/relaties?status=Nieuw")).data.relaties[0].id, R1);
  assert.equal((await vraag("GET", "/relaties?q=jansma")).data.totaal, 1);
  assert.equal((await vraag("GET", "/relaties?q=9301cd")).data.relaties[0].id, R2);
  assert.equal((await vraag("GET", "/relaties?q=9301%20CD")).data.relaties[0].id, R2);
  assert.equal((await vraag("GET", "/relaties?q=dorpsweg+drachten")).data.relaties[0].id, R1);
  assert.equal((await vraag("GET", "/relaties?q=niemand")).data.totaal, 0);
  assert.equal((await vraag("GET", "/relaties?status=Onzin")).status, 422);
  assert.equal((await vraag("GET", "/relaties?eigenaar=piet")).status, 422);
  assert.equal((await vraag("GET", `/relaties?q=${"x".repeat(101)}`)).status, 422);
});

test("GET /relaties/:id: relatie, trajecten met termijnen en etag; 404", async () => {
  await maakR(R1, {}, "w1");
  await trajectInBesluit();
  const r = await vraag("GET", `/relaties/${R1}`);
  assert.equal(r.status, 200);
  assert.equal(r.data.relatie.id, R1);
  assert.equal(r.data.relatie.status, "Klant"); // eerste traject maakt de relatie Klant
  assert.match(r.data.etag, /^"[0-9a-f]{24}"$/);
  assert.equal(r.data.trajecten.length, 1);
  const t = r.data.trajecten[0];
  assert.equal(t.record.id, T1);
  assert.match(t.etag, /^"[0-9a-f]{24}"$/);
  const bezwaar = t.termijnen.find((x) => x.regelId === "deal-bezwaar");
  assert.equal(bezwaar.status, "open");
  assert.equal(bezwaar.einddatum, "2026-11-23"); // 2 nov + 3 weken (fictief), dag-na-start
  assert.deepEqual(r.data.onvolledig, []);
  // zelfde inhoud, zelfde etag; andere inhoud, andere etag
  assert.equal((await vraag("GET", `/relaties/${R1}`)).data.etag, r.data.etag);
  await vraag("PATCH", `/relaties/${R1}`, { wijzigingId: "w2", velden: { plaats: { oud: "Plaats", nieuw: "Drachten" } } });
  assert.notEqual((await vraag("GET", `/relaties/${R1}`)).data.etag, r.data.etag);
  assert.equal((await vraag("GET", `/relaties/${R2}`)).status, 404);
});

test("GET /relaties/:id: traject in register zonder record wordt gemeld als onvolledig", async () => {
  await maakR(R1, {}, "w1");
  await maakT();
  const reg = async (ids) => basis.setJSON("register/trajecten", { ids: { ...(await basis.get("register/trajecten", { type: "json" })).ids, ...ids } });
  // jonger dan 10 minuten (nog bezig): niet gemeld; ouder: gemeld, in dezelfde vorm als leesAlleTrajecten
  await reg({ t_jong: { relatieId: R1, aangemaakt: "2026-11-10T09:55:00.000Z" }, t_weg: { relatieId: R1, aangemaakt: "2026-11-10T09:00:00.000Z" } });
  const r = await vraag("GET", `/relaties/${R1}`);
  assert.equal(r.status, 200);
  assert.deepEqual(r.data.onvolledig, [{ id: "t_weg", relatieId: R1, aangemaakt: "2026-11-10T09:00:00.000Z" }]);
  assert.equal(r.data.trajecten.length, 1);
});

test("PATCH /relaties/:id: toegepast, conflict in 200, idempotent, 404, 422", async () => {
  await maakR(R1, {}, "w1");
  const a = await vraag("PATCH", `/relaties/${R1}`, { wijzigingId: "wa", velden: { telefoon: { oud: null, nieuw: "0512 123456" } } });
  assert.equal(a.status, 200);
  assert.deepEqual(a.data.toegepast, ["telefoon"]);
  assert.deepEqual(a.data.conflicten, []);
  assert.equal(a.data.record.telefoon, "0512 123456");
  // zelfde veld, oude oud-waarde: conflict, wel 200 en niets overschreven
  const c = await vraag("PATCH", `/relaties/${R1}`, { wijzigingId: "wb", velden: { telefoon: { oud: null, nieuw: "0600000000" } } }, { c: ruben });
  assert.equal(c.status, 200);
  assert.deepEqual(c.data.toegepast, []);
  assert.equal(c.data.conflicten.length, 1);
  assert.equal(c.data.conflicten[0].veld, "telefoon");
  assert.equal(c.data.conflicten[0].huidig, "0512 123456");
  assert.equal(c.data.record.telefoon, "0512 123456");
  // idempotent
  const dubbel = await vraag("PATCH", `/relaties/${R1}`, { wijzigingId: "wa", velden: { telefoon: { oud: null, nieuw: "0512 123456" } } });
  assert.equal(dubbel.status, 200);
  assert.equal(dubbel.data.noop, true);
  assert.deepEqual(dubbel.data.toegepast, []);
  assert.equal((await vraag("GET", `/relaties/${R1}/tijdlijn`)).data.regels.filter((l) => l.soort === "wijziging").length, 1);
  assert.equal((await vraag("PATCH", `/relaties/${R2}`, { wijzigingId: "wc", velden: { plaats: { oud: null, nieuw: "x" } } })).status, 404);
  const slecht = await vraag("PATCH", `/relaties/${R1}`, { wijzigingId: "wd", velden: { onzin: { oud: null, nieuw: "x" } } });
  assert.equal(slecht.status, 422);
  assert.equal(slecht.data.fouten.onzin, "onbekend-veld");
  assert.equal((await vraag("PATCH", `/relaties/${R1}`, { wijzigingId: "we", velden: {} })).status, 422);
  assert.equal((await vraag("PATCH", `/relaties/${R1}`, { velden: { plaats: { oud: "Plaats", nieuw: "x" } } })).status, 422);
});

test("gevaarlijke veldnamen worden elk los geweigerd: __proto__, constructor, hasOwnProperty", async () => {
  await maakR(R1, {}, "w1");
  for (const naam of ["__proto__", "constructor", "hasOwnProperty"]) {
    const ruw = `{"wijzigingId":"wp-${naam.length}","velden":{"${naam}":{"oud":null,"nieuw":1}}}`;
    const r = await vraag("PATCH", `/relaties/${R1}`, undefined, { ruw });
    assert.equal(r.status, 422, naam);
    assert.ok(r.data.fouten[naam] || r.data.fouten._, naam);
    // ook als taakveld en op traject
    const t = await vraag("PATCH", `/trajecten/${T1}`, undefined, { ruw });
    assert.ok([404, 422].includes(t.status), naam);
  }
  const body = await vraag("POST", "/relaties", undefined, { ruw: '{"id":"r_zzz","wijzigingId":"wq","velden":{"achternaam":"T","status":"Nieuw"},"__proto__":{"x":1}}' });
  assert.equal(body.status, 422);
  assert.equal(await basis.get("relatie/r_zzz"), null);
  assert.equal({}.x, undefined);
});

test("GET /relaties/:id/tijdlijn: nieuwste eerst; 404", async () => {
  await maakR(R1, {}, "w1");
  await vraag("PATCH", `/relaties/${R1}`, { wijzigingId: "w2", velden: { plaats: { oud: "Plaats", nieuw: "Drachten" } } });
  const t = await vraag("GET", `/relaties/${R1}/tijdlijn`);
  assert.equal(t.status, 200);
  assert.equal(t.data.regels.length, 2);
  assert.equal((await vraag("GET", `/relaties/${R2}/tijdlijn`)).status, 404);
});

// ---------- trajecten ----------
test("POST /relaties/:id/trajecten: 201, Klant, herhaling 200, bestaat-al 409, onbekende relatie 404, ongeldig 422", async () => {
  await maakR(R1, {}, "w1");
  const a = await maakT();
  assert.equal(a.status, 201);
  assert.equal(a.data.record.relatieId, R1);
  assert.equal((await vraag("GET", `/relaties/${R1}`)).data.relatie.status, "Klant");
  const nog = await maakT();
  assert.equal(nog.status, 200);
  assert.equal(nog.data.bestaatAl, true);
  assert.equal((await maakT(R1, T1, { fase: "Aanvraag ingediend" }, "w-andere")).status, 409);
  assert.equal((await maakT(R2, "t_zzz")).status, 404);
  assert.equal((await maakT(R1, "t_nieuw", { fase: "Onzin" })).status, 422);
  assert.equal((await maakT(R1, "x_fout")).status, 422);
  assert.equal((await maakT("onzin", "t_q")).status, 404);
});

test("T5: fase Bezwaar zonder datum via API: 422, tenzij verzenddatum expliciet onbekend", async () => {
  await maakR(R1, {}, "w1");
  // aanmaken
  const aan = await maakT(R1, "t_directbezwaar", { fase: "Bezwaar" });
  assert.equal(aan.status, 422);
  assert.ok(aan.data.fouten.verzenddatumBesluitbrief);
  // wijzigen
  await maakT();
  const wissel = await patchT(T1, { fase: { oud: "Aanvraag ingediend", nieuw: "Bezwaar" } }, "w-bz");
  assert.equal(wissel.status, 422);
  assert.equal(wissel.data.fouten.verzenddatumBesluitbrief, "verplicht-vanaf-besluit");
  assert.equal((await vraag("GET", `/relaties/${R1}`)).data.trajecten[0].record.fase, "Aanvraag ingediend");
  // datum later weghalen terwijl de fase al vanaf Besluit is: ook 422
  await patchT(T1, { verzenddatumBesluitbrief: { oud: null, nieuw: "2026-11-02" }, fase: { oud: "Aanvraag ingediend", nieuw: "Besluit" } }, "w-ok");
  const weg = await patchT(T1, { verzenddatumBesluitbrief: { oud: "2026-11-02", nieuw: null } }, "w-weg");
  assert.equal(weg.status, 422);
  // expliciet onbekend: toegestaan (T4: de engine geeft dan datum-ontbreekt)
  const onbekend = await patchT(T1, { verzenddatumOnbekend: { oud: null, nieuw: true }, verzenddatumBesluitbrief: { oud: "2026-11-02", nieuw: null } }, "w-onb");
  assert.equal(onbekend.status, 200, JSON.stringify(onbekend.data));
  const termijnen = (await vraag("GET", `/relaties/${R1}`)).data.trajecten[0].termijnen;
  assert.equal(termijnen.find((t) => t.regelId === "deal-bezwaar").status, "datum-ontbreekt");
});

test("T15: sluiten met open fatale termijn: 409 met de blokkerende regels; na afvinken lukt het (volledige testcatalogus)", async () => {
  await trajectInBesluit(h);
  const r = await patchT(T1, { fase: { oud: "Besluit", nieuw: "Afgerond" } }, "w-af");
  assert.equal(r.status, 409);
  assert.equal(r.data.code, "open-fatale-termijn");
  // alleen deal-bezwaar (fataal true, afvinkbaar); fataal:null en datum-ontbreekt houden niets tegen
  assert.deepEqual(r.data.termijnen.map((t) => t.regelId), ["deal-bezwaar"]);
  assert.equal(r.data.termijnen[0].status, "open");
  assert.equal(r.data.termijnen[0].dagenOver, 13);
  // niets geschreven: fase en logregels ongewijzigd
  assert.equal((await vraag("GET", `/relaties/${R1}`)).data.trajecten[0].record.fase, "Besluit");
  assert.ok(!(await vraag("GET", `/relaties/${R1}/tijdlijn`)).data.regels.some((l) => l.wijzigingId === "w-af"));
  assert.equal((await patchT(T1, { fase: { oud: "Besluit", nieuw: "Verloren" } }, "w-vl")).status, 409);
  const vink = await vraag("POST", `/trajecten/${T1}/termijnen/deal-bezwaar/afvinken`, { wijzigingId: "w-vink", actie: "Bezwaar ingediend" });
  assert.equal(vink.status, 200);
  const nu = await patchT(T1, { fase: { oud: "Besluit", nieuw: "Afgerond" } }, "w-af3");
  assert.equal(nu.status, 200, JSON.stringify(nu.data));
  assert.equal(nu.data.record.fase, "Afgerond");
});

test("T15: herbevestigen (brondatum gewijzigd na afvinken) blokkeert het sluiten weer", async () => {
  await trajectInBesluit(h);
  await vraag("POST", `/trajecten/${T1}/termijnen/deal-bezwaar/afvinken`, { wijzigingId: "w-vink", actie: "Bezwaar ingediend" });
  await patchT(T1, { verzenddatumBesluitbrief: { oud: "2026-11-02", nieuw: "2026-11-03" } }, "w-datum");
  const r = await patchT(T1, { fase: { oud: "Besluit", nieuw: "Afgerond" } }, "w-af");
  assert.equal(r.status, 409);
  assert.equal(r.data.termijnen[0].status, "herbevestigen");
});

test("sluiten blokkeert niet bij datum-ontbreekt, fataal:null of niet-bevestigde regels", async () => {
  // datum-ontbreekt (verzenddatum expliciet onbekend): geen uitweg, dus geen blokkade
  await maakR(R1, {}, "w1");
  await maakT();
  await patchT(T1, { verzenddatumOnbekend: { oud: null, nieuw: true }, fase: { oud: "Aanvraag ingediend", nieuw: "Besluit" } }, "w-o");
  const t = (await vraag("GET", `/relaties/${R1}`)).data.trajecten[0].termijnen;
  assert.equal(t.find((x) => x.regelId === "deal-bezwaar").status, "datum-ontbreekt");
  assert.equal((await patchT(T1, { fase: { oud: "Besluit", nieuw: "Afgerond" } }, "w-af")).status, 200);
  // niet-bevestigde regels (echte catalogus)
  await maakR(R2, {}, "w2", { handler: hStandaard });
  await maakT(R2, "t_bbb2", undefined, "w-t2");
  await patchT("t_bbb2", { verzenddatumBesluitbrief: { oud: null, nieuw: "2026-11-02" }, fase: { oud: "Aanvraag ingediend", nieuw: "Besluit" } }, "w-b", { handler: hStandaard });
  const nb = (await vraag("GET", `/relaties/${R2}`, undefined, { handler: hStandaard })).data.trajecten[0].termijnen;
  assert.equal(nb.find((x) => x.regelId === "deal-bezwaar").status, "niet-bevestigd");
  assert.equal((await patchT("t_bbb2", { fase: { oud: "Besluit", nieuw: "Verloren" } }, "w-v", { handler: hStandaard })).status, 200);
});

test("T15-race: de termijn wordt tijdens de schrijfpoging heropend: de nieuwe poging geeft 409", async () => {
  await trajectInBesluit(h);
  await vraag("POST", `/trajecten/${T1}/termijnen/deal-bezwaar/afvinken`, { wijzigingId: "w-vink", actie: "Bezwaar ingediend" });
  let eenmaal = true;
  haken.voorSet.push(async (k, v, opt) => {
    if (eenmaal && k === `traject/${T1}` && opt?.onlyIfMatch) {
      eenmaal = false; // de controle is al geslaagd; nu heropent de ander de termijn
      const he = await vraag("POST", `/trajecten/${T1}/termijnen/deal-bezwaar/heropenen`, { wijzigingId: "w-he" });
      assert.equal(he.status, 200);
    }
  });
  const r = await patchT(T1, { fase: { oud: "Besluit", nieuw: "Afgerond" } }, "w-af");
  assert.equal(eenmaal, false);
  assert.equal(r.status, 409);
  assert.equal(r.data.termijnen[0].regelId, "deal-bezwaar");
  assert.equal((await vraag("GET", `/relaties/${R1}`)).data.trajecten[0].record.fase, "Besluit");
});

test("T15 bij aanmaken: traject direct in Afgerond of Verloren: 422 niet-bij-aanmaken", async () => {
  await maakR(R1, {}, "w1");
  for (const fase of ["Afgerond", "Verloren"]) {
    const r = await maakT(R1, "t_gesloten", { fase }, `w-${fase}`);
    assert.equal(r.status, 422);
    assert.equal(r.data.fouten.fase, "niet-bij-aanmaken");
  }
  assert.equal(await basis.get("traject/t_gesloten"), null);
  assert.equal(await basis.get("register/trajecten"), null);
});

test("T15b: sluiten zonder fatale termijn mag; een niet-sluitende wijziging op een open fatale termijn ook", async () => {
  await maakR(R1, {}, "w1");
  await maakT();
  const v = await patchT(T1, { fase: { oud: "Aanvraag ingediend", nieuw: "Verloren" }, redenVerlies: { oud: null, nieuw: "Klant haakt af" } }, "w-v");
  assert.equal(v.status, 200, JSON.stringify(v.data));
  assert.equal(v.data.record.fase, "Verloren");
  // fatale termijn open, maar de fase blijft Besluit: gewoon wijzigen
  await maakR(R2, {}, "w2");
  await maakT(R2, "t_bbb2");
  await patchT("t_bbb2", { verzenddatumBesluitbrief: { oud: null, nieuw: "2026-11-02" }, fase: { oud: "Aanvraag ingediend", nieuw: "Besluit" } }, "w-b");
  const k = await patchT("t_bbb2", { route: { oud: null, nieuw: "Maatwerk met onderzoek" } }, "w-route");
  assert.equal(k.status, 200, JSON.stringify(k.data));
});

test("PATCH /trajecten/:id: 404, ongeldig, conflict in 200, idempotent", async () => {
  await maakR(R1, {}, "w1");
  await maakT();
  assert.equal((await patchT("t_onbekend", { fase: { oud: "a", nieuw: "Besluit" } }, "w")).status, 404);
  assert.equal((await patchT("onzin", { fase: { oud: "a", nieuw: "Besluit" } }, "w")).status, 404);
  const rel = await patchT(T1, { relatieId: { oud: R1, nieuw: R2 } }, "w-rel");
  assert.equal(rel.status, 422);
  const a = await patchT(T1, { aanvraagdatum: { oud: null, nieuw: "2026-10-01" } }, "w-a");
  assert.deepEqual(a.data.toegepast, ["aanvraagdatum"]);
  const c = await patchT(T1, { aanvraagdatum: { oud: null, nieuw: "2026-10-05" } }, "w-b", { c: ruben });
  assert.equal(c.status, 200);
  assert.equal(c.data.conflicten.length, 1);
  assert.equal(c.data.record.aanvraagdatum, "2026-10-01");
  const dubbel = await patchT(T1, { aanvraagdatum: { oud: null, nieuw: "2026-10-01" } }, "w-a");
  assert.equal(dubbel.status, 200);
  assert.equal(dubbel.data.noop, true);
});

// ---------- afvinken en heropenen ----------
test("afvinken: ok, zonder actie 422, niet toegestane actie 422, onbekende regel 404, geen trajectregel 404, onbekend traject 404, idempotent", async () => {
  await trajectInBesluit(h);
  const pad = (regel) => `/trajecten/${T1}/termijnen/${regel}/afvinken`;
  assert.equal((await vraag("POST", pad("deal-bezwaar"), { wijzigingId: "wv1" })).status, 422);
  const nietToegestaan = await vraag("POST", pad("deal-bezwaar"), { wijzigingId: "wv1", actie: "Iets anders" });
  assert.equal(nietToegestaan.status, 422);
  assert.equal(nietToegestaan.data.fouten.actie, "actie-niet-toegestaan");
  assert.equal((await vraag("POST", pad("bestaat-niet"), { wijzigingId: "wv1", actie: "x" })).status, 404);
  assert.equal((await vraag("POST", pad("lead-bellen"), { wijzigingId: "wv1", actie: "x" })).status, 404);
  assert.equal((await vraag("POST", `/trajecten/t_nee/termijnen/deal-bezwaar/afvinken`, { wijzigingId: "wv1", actie: "Bezwaar ingediend" })).status, 404);
  assert.equal((await vraag("POST", pad("deal-bezwaar"), { wijzigingId: "wv1", actie: "Bezwaar ingediend", wie: "x" })).status, 422);
  const ok = await vraag("POST", pad("deal-bezwaar"), { wijzigingId: "wv1", actie: "Bezwaar ingediend" }, { c: ruben });
  assert.equal(ok.status, 200);
  assert.equal(ok.data.record.afgevinkt["deal-bezwaar"].actie, "Bezwaar ingediend");
  assert.equal(ok.data.record.afgevinkt["deal-bezwaar"].wie, "Ruben");
  assert.equal(ok.data.termijnen.find((t) => t.regelId === "deal-bezwaar").status, "afgevinkt");
  const dubbel = await vraag("POST", pad("deal-bezwaar"), { wijzigingId: "wv1", actie: "Bezwaar ingediend" }, { c: ruben });
  assert.equal(dubbel.status, 200);
  assert.equal(dubbel.data.noop, true);
  const afvinkLog = (await vraag("GET", `/relaties/${R1}/tijdlijn`)).data.regels.filter((l) => l.soort === "afvinken");
  assert.equal(afvinkLog.length, 1);
  assert.equal((await vraag("POST", pad("deal-bezwaar"), { wijzigingId: "wv1" , actie: 5 })).status, 422);
});

test("afvinken: actie is null of een string van hooguit 100 tekens, en moet in afvinkActies van de regel staan", async () => {
  // deal-opname (niet fataal) krijgt hier afvinkacties; open zolang de fase Opname gepland is
  const regels = testCatalogus({ "deal-opname": { afvinkActies: ["Opname gedaan", "Opname verzet"] } });
  const hh = maakHandler({ regels, nu: () => new Date(NU.getTime() + 1000 * tik++) });
  await maakR(R1, {}, "w1", { handler: hh });
  await maakT(R1, T1, { fase: "Aanvraag ingediend" });
  const r = await patchT(T1, { opnamedatum: { oud: null, nieuw: "2026-11-05" }, fase: { oud: "Aanvraag ingediend", nieuw: "Opname gepland" } }, "w-o", { handler: hh });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  const pad = `/trajecten/${T1}/termijnen/deal-opname/afvinken`;
  const v = (wid, actie) => vraag("POST", pad, { wijzigingId: wid, ...(actie !== undefined ? { actie } : {}) }, { handler: hh });
  assert.equal((await v("wa1")).data.fouten.actie, "actie-verplicht");
  assert.equal((await v("wa2", null)).status, 422);
  assert.equal((await v("wa3", "Iets anders")).data.fouten.actie, "actie-niet-toegestaan");
  assert.equal((await v("wa4", "x".repeat(101))).data.fouten.actie, "ongeldig");
  assert.equal((await v("wa5", 5)).data.fouten.actie, "ongeldig");
  assert.equal((await v("wa6", ["Opname gedaan"])).status, 422);
  assert.equal((await v("wa7", "Opname gedaan")).status, 200);
  // regel zonder afvinkacties: null mag, lange tekst niet
  await vraag("POST", `/trajecten/${T1}/termijnen/deal-opname/heropenen`, { wijzigingId: "wh" }, { handler: hh });
  const zonder = maakHandler({ regels: testCatalogus(), nu: () => new Date(NU.getTime() + 1000 * tik++) });
  assert.equal((await vraag("POST", pad, { wijzigingId: "wb1", actie: "x".repeat(101) }, { handler: zonder })).status, 422);
  const nul = await vraag("POST", pad, { wijzigingId: "wb2", actie: null }, { handler: zonder });
  assert.equal(nul.status, 200, JSON.stringify(nul.data));
  assert.equal(nul.data.record.afgevinkt["deal-opname"].actie, null);
});

test("heropenen: ok, al open is een no-op, onbekend 404, idempotent", async () => {
  await trajectInBesluit(h);
  const af = `/trajecten/${T1}/termijnen/deal-bezwaar/afvinken`;
  const he = `/trajecten/${T1}/termijnen/deal-bezwaar/heropenen`;
  const alOpen = await vraag("POST", he, { wijzigingId: "wh0" });
  assert.equal(alOpen.status, 200); // al open: no-op, geen fout
  assert.equal(alOpen.data.noop, true);
  assert.equal((await vraag("POST", af, { wijzigingId: "wv0", actie: "Bezwaar ingediend" })).status, 200);
  assert.equal((await vraag("POST", af, { wijzigingId: "wv0b", actie: "Bezwaar ingediend" })).data.noop, true); // zelfde actie nogmaals
  await vraag("POST", af, { wijzigingId: "wv1", actie: "Bezwaar ingediend" });
  const ok = await vraag("POST", he, { wijzigingId: "wh1" });
  assert.equal(ok.status, 200);
  assert.equal(ok.data.record.afgevinkt["deal-bezwaar"], undefined);
  assert.equal(ok.data.termijnen.find((t) => t.regelId === "deal-bezwaar").status, "open");
  const dubbel = await vraag("POST", he, { wijzigingId: "wh1" });
  assert.equal(dubbel.status, 200);
  assert.equal(dubbel.data.noop, true);
  assert.equal((await vraag("POST", `/trajecten/${T1}/termijnen/onzin/heropenen`, { wijzigingId: "wh2" })).status, 404);
  assert.equal((await vraag("POST", he, { wijzigingId: "wh3", actie: "x" })).status, 422);
  assert.equal((await vraag("POST", `/trajecten/t_nee/termijnen/deal-bezwaar/heropenen`, { wijzigingId: "wh4" })).status, 404);
});

test("brondatum wijzigt na afvinken: herbevestigen in GET en afvinken weer mogelijk", async () => {
  await trajectInBesluit(h);
  await vraag("POST", `/trajecten/${T1}/termijnen/deal-bezwaar/afvinken`, { wijzigingId: "wv1", actie: "Bezwaar ingediend" });
  await patchT(T1, { verzenddatumBesluitbrief: { oud: "2026-11-02", nieuw: "2026-11-03" } }, "w-datum");
  const t = (await vraag("GET", `/relaties/${R1}`)).data.trajecten[0].termijnen.find((x) => x.regelId === "deal-bezwaar");
  assert.equal(t.status, "herbevestigen");
});

// ---------- regels ----------
test("GET /regels: alle regels met bevestigingsstatus; standaard-handler: niets bevestigd", async () => {
  const r = await vraag("GET", "/regels");
  assert.equal(r.status, 200);
  assert.ok(r.data.regels.length > 5);
  assert.ok(r.data.regels.every((x) => x.bevestigingsstatus === "bevestigd"));
  const echt = await vraag("GET", "/regels", undefined, { handler: hStandaard });
  assert.ok(echt.data.regels.every((x) => x.bevestigingsstatus === "niet-bevestigd"));
  assert.ok(echt.data.regels.every((x) => x.duur.aantal === null));
});

// ---------- T8 ----------
test("T8: filter op eigenaar en zoekterm verbergt de fatale termijn van Kevin niet; /relaties heeft geen fataal-blok meer", async () => {
  await maakR(R1, { achternaam: "Jansma", eigenaar: "kevin" }, "w1");
  await maakR(R2, { achternaam: "Bakker", eigenaar: "ruben", status: "Poging 1" }, "w2");
  await maakT(R1, T1);
  await patchT(T1, { verzenddatumBesluitbrief: { oud: null, nieuw: "2026-11-02" }, fase: { oud: "Aanvraag ingediend", nieuw: "Besluit" } }, "w-b");
  const gefilterd = await vraag("GET", "/relaties?eigenaar=ruben&q=bakker");
  assert.deepEqual(gefilterd.data.relaties.map((x) => x.id), [R2]);
  assert.equal("fataal" in gefilterd.data, false);
  const start = await vraag("GET", "/start");
  assert.equal(start.status, 200);
  assert.equal(start.data.fataal.aantal, 4);
  assert.equal(start.data.fataal.items.length, 4);
  assert.ok(start.data.fataal.items.every((i) => i.recordId === T1));
  // filters in de querystring van /start doen er niets aan
  const metFilter = await vraag("GET", "/start?eigenaar=ruben&q=bakker&status=Poging%201");
  assert.deepEqual(metFilter.data.fataal, start.data.fataal);
  assert.equal(metFilter.data.fataal.eerstvolgendeDagen, 13); // einddatum 23 nov, vandaag 10 nov
});

test("/start: verlopen termijn blijft staan, ook bij Afgerond (T7 via de start)", async () => {
  await maakR(R1, {}, "w1");
  await maakT();
  await patchT(T1, { verzenddatumBesluitbrief: { oud: null, nieuw: "2026-06-01" }, fase: { oud: "Aanvraag ingediend", nieuw: "Besluit" } }, "w-b");
  const s = (await vraag("GET", "/start")).data;
  assert.equal(s.fataal.verlopen, 3);
  assert.ok(s.fataal.eerstvolgendeDagen < 0);
  assert.ok(s.fataal.items.some((i) => i.status === "open" && i.dagenOver < 0));
  // standaardcatalogus: niets bevestigd, dus signalen in plaats van termijnen
  const echt = (await vraag("GET", "/start", undefined, { handler: hStandaard })).data.fataal;
  assert.equal(echt.verlopen, 0);
  assert.equal(echt.signalen, echt.aantal);
  assert.equal(echt.aantal, EXACT_ECHT);
});

test("T9: traject staat in het register maar de list() laat het weg: toch op /start", async () => {
  await maakR(R1, {}, "w1");
  await trajectInBesluit();
  const orig = basis.list;
  basis.list = async () => ({ blobs: [] }); // nep-list die alles weglaat
  try {
    const s = (await vraag("GET", "/start")).data;
    assert.equal(s.fataal.aantal, 4);
    assert.ok(s.fataal.items.every((i) => i.recordId === T1));
  } finally { basis.list = orig; }
});

test("/start: onvolledig en onleesbaar traject verschijnen in het gezondheidsblok; overige trajecten blijven staan", async () => {
  await maakR(R1, {}, "w1");
  await trajectInBesluit();
  const reg = await basis.get("register/trajecten", { type: "json" });
  // onvolledig: register zonder record, ouder dan 10 minuten; jong (bezig): niet gemeld; onleesbaar: read gooit
  await basis.setJSON("register/trajecten", { ids: { ...reg.ids,
    t_weg: { relatieId: R1, aangemaakt: "2026-11-10T09:00:00.000Z" },
    t_jong: { relatieId: R1, aangemaakt: "2026-11-10T09:59:00.000Z" },
    t_kapot: { relatieId: R1, aangemaakt: "2026-11-10T08:00:00.000Z" } } });
  const origGet = basis.get;
  basis.get = async (k, o) => { if (k === "traject/t_kapot") throw new Error("lezen mislukt"); return origGet.call(basis, k, o); };
  try {
    const s = (await vraag("GET", "/start")).data;
    assert.deepEqual(s.gezondheid.onvolledig.map((x) => x.id), ["t_weg"]);
    assert.deepEqual(s.gezondheid.onleesbaar, [{ id: "t_kapot", relatieId: R1 }]);
    assert.equal(s.gezondheid.aantal, 2);
    assert.equal(s.fataal.aantal, 6); // 4 termijnen + onvolledig + onleesbaar
    assert.deepEqual(s.fataal.items.filter((i) => ["onvolledig", "onleesbaar"].includes(i.status)).map((i) => [i.recordId, i.status, i.fataal]),
      [["t_kapot", "onleesbaar", true], ["t_weg", "onvolledig", true]]);
  } finally { basis.get = origGet; }
});

test("/start: 50 trajecten, 1 onleesbaar: dat ene traject telt mee in aantal en staat in het blok", async () => {
  await maakR(R1, {}, "w1");
  await maakT();
  const model = await basis.get(`traject/${T1}`, { type: "json" });
  const ids = {};
  for (let i = 0; i < 50; i++) {
    const id = `t_n${i}`;
    ids[id] = { relatieId: R1, aangemaakt: "2026-11-01T00:00:00.000Z" };
    if (i !== 7) await basis.setJSON(`traject/${id}`, { ...model, id });
  }
  await basis.setJSON("register/trajecten", { ids });
  const origGet = basis.get;
  await basis.setJSON("traject/t_n7", { ...model, id: "t_n7" });
  basis.get = async (k, o) => { if (k === "traject/t_n7") throw new Error("lezen mislukt"); return origGet.call(basis, k, o); };
  try {
    const s = (await vraag("GET", "/start")).data;
    assert.equal(s.fataal.aantal, 1);
    assert.equal(s.fataal.signalen, 1);
    assert.deepEqual(s.fataal.items.map((i) => [i.recordId, i.status]), [["t_n7", "onleesbaar"]]);
    assert.equal(s.fataal.items[0].naam !== undefined, true);
    const t = (await vraag("GET", "/start?alleen=telling")).data;
    assert.equal(t.fataal.aantal, 1);
  } finally { basis.get = origGet; }
});

test("/start?alleen=telling: alleen tellingen; ongeldige waarde 422", async () => {
  await maakR(R1, {}, "w1");
  await trajectInBesluit();
  const t = await vraag("GET", "/start?alleen=telling");
  assert.equal(t.status, 200);
  assert.deepEqual(Object.keys(t.data).sort(), ["fataal", "gezondheid", "vandaag"]);
  assert.deepEqual(Object.keys(t.data.fataal).sort(), ["aantal", "eerstvolgendeDagen", "signalen", "verlopen"]);
  assert.equal(t.data.fataal.aantal, 4);
  assert.deepEqual(t.data.gezondheid, { aantal: 0 });
  assert.equal((await vraag("GET", "/start?alleen=alles")).status, 422);
});

test("hartslag met een tijd meer dan een uur in de toekomst: ongeldig; een kwartier vooruit mag (klokverschil)", async () => {
  await basis.setJSON("status/dagelijks", { op: new Date(NU.getTime() + 2 * 3600000).toISOString(), ok: true });
  assert.equal((await vraag("GET", "/start")).data.hartslag.waarschuwing, "ongeldig");
  await basis.setJSON("status/dagelijks", { op: new Date(NU.getTime() + 15 * 60000).toISOString(), ok: true });
  assert.equal((await vraag("GET", "/start")).data.hartslag.waarschuwing, null);
});

test("POST /dagelijks: 401 zonder cookie, body moet {} zijn, 200 met {ok, aantallen, fouten}, hartslag handmatig, daarna 429", async () => {
  assert.equal((await vraag("POST", "/dagelijks", {}, { c: null })).status, 401);
  assert.equal((await vraag("POST", "/dagelijks", { x: 1 })).status, 422);
  assert.equal((await vraag("POST", "/dagelijks", undefined, { ruw: "" })).status, 422);
  assert.equal((await vraag("GET", "/dagelijks")).status, 405);
  await maakR(R1, {}, "w1");
  await trajectInBesluit();
  const r = await vraag("POST", "/dagelijks", {});
  assert.equal(r.status, 200, JSON.stringify(r.data));
  assert.deepEqual(Object.keys(r.data).sort(), ["aantallen", "fouten", "ok"]);
  assert.equal(r.data.ok, true);
  assert.equal(r.data.aantallen.fataalItems, 4);
  const h = await basis.get("status/dagelijks", { type: "json" });
  assert.equal(h.handmatig, true);
  const nogmaals = await vraag("POST", "/dagelijks", {});
  assert.equal(nogmaals.status, 429);
  assert.ok(Number(nogmaals.headers.get("retry-after")) > 0);
  // /start ziet de verse hartslag
  assert.equal((await vraag("GET", "/start")).data.hartslag.waarschuwing, null);
  // een oude hartslag (> 15 min) laat een nieuwe run toe
  await basis.setJSON("status/dagelijks", { ...h, op: new Date(NU.getTime() - 16 * 60000).toISOString() });
  assert.equal((await vraag("POST", "/dagelijks", {})).status, 200);
});

test("T18: de engine faalt voor één traject: 'kon niet berekenen: <traject>' in het blok, niet overgeslagen", async () => {
  await maakR(R1, {}, "w1");
  await trajectInBesluit();
  const kapot = await basis.get(`traject/${T1}`, { type: "json" });
  // Een record dat de berekening laat vallen (geen object in fasegeschiedenis én een Proxy-val)
  const giftig = new Proxy({ ...kapot, id: "t_giftig" }, { get(t, k) { if (k === "fase" || k === "fasegeschiedenis") throw new Error("kapot"); return t[k]; } });
  const orig = basis.get;
  basis.get = async (k, o) => (k === "traject/t_giftig" ? giftig : orig.call(basis, k, o));
  const reg = await basis.get("register/trajecten", { type: "json" });
  await basis.setJSON("register/trajecten", { ids: { ...reg.ids, t_giftig: { relatieId: R1, aangemaakt: "2026-11-10T08:00:00.000Z" } } });
  try {
    const s = (await vraag("GET", "/start")).data;
    const kon = s.fataal.items.filter((i) => i.status === "kon-niet-berekenen");
    assert.equal(kon.length, 1);
    assert.equal(kon[0].titel, "kon niet berekenen: t_giftig");
    assert.equal(kon[0].fataal, true);
    assert.equal(s.fataal.items.filter((i) => i.recordId === T1).length, 4); // het gezonde traject blijft
  } finally { basis.get = orig; }
});

test("/start: taken van vandaag (ook achterstallig) en van de komende week, uit de index", async () => {
  const taak = (id, titel, datum) => ({ [`taken.${id}.soort`]: { oud: null, nieuw: "taak" }, [`taken.${id}.titel`]: { oud: null, nieuw: titel }, [`taken.${id}.datum`]: { oud: null, nieuw: datum } });
  await maakR(R1, { achternaam: "Jansma" }, "w1");
  await maakR(R2, { achternaam: "Bakker" }, "w2");
  await maakR("r_ccc3", { achternaam: "Dijk" }, "w3");
  await maakR("r_ddd4", { achternaam: "Veen" }, "w4");
  for (const [rid, id, datum] of [[R1, "k1", "2026-11-10"], [R2, "k2", "2026-11-17"], ["r_ccc3", "k3", "2026-11-18"], ["r_ddd4", "k4", "2026-11-05"]]) {
    const r = await vraag("PATCH", `/relaties/${rid}`, { wijzigingId: `wt-${id}`, velden: taak(id, `Taak ${id}`, datum) });
    assert.equal(r.status, 200, JSON.stringify(r.data));
  }
  const t = (await vraag("GET", "/start")).data.taken;
  assert.deepEqual(t.vandaag.map((x) => [x.relatieId, x.achterstallig]), [["r_ddd4", true], [R1, false]]);
  assert.deepEqual(t.dezeWeek.map((x) => x.relatieId), [R2]); // 17 nov is vandaag + 7; 18 nov valt erbuiten
});

test("T16: hartslag ontbreekt, 27 uur oud, 25 uur oud, met fouten, vers", async () => {
  const uur = (n) => new Date(NU.getTime() - n * 3600000).toISOString();
  const lees = async () => (await vraag("GET", "/start")).data;
  const s0 = await lees();
  assert.equal(s0.hartslag.waarschuwing, "ontbreekt");
  assert.equal(s0.hartslag.laatste, null);
  assert.equal(s0.register, null);
  await basis.setJSON("status/dagelijks", { op: uur(27), ok: true, aantallen: { trajecten: 2 }, fouten: [], details: { register: [{ id: "t_x", relatieId: R1, soort: "ontbrak-in-register", hersteld: true }] } });
  const s1 = await lees();
  assert.equal(s1.hartslag.waarschuwing, "ouder-dan-26-uur");
  assert.ok(s1.hartslag.leeftijdUren > 26);
  assert.deepEqual(s1.register.afwijkingen.map((a) => a.id), ["t_x"]); // vergelijking van de laatste run
  await basis.setJSON("status/dagelijks", { op: uur(25), ok: true, aantallen: {}, fouten: [] });
  assert.equal((await lees()).hartslag.waarschuwing, null);
  await basis.setJSON("status/dagelijks", { op: uur(2), ok: false, aantallen: {}, fouten: [{ stap: "index", soort: "Error" }] });
  assert.equal((await lees()).hartslag.waarschuwing, "laatste-run-met-fouten");
  await basis.setJSON("status/dagelijks", { op: "onzin", ok: true });
  assert.equal((await lees()).hartslag.waarschuwing, "ongeldig");
});

test("/start: 500 zonder deploy-context bij echte data; alleen GET", async () => {
  process.env.DASHBOARD_ECHTE_DATA = "aan";
  assert.equal((await vraag("GET", "/start", undefined, { context: {} })).status, 500);
  delete process.env.DASHBOARD_ECHTE_DATA;
  assert.equal((await vraag("POST", "/start", {})).status, 405);
});

// ---------- 503 ----------
test("logOk:false geeft 503 (aanmaken, wijzigen, traject, afvinken); herhalen met dezelfde wijzigingId lukt", async () => {
  let kapot = false;
  haken.voorSet.push((k) => { if (kapot && k.startsWith("log/")) throw new Error("logfout"); return undefined; });

  kapot = true;
  const a = await maakR(R1, {}, "w1");
  assert.equal(a.status, 503);
  assert.equal(a.data.herhaal, true);
  assert.equal(a.headers.get("retry-after"), "1");
  kapot = false;
  const a2 = await maakR(R1, {}, "w1");
  assert.equal(a2.status, 200);
  assert.equal((await vraag("GET", `/relaties/${R1}/tijdlijn`)).data.regels.length, 1);

  kapot = true;
  const p = await vraag("PATCH", `/relaties/${R1}`, { wijzigingId: "w2", velden: { plaats: { oud: "Plaats", nieuw: "Drachten" } } });
  assert.equal(p.status, 503);
  assert.equal(p.data.wijzigingId, "w2");
  kapot = false;
  const p2 = await vraag("PATCH", `/relaties/${R1}`, { wijzigingId: "w2", velden: { plaats: { oud: "Plaats", nieuw: "Drachten" } } });
  assert.equal(p2.status, 200);
  assert.equal(p2.data.record.plaats, "Drachten");
  assert.equal((await vraag("GET", `/relaties/${R1}/tijdlijn`)).data.regels.filter((l) => l.soort === "wijziging").length, 1);

  kapot = true;
  assert.equal((await maakT()).status, 503);
  kapot = false;
  assert.equal((await maakT()).status, 200);

  await patchT(T1, { verzenddatumBesluitbrief: { oud: null, nieuw: "2026-11-02" }, fase: { oud: "Aanvraag ingediend", nieuw: "Besluit" } }, "w-b");
  kapot = true;
  const v = await vraag("POST", `/trajecten/${T1}/termijnen/deal-bezwaar/afvinken`, { wijzigingId: "wv", actie: "Bezwaar ingediend" });
  assert.equal(v.status, 503);
  const t = await patchT(T1, { aanvraagdatum: { oud: null, nieuw: "2026-10-01" } }, "w-c");
  assert.equal(t.status, 503);
  kapot = false;
  assert.equal((await vraag("POST", `/trajecten/${T1}/termijnen/deal-bezwaar/afvinken`, { wijzigingId: "wv", actie: "Bezwaar ingediend" })).status, 200);
  assert.equal((await patchT(T1, { aanvraagdatum: { oud: null, nieuw: "2026-10-01" } }, "w-c")).status, 200);
  const logs = (await vraag("GET", `/relaties/${R1}/tijdlijn`)).data.regels;
  assert.equal(logs.filter((l) => l.wijzigingId === "wv").length, 1);
  assert.equal(logs.filter((l) => l.wijzigingId === "w-c").length, 1);
});

test("verloren etag-pogingen (gelijktijdig-probeer-opnieuw) geven 503 met herhaal", async () => {
  await maakR(R1, {}, "w1");
  haken.voorSet.push((k, v, opt) => (k === `relatie/${R1}` && opt?.onlyIfMatch ? { modified: false } : undefined));
  const p = await vraag("PATCH", `/relaties/${R1}`, { wijzigingId: "w2", velden: { plaats: { oud: "Plaats", nieuw: "Drachten" } } });
  assert.equal(p.status, 503);
  assert.equal(p.data.code, "gelijktijdig-probeer-opnieuw");
  assert.equal(p.data.herhaal, true);
  haken.voorSet.length = 0;
  assert.equal((await vraag("PATCH", `/relaties/${R1}`, { wijzigingId: "w2", velden: { plaats: { oud: "Plaats", nieuw: "Drachten" } } })).status, 200);
});

test("503 bij gelijktijdigheid op traject (PATCH) en op afvinken; daarna lukt een herhaling", async () => {
  await trajectInBesluit(h);
  haken.voorSet.push((k, v, opt) => (k === `traject/${T1}` && opt?.onlyIfMatch ? { modified: false } : undefined));
  const p = await patchT(T1, { aanvraagdatum: { oud: null, nieuw: "2026-10-01" } }, "w-p");
  assert.equal(p.status, 503);
  assert.equal(p.data.code, "gelijktijdig-probeer-opnieuw");
  assert.equal(p.headers.get("retry-after"), "1");
  const a = await vraag("POST", `/trajecten/${T1}/termijnen/deal-bezwaar/afvinken`, { wijzigingId: "w-a", actie: "Bezwaar ingediend" });
  assert.equal(a.status, 503);
  assert.equal(a.data.herhaal, true);
  haken.voorSet.length = 0;
  assert.equal((await patchT(T1, { aanvraagdatum: { oud: null, nieuw: "2026-10-01" } }, "w-p")).status, 200);
  assert.equal((await vraag("POST", `/trajecten/${T1}/termijnen/deal-bezwaar/afvinken`, { wijzigingId: "w-a", actie: "Bezwaar ingediend" })).status, 200);
  haken.voorSet.push((k, v, opt) => (k === `traject/${T1}` && opt?.onlyIfMatch ? { modified: false } : undefined));
  const he = await vraag("POST", `/trajecten/${T1}/termijnen/deal-bezwaar/heropenen`, { wijzigingId: "w-h" });
  assert.equal(he.status, 503);
  haken.voorSet.length = 0;
  assert.equal((await vraag("POST", `/trajecten/${T1}/termijnen/deal-bezwaar/heropenen`, { wijzigingId: "w-h" })).status, 200);
  const log = (await vraag("GET", `/relaties/${R1}/tijdlijn`)).data.regels;
  assert.equal(log.filter((l) => l.wijzigingId === "w-p").length, 1);
  assert.equal(log.filter((l) => l.wijzigingId === "w-a").length, 1);
});

test("interne fout: 500 zonder details", async () => {
  await maakR(R1, {}, "w1");
  zetStoreFabriek(() => ({ async getWithMetadata() { throw new Error("Jansma 06-12345678"); }, async get() { throw new Error("Jansma 06-12345678"); } }));
  const log = [];
  const orig = console.error;
  console.error = (...a) => log.push(a.join(" "));
  try {
    const r = await vraag("GET", `/relaties/${R1}`);
    assert.equal(r.status, 500);
    assert.ok(!JSON.stringify(r.data).includes("Jansma"));
  } finally { console.error = orig; }
  assert.ok(!log.join(" ").includes("Jansma"));
  assert.ok(!log.join(" ").includes("06-"));
});

test("/start: fatale items, gezondheid en taken hebben losse velden achternaam en plaats", async () => {
  await trajectInBesluit();
  const reg = await basis.get("register/trajecten", { type: "json" });
  await basis.setJSON("register/trajecten", { ids: { ...reg.ids, t_weg: { relatieId: R1, aangemaakt: "2026-11-10T08:00:00.000Z" } } });
  await vraag("PATCH", `/relaties/${R1}`, { wijzigingId: "w-taak", velden: {
    "taken.k1.soort": { oud: null, nieuw: "taak" }, "taken.k1.titel": { oud: null, nieuw: "Bellen" }, "taken.k1.datum": { oud: null, nieuw: "2026-11-10" },
  } });
  const s = (await vraag("GET", "/start")).data;
  assert.ok(s.fataal.items.length >= 2);
  for (const i of s.fataal.items) assert.deepEqual([i.achternaam, i.plaats], ["Test", "Plaats"], `${i.status}`);
  assert.deepEqual(s.taken.vandaag.map((t) => [t.achternaam, t.plaats]), [["Test", "Plaats"]]);
});

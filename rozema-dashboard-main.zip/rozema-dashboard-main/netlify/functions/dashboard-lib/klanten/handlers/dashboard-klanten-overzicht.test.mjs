// Tests voor de routes pijplijn, overzicht en contact in dashboard-klanten.mjs. Alleen fictieve data.
import { test, beforeEach } from "node:test";
import assert from "node:assert/strict";
import { zetStoreFabriek } from "../../opslag.mjs";
import { geheugenStore } from "../../test-hulp.mjs";
import { maakWachtwoordHash, maakToken } from "../../sessie.mjs";
import { testCatalogus } from "../test-regels.mjs";
import { verwijderRelatie } from "../export.mjs";
import { maakHandler } from "../../../dashboard-klanten.mjs";

const NU = new Date("2026-11-19T10:00:00.000Z");
const CTX = { deploy: { context: "deploy-preview" } };
const BASIS = "https://x.test/api/dashboard/klanten";
let gebruikers; let store; let kevin; let h;

beforeEach(async () => {
  gebruikers ??= JSON.stringify({ Kevin: await maakWachtwoordHash("verzonnen-a", 1000) });
  process.env.DASHBOARD_GEBRUIKERS = gebruikers;
  process.env.DASHBOARD_SESSIE_GEHEIM = "z".repeat(40);
  delete process.env.DASHBOARD_ECHTE_DATA;
  store = geheugenStore();
  zetStoreFabriek(() => store);
  kevin = `dashboard_sessie=${maakToken("Kevin")}`;
  let tik = 0;
  h = maakHandler({ regels: testCatalogus(), nu: () => new Date(NU.getTime() + 1000 * tik++) });
});

async function vraag(method, pad, body, { c = kevin } = {}) {
  const res = await h(new Request(`${BASIS}${pad}`, {
    method, headers: { ...(body !== undefined ? { "content-type": "application/json" } : {}), ...(c ? { cookie: c } : {}) },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  }), CTX);
  const t = await res.text();
  let data = null;
  try { data = JSON.parse(t); } catch { /* geen json */ }
  return { status: res.status, data };
}
const maakR = (id, extra = {}) => vraag("POST", "/relaties", { id, wijzigingId: `w-${id}`, velden: { achternaam: "Test", status: "Nieuw", plaats: "Plaats", bron: "Deur", eigenaar: "kevin", ...extra } });
const maakT = (rid, id, velden) => vraag("POST", `/relaties/${rid}/trajecten`, { id, wijzigingId: `w-${id}`, velden });

test("401 zonder sessie op de nieuwe routes", async () => {
  for (const [m, p, b] of [["GET", "/pijplijn"], ["GET", "/overzicht"], ["POST", "/relaties/r_a1/contact", { wijzigingId: "c1", wijze: "Gebeld" }]]) {
    assert.equal((await vraag(m, p, b, { c: null })).status, 401, p);
  }
});

test("pijplijn: trajecten per fase met naam uit de index; filters gevalideerd", async () => {
  assert.equal((await maakR("r_a1")).status, 201);
  assert.equal((await maakR("r_b2", { eigenaar: "ruben", achternaam: "Ander" })).status, 201);
  assert.equal((await maakT("r_a1", "t_a1", { fase: "Aanvraag ingediend", fee: 900 })).status, 201);
  assert.equal((await maakT("r_b2", "t_b2", { fase: "Getekend", route: "AVV" })).status, 201);
  const r = await vraag("GET", "/pijplijn");
  assert.equal(r.status, 200);
  assert.equal(r.data.totaal, 2);
  const k = r.data.kolommen.find((x) => x.fase === "Aanvraag ingediend");
  assert.equal(k.aantal, 1);
  assert.equal(k.fee, 900);
  assert.equal(k.kaarten[0].achternaam, "Test");
  assert.equal(k.kaarten[0].dagenInFase, 0);
  assert.equal((await vraag("GET", "/pijplijn?eigenaar=ruben")).data.totaal, 1);
  assert.equal((await vraag("GET", "/pijplijn?route=AVV")).data.totaal, 1);
  assert.equal((await vraag("GET", "/pijplijn?eigenaar=piet")).status, 422);
  assert.equal((await vraag("GET", "/pijplijn?route=x")).status, 422);
  assert.equal((await vraag("GET", "/pijplijn?archief=misschien")).status, 422);
  assert.equal((await vraag("POST", "/pijplijn", {})).status, 405);
});

test("leadpijplijn: leads per status uit de index, klant verdwijnt na een traject, filters gevalideerd", async () => {
  await maakR("r_a1", { voornaam: "Proef", contactvoorkeur: "WhatsApp", soortWoning: "Eigen woning" });
  await maakR("r_b2", { status: "Poging 1", bron: "Website", eigenaar: "ruben" });
  let r = await vraag("GET", "/leadpijplijn");
  assert.equal(r.status, 200);
  assert.equal(r.data.totaal, 2);
  const nieuw = r.data.kolommen.find((k) => k.status === "Nieuw");
  assert.equal(nieuw.kaarten[0].achternaam, "Test");
  assert.equal(nieuw.kaarten[0].contactvoorkeur, "WhatsApp");
  assert.equal(nieuw.kaarten[0].soortWoning, "Eigen woning");
  assert.equal(nieuw.kaarten[0].dagenInStatus, 0);
  assert.equal(r.data.kolommen.at(-1).status, "Contract getekend");
  // Contract getekend = traject in fase Getekend: de relatie wordt Klant en staat niet meer op het leadbord.
  assert.equal((await maakT("r_a1", "t_a1", { fase: "Getekend", getekendOp: "2026-11-19" })).status, 201);
  r = await vraag("GET", "/leadpijplijn");
  assert.equal(r.data.totaal, 1);
  assert.equal((await vraag("GET", "/relaties/r_a1")).data.relatie.status, "Klant");
  assert.equal((await vraag("GET", "/pijplijn")).data.kolommen.find((k) => k.fase === "Getekend").aantal, 1);
  // Afgevallen (met reden, in één wijziging): gearchiveerd.
  const af = await vraag("PATCH", "/relaties/r_b2", { wijzigingId: "af-1", velden: { status: { oud: "Poging 1", nieuw: "Afgevallen" }, redenAfgevallen: { oud: null, nieuw: "Niet bereikt" } } });
  assert.equal(af.status, 200, JSON.stringify(af.data));
  r = await vraag("GET", "/leadpijplijn");
  assert.equal(r.data.totaal, 0);
  assert.equal(r.data.kolommen.find((k) => k.status === "Afgevallen").gearchiveerd, 1);
  assert.equal((await vraag("GET", "/leadpijplijn?archief=ja")).data.totaal, 1);
  assert.equal((await vraag("GET", "/leadpijplijn?bron=Fax")).status, 422);
  assert.equal((await vraag("GET", "/leadpijplijn?eigenaar=piet")).status, 422);
  assert.equal((await vraag("GET", "/leadpijplijn?archief=x")).status, 422);
});

test("archief in de lijst en op de relatie: afgevallen en uitbetaald standaard verborgen", async () => {
  await maakR("r_a1");
  await maakR("r_b2", { status: "Afgevallen", redenAfgevallen: "Geen interesse" });
  await maakR("r_c3");
  await maakT("r_c3", "t_c3", { fase: "Getekend" });
  const lijst = async (q = "") => (await vraag("GET", `/relaties${q}`)).data.relaties.map((x) => x.id).sort();
  assert.deepEqual(await lijst(), ["r_a1", "r_c3"]);
  // Uitbetaald: de klant gaat naar het archief.
  const p = await vraag("PATCH", "/trajecten/t_c3", { wijzigingId: "u-1", velden: { fase: { oud: "Getekend", nieuw: "Uitbetaald" }, verzenddatumBesluitbrief: { oud: null, nieuw: "2026-10-01" } } });
  assert.equal(p.status, 200, JSON.stringify(p.data));
  assert.deepEqual(await lijst(), ["r_a1"]);
  assert.deepEqual(await lijst("?archief=alleen"), ["r_b2", "r_c3"]);
  assert.deepEqual(await lijst("?archief=toon"), ["r_a1", "r_b2", "r_c3"]);
  assert.equal((await vraag("GET", "/relaties?archief=x")).status, 422);
  assert.equal((await vraag("GET", "/relaties/r_c3")).data.gearchiveerd, true);
  assert.equal((await vraag("GET", "/relaties/r_a1")).data.gearchiveerd, false);
  const kp = await vraag("GET", "/pijplijn");
  assert.equal(kp.data.kolommen.find((k) => k.fase === "Uitbetaald").gearchiveerd, 1);
  assert.equal(kp.data.totaal, 0);
});

test("lijst: leads en klanten apart (?soort), fase-filter bij klanten, archief per soort", async () => {
  await maakR("r_a1");
  await maakR("r_b2", { status: "Afgevallen", redenAfgevallen: "Geen interesse" });
  await maakR("r_c3");
  await maakT("r_c3", "t_c3", { fase: "Getekend" });
  await maakR("r_d4");
  await maakT("r_d4", "t_d4", { fase: "Opname gepland" });
  const ids = async (q) => { const r = await vraag("GET", `/relaties${q}`); assert.equal(r.status, 200, q); return r.data.relaties.map((x) => x.id).sort(); };
  assert.deepEqual(await ids("?soort=lead"), ["r_a1"]);
  assert.deepEqual(await ids("?soort=lead&archief=toon"), ["r_a1", "r_b2"]);
  assert.deepEqual(await ids("?soort=klant"), ["r_c3", "r_d4"]);
  assert.deepEqual(await ids("?soort=klant&fase=Opname%20gepland"), ["r_d4"]);
  const rij = (await vraag("GET", "/relaties?soort=klant")).data.relaties.find((x) => x.id === "r_c3");
  assert.deepEqual(rij.fases, ["Getekend"]);
  await vraag("PATCH", "/trajecten/t_c3", { wijzigingId: "u-1", velden: { fase: { oud: "Getekend", nieuw: "Verloren" }, redenVerlies: { oud: null, nieuw: "Anders" } } });
  assert.deepEqual(await ids("?soort=klant"), ["r_d4"]);
  assert.deepEqual(await ids("?soort=klant&archief=toon"), ["r_c3", "r_d4"]);
  const gearch = (await vraag("GET", "/relaties?soort=klant&archief=toon")).data.relaties.find((x) => x.id === "r_c3");
  assert.equal(gearch.gearchiveerd, true);
  for (const q of ["?soort=x", "?soort=lead&fase=Getekend", "?soort=klant&fase=Schaderapport", "?soort=lead&status=Klant"]) {
    assert.equal((await vraag("GET", `/relaties${q}`)).status, 422, q);
  }
});

test("agenda: afspraken en opnames van iedereen, in te plannen, opnametijd, bereik gevalideerd", async () => {
  await maakR("r_a1", { status: "Afspraak gepland" });
  await maakR("r_b2", { status: "Afspraak gepland", eigenaar: "ruben" });
  const pa = await vraag("PATCH", "/relaties/r_b2", { wijzigingId: "af-1", velden: { "taken.a1.soort": { oud: null, nieuw: "afspraak" }, "taken.a1.titel": { oud: null, nieuw: "Gesprek" }, "taken.a1.datum": { oud: null, nieuw: "2026-11-20" }, "taken.a1.tijd": { oud: null, nieuw: "14:00" }, "taken.a1.eigenaar": { oud: null, nieuw: "ruben" } } });
  assert.equal(pa.status, 200, JSON.stringify(pa.data));
  await maakR("r_c3");
  await maakT("r_c3", "t_c3", { fase: "Opname gepland", opnamedatum: "2026-11-18", opnametijd: "09:30" });
  await maakR("r_d4");
  await maakT("r_d4", "t_d4", { fase: "Opname gepland" });
  const r = await vraag("GET", "/agenda");
  assert.equal(r.status, 200);
  assert.equal(r.data.van, "2026-11-16", "standaard de maandag van deze week");
  assert.equal(r.data.tot, "2026-11-22");
  assert.deepEqual(r.data.items.map((x) => [x.soort, x.relatieId, x.datum, x.tijd, x.eigenaar]),
    [["opname", "r_c3", "2026-11-18", "09:30", "kevin"], ["afspraak", "r_b2", "2026-11-20", "14:00", "ruben"]]);
  assert.deepEqual(r.data.inTePlannen.map((x) => [x.soort, x.relatieId]).sort(), [["afspraak", "r_a1"], ["opname", "r_d4"]]);
  assert.deepEqual((await vraag("GET", "/agenda?wie=ruben")).data.items.map((x) => x.relatieId), ["r_b2"]);
  assert.equal((await vraag("GET", "/agenda?van=2026-11-23")).data.items.length, 0);
  assert.equal((await vraag("GET", "/agenda?van=2026-11-01&tot=2026-11-30")).data.items.length, 2);
  for (const q of ["?van=x", "?wie=piet", "?van=2026-11-10&tot=2026-11-01", "?van=2026-01-01&tot=2026-12-31"]) {
    assert.equal((await vraag("GET", `/agenda${q}`)).status, 422, q);
  }
  assert.equal((await vraag("PATCH", "/trajecten/t_d4", { wijzigingId: "ot-1", velden: { opnametijd: { oud: null, nieuw: "25:00" } } })).status, 422);
  assert.equal((await vraag("GET", "/agenda", undefined, { c: null })).status, 401);
});

test("taken: lead zonder eigenaar bij toewijzen; na toewijzen de flow-taak voor die eigenaar; standaard de ingelogde", async () => {
  await vraag("POST", "/relaties", { id: "r_z1", wijzigingId: "w-z1", velden: { achternaam: "Zonder", status: "Nieuw", bron: "Website" } });
  await maakR("r_a1", { status: "Poging 1" });
  let r = await vraag("GET", "/taken");
  assert.equal(r.status, 200);
  assert.equal(r.data.wie, "kevin", "standaard de taken van wie is ingelogd");
  assert.deepEqual(r.data.toewijzen.map((x) => x.relatieId), ["r_z1"]);
  assert.deepEqual(r.data.taken.map((x) => [x.relatieId, x.stap]), [["r_a1", "lead-poging-1"]]);
  assert.equal(r.data.taken[0].datum, "2026-11-20", "Poging 1 vandaag + 1 dag");
  // Toewijzen aan Kevin: verdwijnt bij toewijzen, de eerste flow-taak verschijnt.
  const p = await vraag("PATCH", "/relaties/r_z1", { wijzigingId: "toe-1", velden: { eigenaar: { oud: null, nieuw: "kevin" } } });
  assert.equal(p.status, 200);
  r = await vraag("GET", "/taken");
  assert.equal(r.data.toewijzen.length, 0);
  assert.ok(r.data.taken.some((x) => x.relatieId === "r_z1" && x.stap === "lead-nieuw" && x.datum === "2026-11-19"));
  assert.deepEqual(r.data.telling, { toewijzen: 0, teLaat: 0, vandaag: 1, totaal: 2 });
  assert.deepEqual((await vraag("GET", "/taken?alleen=telling")).data.telling, r.data.telling);
  assert.equal((await vraag("GET", "/taken?wie=ruben")).data.taken.length, 0);
  assert.equal((await vraag("GET", "/taken?wie=alle")).data.wie, null);
  assert.equal((await vraag("GET", "/taken?wie=piet")).status, 422);
  assert.equal((await vraag("GET", "/taken?alleen=x")).status, 422);
});

test("taken: status verschuiven sluit de oude taak en geeft de volgende; follow-up op de terugbeldatum", async () => {
  await maakR("r_a1", { status: "Poging 1" });
  const p = await vraag("PATCH", "/relaties/r_a1", { wijzigingId: "s-1", velden: { status: { oud: "Poging 1", nieuw: "Later opnieuw" }, terugbeldatum: { oud: null, nieuw: "2027-01-10" } } });
  assert.equal(p.status, 200, JSON.stringify(p.data));
  const t = (await vraag("GET", "/taken")).data.taken;
  assert.deepEqual(t.map((x) => [x.stap, x.datum]), [["lead-later", "2027-01-10"]]);
});

test("relatie: taken van de klant (flow en handmatig); lijst met contactgegevens en volgende taak", async () => {
  await maakR("r_a1", { voornaam: "Proef", email: "proef@example.invalid", telefoon: "0500000000" });
  await maakT("r_a1", "t_a1", { fase: "Getekend" });
  await vraag("PATCH", "/relaties/r_a1", { wijzigingId: "tk-1", velden: { "taken.k1.soort": { oud: null, nieuw: "taak" }, "taken.k1.titel": { oud: null, nieuw: "Stukken ophalen" }, "taken.k1.datum": { oud: null, nieuw: "2026-11-30" } } });
  const rel = (await vraag("GET", "/relaties/r_a1")).data;
  assert.deepEqual(rel.taken.map((x) => [x.bron, x.stap ?? x.titel]), [["flow", "klant-getekend"], ["handmatig", "Stukken ophalen"]]);
  const rij = (await vraag("GET", "/relaties")).data.relaties.find((x) => x.id === "r_a1");
  assert.equal(rij.voornaam, "Proef");
  assert.equal(rij.email, "proef@example.invalid");
  assert.equal(rij.telefoon, "0500000000");
  assert.deepEqual(rij.volgendeTaak, { bron: "flow", stap: "klant-getekend", titel: null, datum: "2026-11-21", tijd: null });
  // Zoeken op e-mail en telefoon.
  assert.equal((await vraag("GET", "/relaties?q=proef%40example")).data.totaal, 1);
  assert.equal((await vraag("GET", "/relaties?q=05000")).data.totaal, 1);
});

test("fase Schaderapport bestaat niet meer: niet kiesbaar, een oud record telt als Adviesrapport", async () => {
  await maakR("r_a1");
  assert.equal((await maakT("r_a1", "t_x", { fase: "Schaderapport" })).status, 422);
  await maakT("r_a1", "t_a1", { fase: "Opname gedaan" });
  assert.equal((await vraag("PATCH", "/trajecten/t_a1", { wijzigingId: "f-1", velden: { fase: { oud: "Opname gedaan", nieuw: "Schaderapport" } } })).status, 422);
  // Een bestaand record met de oude fase (van vóór de samenvoeging) blijft werken.
  const t = await store.get("traject/t_a1", { type: "json" });
  await store.setJSON("traject/t_a1", { ...t, fase: "Schaderapport", fasegeschiedenis: [...t.fasegeschiedenis, { fase: "Schaderapport", van: "2026-11-01", wie: "Kevin" }] });
  const kp = await vraag("GET", "/pijplijn");
  assert.equal(kp.data.kolommen.find((k) => k.fase === "Adviesrapport").aantal, 1);
  assert.equal((await vraag("PATCH", "/trajecten/t_a1", { wijzigingId: "f-2", velden: { fee: { oud: null, nieuw: 900 } } })).status, 200, "een oud record blijft wijzigbaar");
});

test("overzicht: tellingen zonder namen, periode gevalideerd", async () => {
  await maakR("r_a1");
  await maakR("r_b2", { bron: "Website" });
  await maakT("r_a1", "t_a1", { fase: "Getekend", fee: 1000 });
  const r = await vraag("GET", "/overzicht");
  assert.equal(r.status, 200);
  assert.equal(r.data.leads.totaal, 2);
  assert.equal(r.data.leads.perBron.Deur, 1);
  assert.deepEqual(r.data.conversie.Deur, { leads: 1, klanten: 1 });
  assert.deepEqual(r.data.conversie.Website, { leads: 1, klanten: 0 });
  assert.equal(r.data.geld.feePijplijn.bedrag, 1000);
  assert.ok(!JSON.stringify(r.data).includes("Test"), "geen achternamen in het overzicht");
  assert.equal((await vraag("GET", "/overzicht?van=2026-11-01&tot=2026-11-30")).data.leads.totaal, 2);
  assert.equal((await vraag("GET", "/overzicht?van=2026-12-01")).data.leads.totaal, 0);
  assert.equal((await vraag("GET", "/overzicht?van=gisteren")).status, 422);
  assert.equal((await vraag("GET", "/overzicht?van=2026-12-01&tot=2026-11-01")).data.fouten.tot, "voor-van");
});

test("contact: wordt een tijdlijnregel, idempotent op wijzigingId, validatie", async () => {
  await maakR("r_a1");
  const body = { wijzigingId: "c-1", wijze: "Geen gehoor", notitie: "Voicemail ingesproken" };
  const r1 = await vraag("POST", "/relaties/r_a1/contact", body);
  assert.equal(r1.status, 201);
  assert.equal(r1.data.regel.soort, "contact");
  assert.equal(r1.data.regel.wie, "Kevin");
  assert.equal(r1.data.regel.nieuw.datum, "2026-11-19");
  const r2 = await vraag("POST", "/relaties/r_a1/contact", body);
  assert.equal(r2.status, 200);
  assert.equal(r2.data.noop, true);
  const tl = await vraag("GET", "/relaties/r_a1/tijdlijn");
  assert.equal(tl.data.regels.filter((x) => x.soort === "contact").length, 1);
  // Het record zelf (status, versie) verandert niet.
  assert.equal((await vraag("GET", "/relaties/r_a1")).data.relatie.status, "Nieuw");
  assert.equal((await vraag("POST", "/relaties/r_a1/contact", { wijzigingId: "c-2" })).data.fouten.wijze, "verplicht");
  assert.equal((await vraag("POST", "/relaties/r_a1/contact", { wijzigingId: "c-3", wijze: "Gebeld", datum: "2027-01-01" })).data.fouten.datum, "in-de-toekomst");
  assert.equal((await vraag("POST", "/relaties/r_a1/contact", { wijze: "Gebeld" })).data.fouten.wijzigingId, "ongeldig");
  assert.equal((await vraag("POST", "/relaties/r_a1/contact", { wijzigingId: "c-4", wijze: "Gebeld", wie: "Ruben" })).data.fouten.wie, "onbekend-veld");
  assert.equal((await vraag("POST", "/relaties/r_onbekend/contact", { wijzigingId: "c-5", wijze: "Gebeld" })).status, 404);
});

test("contact: na AVG-verwijderen 410 en de contactregel is weg", async () => {
  await maakR("r_a1");
  await vraag("POST", "/relaties/r_a1/contact", { wijzigingId: "c-1", wijze: "WhatsApp" });
  const v = await verwijderRelatie("r_a1", "Test", "Kevin", NU);
  assert.equal(v.ok, true);
  const { blobs } = await store.list({ prefix: "log/r_a1/" });
  assert.equal(blobs.length, 0);
  assert.equal((await vraag("POST", "/relaties/r_a1/contact", { wijzigingId: "c-2", wijze: "Gebeld" })).status, 410);
});

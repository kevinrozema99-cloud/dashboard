// Tests voor dashboard-klanten-export.mjs (K11). Alleen fictieve data.
import { test, beforeEach, afterEach } from "node:test";
import assert from "node:assert/strict";
import { vergelijkRegister } from "../opslag.mjs";
import { voerDagelijksUit } from "../dagelijks.mjs";
import { neemAanvraagOp } from "../instroom.mjs";
import { zetStoreFabriek } from "../../opslag.mjs";
import { geheugenFabriek } from "../../test-hulp.mjs";
import { maakWachtwoordHash, maakToken } from "../../sessie.mjs";
import { testCatalogus } from "../test-regels.mjs";
import { maakHandler as maakKlanten } from "../../../dashboard-klanten.mjs";
import standaard, { maakHandler, config } from "../../../dashboard-klanten-export.mjs";

const NU = new Date("2026-11-10T10:00:00.000Z");
const CTX = { deploy: { context: "deploy-preview" } };
const B = "https://x.test/api/dashboard/klantenbeheer";
const BK = "https://x.test/api/dashboard/klanten";
const R1 = "r_aaa1";
const R2 = "r_bbb2";
const T1 = "t_aaa1";
const T2 = "t_bbb2";

let fabriek; let kevin; let ruben; let h; let klanten; let gebruikers;
const REGELS = testCatalogus();

beforeEach(async () => {
  gebruikers ??= JSON.stringify({ Kevin: await maakWachtwoordHash("verzonnen-a", 1000), Ruben: await maakWachtwoordHash("verzonnen-b", 1000) });
  process.env.DASHBOARD_GEBRUIKERS = gebruikers;
  process.env.DASHBOARD_SESSIE_GEHEIM = "z".repeat(40);
  delete process.env.DASHBOARD_ECHTE_DATA;
  fabriek = geheugenFabriek();
  zetStoreFabriek(fabriek);
  kevin = `dashboard_sessie=${maakToken("Kevin")}`;
  ruben = `dashboard_sessie=${maakToken("Ruben")}`;
  h = maakHandler({ regels: REGELS, nu: () => NU });
  klanten = maakKlanten({ regels: REGELS, nu: () => NU });
});
afterEach(() => { delete process.env.DASHBOARD_ECHTE_DATA; });

const winkel = (naam = "klanten") => fabriek(`dashboard-test-${naam}`);

async function vraag(method, pad, body, { c = kevin, handler = h, headers = {} } = {}) {
  const basis = handler === klanten ? BK : B;
  const res = await handler(new Request(`${basis}${pad}`, {
    method,
    headers: { ...(body !== undefined ? { "content-type": "application/json" } : {}), ...(c ? { cookie: c } : {}), ...headers },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  }), CTX);
  return { status: res.status, headers: res.headers, tekst: await res.text() };
}
const js = (r) => JSON.parse(r.tekst);

async function zaai() {
  // Twee relaties; R1 met traject in Besluit (fatale termijnen) en twee taken; R2 met een traject.
  for (const [id, naam] of [[R1, "Testman"], [R2, "=Formule"]]) {
    const r = await vraag("POST", "/relaties", { id, wijzigingId: `w-${id}`, velden: { achternaam: naam, status: "Nieuw", straat: "Teststraat", huisnummer: "1", plaats: "Plaats", postcode: "9999 ZZ" } }, { handler: klanten });
    assert.equal(r.status, 201, r.tekst);
  }
  for (const [rid, tid] of [[R1, T1], [R2, T2]]) {
    const r = await vraag("POST", `/relaties/${rid}/trajecten`, { id: tid, wijzigingId: `w-${tid}`, velden: { fase: "Aanvraag ingediend" } }, { handler: klanten });
    assert.equal(r.status, 201, r.tekst);
  }
  const p = await vraag("PATCH", `/trajecten/${T1}`, { wijzigingId: "w-besluit", velden: {
    verzenddatumBesluitbrief: { oud: null, nieuw: "2026-11-02" }, fase: { oud: "Aanvraag ingediend", nieuw: "Besluit" } } }, { handler: klanten });
  assert.equal(p.status, 200, p.tekst);
  const t = await vraag("PATCH", `/relaties/${R1}`, { wijzigingId: "w-taken", velden: {
    "taken.k1.soort": { oud: null, nieuw: "taak" }, "taken.k1.titel": { oud: null, nieuw: "Geheime titel Jansen" }, "taken.k1.datum": { oud: null, nieuw: "2026-11-12" },
    "taken.k2.soort": { oud: null, nieuw: "afspraak" }, "taken.k2.titel": { oud: null, nieuw: "Bezoek" }, "taken.k2.datum": { oud: null, nieuw: "2026-11-13" }, "taken.k2.tijd": { oud: null, nieuw: "14:30" },
    "taken.k3.soort": { oud: null, nieuw: "taak" }, "taken.k3.titel": { oud: null, nieuw: "Zonder datum" } } }, { handler: klanten });
  assert.equal(t.status, 200, t.tekst);
  // R2: opname gepland met tijd (gezamenlijke agenda; ook in de feed).
  const o = await vraag("PATCH", `/trajecten/${T2}`, { wijzigingId: "w-opname", velden: {
    fase: { oud: "Aanvraag ingediend", nieuw: "Opname gepland" }, opnamedatum: { oud: null, nieuw: "2026-11-25" }, opnametijd: { oud: null, nieuw: "10:15" } } }, { handler: klanten });
  assert.equal(o.status, 200, o.tekst);
}

test("config.path en standaard-export", () => {
  assert.ok(config.path.every((p) => p.startsWith("/api/dashboard/klantenbeheer/")));
  assert.equal(typeof standaard, "function");
});

test("401 zonder cookie op export, verwijderen en token; feed heeft een token nodig (404)", async () => {
  for (const [m, p] of [["GET", "/export"], ["POST", "/beheer/verwijderen"], ["GET", "/agenda/token"], ["POST", "/agenda/token"]]) {
    const r = await vraag(m, p, m === "POST" ? {} : undefined, { c: null });
    assert.equal(r.status, 401, `${m} ${p}`);
  }
  assert.equal((await vraag("GET", `/agenda/feed/${"a".repeat(43)}.ics`, undefined, { c: null })).status, 404);
  assert.equal((await vraag("GET", "/agenda/feed/onzin.ics", undefined, { c: null })).status, 404);
  assert.equal((await vraag("PUT", "/export")).status, 405);
  assert.equal((await vraag("GET", "/onbekend")).status, 404);
});

test("export json: alles, no-store, attachment, gelogd zonder inhoud", async () => {
  await zaai();
  const r = await vraag("GET", "/export");
  assert.equal(r.status, 200);
  assert.equal(r.headers.get("cache-control"), "no-store");
  assert.match(r.headers.get("content-disposition"), /^attachment; filename="rozema-alles-2026-11-10\.json"$/);
  const d = js(r);
  assert.deepEqual(d.aantallen, { relaties: 2, trajecten: 2 });
  assert.deepEqual(d.relaties.map((x) => x.id), [R1, R2]);
  assert.deepEqual(d.trajecten.map((x) => x.id), [T1, T2]);
  const { blobs } = await winkel().list({ prefix: "exportlog/" });
  assert.equal(blobs.length, 1);
  const log = await winkel().get(blobs[0].key, { type: "json" });
  assert.deepEqual({ wie: log.wie, formaat: log.formaat, relaties: log.relaties, trajecten: log.trajecten }, { wie: "Kevin", formaat: "json", relaties: 2, trajecten: 2 });
  assert.ok(!JSON.stringify(log).includes("Testman"));
  const alleen = js(await vraag("GET", "/export?soort=trajecten"));
  assert.ok(alleen.trajecten && !alleen.relaties);
});

test("export csv: formule-escaping, aanhalingstekens, soort verplicht, ongeldige keuzes 422", async () => {
  await zaai();
  const r = await vraag("GET", "/export?formaat=csv&soort=relaties");
  assert.equal(r.status, 200);
  assert.match(r.headers.get("content-type"), /^text\/csv/);
  assert.equal(r.headers.get("cache-control"), "no-store");
  assert.ok(r.tekst.includes("'=Formule"), "formule krijgt een ' ervoor");
  assert.ok(!/(^|,)=Formule/m.test(r.tekst));
  assert.equal((await vraag("GET", "/export?formaat=csv")).status, 422);
  assert.equal((await vraag("GET", "/export?formaat=xml")).status, 422);
  assert.equal((await vraag("GET", "/export?formaat=csv&soort=alles")).status, 422);
  assert.equal((await vraag("GET", "/export?formaat=csv&soort=trajecten")).status, 200);
});

test("verwijderen: bevestiging verplicht en moet kloppen; niets weg bij een fout", async () => {
  await zaai();
  for (const body of [{ id: R1 }, { id: R1, bevestig: "" }, { id: R1, bevestig: "Verkeerd" }, { id: R1, bevestig: 5 }]) {
    const r = await vraag("POST", "/beheer/verwijderen", body);
    assert.equal(r.status, 422, JSON.stringify(body));
  }
  assert.equal((await vraag("POST", "/beheer/verwijderen", { id: R1, bevestig: "Testman", extra: 1 })).status, 422);
  assert.equal((await vraag("POST", "/beheer/verwijderen", { id: "r_bestaatniet", bevestig: "x" })).status, 404);
  assert.equal((await vraag("POST", "/beheer/verwijderen", { id: "onzin", bevestig: "x" })).status, 422);
  assert.ok(await winkel().get(`relatie/${R1}`));
  assert.equal((await winkel().list({ prefix: "tombstone/" })).blobs.length, 0);
});

test("verwijderen: relatie, trajecten, logs, journaal, register en index weg; alleen anonieme tombstone blijft", async () => {
  await zaai();
  await winkel().setJSON(`logwacht/${R1}/w-x@2026#abc`, { op: "x", regels: [] });
  const r = await vraag("POST", "/beheer/verwijderen", { id: R1, bevestig: " testman " }, { c: ruben });
  assert.equal(r.status, 200, r.tekst);
  assert.deepEqual(js(r).tombstone, { id: R1, verwijderdOp: NU.toISOString(), wie: "Ruben" });
  const s = winkel();
  assert.equal(await s.get(`relatie/${R1}`), null);
  assert.equal(await s.get(`traject/${T1}`), null);
  assert.equal((await s.list({ prefix: `log/${R1}/` })).blobs.length, 0);
  assert.equal((await s.list({ prefix: `logwacht/${R1}/` })).blobs.length, 0);
  const reg = await s.get("register/trajecten", { type: "json" });
  assert.deepEqual(Object.keys(reg.ids), [T2]);
  const index = await s.get("index/relaties", { type: "json" });
  assert.deepEqual(Object.keys(index.rijen), [R2]);
  // De andere relatie is ongemoeid.
  assert.ok(await s.get(`relatie/${R2}`));
  assert.ok(await s.get(`traject/${T2}`));
  assert.ok((await s.list({ prefix: `log/${R2}/` })).blobs.length > 0);
  // Tombstone zonder persoonsgegevens; nergens in de store staat de naam nog.
  const tomb = await s.get(`tombstone/${R1}`, { type: "json" });
  assert.deepEqual(Object.keys(tomb).sort(), ["id", "verwijderdOp", "wie"]);
  const alles = (await s.list({ prefix: "" })).blobs;
  for (const b of alles) assert.ok(!(await s.get(b.key)).includes("Testman"), b.key);
  // Export na verwijderen bevat de relatie niet meer.
  assert.deepEqual(js(await vraag("GET", "/export")).relaties.map((x) => x.id), [R2]);
});

test("agenda: token maken, feed zonder namen, vernieuwen maakt het oude token ongeldig", async () => {
  await zaai();
  assert.deepEqual(js(await vraag("GET", "/agenda/token")), { bestaat: false, op: null });
  const m = js(await vraag("POST", "/agenda/token", {}));
  assert.equal(m.ok, true);
  assert.match(m.url, /^https:\/\/x\.test\/api\/dashboard\/klantenbeheer\/agenda\/feed\/[A-Za-z0-9_-]{43}\.ics$/);
  assert.equal(js(await vraag("GET", "/agenda/token")).bestaat, true);
  // Het token zelf staat niet in de store, alleen een hash.
  const token = /feed\/(.+)\.ics$/.exec(m.url)[1];
  for (const b of (await winkel("agenda").list({ prefix: "" })).blobs) assert.ok(!b.key.includes(token) && !(await winkel("agenda").get(b.key)).includes(token));

  const feed = await vraag("GET", new URL(m.url).pathname.slice("/api/dashboard/klantenbeheer".length), undefined, { c: null });
  assert.equal(feed.status, 200, feed.tekst);
  assert.match(feed.headers.get("content-type"), /^text\/calendar/);
  assert.equal(feed.headers.get("cache-control"), "no-store");
  assert.ok(feed.tekst.startsWith("BEGIN:VCALENDAR\r\n") && feed.tekst.endsWith("END:VCALENDAR\r\n"));
  assert.ok(feed.tekst.includes("DTSTART;VALUE=DATE:20261112"), "taak met datum");
  assert.ok(feed.tekst.includes("DTSTART;TZID=Europe/Amsterdam:20261113T143000"), "taak met tijd");
  assert.ok(feed.tekst.includes(`${T1} `), "traject-id bij een fatale termijn");
  assert.ok(feed.tekst.includes("[[TEKST: klanten.agenda.fataal]]"));
  assert.ok(feed.tekst.includes(`UID:opname-${T2}@`), "opname in de feed");
  assert.ok(feed.tekst.includes("DTSTART;TZID=Europe/Amsterdam:20261125T101500"), "opname met tijd");
  assert.ok(!feed.tekst.includes("Zonder"), "taak zonder datum ontbreekt");
  for (const verboden of ["Testman", "Formule", "Jansen", "Teststraat", "Plaats", "9999", "Bezoek", "Bellen"]) assert.ok(!feed.tekst.includes(verboden), verboden);
  for (const regel of feed.tekst.split("\r\n")) assert.ok(regel.length <= 75, regel);

  const nieuw = js(await vraag("POST", "/agenda/token", {}, { c: kevin }));
  assert.notEqual(nieuw.url, m.url);
  assert.equal((await vraag("GET", new URL(m.url).pathname.slice("/api/dashboard/klantenbeheer".length), undefined, { c: null })).status, 404);
  assert.equal((await vraag("GET", new URL(nieuw.url).pathname.slice("/api/dashboard/klantenbeheer".length), undefined, { c: null })).status, 200);
  assert.equal((await winkel("agenda").list({ prefix: "hash/" })).blobs.length, 1);
});

test("agenda: token van een gebruiker die niet meer bestaat werkt niet; POST eist json en same-origin", async () => {
  const m = js(await vraag("POST", "/agenda/token", {}, { c: ruben }));
  const pad = new URL(m.url).pathname.slice("/api/dashboard/klantenbeheer".length);
  process.env.DASHBOARD_GEBRUIKERS = JSON.stringify({ Kevin: "x" });
  assert.equal((await vraag("GET", pad, undefined, { c: null })).status, 404);
  const res = await h(new Request(`${B}/agenda/token`, { method: "POST", headers: { cookie: kevin, "content-type": "text/plain" }, body: "x" }), CTX);
  assert.equal(res.status, 415);
  assert.equal((await vraag("POST", "/agenda/token", {}, { headers: { "sec-fetch-site": "cross-site" } })).status, 403);
});

test("echte data aan zonder deploy-context: 500, geen persoonsgegevens in de log", async () => {
  process.env.DASHBOARD_ECHTE_DATA = "aan";
  const log = [];
  const orig = console.error;
  console.error = (...a) => log.push(a.join(" "));
  try {
    const res = await h(new Request(`${B}/export`, { headers: { cookie: kevin } }), {});
    assert.equal(res.status, 500);
  } finally { console.error = orig; }
  assert.ok(!log.join(" ").includes("Test"));
});

test("na verwijderen: aanmaken van relatie of traject geeft 410, geen nieuwe logregels, register wordt niet hersteld", async () => {
  await zaai();
  assert.equal((await vraag("POST", "/beheer/verwijderen", { id: R1, bevestig: "Testman" })).status, 200);
  const nieuw = await vraag("POST", "/relaties", { id: R1, wijzigingId: "w-opnieuw", velden: { achternaam: "Terug", status: "Nieuw" } }, { handler: klanten });
  assert.equal(nieuw.status, 410, nieuw.tekst);
  const traj = await vraag("POST", `/relaties/${R1}/trajecten`, { id: "t_nieuw", wijzigingId: "w-tn", velden: { fase: "Aanvraag ingediend" } }, { handler: klanten });
  assert.equal(traj.status, 410, traj.tekst);
  assert.equal(await winkel().get(`relatie/${R1}`), null);
  assert.equal((await winkel().list({ prefix: `log/${R1}/` })).blobs.length, 0);
  assert.equal((await winkel().list({ prefix: `logwacht/${R1}/` })).blobs.length, 0);
  // Een achtergebleven trajectrecord van de verwijderde relatie wordt niet in het register hersteld.
  await winkel().setJSON("traject/t_wees", { id: "t_wees", relatieId: R1, fase: "Besluit" });
  await vergelijkRegister(NU);
  const reg = await winkel().get("register/trajecten", { type: "json" });
  assert.ok(!reg.ids.t_wees);
  // Een andere relatie is niet geraakt.
  assert.equal((await vraag("POST", "/relaties", { id: "r_cccc", wijzigingId: "w-c", velden: { achternaam: "Nieuw", status: "Nieuw" } }, { handler: klanten })).status, 201);
});

test("herhaald verwijderen na een halve poging: tombstone en relatie weg, rest wordt zonder bevestiging opgeruimd, ok", async () => {
  await zaai();
  // Halve poging: tombstone geschreven en relatie gewist, de rest staat nog.
  await winkel().setJSON(`tombstone/${R1}`, { id: R1, verwijderdOp: NU.toISOString(), wie: "Kevin" });
  await winkel().delete(`relatie/${R1}`);
  await winkel().setJSON(`logwacht/${R1}/w-x@2026#abc`, { op: "x", regels: [] });
  // Een traject zonder registeritem wordt via list() gevonden.
  await winkel().setJSON("traject/t_los", { id: "t_los", relatieId: R1, fase: "Besluit" });
  const r = await vraag("POST", "/beheer/verwijderen", { id: R1 });
  assert.equal(r.status, 200, r.tekst);
  assert.equal(js(r).alVerwijderd, true);
  assert.equal(await winkel().get(`traject/${T1}`), null);
  assert.equal(await winkel().get("traject/t_los"), null);
  assert.equal((await winkel().list({ prefix: `log/${R1}/` })).blobs.length, 0);
  assert.equal((await winkel().list({ prefix: `logwacht/${R1}/` })).blobs.length, 0);
  assert.deepEqual(Object.keys((await winkel().get("index/relaties", { type: "json" })).rijen), [R2]);
  // En nog een keer: nog steeds ok.
  assert.equal((await vraag("POST", "/beheer/verwijderen", { id: R1 })).status, 200);
  // Zonder tombstone en zonder relatie blijft het 404.
  assert.equal((await vraag("POST", "/beheer/verwijderen", { id: "r_nooit" })).status, 404);
});

test("export: tijdlijn in de JSON, traject zonder register uit list(), waarschuwing bij onleesbaar record", async () => {
  await zaai();
  await winkel().setJSON("traject/t_los", { id: "t_los", relatieId: R2, fase: "Besluit" });
  const d = js(await vraag("GET", "/export"));
  assert.ok(d.trajecten.some((t) => t.id === "t_los"));
  assert.ok(d.tijdlijnen[R1].length > 0);
  assert.deepEqual(d.waarschuwingen, []);
  const orig = winkel().get;
  winkel().get = async (k, o) => { if (k === `traject/${T2}`) throw new Error("kapot"); return orig(k, o); };
  const r = await vraag("GET", "/export?formaat=csv&soort=trajecten");
  assert.equal(r.status, 200);
  assert.match(r.headers.get("x-export-waarschuwing"), /onleesbaar:1/);
  const j = await vraag("GET", "/export");
  winkel().get = orig;
  assert.match(js(j).waarschuwingen[0], /onleesbaar/);
});

test("agenda-token: bij een conflict op gebruiker/<wie> ruimt het verzoek zijn eigen hash op en probeert opnieuw", async () => {
  const a = winkel("agenda");
  const orig = a.setJSON;
  let eerste = true;
  a.setJSON = async (k, v, o) => {
    if (k.startsWith("gebruiker/") && eerste) { eerste = false; return { modified: false }; }
    return orig(k, v, o);
  };
  const m = js(await vraag("POST", "/agenda/token", {}));
  assert.equal(m.ok, true);
  assert.equal((await a.list({ prefix: "hash/" })).blobs.length, 1);
  // Blijft het conflict, dan 503.
  a.setJSON = async (k, v, o) => (k.startsWith("gebruiker/") ? { modified: false } : orig(k, v, o));
  const f = await vraag("POST", "/agenda/token", {});
  assert.equal(f.status, 503);
  assert.equal((await a.list({ prefix: "hash/" })).blobs.length, 1);
});

test("dagelijkse run ruimt na een race weestrajecten, logs en indexrijen van een verwijderde relatie op", async () => {
  await zaai();
  await vraag("POST", "/beheer/verwijderen", { id: R1, bevestig: "Testman" });
  // Race-resten: een terug-geschreven relatie, traject, logregel en indexrij.
  await winkel().setJSON(`relatie/${R1}`, { id: R1, achternaam: "Testman" });
  await winkel().setJSON("traject/t_wees", { id: "t_wees", relatieId: R1, fase: "Besluit" });
  await winkel().setJSON(`log/${R1}/x@1-000`, { op: "1" });
  const reg = await winkel().get("register/trajecten", { type: "json" });
  await winkel().setJSON("register/trajecten", { ids: { ...reg.ids, t_wees: { relatieId: R1, aangemaakt: "2026-11-10T08:00:00.000Z" } } });
  const idx = await winkel().get("index/relaties", { type: "json" });
  await winkel().setJSON("index/relaties", { rijen: { ...idx.rijen, [R1]: { id: R1 } } });
  const hs = await voerDagelijksUit({ nu: NU, regels: REGELS });
  assert.equal(hs.aantallen.tombstonesOpgeruimd, 1);
  assert.equal(await winkel().get(`relatie/${R1}`), null);
  assert.equal(await winkel().get("traject/t_wees"), null);
  assert.equal((await winkel().list({ prefix: `log/${R1}/` })).blobs.length, 0);
  assert.ok(!(await winkel().get("register/trajecten", { type: "json" })).ids.t_wees);
  assert.ok(!(await winkel().get("index/relaties", { type: "json" })).rijen[R1]);
  assert.ok(await winkel().get(`relatie/${R2}`), "andere relatie ongemoeid");
});

test("maakTraject: wordt de relatie tijdens het aanmaken verwijderd, dan verdwijnen record en registeritem en volgt 410", async () => {
  await zaai();
  const orig = winkel().get;
  let n = 0;
  winkel().get = async (k, o) => {
    if (k === `tombstone/${R2}`) { n++; if (n === 1) return null; return { id: R2, verwijderdOp: "x", wie: "Kevin" }; }
    return orig(k, o);
  };
  const r = await vraag("POST", `/relaties/${R2}/trajecten`, { id: "t_race", wijzigingId: "w-race", velden: { fase: "Aanvraag ingediend" } }, { handler: klanten });
  winkel().get = orig;
  assert.equal(r.status, 410, r.tekst);
  assert.equal(await winkel().get("traject/t_race"), null);
  assert.ok(!(await winkel().get("register/trajecten", { type: "json" })).ids.t_race);
});

// ---------- koppeling K11 en K9: instroomclaims bij AVG-verwijderen ----------
test("verwijderen haalt de instroomclaim van de relatie weg (idempotent); andere claims blijven; de dagelijkse run ruimt een late claim op", async () => {
  process.env.DASHBOARD_INSTROOM_GEHEIM = "verzonnen-testgeheim-0123456789";
  try {
    const aanvraag = (huisnummer) => ({
      spam: false, voorWie: "eigenaar", postcode: "9999 ZZ", huisnummer, straat: "Teststraat", plaats: "Testplaats",
      voornaam: "Test", achternaam: "Testpersoon", telefoon: "0612345678", email: "", contactvoorkeur: "bellen", bron: "", pagina: "/",
    });
    const a = await neemAanvraagOp(aanvraag("12"), NU);
    const b = await neemAanvraagOp(aanvraag("14"), NU);
    assert.equal(a.ok && b.ok, true);
    const claims = async () => {
      const { blobs } = await winkel().list({ prefix: "ontdubbel/instroom/" });
      return Promise.all(blobs.map(async (x) => (await winkel().get(x.key, { type: "json" })).relatieId));
    };
    assert.deepEqual((await claims()).sort(), [a.relatieId, b.relatieId].sort());

    const r = await vraag("POST", "/beheer/verwijderen", { id: a.relatieId, bevestig: "Testpersoon" });
    assert.equal(r.status, 200, r.tekst);
    assert.equal(js(r).verwijderd.claims, 1);
    assert.deepEqual(await claims(), [b.relatieId], "alleen de claim van de verwijderde relatie is weg");

    // Herhaald verwijderen: geen fout, niets meer te wissen.
    const r2 = await vraag("POST", "/beheer/verwijderen", { id: a.relatieId });
    assert.equal(r2.status, 200, r2.tekst);
    assert.equal(js(r2).alVerwijderd, true);
    assert.equal(js(r2).verwijderd.claims, 0);

    // Race: een claim die na het verwijderen nog naar de relatie wijst, verdwijnt in de dagelijkse run (stap index).
    await winkel().setJSON("ontdubbel/instroom/laat", { relatieId: a.relatieId, op: NU.toISOString(), h2: "x", hv: {} });
    const hs = await voerDagelijksUit({ nu: NU, regels: REGELS });
    assert.equal(hs.aantallen.tombstonesOpgeruimd, 1);
    assert.deepEqual(await claims(), [b.relatieId]);
    // Een nieuwe aanvraag met dezelfde gegevens geeft daarna een nieuwe relatie, niet de verwijderde.
    const c = await neemAanvraagOp(aanvraag("12"), new Date(NU.getTime() + 60000));
    assert.equal(c.ok, true, JSON.stringify(c));
    assert.notEqual(c.relatieId, a.relatieId);
  } finally {
    delete process.env.DASHBOARD_INSTROOM_GEHEIM;
  }
});

// ---------- fixes eindreview: 410, tijdslimieten, tombstone-termijn ----------
test("na verwijderen: lezen, wijzigen, tijdlijn, afvinken en heropenen geven 410 (niet 404); een onbekend id blijft 404", async () => {
  await zaai();
  // Een traject-record dat na een race nog bestaat terwijl de relatie weg is: ook 410.
  await vraag("POST", "/beheer/verwijderen", { id: R1, bevestig: "Testman" });
  const lees = await vraag("GET", `/relaties/${R1}`, undefined, { handler: klanten });
  assert.equal(lees.status, 410, lees.tekst);
  assert.equal((await vraag("PATCH", `/relaties/${R1}`, { wijzigingId: "w-nieuw1", velden: { telefoon: "0600000000" } }, { handler: klanten })).status, 410);
  assert.equal((await vraag("GET", `/relaties/${R1}/tijdlijn`, undefined, { handler: klanten })).status, 410);
  assert.equal((await vraag("GET", "/relaties/r_onbekend", undefined, { handler: klanten })).status, 404);
  assert.equal((await vraag("PATCH", "/relaties/r_onbekend", { wijzigingId: "w-nieuw2", velden: { telefoon: "0600000000" } }, { handler: klanten })).status, 404);
  await winkel().setJSON("traject/t_wees", { id: "t_wees", relatieId: R1, fase: "Aanvraag ingediend", toegepast: [] });
  assert.equal((await vraag("PATCH", "/trajecten/t_wees", { wijzigingId: "w-nieuw3", velden: { fase: "Besluit" } }, { handler: klanten })).status, 410);
  const regel = REGELS.find((r) => r.record === "traject").id;
  assert.equal((await vraag("POST", `/trajecten/t_wees/termijnen/${regel}/afvinken`, { wijzigingId: "w-nieuw4" }, { handler: klanten })).status, 410);
  assert.equal((await vraag("POST", `/trajecten/t_wees/termijnen/${regel}/heropenen`, { wijzigingId: "w-nieuw5" }, { handler: klanten })).status, 410);
});

test("beheer/verwijderen met een verlopen tijdsbudget: ok met deels:true; de dagelijkse run maakt het af en zet opgeruimdOp", async () => {
  await zaai();
  const hKlein = maakHandler({ regels: REGELS, nu: () => NU, verwijderBudgetMs: 0 });
  const r = await vraag("POST", "/beheer/verwijderen", { id: R1, bevestig: "Testman" }, { handler: hKlein });
  assert.equal(r.status, 200, r.tekst);
  assert.equal(js(r).ok, true);
  assert.equal(js(r).deels, true);
  assert.ok(await winkel().get(`tombstone/${R1}`), "tombstone staat er al");
  assert.equal(await winkel().get(`relatie/${R1}`), null);
  assert.ok(await winkel().get(`traject/${T1}`), "het traject is nog niet opgeruimd");
  assert.equal((await vraag("GET", `/relaties/${R1}`, undefined, { handler: klanten })).status, 410);
  const hs = await voerDagelijksUit({ nu: NU, regels: REGELS });
  assert.equal(hs.aantallen.tombstonesOpgeruimd, 1);
  assert.equal(await winkel().get(`traject/${T1}`), null);
  assert.equal((await winkel().list({ prefix: `log/${R1}/` })).blobs.length, 0);
  const tomb = await winkel().get(`tombstone/${R1}`, { type: "json" });
  assert.equal(tomb.opgeruimdOp, NU.toISOString());
  // Zonder tijdsprobleem: geen deels-veld.
  const r2 = await vraag("POST", "/beheer/verwijderen", { id: R2, bevestig: "=Formule" });
  assert.equal(js(r2).deels, undefined);
});

test("dagelijkse run: tombstone met opgeruimdOp ouder dan 7 dagen wordt overgeslagen, jonger of zonder niet; opgeruimdOp schuift niet op", async () => {
  await zaai();
  await vraag("POST", "/beheer/verwijderen", { id: R1, bevestig: "Testman" });
  const dag = 24 * 3600 * 1000;
  const run1 = await voerDagelijksUit({ nu: new Date(NU.getTime() + dag), regels: REGELS });
  assert.equal(run1.aantallen.tombstonesOpgeruimd, 1);
  const eerste = (await winkel().get(`tombstone/${R1}`, { type: "json" })).opgeruimdOp;
  assert.equal(eerste, new Date(NU.getTime() + dag).toISOString());
  const run2 = await voerDagelijksUit({ nu: new Date(NU.getTime() + 3 * dag), regels: REGELS });
  assert.equal(run2.aantallen.tombstonesOpgeruimd, 1, "binnen 7 dagen nog een keer");
  assert.equal((await winkel().get(`tombstone/${R1}`, { type: "json" })).opgeruimdOp, eerste);
  // Race-rest na 9 dagen: wordt niet meer opgeruimd.
  await winkel().setJSON("traject/t_laat", { id: "t_laat", relatieId: R1, fase: "Besluit" });
  const run3 = await voerDagelijksUit({ nu: new Date(NU.getTime() + 9 * dag), regels: REGELS });
  assert.equal(run3.aantallen.tombstonesOpgeruimd, 0);
  assert.equal(run3.aantallen.tombstonesOvergeslagen, 1);
  assert.ok(await winkel().get("traject/t_laat"));
});

test("dagelijkse run: de lijst met trajecten wordt één keer gelezen, ook bij meer tombstones; een mislukte tombstone stopt de rest niet en de index wordt herbouwd", async () => {
  await zaai();
  const s = winkel();
  const origList = s.list;
  const origDel = s.delete;
  let trajectLijsten = 0;
  s.list = async (o) => { if (o?.prefix === "traject/") trajectLijsten++; return origList(o); };
  await voerDagelijksUit({ nu: NU, regels: REGELS }); // zonder tombstones: de basis voor de telling
  const basis = trajectLijsten;
  trajectLijsten = 0;
  s.list = origList;
  await vraag("POST", "/beheer/verwijderen", { id: R1, bevestig: "Testman" });
  await vraag("POST", "/beheer/verwijderen", { id: R2, bevestig: "=Formule" });
  s.list = async (o) => { if (o?.prefix === "traject/") trajectLijsten++; return origList(o); };
  // De tombstone van R1 geeft een fout bij het verwijderen van het relatierecord (alleen in deze run).
  s.delete = async (k) => { if (k === `relatie/${R1}`) throw new Error("kapot"); return origDel(k); };
  let hs;
  try { hs = await voerDagelijksUit({ nu: NU, regels: REGELS }); } finally { s.list = origList; s.delete = origDel; }
  assert.equal(trajectLijsten, basis + 1, "één extra lijst voor alle tombstones samen");
  assert.equal(hs.aantallen.tombstonesMislukt, 1);
  assert.equal(hs.aantallen.tombstonesOpgeruimd, 1);
  assert.ok(typeof hs.aantallen.indexRijen === "number", "index is toch herbouwd");
  assert.ok(hs.fouten.some((f) => f.stap === "index" && f.soort === "tombstones-niet-opgeruimd"));
  assert.equal((await s.get(`tombstone/${R1}`, { type: "json" })).opgeruimdOp, undefined, "mislukt: geen opgeruimdOp");
  assert.ok((await s.get(`tombstone/${R2}`, { type: "json" })).opgeruimdOp);
});

test("elk antwoord van de API heeft X-Content-Type-Options: nosniff", async () => {
  const r = await vraag("GET", "/export");
  assert.equal(r.headers.get("x-content-type-options"), "nosniff");
  assert.equal((await vraag("GET", "/export", undefined, { c: null })).headers.get("x-content-type-options"), "nosniff");
});

test("ruimOp haalt register en index altijd eerst weg, ook bij een verlopen budget", async () => {
  await zaai();
  const hKlein = maakHandler({ regels: REGELS, nu: () => NU, verwijderBudgetMs: 0 });
  const r = await vraag("POST", "/beheer/verwijderen", { id: R1, bevestig: "Testman" }, { handler: hKlein });
  assert.equal(js(r).deels, true);
  const reg = await winkel().get("register/trajecten", { type: "json" });
  assert.ok(!reg.ids[T1], "registeritem weg");
  const index = await winkel().get("index/relaties", { type: "json" });
  assert.ok(!index.rijen[R1], "indexrij weg");
  assert.ok(await winkel().get(`traject/${T1}`), "het begrensde werk bleef liggen");
});

test("tombstone-traject: na verwijderen geven PATCH, afvinken en heropenen op het (gewiste) traject 410; een onbekend traject blijft 404", async () => {
  await zaai();
  assert.equal((await vraag("POST", "/beheer/verwijderen", { id: R1, bevestig: "Testman" })).status, 200);
  assert.equal(await winkel().get(`traject/${T1}`), null);
  const tomb = await winkel().get(`tombstone-traject/${T1}`, { type: "json" });
  assert.deepEqual(tomb, { id: T1 });
  const regel = REGELS.find((x) => x.record === "traject").id;
  assert.equal((await vraag("PATCH", `/trajecten/${T1}`, { wijzigingId: "w-p1", velden: { fase: { oud: "Aanvraag ingediend", nieuw: "Besluit" } } }, { handler: klanten })).status, 410);
  assert.equal((await vraag("POST", `/trajecten/${T1}/termijnen/${regel}/afvinken`, { wijzigingId: "w-p2" }, { handler: klanten })).status, 410);
  assert.equal((await vraag("POST", `/trajecten/${T1}/termijnen/${regel}/heropenen`, { wijzigingId: "w-p3" }, { handler: klanten })).status, 410);
  assert.equal((await vraag("PATCH", "/trajecten/t_onbekend", { wijzigingId: "w-p4", velden: { fase: { oud: "a", nieuw: "b" } } }, { handler: klanten })).status, 404);
  // Het traject van de andere relatie is niet geraakt.
  assert.equal(await winkel().get(`tombstone-traject/${T2}`), null);
});

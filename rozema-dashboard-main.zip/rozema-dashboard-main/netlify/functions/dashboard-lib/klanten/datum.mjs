// Datumrekenen voor de termijnengine. Datums zijn "YYYY-MM-DD"; gerekend wordt op UTC-middag,
// zodat zomer-/wintertijd nooit een dag laat verschuiven. Geen enkele termijn staat hier vast.
import { isIsoDatum, isIsoTijdstip } from "./model.mjs";

export const EENHEDEN = ["dagen", "weken", "maanden"];
export const TELLINGEN = ["dag-na-start", "zelfde-dag"];
export const WEEKEND_REGELS = ["doorschuiven", "niet"];

const DAG_MS = 86400000;
const naarUtc = (iso) => {
  if (!isIsoDatum(iso)) throw new Error(`ongeldige datum: ${String(iso)}`);
  return new Date(`${iso}T12:00:00Z`);
};
const naarIso = (d) => d.toISOString().slice(0, 10);

// "Vandaag" volgens Europe/Amsterdam (Functions draaien in de VS).
export function vandaagAmsterdam(nu = new Date()) {
  const delen = new Intl.DateTimeFormat("nl-NL", { timeZone: "Europe/Amsterdam", year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(nu);
  const g = (t) => delen.find((p) => p.type === t).value;
  return `${g("year")}-${g("month")}-${g("day")}`;
}

// Datum of tijdstip -> datum (Amsterdam). Leeg -> null; onzin -> fout.
export function datumVan(waarde) {
  if (waarde === null || waarde === undefined || waarde === "") return null;
  if (typeof waarde === "string" && isIsoDatum(waarde)) return waarde;
  // Tijdstip: echte kalenderdatum en Z of offset verplicht.
  if (isIsoTijdstip(waarde)) return vandaagAmsterdam(new Date(waarde));
  throw new Error(`ongeldige datum: ${String(waarde)}`);
}

export const plusDagen = (iso, n) => naarIso(new Date(naarUtc(iso).getTime() + n * DAG_MS));

export function plusMaanden(iso, n) {
  const d = naarUtc(iso);
  const dag = d.getUTCDate();
  const doel = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + n, 1, 12));
  const laatste = new Date(Date.UTC(doel.getUTCFullYear(), doel.getUTCMonth() + 1, 0, 12)).getUTCDate();
  doel.setUTCDate(Math.min(dag, laatste));
  return naarIso(doel);
}

export function plusEenheid(iso, aantal, eenheid) {
  if (!Number.isInteger(aantal) || aantal < 1) throw new Error("ongeldig aantal");
  if (eenheid === "dagen") return plusDagen(iso, aantal);
  if (eenheid === "weken") return plusDagen(iso, aantal * 7);
  if (eenheid === "maanden") return plusMaanden(iso, aantal);
  throw new Error(`onbekende eenheid: ${String(eenheid)}`);
}

// Hele dagen van a naar b (b later = positief).
export const dagenTussen = (a, b) => Math.round((naarUtc(b).getTime() - naarUtc(a).getTime()) / DAG_MS);

// 0 = zondag ... 6 = zaterdag.
export const weekdag = (iso) => naarUtc(iso).getUTCDay();

export function isWerkdag(iso, feestdagen = []) {
  const w = weekdag(iso);
  return w !== 0 && w !== 6 && !feestdagen.includes(iso);
}

// Eerstvolgende werkdag op of na `iso`.
export function schuifNaarWerkdag(iso, feestdagen = []) {
  let d = iso;
  for (let i = 0; i < 400 && !isWerkdag(d, feestdagen); i++) d = plusDagen(d, 1);
  if (!isWerkdag(d, feestdagen)) throw new Error("geen werkdag gevonden");
  return d;
}

// Einddatum van een termijn.
// - "dag-na-start": de startdag telt niet mee (dag 1 is de dag erna): einde = start + duur.
// - "zelfde-dag": de startdag telt als dag 1: einde = start + duur - 1 dag.
// - weekendFeestdag "doorschuiven": valt het einde op weekend/feestdag, dan de eerstvolgende werkdag;
//   "niet": niet doorschuiven.
// Alle parameters verplicht; onbekende waarden gooien een fout (de engine geeft dan geen datum).
export function berekenEinddatum(start, duur, telling, weekendFeestdag, feestdagen = []) {
  if (!TELLINGEN.includes(telling)) throw new Error(`onbekende telling: ${String(telling)}`);
  if (!WEEKEND_REGELS.includes(weekendFeestdag)) throw new Error(`onbekende weekendregel: ${String(weekendFeestdag)}`);
  let eind = plusEenheid(start, duur?.aantal, duur?.eenheid);
  if (telling === "zelfde-dag") eind = plusDagen(eind, -1);
  return weekendFeestdag === "doorschuiven" ? schuifNaarWerkdag(eind, feestdagen) : eind;
}

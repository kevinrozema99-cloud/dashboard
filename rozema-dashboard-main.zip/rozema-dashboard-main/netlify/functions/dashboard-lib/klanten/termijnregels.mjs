// Termijnregels: de Zoho-workflowregels precies nagebouwd (KLANTEN-ARCHITECTUUR.md §2 + Aanvulling).
//
// HARDE REGEL: in dit bestand staat GEEN ENKELE duur, telling, weekendregel of feestdag met een echte
// waarde. Alles is null tot Kevin of Ruben het uit K1 bevestigt (taak K0). Test T20 bewaakt dit.
// Onbekend is veilig: duur.aantal === null -> "niet-bevestigd"; fataal === null -> behandeld als fataal;
// titel === null -> "Actie uit Zoho-regel '<zoho>', inhoud nog onbekend".
//
// Regelvorm:
//  id, zoho (naam in Zoho), record ("relatie"|"traject"), titel,
//  alsLeeg (veldnaam: regel geldt alleen als dat veld leeg is),
//  start: {soort: "aangemaakt"|"status"|"fase"|"veld", waarde},
//  duur: {aantal, eenheid}, telling ("dag-na-start"|"zelfde-dag"), weekendFeestdag ("doorschuiven"|"niet"),
//  geldtVoor: {routes, fases} | null, geldtZolang: {status: [...]} | {fase: [...]} | null (alleen niet-fatale regels),
//  vereistVanafFase, fataal (true|false|null), actief, afvinkActies, vervolgActie, voorstelUitZoho, bron,
//  bevestigd: {door, op, bron} | null.

import { STATUSSEN } from "./model.mjs";

// Feestdagen ("YYYY-MM-DD"): leeg tot K1 het zegt.
export const FEESTDAGEN = Object.freeze([]);

const BRON = "KLANTEN-ARCHITECTUUR.md, Aanvulling";
const NIET_BEVESTIGD = { duur: { aantal: null, eenheid: null }, telling: null, weekendFeestdag: null, bevestigd: null };

// De null-standaard geldt alleen waar de regel zelf niets opgeeft (de catalogus geeft niets op).
export function maakRegel(r) {
  return Object.freeze({
    geldtVoor: null, geldtZolang: null, alsLeeg: null, vereistVanafFase: null, afvinkActies: Object.freeze([]), vervolgActie: null,
    voorstelUitZoho: null, actief: true, bron: BRON, ...NIET_BEVESTIGD, ...r,
    duur: Object.freeze({ ...(r.duur ?? NIET_BEVESTIGD.duur) }),
  });
}
const regel = maakRegel;

const BESLUIT = "Deal: termijnen na besluitbrief";

export const CATALOGUS = Object.freeze([
  // Zoho-voorwaarde: bij maken, "Lead Status IS NIET Afgevallen". Gecombineerd met de leadketen: geldt zolang status Nieuw.
  regel({ id: "lead-bellen", zoho: "Lead: nieuwe lead bellen", record: "relatie", titel: "Bellen: nieuwe lead", start: { soort: "aangemaakt", waarde: null },
    geldtZolang: { status: ["Nieuw"] }, fataal: false, vervolgActie: { status: "Poging 1" } }),
  // Einde van de titel is aangevuld: in de schermafdruk was "(ander moment van de ..." afgekapt.
  regel({ id: "lead-poging-2", zoho: "Lead: belpoging 2 na Poging 1", record: "relatie", titel: "Belpoging 2 (ander moment van de dag)",
    start: { soort: "status", waarde: "Poging 1" }, geldtZolang: { status: ["Poging 1"] }, fataal: false, vervolgActie: { status: "Poging 2" } }),
  regel({ id: "lead-poging-3", zoho: "Lead: belpoging 3 na Poging 2", record: "relatie", titel: "Belpoging 3",
    start: { soort: "status", waarde: "Poging 2" }, geldtZolang: { status: ["Poging 2"] }, fataal: false, vervolgActie: { status: "Poging 3" } }),
  // Einde van de titel is aangevuld: in de schermafdruk was "(laatste po..." afgekapt.
  regel({ id: "lead-whatsapp", zoho: "Lead: WhatsApp na Poging 3", record: "relatie", titel: "WhatsApp-bericht sturen (laatste poging)",
    start: { soort: "status", waarde: "Poging 3" }, geldtZolang: { status: ["Poging 3"] }, fataal: false, vervolgActie: { status: "WhatsApp verstuurd" } }),
  // Einde van de titel is aangevuld: in de schermafdruk was "Zet op A..." afgekapt (vermoedelijk "Afgevallen").
  regel({ id: "lead-afsluiten", zoho: "Lead: afsluiten na WhatsApp", record: "relatie", titel: "Geen reactie op WhatsApp? Zet op Afgevallen",
    start: { soort: "status", waarde: "WhatsApp verstuurd" }, geldtZolang: { status: ["WhatsApp verstuurd"] }, fataal: false,
    vervolgActie: { status: "Afgevallen", redenAfgevallen: "Niet bereikt" } }),
  // VANGNET (Zoho: uit, Ruben beslist nog, vraag 13): status Contact gehad, Keukentafelgesprek gedaan of Later
  // opnieuw EN terugbeldatum leeg -> taak "Terugbeldatum zetten". Startdatum = laatste wissel naar die status.
  regel({ id: "lead-terugbeldatum", zoho: "Lead: vangnet terugbeldatum", record: "relatie", titel: "Terugbeldatum zetten",
    start: { soort: "status", waarde: ["Contact gehad", "Keukentafelgesprek gedaan", "Later opnieuw"] },
    geldtZolang: { status: ["Contact gehad", "Keukentafelgesprek gedaan", "Later opnieuw"] }, alsLeeg: "terugbeldatum",
    fataal: false, actief: false }),
  // Nieuw in het dashboard, niet uit Zoho (daarom zoho: null).
  regel({ id: "lead-terugbellen", zoho: null, record: "relatie", titel: "Terugbellen",
    start: { soort: "veld", waarde: "terugbeldatum" }, geldtZolang: { status: STATUSSEN.filter((s) => !["Afgevallen", "Klant", "Niet gekwalificeerd"].includes(s)) },
    fataal: false }),
  // Zoho-voorwaarde: opnamedatum niet leeg (niet aan een fase gebonden).
  regel({ id: "deal-opname", zoho: "Deal: opname voorbereiden", record: "traject", titel: "Opname voorbereiden",
    start: { soort: "veld", waarde: "opnamedatum" }, fataal: false }),
  // In Zoho: "Zienswijze indienen (termijn 2 weken)". De 2 weken is alleen een voorstel, geen bevestigde duur.
  regel({ id: "deal-zienswijze", zoho: "Deal: zienswijze na adviesrapport", record: "traject", titel: "Zienswijze indienen",
    start: { soort: "veld", waarde: "datumAdviesrapport" }, vereistVanafFase: "Adviesrapport", fataal: null, voorstelUitZoho: Object.freeze({ aantal: 2, eenheid: "weken" }) }),
  // "Deal: termijnen na besluitbrief" (3 acties), voorwaarde: verzenddatum besluitbrief niet leeg.
  regel({ id: "deal-besluit-controleren", zoho: BESLUIT, record: "traject", titel: "Besluit controleren",
    start: { soort: "veld", waarde: "verzenddatumBesluitbrief" }, vereistVanafFase: "Besluit", fataal: null }),
  regel({ id: "deal-bezwaar-beslissen", zoho: BESLUIT, record: "traject", titel: "Bezwaar beslissen",
    start: { soort: "veld", waarde: "verzenddatumBesluitbrief" }, vereistVanafFase: "Besluit", fataal: null }),
  // Titel in Zoho: "FATALE TERMIJN: bezwaar uiterlijk o..." (afgekapt); <einddatum> wordt door de engine ingevuld.
  regel({ id: "deal-bezwaar", zoho: BESLUIT, record: "traject", titel: "Fatale termijn: bezwaar uiterlijk op <einddatum>",
    start: { soort: "veld", waarde: "verzenddatumBesluitbrief" }, vereistVanafFase: "Besluit", fataal: true,
    afvinkActies: Object.freeze(["Bezwaar ingediend", "Besluit geaccepteerd"]) }),
  regel({ id: "deal-factuur", zoho: "Deal: factuur na uitbetaling", record: "traject", titel: "Factuur sturen",
    start: { soort: "fase", waarde: "Uitbetaald" }, geldtZolang: { fase: ["Uitbetaald"] }, fataal: false }),
]);

// Bewust NIET in de catalogus:
// - "Deal: dealnaam uit contact": geen taak; de naam wordt getoond als weergavenaam (model.mjs).
// - "Big Deal Rule": Zoho-voorbeeld, staat uit.
// - De vier "Kwalificatie: ..."-regels: 0 acties, staan uit (vraag 14).

const FATAAL_WAARDEN = [true, false, null];
const SOORTEN = ["aangemaakt", "status", "fase", "veld"];

// Structuurcontrole van een regellijst; geeft een lijst foutteksten (leeg = in orde).
export function valideerRegels(regels) {
  const fouten = [];
  const ids = new Set();
  for (const r of regels) {
    if (!r || typeof r.id !== "string") { fouten.push("regel zonder id"); continue; }
    if (ids.has(r.id)) fouten.push(`dubbel id ${r.id}`);
    ids.add(r.id);
    if (!["relatie", "traject"].includes(r.record)) fouten.push(`${r.id}: record`);
    if (!r.start || !SOORTEN.includes(r.start.soort)) fouten.push(`${r.id}: start.soort`);
    if (!FATAAL_WAARDEN.includes(r.fataal)) fouten.push(`${r.id}: fataal`);
    if (typeof r.actief !== "boolean") fouten.push(`${r.id}: actief`);
    if (!r.duur || !("aantal" in r.duur)) fouten.push(`${r.id}: duur`);
    // Fatale regels (fataal true of null) kunnen niet uit of beperkt worden: ze blijven tot afgevinkt.
    if (r.fataal !== false) {
      if (r.actief === false) fouten.push(`${r.id}: fatale regel kan niet actief:false zijn`);
      if (r.geldtVoor) fouten.push(`${r.id}: fatale regel kan geen geldtVoor hebben`);
      if (r.alsLeeg) fouten.push(`${r.id}: fatale regel kan geen alsLeeg hebben`);
      if (r.geldtZolang) fouten.push(`${r.id}: fatale regel kan geen geldtZolang hebben`);
    }
    if (r.zoho !== null && typeof r.zoho !== "string") fouten.push(`${r.id}: zoho`);
  }
  return fouten;
}

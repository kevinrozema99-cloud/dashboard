// Takenlijst (opdracht Ruben 20-11-2026): alles wat er te doen is, op één plek, zodat niets gemist wordt.
// Pure functies; de route leest index en trajecten en geeft ze hier door.
//
// Een taak komt uit één van drie bronnen:
//   flow       de volgende stap bij de status of fase (flow.mjs); klaar = de kaart verder zetten
//   handmatig  een taak of afspraak op de klant (relatie.taken); klaar = afvinken
//   termijn    een termijn uit termijnregels.mjs met een berekende einddatum (pas als de duur bevestigd is)
// Een relatie zonder eigenaar staat bij "toewijzen" en levert nog geen flow-taken op.
import { ARCHIEF_STATUSSEN, EIGENAREN, isIsoDatum } from "./model.mjs";
import { leadTaak, klantTaak, alsLead } from "./flow.mjs";
import { STATUS, termijnenVoor } from "./termijnen.mjs";

const isObj = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
const naamVan = (r) => [r?.voornaam, r?.achternaam].filter((x) => typeof x === "string" && x.trim()).join(" ") || r?.naam || null;

function basis(rij) {
  return { relatieId: rij.id, naam: naamVan(rij), plaats: rij.plaats ?? null, telefoon: rij.telefoon ?? null };
}

// Alle taken van één relatie (indexrij) en haar trajecten. eigenaar null = nog toe te wijzen: geen flow-taken.
export function takenVanRelatie(rij, trajecten, regels, vandaag) {
  const uit = [];
  const b = basis(rij);
  const eigenaar = rij.eigenaar ?? null;
  for (const t of Array.isArray(rij.openTaken) ? rij.openTaken : []) {
    if (!isObj(t)) continue;
    uit.push({ ...b, id: `h:${rij.id}:${t.id}`, bron: "handmatig", taakId: t.id, titel: t.titel ?? null, soort: t.soort ?? "taak",
      datum: isIsoDatum(t.datum) ? t.datum : null, tijd: t.tijd ?? null, eigenaar: t.eigenaar ?? eigenaar });
  }
  if (!eigenaar || ARCHIEF_STATUSSEN.includes(rij.status)) return uit;
  const lead = rij.status !== "Klant" ? leadTaak(alsLead(rij), vandaag) : null;
  if (lead) uit.push({ ...b, id: `f:${rij.id}:${lead.stap}`, bron: "flow", stap: lead.stap, datum: lead.datum, eigenaar });
  for (const t of trajecten) {
    const k = klantTaak(t, vandaag);
    if (k) uit.push({ ...b, id: `f:${t.id}:${k.stap}`, bron: "flow", stap: k.stap, datum: k.datum, eigenaar, trajectId: t.id, fase: t.fase });
    // Wettelijke termijnen alleen met een berekende datum; de rest is instelwerk (Termijnregels), geen taak.
    let termijnen = [];
    try { termijnen = termijnenVoor(t, null, regels, vandaag); } catch { termijnen = []; }
    for (const tm of termijnen) {
      if (tm.status !== STATUS.OPEN || !isIsoDatum(tm.einddatum)) continue;
      uit.push({ ...b, id: `t:${t.id}:${tm.regelId}`, bron: "termijn", regelId: tm.regelId, titel: tm.titel ?? null,
        datum: tm.einddatum, eigenaar, trajectId: t.id, fataal: tm.fataal === true });
    }
  }
  return uit;
}

// rijen: index-rijen (array); trajecten: records; wie: "kevin" | "ruben" | null (= iedereen).
// Geeft {toewijzen, taken, telling}. Taken op datum, zonder datum achteraan.
export function maakTaken(rijen, trajecten, regels, vandaag, { wie = null } = {}) {
  const perRelatie = new Map();
  for (const t of Array.isArray(trajecten) ? trajecten : []) if (t?.relatieId) perRelatie.set(t.relatieId, [...(perRelatie.get(t.relatieId) ?? []), t]);
  const toewijzen = [];
  let taken = [];
  for (const rij of Array.isArray(rijen) ? rijen : []) {
    if (!isObj(rij)) continue;
    if (!rij.eigenaar && !ARCHIEF_STATUSSEN.includes(rij.status)) {
      toewijzen.push({ ...basis(rij), status: rij.status ?? null, bron: rij.bron ?? null, aangemaakt: rij.aangemaakt ?? null });
    }
    taken.push(...takenVanRelatie(rij, perRelatie.get(rij.id) ?? [], regels, vandaag));
  }
  if (wie) taken = taken.filter((t) => t.eigenaar === wie);
  taken.sort((a, b) => (a.datum ?? "9999").localeCompare(b.datum ?? "9999") || String(a.naam).localeCompare(String(b.naam), "nl") || a.id.localeCompare(b.id));
  toewijzen.sort((a, b) => String(a.aangemaakt ?? "").localeCompare(String(b.aangemaakt ?? "")) || a.relatieId.localeCompare(b.relatieId));
  const telling = {
    toewijzen: toewijzen.length,
    teLaat: taken.filter((t) => t.datum && t.datum < vandaag).length,
    vandaag: taken.filter((t) => t.datum === vandaag).length,
    totaal: taken.length,
  };
  return { toewijzen, taken, telling };
}

// Eerstvolgende taak van één relatie (voor "Alle klanten"), of null.
export function volgendeTaakVan(rij, trajecten, regels, vandaag) {
  const t = takenVanRelatie(rij, trajecten, regels, vandaag)
    .sort((a, b) => (a.datum ?? "9999").localeCompare(b.datum ?? "9999"))[0];
  return t ? { bron: t.bron, stap: t.stap ?? null, titel: t.titel ?? null, datum: t.datum ?? null, tijd: t.tijd ?? null } : null;
}

export const isEigenaar = (w) => EIGENAREN.includes(w);

// Klantenmodule K3: alle lees- en schrijfacties op store "klanten".
// Bron: dashboard/KLANTEN-ARCHITECTUUR.md §1 (Datamodel, Gelijktijdigheid, Tijdlijn) en §6 K3.
// Een latere overstap naar een database raakt alleen dit bestand.
//
// Geen console.log: logregels en records bevatten persoonsgegevens en blijven in de store.
// Fouten zijn codes: {ok:false, fouten:{veld|_: code}}. Codes die K4 moet vertalen: zie verslag.
import { randomUUID } from "node:crypto";
import { store } from "../opslag.mjs";
import { valideerRelatie, valideerTraject, wisselStatus, wisselFase, weergavenaam, isVanafBesluit } from "./model.mjs";
import { termijnenVoor, maakAfvinkRecord } from "./termijnen.mjs";
import { CATALOGUS } from "./termijnregels.mjs";
import { vandaagAmsterdam } from "./datum.mjs";
import { statusSinds } from "./flow.mjs";

const STORE = "klanten";
const RELATIE_ID = /^r_[A-Za-z0-9_-]{1,62}$/;
const TRAJECT_ID = /^t_[A-Za-z0-9_-]{1,62}$/;
const WIJZIGING_ID = /^[A-Za-z0-9_-]{1,64}$/;
const GROEP = 20;
const MAX_TOEGEPAST = 50;
export const ONVOLLEDIG_NA_MS = 10 * 60 * 1000;

const st = () => store(STORE);
const isObj = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
const norm = (v) => (v === undefined ? null : v);
// Vergelijkt met gesorteerde sleutels, zodat de volgorde van sleutels niet uitmaakt.
const stabiel = (v) => (Array.isArray(v) ? v.map(stabiel) : isObj(v) ? Object.fromEntries(Object.keys(v).sort().map((k) => [k, stabiel(v[k])])) : v);
const gelijk = (a, b) => JSON.stringify(stabiel(norm(a))) === JSON.stringify(stabiel(norm(b)));
const nietLeeg = (s) => typeof s === "string" && s.trim() !== "";
const fout = (fouten) => ({ ok: false, fouten });
export const MAX_VELDEN = 100;

// Sleutels die het prototype kunnen raken.
const GEVAARLIJK = new Set(["__proto__", "constructor", "prototype"]);
const isGevaarlijk = (k) => GEVAARLIJK.has(k) || k in Object.prototype;
function bevatGevaarlijk(v, diepte = 0) {
  if (diepte > 8) return true;
  if (Array.isArray(v)) return v.some((x) => bevatGevaarlijk(x, diepte + 1));
  if (isObj(v)) return Object.keys(v).some((k) => GEVAARLIJK.has(k) || bevatGevaarlijk(v[k], diepte + 1));
  return false;
}
const veilig = (fn) => { try { return fn(); } catch { return { ok: false, fouten: { _: "ongeldig" } }; } };

async function leesStrong(s, sleutel) {
  return (await s.get(sleutel, { type: "json", consistency: "strong" })) ?? null;
}

// Parallel in groepen van 20.
async function inGroepen(items, fn) {
  const uit = [];
  for (let i = 0; i < items.length; i += GROEP) uit.push(...(await Promise.all(items.slice(i, i + GROEP).map(fn))));
  return uit;
}

// Zoals bijwerk() uit ../opslag.mjs, maar met een async callback (nodig voor het journaal en controles).
async function bijwerkA(s, sleutel, fn, pogingen = 3) {
  for (let i = 0; i < pogingen; i++) {
    const r = await s.getWithMetadata(sleutel, { type: "json", consistency: "strong" });
    const nieuw = await fn(r ? r.data : null);
    if (nieuw === undefined) return { geschreven: false, waarde: r ? r.data : null };
    const res = await s.setJSON(sleutel, nieuw, r ? { onlyIfMatch: r.etag } : { onlyIfNew: true });
    if (!res || res.modified !== false) return { geschreven: true, waarde: nieuw };
  }
  return { geschreven: false, waarde: null, conflict: true };
}

// ---------- pad-hulp (taken.<id>.<veld>), alleen eigen sleutels ----------
const pad = (veld) => veld.split(".");
function haal(rec, delen) {
  let h = rec;
  for (const d of delen) {
    if (isGevaarlijk(d) || !isObj(h) || !Object.hasOwn(h, d)) return undefined;
    h = h[d];
  }
  return h;
}
function zet(rec, delen, waarde) {
  let h = rec;
  for (const d of delen.slice(0, -1)) {
    if (isGevaarlijk(d)) throw new Error("ongeldig-pad");
    if (!Object.hasOwn(h, d) || !isObj(h[d])) h[d] = {};
    h = h[d];
  }
  const l = delen.at(-1);
  if (isGevaarlijk(l)) throw new Error("ongeldig-pad");
  h[l] = waarde;
}
const TAAK_ID = /^[A-Za-z0-9_-]{1,64}$/;
const TAAKVELDEN = ["soort", "titel", "datum", "tijd", "eigenaar", "klaar"];

// ---------- logregels ----------
// Deterministische sleutel op record + wijzigingId + tijd + volgnummer: een herhaling of een tweede aanlevering schrijft dezelfde
// sleutels (onlyIfNew) en kan nooit een dubbele logregel maken. De volgorde in de tijdlijn komt uit het veld `op`.
// `lid` = <recordId>.<wijzigingId>: dezelfde wijzigingId op twee records van één relatie botst zo niet, en de tijd
// van de toepassing (op) zit in de sleutel: een echte nieuwe toepassing na het toegepast-venster krijgt een eigen regel.
const logSleutel = (relatieId, lid, op, n) => `log/${relatieId}/${lid}@${op}-${String(n).padStart(3, "0")}`;
// Journaalsleutel per verzoek (tijd + willekeurig achtervoegsel): een verliezer wist nooit het journaal van een ander.
const journaalSleutel = (relatieId, lid, op, tok) => `logwacht/${relatieId}/${lid}@${op}#${tok}`;
const journaalPrefix = (relatieId, lid) => `logwacht/${relatieId}/${lid}@`;

// Het journaal (de logregels van een wijziging) wordt VOOR het record geschreven en na de logregels
// verwijderd. Zo kan een mislukte log later alsnog worden aangeleverd.
async function bewaarJournaal(s, relatieId, lid, op, tok, regels, wijzigingId) {
  if (await isVerwijderd(relatieId)) return; // K11: geen nieuwe persoonsgegevens voor een verwijderde relatie
  await s.setJSON(journaalSleutel(relatieId, lid, op, tok), { op, regels, wijzigingId });
}
async function schrijfRegels(s, relatieId, lid, j) {
  if (await isVerwijderd(relatieId)) return; // K11
  let n = 0;
  for (const regel of j.regels) {
    await s.setJSON(logSleutel(relatieId, lid, j.op, n++), { ...regel, wijzigingId: j.wijzigingId ?? lid, relatieId, op: j.op }, { onlyIfNew: true });
  }
}
// Direct na het schrijven van het record: alleen het EIGEN journaal, strong gelezen op de bekende sleutel
// (list is niet strong en wordt hier niet gebruikt). Geeft true als het gelukt is.
async function leverEigen(s, relatieId, wijzigingId, op, tok) {
  try {
    const key = journaalSleutel(relatieId, wijzigingId, op, tok);
    const j = await leesStrong(s, key);
    if (!j) return false; // het journaal had er moeten zijn: de dagelijkse run of een herhaling lost het op
    await schrijfRegels(s, relatieId, wijzigingId, j);
    await s.delete(key);
    return true;
  } catch {
    return false;
  }
}
// Alleen het EIGEN journaal weg: de wijziging is niet door ons toegepast.
async function gooiJournaalWeg(s, relatieId, wijzigingId, op, tok) {
  try { await s.delete(journaalSleutel(relatieId, wijzigingId, op, tok)); } catch { /* opruimen mislukt: onschuldig */ }
}

// Was dit journaal echt toegepast? Geeft {toegepast, recordOp}. Een Klant-wissel moet in de statusgeschiedenis
// staan met dezelfde wie en van; elke andere wijziging moet in `toegepast` van het record staan.
async function isToegepast(s, lid, j) {
  const wijzigingId = j.wijzigingId ?? lid;
  const e = j.regels?.[0];
  if (!e) return { toegepast: false };
  const rec = await leesStrong(s, `${e.record}/${e.recordId}`);
  if (!rec) return { toegepast: false };
  const toegepast = wijzigingId.startsWith("klant.")
    ? !!rec.statusgeschiedenis?.some((x) => x.status === "Klant" && x.wie === e.wie && x.van === e.van)
    : !!rec.toegepast?.includes(wijzigingId);
  return { toegepast, recordOp: rec.gewijzigd?.op ?? null };
}

// Levert uit de gegeven journaalsleutels van één wijziging af: hoogstens één set logregels (het journaal waarvan
// `op` gelijk is aan gewijzigd.op van het record, anders het oudste), en wist alle andere. Niet toegepaste
// journalen zijn weesjournalen en worden gewist. Geeft {ok, geleverd (0|1), weggegooid}.
async function leverGroep(s, relatieId, wijzigingId, sleutels) {
  try {
    const js = [];
    for (const key of sleutels) {
      const j = await leesStrong(s, key);
      if (j) js.push({ key, j, ...(await isToegepast(s, wijzigingId, j)) });
    }
    const goed = js.filter((x) => x.toegepast).sort((a, b) => (b.j.op === b.recordOp) - (a.j.op === a.recordOp) || String(a.j.op).localeCompare(String(b.j.op)));
    if (goed.length) await schrijfRegels(s, relatieId, wijzigingId, goed[0].j);
    for (const { key } of js) await s.delete(key);
    return { ok: true, geleverd: goed.length ? 1 : 0, weggegooid: js.length - (goed.length ? 1 : 0) };
  } catch {
    return { ok: false, geleverd: 0, weggegooid: 0 };
  }
}
// Herhaling van een eerder verzoek (noop / bestaatAl): lever af wat daar niet af kwam. Best effort via list
// (mag een zeer recent journaal missen; de dagelijkse run vangt dat op).
async function leverHerhaling(s, relatieId, wijzigingId) {
  try {
    const { blobs } = await s.list({ prefix: journaalPrefix(relatieId, wijzigingId) });
    if (!blobs.length) return true;
    return (await leverGroep(s, relatieId, wijzigingId, blobs.map((b) => b.key))).ok;
  } catch {
    return false;
  }
}

// ---------- index ----------
export function indexRij(r) {
  const nr = `${r.huisnummer ?? ""}${r.toevoeging ?? ""}`;
  const open = Object.entries(r.taken || {})
    .filter(([, t]) => t && !t.klaar)
    .map(([id, t]) => ({ id, titel: t.titel ?? null, datum: t.datum ?? null, tijd: t.tijd ?? null, soort: t.soort ?? null, eigenaar: t.eigenaar ?? null }))
    .sort((a, b) => (a.datum ?? "9999").localeCompare(b.datum ?? "9999") || (a.tijd ?? "").localeCompare(b.tijd ?? "") || a.id.localeCompare(b.id));
  return {
    id: r.id, naam: weergavenaam(r), achternaam: r.achternaam ?? null, adres: [r.straat, nr].filter((x) => x && String(x).trim()).join(" "),
    postcode: r.postcode ?? null, plaats: r.plaats ?? null, status: r.status ?? null, eigenaar: r.eigenaar ?? null,
    volgendeTaak: open[0] ?? null, versie: r.versie ?? 0,
    // Voor de overzichten (bron, instroom per maand). Oudere rijen missen deze velden tot de volgende schrijfactie of
    // de dagelijkse herbouw; de overzichten tellen ze dan als "onbekend".
    bron: r.bron ?? null, aangemaakt: typeof r.aangemaakt?.op === "string" ? r.aangemaakt.op.slice(0, 10) : null,
    // Voor de leadpijplijn: sinds wanneer in deze status, contactwijze en soort woning.
    statusSinds: statusSinds(r), contactvoorkeur: r.contactvoorkeur ?? null, soortWoning: r.soortWoning ?? null,
    // Voor "Alle klanten" en de takenlijst: contactgegevens, terugbeldatum en alle open taken (klein: alleen de taakvelden).
    voornaam: r.voornaam ?? null, email: r.email ?? null, telefoon: r.telefoon ?? r.mobiel ?? null,
    terugbeldatum: r.terugbeldatum ?? null, openTaken: open.slice(0, 50),
  };
}
const nieuwerDan = (a, b) => typeof a?.versie === "number" && typeof b?.versie === "number" && a.versie > b.versie;

// Leest de relatie opnieuw (strong) en schrijft de rij alleen als er geen nieuwere rij staat.
async function indexUpsert(s, relatieId) {
  try {
    const rec = await leesStrong(s, `relatie/${relatieId}`);
    if (!rec) return false;
    const rij = indexRij(rec);
    const r = await bijwerkA(s, "index/relaties", async (cur) => {
      if (await isVerwijderd(relatieId)) return undefined; // K11: geen indexrij voor een verwijderde relatie
      if (nieuwerDan(cur?.rijen?.[rec.id], rij)) return undefined;
      return { rijen: { ...(cur?.rijen || {}), [rec.id]: rij } };
    });
    return !r.conflict;
  } catch {
    return false; // achterstand herstelt bij de volgende schrijfactie of herbouwIndex()
  }
}

// ---------- register ----------
async function registerVoeg(s, id, relatieId, nu) {
  const r = await bijwerkA(s, "register/trajecten", (cur) => {
    if (cur?.ids?.[id]) return undefined;
    return { ids: { ...(cur?.ids || {}), [id]: { relatieId, aangemaakt: nu.toISOString() } } };
  });
  return !r.conflict;
}

// Na het schrijven van het record: bevestig het registeritem (altijd een echte schrijfactie als het nog niet
// bevestigd is). Daardoor verliest een gelijktijdige verwijderOnvolledig op de etag, ziet het record en stopt.
// Ontbreekt het item (weggehaald), dan wordt het teruggezet.
async function registerBevestig(s, id, relatieId, nu) {
  const r = await bijwerkA(s, "register/trajecten", (cur) => {
    const item = cur?.ids?.[id];
    if (item?.bevestigd) return undefined;
    return { ids: { ...(cur?.ids || {}), [id]: { relatieId, aangemaakt: item?.aangemaakt ?? nu.toISOString(), bevestigd: nu.toISOString() } } };
  });
  return !r.conflict;
}

const trim = (lijst, id) => [...(lijst || []).filter((x) => x !== id), id].slice(-MAX_TOEGEPAST);

// ---------- aanmaken ----------
export async function maakRelatie({ id, wijzigingId, velden, herkomst } = {}, wie, nu = new Date()) {
  if (typeof id !== "string" || !RELATIE_ID.test(id)) return fout({ id: "geen-id" });
  if (typeof wijzigingId !== "string" || !WIJZIGING_ID.test(wijzigingId)) return fout({ wijzigingId: "geen-id" });
  if (!nietLeeg(wie)) return fout({ _: "van-en-wie-verplicht" });
  if (bevatGevaarlijk(velden) || bevatGevaarlijk(herkomst)) return fout({ velden: "ongeldig" });
  if (await isVerwijderd(id)) return fout({ _: "verwijderd" }); // K11
  const s = st();
  const tok = randomUUID();
  const lid = `${id}.${wijzigingId}`;
  const bestaand = await leesStrong(s, `relatie/${id}`);
  if (bestaand) {
    if (bestaand.toegepast?.includes(wijzigingId)) {
      const logOk = await leverHerhaling(s, id, lid);
      await indexUpsert(s, id);
      return { ok: true, bestaatAl: true, record: bestaand, logOk };
    }
    return fout({ id: "bestaat-al" });
  }
  const v = veilig(() => valideerRelatie(velden));
  if (!v.ok) return fout(v.fouten);
  const van = vandaagAmsterdam(nu);
  const stempel = { wie, op: nu.toISOString() };
  const record = {
    ...v.waarde, id, statusgeschiedenis: [{ status: v.waarde.status, van, wie }],
    ...(herkomst ? { herkomst } : {}), aangemaakt: stempel, gewijzigd: stempel, toegepast: [wijzigingId], versie: 1,
  };
  const c = veilig(() => valideerRelatie(record, { systeem: true }));
  if (!c.ok) return fout(c.fouten);
  await bewaarJournaal(s, id, lid, stempel.op, tok, [{ soort: "aanmaak", record: "relatie", recordId: id, wie, veld: null, oud: null, nieuw: v.waarde }], wijzigingId);
  const res = await s.setJSON(`relatie/${id}`, record, { onlyIfNew: true });
  if (res?.modified === false) {
    const nu2 = await leesStrong(s, `relatie/${id}`);
    if (nu2?.toegepast?.includes(wijzigingId)) {
      await gooiJournaalWeg(s, id, lid, stempel.op, tok);
      const logOk = await leverHerhaling(s, id, lid);
      return { ok: true, bestaatAl: true, record: nu2, logOk };
    }
    await gooiJournaalWeg(s, id, lid, stempel.op, tok);
    return fout({ id: "bestaat-al" });
  }
  const logOk = await leverEigen(s, id, lid, stempel.op, tok);
  const indexOk = await indexUpsert(s, id);
  return { ok: true, bestaatAl: false, record, logOk, indexOk };
}

// ---------- samenvoegen per veld ----------
const SPECIAAL = { relatie: "status", traject: "fase" };
const NIET_WIJZIGBAAR = { relatie: [], traject: ["relatieId"] };

// Past de velden toe op een kopie van `huidig`. Geeft {rec, toegepast, conflicten, fouten, logregels}.
function voegSamen(soort, huidig, velden, wie, nu) {
  const valideer = soort === "relatie" ? valideerRelatie : valideerTraject;
  const speciaal = SPECIAAL[soort];
  const rec = structuredClone(huidig);
  const toegepast = [];
  const conflicten = [];
  const fouten = {};
  const logregels = [];
  const aanraking = new Set();
  let speciaalVraag = null;

  for (const [veld, w] of Object.entries(velden)) {
    if (!isObj(w) || !("nieuw" in w)) { fouten[veld] = "geen-oud-nieuw"; continue; }
    if (bevatGevaarlijk(w.oud) || bevatGevaarlijk(w.nieuw)) { fouten[veld] = "ongeldig"; continue; }
    const delen = pad(veld);
    if (delen.some(isGevaarlijk)) { fouten[veld] = "ongeldig"; continue; }
    const taak = soort === "relatie" && delen[0] === "taken";
    if (taak && (delen.length !== 3 || !TAAK_ID.test(delen[1]) || !TAAKVELDEN.includes(delen[2]))) { fouten[veld] = "ongeldig"; continue; }
    if (!taak && delen.length !== 1) { fouten[veld] = "onbekend-veld"; continue; }
    if (NIET_WIJZIGBAAR[soort].includes(veld)) { fouten[veld] = "niet-wijzigbaar"; continue; }
    if (veld === speciaal) { speciaalVraag = w; continue; }
    // Waarde controleren (taken: na afloop als geheel, want soort en titel horen samen).
    let nieuw = w.nieuw;
    if (!taak) {
      const v = veilig(() => valideer({ [veld]: w.nieuw }, { deel: true }));
      if (!v.ok) { fouten[veld] = v.fouten[veld] ?? v.fouten._ ?? "ongeldig"; continue; }
      nieuw = v.waarde[veld];
    }
    const huidigeWaarde = haal(rec, delen);
    if (gelijk(huidigeWaarde, w.oud)) {
      zet(rec, delen, nieuw);
      toegepast.push(veld);
      if (taak) aanraking.add(delen[1]);
      logregels.push({ soort: "wijziging", record: soort, recordId: huidig.id, wie, veld, oud: norm(huidigeWaarde), nieuw: norm(nieuw) });
    } else if (!gelijk(huidigeWaarde, nieuw)) {
      conflicten.push({ veld, huidig: norm(huidigeWaarde), oud: norm(w.oud), nieuw: norm(w.nieuw) });
    }
  }
  for (const tid of aanraking) {
    const v = veilig(() => valideerRelatie({ taken: { [tid]: rec.taken[tid] } }, { deel: true }));
    if (!v.ok) for (const [k, c] of Object.entries(v.fouten)) fouten[k] = c;
    else rec.taken[tid] = v.waarde.taken[tid];
  }

  // Status of fase: via de wisselfunctie (geschiedenis in dezelfde schrijfactie).
  if (speciaalVraag && Object.keys(fouten).length === 0) {
    const w = speciaalVraag;
    if (gelijk(huidig[speciaal], w.oud)) {
      if (!gelijk(rec[speciaal], w.nieuw)) {
        const van = vandaagAmsterdam(nu);
        let r;
        if (soort === "relatie") r = veilig(() => wisselStatus(rec, w.nieuw, { wie, van }));
        else r = veilig(() => wisselFase(rec, w.nieuw, { wie, van }));
        if (r.fouten) Object.assign(fouten, r.fouten);
        else if (r.logregel) {
          Object.assign(rec, r.waarde);
          toegepast.push(speciaal);
          logregels.push({ ...r.logregel, recordId: huidig.id });
        }
      }
    } else if (!gelijk(huidig[speciaal], w.nieuw)) {
      conflicten.push({ veld: speciaal, huidig: norm(huidig[speciaal]), oud: norm(w.oud), nieuw: norm(w.nieuw) });
    }
  }

  // Kruisregel traject: vanaf Besluit een verzenddatum of expliciet onbekend.
  if (soort === "traject" && toegepast.length && !fouten.fase && !fouten.verzenddatumBesluitbrief
    && isVanafBesluit(rec.fase) && !rec.verzenddatumBesluitbrief && rec.verzenddatumOnbekend !== true) {
    fouten.verzenddatumBesluitbrief = "verplicht-vanaf-besluit";
  }
  // Kruisregel relatie: reden bij Afgevallen.
  if (soort === "relatie" && toegepast.length && rec.status === "Afgevallen" && !nietLeeg(rec.redenAfgevallen)) {
    fouten.redenAfgevallen ||= "verplicht-bij-afgevallen";
  }
  return { rec, toegepast, conflicten, fouten, logregels };
}

// opties.controle(nieuwRecord, huidigRecord): draait binnen de schrijfpoging, op het verse record.
// Geeft het een fout terug (string of {veld: code}), dan wordt er niets geschreven en komt die fout terug.
async function wijzigRecord(soort, id, wijziging, wie, nu, opties) {
  const sleutel = `${soort}/${id}`;
  if (!isObj(wijziging) || typeof wijziging.wijzigingId !== "string" || !WIJZIGING_ID.test(wijziging.wijzigingId)) return fout({ wijzigingId: "geen-id" });
  if (!isObj(wijziging.velden) || Object.keys(wijziging.velden).length === 0) return fout({ velden: "verplicht" });
  if (Object.keys(wijziging.velden).length > MAX_VELDEN) return fout({ velden: "te-veel" });
  if (Object.keys(wijziging.velden).includes("__proto__")) return fout({ velden: "ongeldig" });
  if (!nietLeeg(wie)) return fout({ _: "van-en-wie-verplicht" });
  const wid = wijziging.wijzigingId;
  const s = st();
  const tok = randomUUID();
  const lid = `${id}.${wid}`;
  let uitkomst = null;
  let relatieId = soort === "relatie" ? id : null;
  const r = await bijwerkA(s, sleutel, async (huidig) => {
    uitkomst = null;
    if (!huidig) { uitkomst = { nietGevonden: true, verwijderd: soort === "relatie" ? await isVerwijderd(id) : await isTrajectVerwijderd(id) }; return undefined; }
    relatieId = soort === "relatie" ? id : huidig.relatieId;
    // K11: een record dat nog bestaat terwijl de relatie AVG-verwijderd is (race): niet meer wijzigen.
    if (soort === "traject" && await isVerwijderd(relatieId)) { uitkomst = { nietGevonden: true, verwijderd: true }; return undefined; }
    let m;
    try { m = voegSamen(soort, huidig, wijziging.velden, wie, nu); } catch { uitkomst = { fouten: { _: "ongeldig" } }; return undefined; }
    if (huidig.toegepast?.includes(wid)) {
      // Herhaling: niets opnieuw toepassen, wel de conflicten opnieuw tonen (tegen het huidige record).
      uitkomst = { noop: true, record: huidig, conflicten: m.conflicten };
      return undefined;
    }
    uitkomst = { ...m, huidig };
    if (Object.keys(m.fouten).length || m.toegepast.length === 0) return undefined;
    if (opties?.controle) {
      const c = await opties.controle(m.rec, huidig);
      if (c) { uitkomst = { ...uitkomst, fouten: typeof c === "string" ? { _: c } : c }; return undefined; }
    }
    m.rec.toegepast = trim(huidig.toegepast, wid);
    m.rec.gewijzigd = { wie, op: nu.toISOString() };
    if (soort === "relatie") m.rec.versie = (huidig.versie ?? 0) + 1;
    await bewaarJournaal(s, relatieId, lid, nu.toISOString(), tok, m.logregels, wid);
    return m.rec;
  });
  if (uitkomst?.nietGevonden) return fout({ _: uitkomst.verwijderd ? "verwijderd" : "niet-gevonden" });
  const eigenOp = nu.toISOString();
  if (uitkomst?.noop) {
    await gooiJournaalWeg(s, relatieId, lid, eigenOp, tok); // een verloren poging van dit verzoek zelf
    const logOk = await leverHerhaling(s, relatieId, lid);
    if (soort === "relatie") await indexUpsert(s, id);
    return { ok: true, noop: true, toegepast: [], conflicten: uitkomst.conflicten, record: uitkomst.record, logOk };
  }
  if (r.conflict) { if (relatieId) await gooiJournaalWeg(s, relatieId, lid, eigenOp, tok); return fout({ _: "gelijktijdig-probeer-opnieuw" }); }
  if (Object.keys(uitkomst.fouten).length) { await gooiJournaalWeg(s, relatieId, lid, eigenOp, tok); return fout(uitkomst.fouten); }
  if (!r.geschreven) { await gooiJournaalWeg(s, relatieId, lid, eigenOp, tok); return { ok: true, noop: false, toegepast: [], conflicten: uitkomst.conflicten, record: uitkomst.huidig, logOk: true }; }
  const logOk = await leverEigen(s, relatieId, lid, eigenOp, tok);
  const indexOk = soort === "relatie" ? await indexUpsert(s, id) : true;
  return { ok: true, noop: false, toegepast: uitkomst.toegepast, conflicten: uitkomst.conflicten, record: r.waarde, logOk, indexOk };
}

export function wijzigRelatie(id, wijziging, wie, nu = new Date(), opties) {
  return wijzigRecord("relatie", id, wijziging, wie, nu, opties);
}
export function wijzigTraject(id, wijziging, wie, nu = new Date(), opties) {
  return wijzigRecord("traject", id, wijziging, wie, nu, opties);
}

// ---------- traject aanmaken ----------
// Relatie naar status Klant (tenzij al Klant). Het journaal-id bevat een punt: een client-wijzigingId kan dat niet zijn.
const klantId = (trajectId) => `klant.${trajectId.slice(2)}`;
async function relatieNaarKlant(s, relatieId, trajectId, wie, nu) {
  const wijzigingId = klantId(trajectId);
  const jid = `${relatieId}.${wijzigingId}`;
  nu = new Date(nu.getTime() + 1); // de Klant-wissel komt in de tijdlijn na de aanmaak van het traject
  const op = nu.toISOString();
  const tok = randomUUID();
  const r = await bijwerkA(s, `relatie/${relatieId}`, async (rel) => {
    if (!rel || rel.status === "Klant") return undefined;
    const w = veilig(() => wisselStatus(rel, "Klant", { wie, van: vandaagAmsterdam(nu) }));
    if (w.fouten || !w.logregel) return undefined;
    const nieuw = w.waarde;
    nieuw.gewijzigd = { wie, op };
    nieuw.versie = (rel.versie ?? 0) + 1;
    await bewaarJournaal(s, relatieId, jid, op, tok, [{ ...w.logregel, recordId: relatieId }], wijzigingId);
    return nieuw;
  });
  if (!r.geschreven) await gooiJournaalWeg(s, relatieId, jid, op, tok);
  if (r.conflict) return { conflict: true, geschreven: false, logOk: true };
  let logOk = true;
  if (r.geschreven) {
    logOk = await leverEigen(s, relatieId, jid, op, tok);
    await indexUpsert(s, relatieId);
  }
  return { conflict: false, geschreven: r.geschreven, logOk };
}

// Onthoudt op het traject dat de Klant-stap gedaan is (ook als de relatie al Klant was). Daarna zet een
// herhaling van maakTraject de status nooit meer terug.
async function zetKlantGezet(s, trajectId) {
  const r = await bijwerkA(s, `traject/${trajectId}`, (t) => (!t || t.klantGezet === true ? undefined : { ...t, klantGezet: true }));
  return { conflict: !!r.conflict, record: r.geschreven ? r.waarde : null };
}

export async function maakTraject(relatieId, { id, wijzigingId, velden } = {}, wie, nu = new Date()) {
  if (typeof relatieId !== "string" || !RELATIE_ID.test(relatieId)) return fout({ relatieId: "geen-id" });
  if (typeof id !== "string" || !TRAJECT_ID.test(id)) return fout({ id: "geen-id" });
  if (typeof wijzigingId !== "string" || !WIJZIGING_ID.test(wijzigingId)) return fout({ wijzigingId: "geen-id" });
  if (!nietLeeg(wie)) return fout({ _: "van-en-wie-verplicht" });
  if (bevatGevaarlijk(velden)) return fout({ velden: "ongeldig" });
  const s = st();
  const tok = randomUUID();
  const lid = `${id}.${wijzigingId}`;
  if (await isVerwijderd(relatieId)) return fout({ _: "verwijderd" }); // K11
  const relatie = await leesStrong(s, `relatie/${relatieId}`);
  if (!relatie) return fout({ relatieId: "niet-gevonden" });

  // Alles na het schrijven van het record; ook voor een herhaling: register bevestigen, Klant (eenmalig), log.
  const afronden = async (record, bestaatAl, eigenOp) => {
    if (await isVerwijderd(relatieId)) { // K11: de relatie is intussen AVG-verwijderd: eigen record en registeritem weer weg
      await s.delete(`traject/${id}`);
      await bijwerkA(s, "register/trajecten", (cur) => {
        if (!cur?.ids?.[id]) return undefined;
        const { [id]: _weg, ...rest } = cur.ids;
        return { ids: rest };
      });
      return fout({ _: "verwijderd" });
    }
    if (!(await registerBevestig(s, id, relatieId, nu))) return fout({ _: "gelijktijdig-probeer-opnieuw" });
    let klantOk = true;
    let rec = record;
    let klantStap = null;
    if (record.klantGezet !== true) {
      const k = await relatieNaarKlant(s, relatieId, id, wie, nu);
      klantStap = k;
      klantOk = !k.conflict;
      if (klantOk) {
        const z = await zetKlantGezet(s, id);
        klantOk = !z.conflict;
        rec = z.record ?? (await leesStrong(s, `traject/${id}`)) ?? record;
      }
    }
    const aanmaakOk = bestaatAl ? await leverHerhaling(s, relatieId, lid) : await leverEigen(s, relatieId, lid, eigenOp, tok);
    const klantLogOk = (klantStap?.logOk ?? true) && (bestaatAl ? await leverHerhaling(s, relatieId, `${relatieId}.${klantId(id)}`) : true);
    return { ok: true, bestaatAl, record: rec, logOk: aanmaakOk && klantLogOk, relatieStatusOk: klantOk };
  };

  const bestaand = await leesStrong(s, `traject/${id}`);
  if (bestaand) {
    if (bestaand.relatieId === relatieId && bestaand.toegepast?.includes(wijzigingId)) return afronden(bestaand, true, null);
    return fout({ id: "bestaat-al" });
  }
  if (isObj(velden) && velden.relatieId !== undefined && velden.relatieId !== relatieId) return fout({ relatieId: "komt-niet-overeen" });
  const v = veilig(() => valideerTraject({ ...(velden || {}), relatieId }));
  if (!v.ok) return fout(v.fouten);
  const stempel = { wie, op: nu.toISOString() };
  const record = {
    ...v.waarde, id, fasegeschiedenis: [{ fase: v.waarde.fase, van: vandaagAmsterdam(nu), wie }],
    aangemaakt: stempel, gewijzigd: stempel, toegepast: [wijzigingId],
  };
  const c = veilig(() => valideerTraject(record, { systeem: true }));
  if (!c.ok) return fout(c.fouten);
  // EERST het register, DAN het record: een traject dat bestaat is altijd vindbaar.
  if (!(await registerVoeg(s, id, relatieId, nu))) return fout({ _: "gelijktijdig-probeer-opnieuw" });
  await bewaarJournaal(s, relatieId, lid, stempel.op, tok, [{ soort: "aanmaak", record: "traject", recordId: id, wie, veld: null, oud: null, nieuw: v.waarde }], wijzigingId);
  const res = await s.setJSON(`traject/${id}`, record, { onlyIfNew: true });
  if (res?.modified === false) {
    await gooiJournaalWeg(s, relatieId, lid, stempel.op, tok);
    const nu2 = await leesStrong(s, `traject/${id}`);
    if (nu2?.relatieId === relatieId && nu2.toegepast?.includes(wijzigingId)) return afronden(nu2, true, null);
    return fout({ id: "bestaat-al" });
  }
  return afronden(record, false, stempel.op);
}

// ---------- afvinken ----------
// opties.regels: catalogus (standaard CATALOGUS; tests geven een testcatalogus mee).
async function wijzigAfgevinkt(trajectId, regelId, wijzigingId, wie, nu, opties, bouw) {
  if (typeof wijzigingId !== "string" || !WIJZIGING_ID.test(wijzigingId)) return fout({ wijzigingId: "geen-id" });
  if (!nietLeeg(wie)) return fout({ _: "van-en-wie-verplicht" });
  const regels = opties?.regels ?? CATALOGUS;
  const regel = regels.find((r) => r.id === regelId);
  if (!regel) return fout({ regelId: "onbekende-regel" });
  if (regel.record !== "traject") return fout({ regelId: "geen-trajectregel" });
  const s = st();
  const tok = randomUUID();
  const lid = `${trajectId}.${wijzigingId}`;
  let uitkomst = null;
  let relatieId = null;
  const r = await bijwerkA(s, `traject/${trajectId}`, async (t) => {
    uitkomst = null;
    if (!t) { uitkomst = { f: { _: (await isTrajectVerwijderd(trajectId)) ? "verwijderd" : "niet-gevonden" } }; return undefined; }
    relatieId = t.relatieId;
    if (await isVerwijderd(relatieId)) { uitkomst = { f: { _: "verwijderd" } }; return undefined; }
    if (t.toegepast?.includes(wijzigingId)) { uitkomst = { noop: true, record: t }; return undefined; }
    const b = await bouw(t, regel);
    if (b.fouten) { uitkomst = { f: b.fouten }; return undefined; }
    // Niets te doen (al heropend, of al met dezelfde actie afgevinkt): geen schrijfactie, geen logregel.
    if (b.noop) { uitkomst = { noop: true, record: t }; return undefined; }
    const op = nu.toISOString();
    await bewaarJournaal(s, relatieId, lid, op, tok, [{ ...b.log, record: "traject", recordId: trajectId, wie }], wijzigingId);
    uitkomst = {};
    return { ...t, afgevinkt: b.afgevinkt, toegepast: trim(t.toegepast, wijzigingId), gewijzigd: { wie, op } };
  });
  const eigenOp = nu.toISOString();
  if (uitkomst?.noop) {
    await gooiJournaalWeg(s, relatieId, lid, eigenOp, tok);
    return { ok: true, noop: true, record: uitkomst.record, logOk: await leverHerhaling(s, relatieId, lid) };
  }
  if (r.conflict) { if (relatieId) await gooiJournaalWeg(s, relatieId, lid, eigenOp, tok); return fout({ _: "gelijktijdig-probeer-opnieuw" }); }
  if (uitkomst?.f) { if (relatieId) await gooiJournaalWeg(s, relatieId, lid, eigenOp, tok); return fout(uitkomst.f); }
  return { ok: true, noop: false, record: r.waarde, logOk: await leverEigen(s, relatieId, lid, eigenOp, tok) };
}

export function vinkAf(trajectId, regelId, { actie, wijzigingId } = {}, wie, nu = new Date(), opties) {
  const regels = opties?.regels ?? CATALOGUS;
  return wijzigAfgevinkt(trajectId, regelId, wijzigingId, wie, nu, opties, async (t, regel) => {
    const relatie = await leesStrong(st(), `relatie/${t.relatieId}`);
    const item = termijnenVoor(t, relatie, regels, vandaagAmsterdam(nu)).find((i) => i.regelId === regelId);
    const a = maakAfvinkRecord(regel, item?.brondatum ?? null, { actie, wie }, nu);
    if (a.fout) return { fouten: { actie: a.fout } };
    // Al afgevinkt met dezelfde actie en dezelfde brondatum: no-op (een tweede keer afvinken uit de offline-wachtrij).
    const bestaand = t.afgevinkt?.[regelId];
    if (bestaand && bestaand.actie === a.waarde.actie && bestaand.brondatum === a.waarde.brondatum) return { noop: true };
    return {
      afgevinkt: { ...(t.afgevinkt || {}), [regelId]: a.waarde },
      log: { soort: "afvinken", veld: `afgevinkt.${regelId}`, oud: norm(t.afgevinkt?.[regelId]), nieuw: a.waarde },
    };
  });
}

export function heropen(trajectId, regelId, { wijzigingId } = {}, wie, nu = new Date(), opties) {
  return wijzigAfgevinkt(trajectId, regelId, wijzigingId, wie, nu, opties, (t) => {
    if (!t.afgevinkt?.[regelId]) return { noop: true }; // al open: een tweede keer heropenen is een no-op
    const { [regelId]: oud, ...rest } = t.afgevinkt;
    return { afgevinkt: rest, log: { soort: "heropenen", veld: `afgevinkt.${regelId}`, oud, nieuw: null } };
  });
}

// ---------- lezen ----------
export const leesRelatie = (id) => leesStrong(st(), `relatie/${id}`);
export const leesTraject = (id) => leesStrong(st(), `traject/${id}`);
// K11: bestaat er een tombstone (AVG-verwijderd)? Dan weigeren aanmaken en het schrijven van journaal en logregels.
export async function isVerwijderd(relatieId) {
  return typeof relatieId === "string" && RELATIE_ID.test(relatieId) && !!(await leesStrong(st(), `tombstone/${relatieId}`));
}
// K11: bij het verwijderen van een relatie staan de ids van haar trajecten (alleen ids) onder tombstone-traject/<id>.
export async function isTrajectVerwijderd(trajectId) {
  return typeof trajectId === "string" && TRAJECT_ID.test(trajectId) && !!(await leesStrong(st(), `tombstone-traject/${trajectId}`));
}
export async function leesRegister() {
  return (await leesStrong(st(), "register/trajecten")) ?? { ids: {} };
}
export async function leesIndex() {
  return (await leesStrong(st(), "index/relaties")) ?? { rijen: {} };
}

// Register eerst (strong), dan elk record strong, in groepen van 20 met allSettled. Geeft
// {trajecten: [record], onvolledig: [{id, relatieId, aangemaakt}], onleesbaar: [{id, relatieId}]}.
// onvolledig: registeritem zonder record, ouder dan 10 minuten (jonger = nog bezig, overgeslagen).
// onleesbaar: de read zelf mislukte; de overige trajecten blijven gewoon zichtbaar.
export async function leesAlleTrajecten(nu = new Date()) {
  const s = st();
  const reg = (await leesStrong(s, "register/trajecten")) ?? { ids: {} };
  const ids = Object.keys(reg.ids || {});
  const uitslag = [];
  for (let i = 0; i < ids.length; i += GROEP) {
    uitslag.push(...(await Promise.allSettled(ids.slice(i, i + GROEP).map((id) => leesStrong(s, `traject/${id}`)))));
  }
  const trajecten = [];
  const onvolledig = [];
  const onleesbaar = [];
  ids.forEach((id, i) => {
    const item = reg.ids[id];
    const u = uitslag[i];
    if (u.status === "rejected") { onleesbaar.push({ id, relatieId: item?.relatieId ?? null }); return; }
    if (u.value) { trajecten.push(u.value); return; }
    const t = Date.parse(item?.aangemaakt);
    if (!Number.isFinite(t) || nu.getTime() - t > ONVOLLEDIG_NA_MS) onvolledig.push({ id, relatieId: item?.relatieId ?? null, aangemaakt: item?.aangemaakt ?? null });
  });
  return { trajecten, onvolledig, onleesbaar };
}

// Nieuwste eerst. Mag enkele seconden achterlopen (list).
export async function leesTijdlijn(relatieId) {
  const s = st();
  const { blobs } = await s.list({ prefix: `log/${relatieId}/` });
  const sleutels = blobs.map((b) => b.key);
  const regels = (await inGroepen(sleutels, async (k) => { const r = await leesStrong(s, k); return r ? { k, r } : null; })).filter(Boolean);
  return regels
    .sort((a, b) => String(b.r.op).localeCompare(String(a.r.op)) || b.k.localeCompare(a.k))
    .map((x) => x.r);
}

// ---------- onderhoud (geplande Function en beheer) ----------
const MISLUKT = Symbol("mislukt");

// Bouwt de index opnieuw uit de relatie-records. Een rij verdwijnt alleen als een strong get op de relatie
// null geeft; samenvoegen gebeurt binnen de schrijfpoging op de nieuwste index (nieuwste rij per id wint).
export async function herbouwIndex() {
  const s = st();
  const { blobs } = await s.list({ prefix: "relatie/" });
  const lees = (id) => leesStrong(s, `relatie/${id}`).catch(() => MISLUKT);
  const ids = blobs.map((b) => b.key.slice("relatie/".length));
  const gelezen = new Map((await inGroepen(ids, async (id) => [id, await lees(id)])));
  const oud = (await leesStrong(s, "index/relaties"))?.rijen ?? {};
  const weg = new Set();
  for (const id of Object.keys(oud)) {
    if (gelezen.has(id)) continue;
    const rec = await lees(id);
    if (rec === null) weg.add(id);
    else gelezen.set(id, rec);
  }
  const records = new Map([...gelezen].filter(([, rec]) => rec && rec !== MISLUKT));
  const afwijkingen = [];
  for (const id of new Set([...Object.keys(oud), ...records.keys()])) {
    if (weg.has(id)) afwijkingen.push({ id, soort: "geen-record" });
    else if (!oud[id]) afwijkingen.push({ id, soort: "ontbrak-in-index" });
    else if (records.has(id) && !gelijk(oud[id], indexRij(records.get(id)))) afwijkingen.push({ id, soort: "verouderd" });
  }
  const r = await bijwerkA(s, "index/relaties", (cur) => {
    const rijen = { ...(cur?.rijen || {}) };
    for (const id of weg) delete rijen[id];
    for (const [id, rec] of records) {
      const rij = indexRij(rec);
      if (!nieuwerDan(rijen[id], rij)) rijen[id] = rij;
    }
    return { rijen };
  });
  return { aantal: records.size, afwijkingen, geschreven: r.geschreven === true };
}

// list("traject/") tegen het register. Ontbrekende registeritems worden bijgezet en teruggegeven;
// registeritems zonder record worden alleen gemeld (zie leesAlleTrajecten voor "onvolledig").
export async function vergelijkRegister(nu = new Date()) {
  const s = st();
  const { blobs } = await s.list({ prefix: "traject/" });
  const ids = blobs.map((b) => b.key.slice("traject/".length));
  const reg = (await leesStrong(s, "register/trajecten")) ?? { ids: {} };
  const afwijkingen = [];
  for (const id of ids) {
    if (reg.ids?.[id]) continue;
    const rec = await leesStrong(s, `traject/${id}`);
    if (!rec) continue;
    if (await isVerwijderd(rec.relatieId)) continue; // K11: niet herstellen voor een verwijderde relatie
    const gezet = await registerVoeg(s, id, rec.relatieId, nu);
    afwijkingen.push({ id, relatieId: rec.relatieId, soort: "ontbrak-in-register", hersteld: gezet });
  }
  const bekend = new Set(ids);
  for (const [id, item] of Object.entries(reg.ids || {})) {
    if (!bekend.has(id)) afwijkingen.push({ id, relatieId: item?.relatieId ?? null, soort: "record-ontbreekt-in-list", aangemaakt: item?.aangemaakt ?? null });
  }
  return { afwijkingen };
}

// Beheer: haalt een registeritem zonder record weg (het traject is nooit volledig aangemaakt) en logt dat.
// Weigert als het record wel bestaat (strong gelezen, binnen de schrijfpoging).
export async function verwijderOnvolledig(id, wie, nu = new Date()) {
  if (typeof id !== "string" || !TRAJECT_ID.test(id)) return fout({ id: "geen-id" });
  if (!nietLeeg(wie)) return fout({ _: "van-en-wie-verplicht" });
  const s = st();
  let item = null;
  let bestaat = false;
  const r = await bijwerkA(s, "register/trajecten", async (cur) => {
    item = cur?.ids?.[id] ?? null; bestaat = false;
    if (!item) return undefined;
    if (await leesStrong(s, `traject/${id}`)) { bestaat = true; return undefined; }
    const { [id]: _weg, ...rest } = cur.ids;
    return { ids: rest };
  });
  if (r.conflict) return fout({ _: "gelijktijdig-probeer-opnieuw" });
  if (!item) return fout({ id: "niet-in-register" });
  if (bestaat) return fout({ id: "record-bestaat" });
  let logOk = false;
  if (item.relatieId) {
    try {
      const wid = `vo.${id.slice(2)}.${nu.toISOString()}`;
      await s.setJSON(logSleutel(item.relatieId, `${id}.${wid}`, nu.toISOString(), 0), {
        soort: "verwijder-onvolledig", record: "traject", recordId: id, wie, veld: null, oud: item, nieuw: null, wijzigingId: wid, relatieId: item.relatieId, op: nu.toISOString(),
      }, { onlyIfNew: true });
      logOk = true;
    } catch { logOk = false; }
  }
  return { ok: true, verwijderd: id, relatieId: item.relatieId ?? null, logOk };
}

// Voor de geplande Function: handelt journalen af die ouder zijn dan 10 minuten (dus niet meer onderweg).
// Per wijzigingId wordt hoogstens één set logregels geschreven, en alleen voor een wijziging die echt is
// toegepast (zie isToegepast). De rest zijn weesjournalen en wordt gewist.
// Geeft {geleverd, weggegooid, mislukt, overgeslagen}.
export async function leverOpenJournalen(nu = new Date()) {
  const s = st();
  const { blobs } = await s.list({ prefix: "logwacht/" });
  const uit = { geleverd: 0, weggegooid: 0, mislukt: 0, overgeslagen: 0 };
  const groepen = new Map();
  for (const { key } of blobs) {
    const m = /^logwacht\/([^/]+)\/([^@]+)@(.+)$/.exec(key);
    if (!m) continue;
    const gk = `${m[1]}/${m[2]}`;
    if (!groepen.has(gk)) groepen.set(gk, { relatieId: m[1], wid: m[2], sleutels: [] });
    groepen.get(gk).sleutels.push(key);
  }
  for (const g of groepen.values()) {
    const oud = [];
    for (const key of g.sleutels) {
      const j = await leesStrong(s, key).catch(() => null);
      if (!j) continue;
      const t = Date.parse(j.op);
      if (Number.isFinite(t) && nu.getTime() - t < ONVOLLEDIG_NA_MS) uit.overgeslagen++; else oud.push(key);
    }
    if (!oud.length) continue;
    const r = await leverGroep(s, g.relatieId, g.wid, oud);
    if (!r.ok) uit.mislukt++;
    else { uit.geleverd += r.geleverd; uit.weggegooid += r.weggegooid; }
  }
  return uit;
}

// ---------- losse tijdlijnregel (K9) ----------
// Voegt één regel toe aan de tijdlijn van een bestaande relatie zonder het record te wijzigen (bijv. "aanvraag opnieuw
// binnengekomen"). `nieuw` is een klein object zonder inhoud van de aanvraag. Alleen toevoegen (onlyIfNew); geeft true/false.
export async function voegTijdlijnregelToe(relatieId, { soort, nieuw, wijzigingId }, wie, nu = new Date()) {
  if (typeof relatieId !== "string" || !RELATIE_ID.test(relatieId)) return false;
  if (typeof soort !== "string" || !WIJZIGING_ID.test(soort) || !nietLeeg(wie)) return false;
  if (typeof wijzigingId !== "string" || !WIJZIGING_ID.test(wijzigingId) || bevatGevaarlijk(nieuw)) return false;
  try {
    const s = st();
    if (!(await leesStrong(s, `relatie/${relatieId}`))) return false;
    const op = nu.toISOString();
    const res = await s.setJSON(logSleutel(relatieId, `${relatieId}.${wijzigingId}`, op, 0),
      { soort, record: "relatie", recordId: relatieId, wie, veld: null, oud: null, nieuw: nieuw ?? null, wijzigingId, relatieId, op }, { onlyIfNew: true });
    return res?.modified !== false;
  } catch {
    return false;
  }
}

// ---------- contactmoment ----------
// Legt een contactmoment (gebeld, WhatsApp, gesprek, ...) vast als tijdlijnregel van soort "contact". Het record zelf
// verandert niet. De sleutel hangt alleen af van relatie en wijzigingId (geen tijd): een herhaling uit de offline
// wachtrij schrijft dezelfde sleutel en maakt nooit een tweede regel. Staat onder log/<relatieId>/, dus AVG-verwijderen
// (ruimOp) neemt hem mee. `contact` is al gevalideerd (valideerContact in model.mjs).
// Geeft {ok:true, regel, noop?} of {ok:false, fouten}.
export async function legContactVast(relatieId, { wijzigingId, contact }, wie, nu = new Date()) {
  if (typeof relatieId !== "string" || !RELATIE_ID.test(relatieId)) return fout({ _: "niet-gevonden" });
  if (typeof wijzigingId !== "string" || !WIJZIGING_ID.test(wijzigingId)) return fout({ wijzigingId: "ongeldig" });
  if (!nietLeeg(wie)) return fout({ _: "wie-verplicht" });
  if (!isObj(contact) || bevatGevaarlijk(contact)) return fout({ contact: "ongeldig" });
  const s = st();
  if (await isVerwijderd(relatieId)) return fout({ _: "verwijderd" });
  if (!(await leesStrong(s, `relatie/${relatieId}`))) return fout({ _: "niet-gevonden" });
  const sleutel = `log/${relatieId}/${relatieId}.contact-${wijzigingId}@contact-000`;
  const regel = {
    soort: "contact", record: "relatie", recordId: relatieId, wie, veld: null, oud: null,
    nieuw: { wijze: contact.wijze, datum: contact.datum ?? null, notitie: contact.notitie ?? null },
    wijzigingId, relatieId, op: nu.toISOString(),
  };
  const res = await s.setJSON(sleutel, regel, { onlyIfNew: true });
  if (res?.modified === false) return { ok: true, noop: true, regel: (await leesStrong(s, sleutel)) ?? regel };
  return { ok: true, regel };
}

// Termijnengine: pure functies, geen opslag. Zie KLANTEN-ARCHITECTUUR.md §2 + Aanvulling.
// Berekent nooit een datum voor een regel die niet volledig bevestigd is.
import { FASES, faseIndex, isIsoDatum, weergavenaam, normFase } from "./model.mjs";
import { FEESTDAGEN } from "./termijnregels.mjs";
import { berekenEinddatum, dagenTussen, datumVan, EENHEDEN, TELLINGEN, WEEKEND_REGELS } from "./datum.mjs";

export const STATUS = Object.freeze({
  OPEN: "open", AFGEVINKT: "afgevinkt", HERBEVESTIGEN: "herbevestigen", DATUM_ONTBREEKT: "datum-ontbreekt",
  NIET_BEVESTIGD: "niet-bevestigd", NVT: "nvt", KON_NIET_BEREKENEN: "kon-niet-berekenen",
});

// fataal === null (onbekend) telt als fataal.
export const isFataal = (regel) => regel.fataal !== false;

// Titel van een regel; null -> vaste melding met de Zoho-naam.
export function titelVan(regel, einddatum = null) {
  if (regel.titel === null || regel.titel === undefined) return `Actie uit Zoho-regel '${regel.zoho}', inhoud nog onbekend`;
  return einddatum ? regel.titel.replaceAll("<einddatum>", einddatum) : regel.titel;
}

// Is de regel volledig bevestigd (alle getallen en keuzes aanwezig én bevestigd)?
export function isBevestigd(regel) {
  const d = regel.duur || {};
  const b = regel.bevestigd;
  return Number.isInteger(d.aantal) && d.aantal >= 1 && EENHEDEN.includes(d.eenheid) && TELLINGEN.includes(regel.telling)
    && WEEKEND_REGELS.includes(regel.weekendFeestdag) && !!b && typeof b.door === "string" && b.door !== "" && typeof b.op === "string" && b.op !== "";
}

// Laatste geschiedenisregel met deze waarde -> startdatum (of null).
function startUitGeschiedenis(lijst, sleutel, waarde) {
  const e = (lijst || []).filter((x) => x && [].concat(waarde).includes(x[sleutel])).at(-1);
  return e ? datumVan(e.van) : null;
}

// Startdatum van de regel op dit record. Geeft {datum} of {ontbreekt:true, vanwege}.
// vanwege: "veld" (de gebeurtenis is er nog niet) of "toestand" (record staat in de toestand, datum ontbreekt).
function bepaalStart(regel, rec, traject, relatie) {
  const { soort, waarde } = regel.start;
  if (soort === "aangemaakt") {
    const d = datumVan(rec.aangemaakt?.op);
    return d ? { datum: d } : { ontbreekt: true, vanwege: "toestand" };
  }
  if (soort === "status") {
    const lijst = [].concat(waarde);
    const d = startUitGeschiedenis(relatie?.statusgeschiedenis, "status", lijst);
    if (d) return { datum: d };
    return { ontbreekt: true, vanwege: lijst.includes(relatie?.status) ? "toestand" : "veld" };
  }
  if (soort === "fase") {
    const d = startUitGeschiedenis(traject?.fasegeschiedenis, "fase", waarde);
    if (d) return { datum: d };
    return { ontbreekt: true, vanwege: traject?.fase === waarde ? "toestand" : "veld" };
  }
  const d = datumVan(rec[waarde]);
  return d ? { datum: d } : { ontbreekt: true, vanwege: "veld" };
}

// Is de datum vereist? Ja zodra het traject ooit (fase of fasegeschiedenis) op of voorbij vereistVanafFase was,
// of als de huidige fase onbekend is (ook "Verloren (vervallen)"), zodat een afgesloten traject niet stil verdwijnt.
function faseVereist(regel, traject) {
  if (!regel.vereistVanafFase || regel.record !== "traject" || !traject) return false;
  const grens = FASES.indexOf(regel.vereistVanafFase);
  if (grens < 0) return true;
  const fase = normFase(traject.fase);
  if (!FASES.includes(fase)) return true;
  const geschiedenis = (traject.fasegeschiedenis || []).map((e) => normFase(e?.fase)).filter((f) => FASES.includes(f) && f !== "Verloren");
  // Verloren zonder bruikbare geschiedenis: we weten niet hoe ver het was, dus de veilige kant (vereist).
  if (traject.fase === "Verloren" && geschiedenis.length === 0) return true;
  const bereikt = [fase, ...geschiedenis];
  return bereikt.some((f) => FASES.includes(f) && f !== "Verloren" && FASES.indexOf(f) >= grens);
}

function geldtZolangOk(regel, traject, relatie) {
  const g = regel.geldtZolang;
  if (!g) return true;
  if (g.status && !g.status.includes(relatie?.status)) return false;
  if (g.fase && !g.fase.includes(traject?.fase)) return false;
  return true;
}

function geldtVoorOk(regel, traject) {
  const g = regel.geldtVoor;
  if (!g) return true;
  if (g.routes && !g.routes.includes(traject?.route)) return false;
  if (g.fases && !g.fases.includes(traject?.fase)) return false;
  return true;
}

// Eén regel op één record.
function beoordeel(regel, traject, relatie, vandaag, feestdagen) {
  const rec = regel.record === "traject" ? traject : relatie;
  const item = {
    regelId: regel.id, zoho: regel.zoho, titel: titelVan(regel), status: STATUS.NVT, fataal: isFataal(regel), fataalOnbekend: regel.fataal === null,
    record: regel.record, recordId: rec?.id ?? null, relatieId: regel.record === "traject" ? traject?.relatieId ?? relatie?.id ?? null : relatie?.id ?? null,
    brondatum: null, einddatum: null, dagenOver: null, vervolgActie: regel.vervolgActie, afvinkActies: regel.afvinkActies || [],
  };
  const klaar = (status, extra = {}) => ({ ...item, status, ...extra });

  if (!rec) return klaar(STATUS.NVT);
  // Fatale regels (fataal true of null) blijven tot afgevinkt: actief, geldtVoor, geldtZolang en alsLeeg tellen niet.
  const fataal = isFataal(regel);
  if (!fataal) {
    if (regel.actief === false) return klaar(STATUS.NVT);
    if (regel.record === "traject" && !geldtVoorOk(regel, traject)) return klaar(STATUS.NVT);
    if (!geldtZolangOk(regel, traject, relatie)) return klaar(STATUS.NVT);
  }

  if (!fataal && regel.alsLeeg && datumVan(rec[regel.alsLeeg]) !== null) return klaar(STATUS.NVT);

  const start = bepaalStart(regel, rec, traject, relatie);
  if (start.ontbreekt) {
    if (start.vanwege === "toestand") return klaar(STATUS.DATUM_ONTBREEKT);
    // Veld leeg: pas vanaf vereistVanafFase een fataal signaal.
    return klaar(faseVereist(regel, traject) ? STATUS.DATUM_ONTBREEKT : STATUS.NVT);
  }
  const brondatum = start.datum;

  const af = rec.afgevinkt?.[regel.id];
  if (af) {
    return klaar(af.brondatum === brondatum ? STATUS.AFGEVINKT : STATUS.HERBEVESTIGEN, { brondatum, afgevinktBij: af.brondatum ?? null });
  }
  if (!isBevestigd(regel)) return klaar(STATUS.NIET_BEVESTIGD, { brondatum });

  const einddatum = berekenEinddatum(brondatum, regel.duur, regel.telling, regel.weekendFeestdag, feestdagen);
  return klaar(STATUS.OPEN, { brondatum, einddatum, dagenOver: dagenTussen(vandaag, einddatum), titel: titelVan(regel, einddatum) });
}

// Termijnen voor één record. Met `traject`: de regels met record "traject"; zonder (null): de regels met record
// "relatie". Eén item per regel, ook "nvt". `vandaag` = "YYYY-MM-DD" (zie vandaagAmsterdam).
export function termijnenVoor(traject, relatie, regels, vandaag, opties = {}) {
  const feestdagen = opties.feestdagen ?? FEESTDAGEN;
  const soort = traject ? "traject" : "relatie";
  const rec = traject ?? relatie;
  // Een fout in één regel verbergt de andere regels van hetzelfde record niet.
  return regels.filter((r) => r.record === soort).map((r) => {
    try {
      return beoordeel(r, traject ?? null, relatie ?? null, vandaag, feestdagen);
    } catch {
      return {
        regelId: r.id, zoho: r.zoho, titel: `kon niet berekenen: ${rec?.id ?? "onbekend"}`, status: STATUS.KON_NIET_BEREKENEN,
        fataal: isFataal(r), fataalOnbekend: r.fataal === null, record: r.record, recordId: rec?.id ?? null,
        relatieId: soort === "traject" ? traject?.relatieId ?? relatie?.id ?? null : relatie?.id ?? null,
        brondatum: null, einddatum: null, dagenOver: null, vervolgActie: r.vervolgActie, afvinkActies: r.afvinkActies || [],
      };
    }
  });
}

function alsMap(relaties) {
  if (relaties instanceof Map) return relaties;
  if (Array.isArray(relaties)) return new Map(relaties.filter(Boolean).map((r) => [r.id, r]));
  return new Map(Object.entries(relaties || {}));
}

const cmp = (a, b) => (a < b ? -1 : a > b ? 1 : 0);
// Rang in het blok: 0 = aandacht nu (open en verlopen, datum ontbreekt, kon niet berekenen),
// 1 = open en nog niet verlopen, 2 = herbevestigen en niet bevestigd.
const rang = (i) => {
  if (i.status === STATUS.OPEN) return i.dagenOver < 0 ? 0 : 1;
  if (i.status === STATUS.DATUM_ONTBREEKT || i.status === STATUS.KON_NIET_BEREKENEN) return 0;
  return 2;
};
// Binnen rang 0: eerst concreet verlopen termijnen, dan "kon niet berekenen", dan "datum ontbreekt".
const SUBRANG = { open: 0, "kon-niet-berekenen": 1, "datum-ontbreekt": 2, herbevestigen: 0, "niet-bevestigd": 1 };
const oudsteDatum = (lijst) => lijst.map((x) => x.brondatum).filter(Boolean).sort()[0] ?? null;

// Het fatale blok: alle fatale termijnen en signalen van ALLE trajecten (en relaties), nooit gefilterd op
// eigenaar, status of zoekterm. Niets wordt overgeslagen: een fout in een fatale regel (of in het hele record)
// geeft één item "kon niet berekenen: <id>" met fataal:true en regelIds van de kapotte fatale regels.
//
// Geeft {items, gezondheid}:
// - items: het fatale blok, gesorteerd.
//   Rang 0 (aandacht nu): open en verlopen (oudste einddatum eerst), dan "kon niet berekenen", dan "datum ontbreekt".
//   Rang 1: open op einddatum. Rang 2: herbevestigen, dan niet bevestigd.
//   Signalen van dezelfde soort: oudste brondatum eerst, ontbrekende brondatum bovenaan, dan id.
//   Niet-bevestigde regels met fataal: null komen als ÉÉN samengevat signaal per record ({samengevat:true,
//   zoho:null, brondatum = de oudste, regels:[{regelId, brondatum}], regelIds, aantal}); fataal: true blijft apart.
// - gezondheid: niet-fatale regels die niet te berekenen waren ({regelId, recordId, relatieId, naam, titel}).
//   Die horen niet in het fatale blok (ze zijn niet fataal), maar mogen ook niet stil verdwijnen: het startscherm
//   toont ze als gezondheidsmelding.
// opties.bereken (alleen voor tests) vervangt termijnenVoor.
export function maakFataalBlok(trajecten, relaties, regels, vandaag, opties = {}) {
  const bereken = opties.bereken ?? termijnenVoor;
  const feestdagen = opties.feestdagen ?? FEESTDAGEN;
  const rel = alsMap(relaties);
  const items = [];
  const gezondheid = [];
  const naamVan = (relatieId) => (relatieId && rel.has(relatieId) ? weergavenaam(rel.get(relatieId)) : null);
  const verwerk = (id, relatieId, fn) => {
    const eigen = [];
    const zwak = [];
    try {
      for (const t of fn()) {
        if (t.status === STATUS.KON_NIET_BEREKENEN && !t.fataal) zwak.push(t);
        else if (t.fataal && t.status !== STATUS.NVT && t.status !== STATUS.AFGEVINKT) eigen.push({ ...t, naam: naamVan(relatieId) });
      }
    } catch {
      zwak.length = 0;
      eigen.length = 0;
      eigen.push({
        regelId: null, zoho: null, titel: `kon niet berekenen: ${id}`, status: STATUS.KON_NIET_BEREKENEN, fataal: true,
        record: null, recordId: id, relatieId: relatieId ?? null, brondatum: null, einddatum: null, dagenOver: null,
        vervolgActie: null, afvinkActies: [], naam: naamVan(relatieId),
      });
    }
    for (const z of zwak) gezondheid.push({ regelId: z.regelId, recordId: z.recordId, relatieId: z.relatieId, naam: naamVan(relatieId), titel: z.titel });
    const kapot = eigen.filter((x) => x.status === STATUS.KON_NIET_BEREKENEN);
    const samen = eigen.filter((x) => x.status === STATUS.NIET_BEVESTIGD && x.fataalOnbekend);
    const rest = eigen.filter((x) => x.status !== STATUS.KON_NIET_BEREKENEN && !(x.status === STATUS.NIET_BEVESTIGD && x.fataalOnbekend));
    if (kapot.length) {
      const ids = kapot.map((x) => x.regelId).filter(Boolean);
      items.push({ ...kapot[0], fataal: kapot.some((x) => x.fataal), regelId: ids.length === 1 ? ids[0] : null, regelIds: ids });
    }
    if (samen.length) {
      items.push({
        ...samen[0], regelId: null, zoho: null, regelIds: samen.map((x) => x.regelId), aantal: samen.length, samengevat: true,
        regels: samen.map((x) => ({ regelId: x.regelId, brondatum: x.brondatum })), brondatum: oudsteDatum(samen),
        titel: samen.map((x) => x.titel).join(", "),
      });
    }
    items.push(...rest);
  };
  for (const t of trajecten || []) {
    const id = t?.id ?? "onbekend";
    verwerk(id, t?.relatieId, () => {
      if (!t || typeof t !== "object") throw new Error("geen traject");
      return bereken(t, rel.get(t.relatieId) ?? null, regels, vandaag, { feestdagen });
    });
  }
  for (const [id, r] of rel) verwerk(id, id, () => bereken(null, r, regels, vandaag, { feestdagen }));
  items.sort((a, b) =>
    rang(a) - rang(b)
    || (SUBRANG[a.status] ?? 9) - (SUBRANG[b.status] ?? 9)
    || (a.status === STATUS.OPEN ? cmp(a.einddatum, b.einddatum) : cmp(a.brondatum ?? "", b.brondatum ?? ""))
    || cmp(String(a.recordId), String(b.recordId)) || cmp(String(a.regelId), String(b.regelId)));
  return { items, gezondheid };
}

// Afvinkrecord voor traject.afgevinkt[regel.id]. Bij een fatale regel is een actie uit afvinkActies verplicht;
// zonder bekende acties (nog niet bevestigd) kan een fatale regel niet worden afgevinkt.
// Geeft {waarde} of {fout}: "actie-verplicht" | "actie-niet-toegestaan" | "geen-acties-bekend" | "brondatum-ontbreekt" | "wie-verplicht" (K4: 422).
export function maakAfvinkRecord(regel, brondatum, { actie, wie } = {}, nu = new Date()) {
  if (!isIsoDatum(brondatum)) return { fout: "brondatum-ontbreekt" };
  if (typeof wie !== "string" || wie.trim() === "") return { fout: "wie-verplicht" };
  if (isFataal(regel)) {
    if (typeof actie !== "string" || actie === "") return { fout: "actie-verplicht" };
    if (!regel.afvinkActies?.length) return { fout: "geen-acties-bekend" };
    if (!regel.afvinkActies.includes(actie)) return { fout: "actie-niet-toegestaan" };
  }
  return { waarde: { actie: actie ?? null, brondatum, wie, op: nu.toISOString() } };
}

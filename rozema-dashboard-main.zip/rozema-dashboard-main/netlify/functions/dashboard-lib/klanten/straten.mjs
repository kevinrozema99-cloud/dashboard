// K10: GET /straten voor de deur-app (KLANTEN-ARCHITECTUUR.md §3): in welke straten van een plaats al een klant
// of traject is. Geeft alleen `{straat, klant: true}` terug: geen aantallen per persoon, geen namen, geen id's.
// Puur: de Function leest de opslag en geeft de gegevens hier door.

export const STATUS_KLANT = "Klant";

// Zelfde vouwing als het zoeken in dashboard-klanten.mjs: hoofdletters en accenten tellen niet mee.
export const vouwNaam = (s) => String(s ?? "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/\s+/g, " ").trim();

// Relatie-id's met minstens één traject, uit het register ({ids: {<tid>: {relatieId}}}).
export function relatiesMetTraject(register) {
  const set = new Set();
  for (const item of Object.values(register?.ids ?? {})) {
    if (typeof item?.relatieId === "string") set.add(item.relatieId);
  }
  return set;
}

// De index-rijen in deze plaats die een klant zijn (status Klant) of een traject hebben.
export function klantRijenInPlaats(rijen, register, plaats) {
  const doel = vouwNaam(plaats);
  const metTraject = relatiesMetTraject(register);
  return rijen.filter((r) => vouwNaam(r.plaats) === doel && (r.status === STATUS_KLANT || metTraject.has(r.id)));
}

// straatVan(rij) geeft de straatnaam uit het relatie-record, of undefined als lezen mislukte of de straat ontbreekt.
// Geeft {straten: [{straat, klant: true}], onvolledig}: onvolledig is het aantal rijen waarvan de straat niet te
// bepalen was (lezen mislukt, record weg of geen straat).
export function maakStraten(rijen, straatVan) {
  const per = new Map();
  let onvolledig = 0;
  for (const r of rijen) {
    const straat = String(straatVan(r) ?? "").trim();
    const sleutel = vouwNaam(straat);
    if (!sleutel) { onvolledig += 1; continue; }
    if (!per.has(sleutel)) per.set(sleutel, { straat, klant: true });
  }
  return { straten: [...per.values()].sort((a, b) => a.straat.localeCompare(b.straat, "nl")), onvolledig };
}

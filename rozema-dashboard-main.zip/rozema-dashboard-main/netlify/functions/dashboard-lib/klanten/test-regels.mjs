// Hulp voor tests: een aparte catalogus met FICTIEVE getallen. Nooit importeren uit productiecode.
import { CATALOGUS } from "./termijnregels.mjs";

const BEVESTIGD = { door: "test", op: "2000-01-01", bron: "fictief" };

// Zet voor alle regels fictieve, "bevestigde" waarden in.
export function testCatalogus(aanpassing = {}) {
  return CATALOGUS.map((r) => ({
    ...r,
    duur: { aantal: 3, eenheid: "weken" },
    telling: "dag-na-start",
    weekendFeestdag: "niet",
    bevestigd: BEVESTIGD,
    ...(aanpassing[r.id] || {}),
  }));
}
export const testRegel = (id, extra = {}) => testCatalogus({ [id]: extra }).find((r) => r.id === id);
export { BEVESTIGD };

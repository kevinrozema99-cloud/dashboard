// Klantenmodule K11: iCal-feed met fatale termijnen en taken met datum, beschermd met een geheim token per gebruiker.
// In de feed staan GEEN namen of adressen: alleen een omschrijving (placeholder-sleutel), het traject-id of
// relatie-id en een generieke code. De omschrijvingen komen straks uit het content-bestand.
import { createHash, randomBytes } from "node:crypto";
import { store } from "../opslag.mjs";
import { gebruikers } from "../sessie.mjs";
import { leesIndex, leesRelatie, leesAlleTrajecten } from "./opslag.mjs";
import { normFase } from "./model.mjs";
import { berekenFataalBlok } from "./start.mjs";
import { STATUS } from "./termijnen.mjs";
import { plusDagen, vandaagAmsterdam } from "./datum.mjs";

const AGENDA_STORE = "agenda";
const GROEP = 20;
export const TOKEN_PATROON = /^[A-Za-z0-9_-]{43}$/;
const ISO = /^\d{4}-\d{2}-\d{2}$/;
const TIJD = /^([01]\d|2[0-3]):[0-5]\d$/;

// Omschrijvingen: placeholders (CLAUDE.md regel 1). Kevin vervangt ze via het content-bestand.
export const OMSCHRIJVING = Object.freeze({
  fataal: "[[TEKST: klanten.agenda.fataal]]",
  taak: "[[TEKST: klanten.agenda.taak]]",
  opname: "[[TEKST: klanten.agenda.opname]]",
  kalender: "[[TEKST: klanten.agenda.kalender]]",
});

const hashVan = (token) => createHash("sha256").update(token).digest("hex");
const st = () => store(AGENDA_STORE);
const naamSleutel = (wie) => `gebruiker/${encodeURIComponent(wie)}`;

// ---------- token ----------
// Opslag: alleen de hash van het token. `hash/<hash>` -> {wie}, `gebruiker/<wie>` -> {hash, op}.
// Het token zelf wordt één keer teruggegeven (bij maken of vernieuwen) en is daarna niet meer op te vragen.
// Geeft {token, op}, of null als het na enkele pogingen niet lukte (gelijktijdig vernieuwen).
// `gebruiker/<wie>` wordt met onlyIfMatch (of onlyIfNew) geschreven; verliest dit verzoek, dan ruimt het zijn eigen hash op.
export async function vernieuwToken(wie, nu = new Date(), pogingen = 3) {
  const s = st();
  for (let i = 0; i < pogingen; i++) {
    const token = randomBytes(32).toString("base64url");
    const hash = hashVan(token);
    const r = await s.getWithMetadata(naamSleutel(wie), { type: "json", consistency: "strong" });
    await s.setJSON(`hash/${hash}`, { wie, op: nu.toISOString() });
    const res = await s.setJSON(naamSleutel(wie), { hash, op: nu.toISOString() }, r ? { onlyIfMatch: r.etag } : { onlyIfNew: true });
    if (res && res.modified === false) { await s.delete(`hash/${hash}`); continue; }
    if (r?.data?.hash && r.data.hash !== hash) await s.delete(`hash/${r.data.hash}`);
    return { token, op: nu.toISOString() };
  }
  return null;
}

export async function tokenStand(wie) {
  const g = await st().get(naamSleutel(wie), { type: "json", consistency: "strong" });
  return { bestaat: !!g, op: g?.op ?? null };
}

// Geeft de naam van de gebruiker of null. Een gebruiker die niet meer in DASHBOARD_GEBRUIKERS staat, telt niet meer.
export async function wieIsToken(token, env = process.env) {
  if (typeof token !== "string" || !TOKEN_PATROON.test(token)) return null;
  const rec = await st().get(`hash/${hashVan(token)}`, { type: "json", consistency: "strong" });
  if (!rec?.wie || !Object.hasOwn(gebruikers(env), rec.wie)) return null;
  return rec.wie;
}

// ---------- gebeurtenissen ----------
async function inGroepen(lijst, fn) {
  const uit = [];
  for (let i = 0; i < lijst.length; i += GROEP) uit.push(...(await Promise.allSettled(lijst.slice(i, i + GROEP).map(fn))));
  return uit;
}

// Geeft [{uid, datum, tijd|null, omschrijving, code}] (alleen ids, codes en datums).
export async function verzamelGebeurtenissen(regels, nu = new Date()) {
  const vandaag = vandaagAmsterdam(nu);
  const blok = await berekenFataalBlok(regels, vandaag, nu);
  const uit = [];
  for (const i of blok.items) {
    if (i.record !== "traject" || !i.regelId || !ISO.test(i.einddatum ?? "")) continue;
    if (i.status !== STATUS.OPEN && i.status !== STATUS.HERBEVESTIGEN) continue;
    uit.push({ uid: `fataal-${i.recordId}-${i.regelId}`, datum: i.einddatum, tijd: null, omschrijving: OMSCHRIJVING.fataal, code: `${i.recordId} ${i.regelId}` });
  }
  const index = await leesIndex();
  const ids = Object.keys(index.rijen ?? {});
  const gelezen = await inGroepen(ids, (id) => leesRelatie(id));
  gelezen.forEach((g, n) => {
    if (g.status !== "fulfilled" || !g.value) return;
    for (const [tid, t] of Object.entries(g.value.taken ?? {})) {
      if (!t || t.klaar || !ISO.test(t.datum ?? "")) continue;
      uit.push({ uid: `taak-${ids[n]}-${tid}`, datum: t.datum, tijd: TIJD.test(t.tijd ?? "") ? t.tijd : null, omschrijving: OMSCHRIJVING.taak, code: `${ids[n]} ${tid}` });
    }
  });
  // Opnames (gezamenlijke agenda): de opnamedatum van elk traject dat niet verloren is, met tijd als die er is.
  const { trajecten } = await leesAlleTrajecten(nu);
  for (const t of trajecten) {
    if (!t?.id || normFase(t.fase) === "Verloren" || !ISO.test(t.opnamedatum ?? "")) continue;
    uit.push({ uid: `opname-${t.id}`, datum: t.opnamedatum, tijd: TIJD.test(t.opnametijd ?? "") ? t.opnametijd : null, omschrijving: OMSCHRIJVING.opname, code: t.id });
  }
  return uit.sort((a, b) => a.datum.localeCompare(b.datum) || a.uid.localeCompare(b.uid));
}

// ---------- iCal ----------
const esc = (t) => String(t).replaceAll("\\", "\\\\").replaceAll(";", "\\;").replaceAll(",", "\\,").replace(/\r?\n/g, "\\n");
// Regels langer dan 75 octetten worden gevouwen (RFC 5545 §3.1), op UTF-8-octetten en zonder een teken te splitsen.
export function vouwRegel(r) {
  const delen = [];
  let huidig = "";
  let bytes = 0;
  let max = 75;
  for (const teken of r) {
    const n = Buffer.byteLength(teken, "utf8");
    if (bytes + n > max) { delen.push(huidig); huidig = " "; bytes = 1; max = 75; }
    huidig += teken;
    bytes += n;
  }
  delen.push(huidig);
  return delen.join("\r\n");
}
// Tijden van taken zijn Amsterdamse kloktijd: TZID met een VTIMEZONE (EU-zomertijdregels).
const TZID = "Europe/Amsterdam";
const VTIMEZONE = [
  "BEGIN:VTIMEZONE", `TZID:${TZID}`,
  "BEGIN:STANDARD", "DTSTART:19701025T030000", "TZOFFSETFROM:+0200", "TZOFFSETTO:+0100", "RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU", "END:STANDARD",
  "BEGIN:DAYLIGHT", "DTSTART:19700329T020000", "TZOFFSETFROM:+0100", "TZOFFSETTO:+0200", "RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU", "END:DAYLIGHT",
  "END:VTIMEZONE",
];
const zonderStreepjes = (iso) => iso.replaceAll("-", "");
const stempel = (nu) => nu.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, "");

export function maakIcs(gebeurtenissen, nu = new Date()) {
  const r = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Rozema Adviseurs//Dashboard//NL", "CALSCALE:GREGORIAN", `X-WR-CALNAME:${esc(OMSCHRIJVING.kalender)}`];
  if (gebeurtenissen.some((g) => g.tijd)) r.push(...VTIMEZONE);
  for (const g of gebeurtenissen) {
    r.push("BEGIN:VEVENT", `UID:${g.uid}@dashboard.rozema`, `DTSTAMP:${stempel(nu)}`);
    if (g.tijd) r.push(`DTSTART;TZID=${TZID}:${zonderStreepjes(g.datum)}T${g.tijd.replace(":", "")}00`, "DURATION:PT30M");
    else r.push(`DTSTART;VALUE=DATE:${zonderStreepjes(g.datum)}`, `DTEND;VALUE=DATE:${zonderStreepjes(plusDagen(g.datum, 1))}`);
    r.push(`SUMMARY:${esc(`${g.omschrijving} ${g.code}`)}`, "END:VEVENT");
  }
  r.push("END:VCALENDAR");
  return `${r.map(vouwRegel).join("\r\n")}\r\n`;
}

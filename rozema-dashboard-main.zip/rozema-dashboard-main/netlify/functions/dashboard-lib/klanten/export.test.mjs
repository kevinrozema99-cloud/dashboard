// Tests voor export.mjs en agenda.mjs (K11): CSV-escaping en iCal-opbouw. Alleen fictieve data.
import { test } from "node:test";
import assert from "node:assert/strict";
import { csvCel, maakCsv, bevestigingsWaarde } from "./export.mjs";
import { maakIcs, vouwRegel, OMSCHRIJVING } from "./agenda.mjs";

test("csvCel: formule-tekens krijgen een ' ervoor, ook na spaties niet nodig; getallen en lege waarden ongemoeid", () => {
  for (const v of ["=1+1", "+31612345678", "-1", "@SOM(A1)", "\tx", "\rx"]) assert.ok(csvCel(v).replace(/^"/, "").startsWith("'"), JSON.stringify(v));
  assert.equal(csvCel("gewoon"), "gewoon");
  assert.equal(csvCel("a=b"), "a=b");
  assert.equal(csvCel(-5), "-5");
  assert.equal(csvCel(null), "");
  assert.equal(csvCel(undefined), "");
  assert.equal(csvCel(true), "true");
});

test("csvCel: aanhalingstekens, komma, puntkomma en regeleinden tussen dubbele aanhalingstekens", () => {
  assert.equal(csvCel('a"b'), '"a""b"');
  assert.equal(csvCel("a,b"), '"a,b"');
  assert.equal(csvCel("a;b"), '"a;b"');
  assert.equal(csvCel("a\nb"), '"a\nb"');
  assert.equal(csvCel({ x: "=1" }), '"{""x"":""=1""}"');
  assert.equal(csvCel([1, 2]), '"[1,2]"');
});

test("maakCsv: id eerst, vereniging van kolommen, BOM en CRLF", () => {
  const t = maakCsv([{ id: "r_1", b: "x" }, { id: "r_2", a: "=y" }]);
  assert.ok(t.startsWith("﻿id,a,b\r\n"));
  assert.ok(t.includes("r_2,'=y,\r\n"));
  assert.ok(t.endsWith("\r\n"));
});

test("bevestigingsWaarde: achternaam", () => {
  assert.equal(bevestigingsWaarde({ achternaam: "Test" }), "Test");
});

test("maakIcs: hele dag en met tijd, alleen id's en placeholder, regels hoogstens 75 tekens", () => {
  const ics = maakIcs([
    { uid: "taak-r_1-k1", datum: "2026-12-31", tijd: null, omschrijving: OMSCHRIJVING.taak, code: "r_1 k1" },
    { uid: "taak-r_1-k2", datum: "2026-11-13", tijd: "09:05", omschrijving: OMSCHRIJVING.taak, code: "r_1 k2" },
  ], new Date("2026-11-10T10:00:00.000Z"));
  assert.ok(ics.includes("DTSTART;VALUE=DATE:20261231\r\nDTEND;VALUE=DATE:20270101"));
  assert.ok(ics.includes("DTSTART;TZID=Europe/Amsterdam:20261113T090500\r\nDURATION:PT30M"));
  assert.ok(ics.includes("DTSTAMP:20261110T100000Z"));
  assert.ok(ics.includes("SUMMARY:[[TEKST: klanten.agenda.taak]] r_1 k1"));
  assert.equal(ics.match(/BEGIN:VEVENT/g).length, 2);
  for (const regel of ics.split("\r\n")) assert.ok(regel.length <= 75);
});

test("maakIcs: VTIMEZONE alleen bij een tijd", () => {
  const zonder = maakIcs([{ uid: "a", datum: "2026-11-13", tijd: null, omschrijving: "x", code: "y" }]);
  assert.ok(!zonder.includes("VTIMEZONE"));
  const met = maakIcs([{ uid: "a", datum: "2026-11-13", tijd: "10:00", omschrijving: "x", code: "y" }]);
  assert.ok(met.includes("BEGIN:VTIMEZONE\r\nTZID:Europe/Amsterdam") && met.includes("END:VTIMEZONE"));
});

test("vouwRegel: op UTF-8-octetten, een teken wordt nooit gesplitst, ontvouwen geeft het origineel", () => {
  for (const tekst of ["a".repeat(200), "é".repeat(100), "€".repeat(60), "x😀".repeat(40)]) {
    const r = `SUMMARY:${tekst}`;
    const v = vouwRegel(r);
    for (const regel of v.split("\r\n")) assert.ok(Buffer.byteLength(regel, "utf8") <= 75, regel.length);
    assert.equal(v.replaceAll("\r\n ", ""), r);
    assert.ok(!v.includes("\uFFFD"));
  }
  assert.equal(vouwRegel("kort"), "kort");
});

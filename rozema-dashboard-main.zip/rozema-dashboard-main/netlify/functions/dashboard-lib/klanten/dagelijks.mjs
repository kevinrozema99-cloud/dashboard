// Klantenmodule K5: kern van de dagelijkse run (KLANTEN-ARCHITECTUUR.md §2 "Nooit uit beeld" punt 6), gedeeld door de
// geplande Function en de handmatige route. Draait alleen op de productiedeploy van Netlify. Elke stap staat op zichzelf: een fout in één stap stopt de
// andere niet en komt in de hartslag. De hartslag bevat alleen aantallen en ids, nooit namen of teksten.
import { leverOpenJournalen, vergelijkRegister, herbouwIndex, ONVOLLEDIG_NA_MS } from "./opslag.mjs";
import { ruimVerlopenClaimsOp } from "./instroom.mjs";
import { lijstTombstones, ruimTombstoneOp, trajectOverzicht } from "./export.mjs";
import { CATALOGUS } from "./termijnregels.mjs";
import { vandaagAmsterdam } from "./datum.mjs";
import { berekenFataalBlok, telFataal, schrijfHartslag, beperk, isAfgekapt } from "./start.mjs";

// Alleen de soort fout, nooit de melding (die kan gegevens bevatten).
const soortFout = (err) => String(err?.name ?? "Error").slice(0, 40);

// De kern, los van Netlify te testen. Geeft de hartslag terug (ook als het schrijven mislukte: schrijfOk false).
export async function voerDagelijksUit({ nu = new Date(), regels = CATALOGUS, opties = {}, handmatig = false } = {}) {
  const aantallen = {};
  const details = {};
  const fouten = [];
  let afgekapt = false;
  const lijst = (l) => { if (isAfgekapt(l)) afgekapt = true; return beperk(l); };
  const stap = async (naam, fn) => {
    try { await fn(); } catch (err) { fouten.push({ stap: naam, soort: soortFout(err) }); }
  };

  await stap("journalen", async () => {
    const r = await leverOpenJournalen(nu);
    aantallen.journalenGeleverd = r.geleverd;
    aantallen.journalenWeggegooid = r.weggegooid;
    aantallen.journalenMislukt = r.mislukt;
    aantallen.journalenOvergeslagen = r.overgeslagen;
    if (r.mislukt > 0) fouten.push({ stap: "journalen", soort: "niet-alles-geleverd" });
  });

  await stap("register", async () => {
    const r = await vergelijkRegister(nu);
    // list() kan achterlopen: een registeritem jonger dan ONVOLLEDIG_NA_MS zonder record in de list is nog bezig, geen afwijking.
    const jong = (a) => {
      if (a.soort !== "record-ontbreekt-in-list") return false;
      const t = Date.parse(a.aangemaakt);
      return Number.isFinite(t) && nu.getTime() - t <= ONVOLLEDIG_NA_MS;
    };
    const echt = r.afwijkingen.filter((a) => !jong(a));
    aantallen.registerAfwijkingen = echt.length;
    aantallen.registerJong = r.afwijkingen.length - echt.length;
    details.register = lijst(echt.map((a) => ({ id: a.id, relatieId: a.relatieId ?? null, soort: a.soort, ...(a.hersteld !== undefined ? { hersteld: a.hersteld } : {}) })));
  });

  await stap("index", async () => {
    // K11: weestrajecten en indexrijen van AVG-verwijderde relaties (na een race) eerst opruimen, vóór de index wordt herbouwd.
    // Zelfde stap als de index, zodat een mislukte list() niet als extra stap in de hartslag verschijnt. Alleen ids en aantallen.
    // Een fout bij één tombstone stopt de rest niet (en de index wordt altijd herbouwd). De lijst met trajecten wordt één keer gelezen.
    let opgeruimd = 0;
    let mislukt = 0;
    let overgeslagen = 0;
    let lijstFout = null;
    try {
      const ids = await lijstTombstones();
      const overzicht = ids.length ? await trajectOverzicht() : undefined;
      for (const id of ids) {
        try {
          const v = await ruimTombstoneOp(id, nu, { overzicht });
          if (v?.overgeslagen) overgeslagen++;
          else if (v) opgeruimd++;
          else mislukt++;
        } catch { mislukt++; }
      }
    } catch (err) { lijstFout = err; }
    aantallen.tombstonesOpgeruimd = opgeruimd;
    aantallen.tombstonesOvergeslagen = overgeslagen;
    aantallen.tombstonesMislukt = mislukt;
    if (mislukt > 0) fouten.push({ stap: "index", soort: "tombstones-niet-opgeruimd" });
    // De index wordt altijd herbouwd, ook als de tombstones mislukten; een fout bij de lijst of de index komt daarna als stapfout.
    let r = null;
    let indexFout = null;
    try { r = await herbouwIndex(); } catch (err) { indexFout = err; }
    if (r) {
      aantallen.indexRijen = r.aantal;
      aantallen.indexAfwijkingen = r.afwijkingen.length;
      details.index = lijst(r.afwijkingen.map((a) => ({ id: a.id, soort: a.soort })));
      if (!r.geschreven) fouten.push({ stap: "index", soort: "niet-geschreven" });
    }
    if (lijstFout) throw lijstFout;
    if (indexFout) throw indexFout;
  });

  await stap("termijnen", async () => {
    const b = await berekenFataalBlok(regels, vandaagAmsterdam(nu), nu, opties);
    const tel = telFataal(b.items);
    Object.assign(aantallen, {
      trajecten: b.trajecten, fataalItems: tel.aantal, verlopen: tel.verlopen, signalen: tel.signalen,
      gezondheid: b.gezondheid.length, onvolledig: b.onvolledig.length, onleesbaar: b.onleesbaar.length,
      konNietBerekenen: b.items.filter((i) => i.status === "kon-niet-berekenen").length,
    });
    details.fataal = lijst(b.items.map((i) => ({ recordId: i.recordId ?? null, regelId: i.regelId ?? null, status: i.status })));
    details.onvolledig = lijst(b.onvolledig.map((o) => ({ id: o.id, relatieId: o.relatieId })));
    details.onleesbaar = lijst(b.onleesbaar.map((o) => ({ id: o.id, relatieId: o.relatieId })));
  });

  await stap("instroomClaims", async () => {
    const r = await ruimVerlopenClaimsOp(nu);
    aantallen.instroomClaimsOpgeruimd = r.verwijderd;
  });

  const hartslag = { op: nu.toISOString(), ok: fouten.length === 0, handmatig: handmatig === true, afgekapt, aantallen, fouten, details };
  let schrijfOk = true;
  try { await schrijfHartslag(hartslag); } catch { schrijfOk = false; }
  return { ...hartslag, schrijfOk };
}


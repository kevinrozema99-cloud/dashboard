import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { CATALOGUS, FEESTDAGEN, valideerRegels, maakRegel } from "./termijnregels.mjs";
import { isBevestigd, termijnenVoor, maakFataalBlok as blokRuw, maakAfvinkRecord, titelVan, isFataal } from "./termijnen.mjs";
import { vandaagAmsterdam, berekenEinddatum, plusDagen, plusMaanden, dagenTussen, weekdag, schuifNaarWerkdag, datumVan } from "./datum.mjs";
import { wisselStatus, wisselFase, isIsoTijdstip, controleerWaarde, valideerRelatie, valideerTraject } from "./model.mjs";
import { testCatalogus, testRegel } from "./test-regels.mjs";

const VANDAAG = "2026-11-10";
// De meeste tests kijken naar het blok zelf; `gezondheid` testen we apart met blokRuw.
const maakFataalBlok = (...a) => blokRuw(...a).items;
const T = (extra = {}) => ({ id: "t_1", relatieId: "r_1", fase: "Besluit", ...extra });
const R = (extra = {}) => ({ id: "r_1", achternaam: "Test", status: "Klant", aangemaakt: { wie: "kevin", op: "2026-11-02T10:00:00Z" }, ...extra });
const REGELS = testCatalogus();
const vind = (items, id) => items.find((i) => i.regelId === id);
const traj = (t, r = R(), regels = REGELS, v = VANDAAG, o) => termijnenVoor(t, r, regels, v, o);

// ---- datum ----
test("T13: vandaag volgens Europe/Amsterdam, zomer en winter", () => {
  assert.equal(vandaagAmsterdam(new Date("2026-07-10T23:30:00Z")), "2026-07-11"); // CEST
  assert.equal(vandaagAmsterdam(new Date("2026-07-10T21:30:00Z")), "2026-07-10");
  assert.equal(vandaagAmsterdam(new Date("2026-01-10T23:30:00Z")), "2026-01-11"); // CET
  assert.equal(vandaagAmsterdam(new Date("2026-01-10T22:30:00Z")), "2026-01-10");
});

test("datum: optellen over zomertijdwissel, maanden, dagen tussen", () => {
  assert.equal(plusDagen("2026-10-20", 21), "2026-11-10");
  assert.equal(dagenTussen("2026-10-20", "2026-11-10"), 21);
  assert.equal(plusMaanden("2026-01-31", 1), "2026-02-28");
  assert.equal(datumVan("2026-07-10T23:30:00Z"), "2026-07-11");
  assert.equal(datumVan(null), null);
  assert.throws(() => datumVan("kapot"));
});

test("T14: einde op zaterdag: doorschuiven naar maandag, niet blijft zaterdag", () => {
  const duur = { aantal: 3, eenheid: "weken" };
  assert.equal(weekdag("2026-11-14"), 6);
  assert.equal(berekenEinddatum("2026-10-24", duur, "dag-na-start", "doorschuiven"), "2026-11-16");
  assert.equal(berekenEinddatum("2026-10-24", duur, "dag-na-start", "niet"), "2026-11-14");
  // feestdag meenemen
  assert.equal(berekenEinddatum("2026-10-24", duur, "dag-na-start", "doorschuiven", ["2026-11-16"]), "2026-11-17");
  assert.equal(schuifNaarWerkdag("2026-11-15"), "2026-11-16");
});

test("telling: dag-na-start tegenover zelfde-dag", () => {
  const duur = { aantal: 3, eenheid: "weken" };
  assert.equal(berekenEinddatum("2026-11-02", duur, "dag-na-start", "niet"), "2026-11-23");
  assert.equal(berekenEinddatum("2026-11-02", duur, "zelfde-dag", "niet"), "2026-11-22");
  assert.throws(() => berekenEinddatum("2026-11-02", duur, null, "niet"));
  assert.throws(() => berekenEinddatum("2026-11-02", duur, "dag-na-start", null));
});

// ---- engine ----
test("T1: brondatum + regel (3 weken, dag-na) geeft einddatum en dagenOver", () => {
  const i = vind(traj(T({ verzenddatumBesluitbrief: "2026-11-02" })), "deal-bezwaar");
  assert.equal(i.status, "open");
  assert.equal(i.einddatum, "2026-11-23");
  assert.equal(i.dagenOver, 13);
  assert.equal(i.titel, "Fatale termijn: bezwaar uiterlijk op 2026-11-23");
});

test("T2: brondatum gewijzigd, niet afgevinkt: einddatum schuift mee", () => {
  const a = vind(traj(T({ verzenddatumBesluitbrief: "2026-11-02" })), "deal-bezwaar");
  const b = vind(traj(T({ verzenddatumBesluitbrief: "2026-11-05" })), "deal-bezwaar");
  assert.equal(dagenTussen(a.einddatum, b.einddatum), 3);
});

const afgevinkt = (brondatum) => ({ "deal-bezwaar": { actie: "Bezwaar ingediend", brondatum, wie: "ruben", op: "2026-11-03T08:00:00Z" } });

test("T3: afgevinkt, daarna brondatum gewijzigd: herbevestigen, staat in fatale blok", () => {
  const t = T({ verzenddatumBesluitbrief: "2026-11-02", afgevinkt: afgevinkt("2026-11-02") });
  assert.equal(vind(traj(t), "deal-bezwaar").status, "afgevinkt");
  const t2 = { ...t, verzenddatumBesluitbrief: "2026-11-04" };
  assert.equal(vind(traj(t2), "deal-bezwaar").status, "herbevestigen");
  const blok = maakFataalBlok([t2], [R()], REGELS, VANDAAG);
  assert.ok(blok.some((b) => b.regelId === "deal-bezwaar" && b.status === "herbevestigen"));
});

test("T4: brondatum leeg bij fase Besluit: datum-ontbreekt, fataal; eerder in het traject nvt", () => {
  const i = vind(traj(T()), "deal-bezwaar");
  assert.equal(i.status, "datum-ontbreekt");
  assert.equal(i.fataal, true);
  assert.equal(vind(traj(T({ fase: "Adviesrapport" })), "deal-bezwaar").status, "nvt");
  // expliciet onbekend blijft een fataal signaal
  assert.equal(vind(traj(T({ verzenddatumOnbekend: true })), "deal-bezwaar").status, "datum-ontbreekt");
});

test("T6: regel met aantal null: niet-bevestigd, geen einddatum", () => {
  const regels = testCatalogus({ "deal-bezwaar": { duur: { aantal: null, eenheid: "weken" } } });
  const i = vind(traj(T({ verzenddatumBesluitbrief: "2026-11-02" }), R(), regels), "deal-bezwaar");
  assert.equal(i.status, "niet-bevestigd");
  assert.equal(i.einddatum, null);
  assert.equal(i.dagenOver, null);
  // ook de echte catalogus, en ook bij ontbrekende bevestiging met wel een getal
  assert.equal(vind(traj(T({ verzenddatumBesluitbrief: "2026-11-02" }), R(), CATALOGUS), "deal-bezwaar").status, "niet-bevestigd");
  const zonderBevestiging = testCatalogus({ "deal-bezwaar": { bevestigd: null } });
  assert.equal(vind(traj(T({ verzenddatumBesluitbrief: "2026-11-02" }), R(), zonderBevestiging), "deal-bezwaar").status, "niet-bevestigd");
});

test("T7: 200 dagen verlopen, traject Afgerond, niet afgevinkt: nog in het blok", () => {
  const eind = plusDagen(VANDAAG, -200);
  const start = plusDagen(eind, -21);
  const t = T({ fase: "Afgerond", verzenddatumBesluitbrief: start });
  const blok = maakFataalBlok([t], [R()], REGELS, VANDAAG);
  const i = blok.find((b) => b.regelId === "deal-bezwaar");
  assert.equal(i.dagenOver, -200);
  assert.equal(i.status, "open");
});

test("T17: fatale termijn afvinken zonder actie wordt geweigerd", () => {
  const bezwaar = testRegel("deal-bezwaar");
  assert.equal(maakAfvinkRecord(bezwaar, "2026-11-02", { wie: "ruben" }).fout, "actie-verplicht");
  assert.equal(maakAfvinkRecord(bezwaar, "2026-11-02", { actie: "Iets anders", wie: "ruben" }).fout, "actie-niet-toegestaan");
  const ok = maakAfvinkRecord(bezwaar, "2026-11-02", { actie: "Bezwaar ingediend", wie: "ruben" }, new Date("2026-11-03T08:00:00Z"));
  assert.deepEqual(ok.waarde, { actie: "Bezwaar ingediend", brondatum: "2026-11-02", wie: "ruben", op: "2026-11-03T08:00:00.000Z" });
  // fataal null zonder bekende acties: kan niet (onbekend is veilig)
  assert.equal(maakAfvinkRecord(testRegel("deal-zienswijze"), "2026-11-02", { actie: "x", wie: "ruben" }).fout, "geen-acties-bekend");
  // niet-fatale regel: actie niet nodig
  assert.ok(maakAfvinkRecord(testRegel("deal-opname"), "2026-11-02", { wie: "ruben" }).waarde);
});

test("T18: fout bij één traject: item 'kon niet berekenen', niets overgeslagen", () => {
  const trajecten = [T({ id: "t_1", verzenddatumBesluitbrief: "2026-11-02" }), T({ id: "t_2", verzenddatumBesluitbrief: "2026-11-02" }), T({ id: "t_3", verzenddatumBesluitbrief: "2026-11-02" })];
  const bereken = (t, ...rest) => { if (t?.id === "t_2") throw new Error("boem"); return termijnenVoor(t, ...rest); };
  const blok = maakFataalBlok(trajecten, [R()], REGELS, VANDAAG, { bereken });
  const kapot = blok.filter((b) => b.status === "kon-niet-berekenen");
  assert.equal(kapot.length, 1);
  assert.equal(kapot[0].titel, "kon niet berekenen: t_2");
  assert.ok(blok.some((b) => b.recordId === "t_1" && b.regelId === "deal-bezwaar"));
  assert.ok(blok.some((b) => b.recordId === "t_3" && b.regelId === "deal-bezwaar"));
});

test("T18b: onleesbare brondatum in echte data geeft ook 'kon niet berekenen'", () => {
  const blok = maakFataalBlok([T({ id: "t_9", verzenddatumBesluitbrief: "kapot" }), null], [R()], REGELS, VANDAAG);
  assert.ok(blok.some((b) => b.titel === "kon niet berekenen: t_9"));
  assert.ok(blok.some((b) => b.titel === "kon niet berekenen: onbekend"));
});

test("fatale blok filtert nooit op eigenaar of zoekterm: blok = vereniging van de blokken per traject", () => {
  const relaties = [R({ id: "r_1", eigenaar: "kevin", achternaam: "Kevinsklant", status: "Klant" }), R({ id: "r_2", eigenaar: "ruben", achternaam: "Rubensklant", status: "Afgevallen", redenAfgevallen: "Anders" })];
  const trajecten = [T({ id: "t_1", relatieId: "r_1", verzenddatumBesluitbrief: "2026-11-02" }), T({ id: "t_2", relatieId: "r_2", fase: "Afgerond", verzenddatumBesluitbrief: "2026-01-02" })];
  const alles = maakFataalBlok(trajecten, relaties, REGELS, VANDAAG);
  const los = trajecten.flatMap((t) => maakFataalBlok([t], relaties.filter((r) => r.id === t.relatieId), REGELS, VANDAAG));
  const sleutel = (b) => `${b.recordId}/${b.regelId}/${b.status}`;
  assert.deepEqual(alles.map(sleutel).sort(), los.map(sleutel).sort());
  assert.deepEqual([...new Set(alles.map((x) => x.naam))].sort(), ["Kevinsklant", "Rubensklant"]);
  // ook de afgevallen relatie van Ruben en het afgeronde traject staan erin
  assert.ok(alles.some((x) => x.recordId === "t_2" && x.regelId === "deal-bezwaar"));
  assert.ok(alles.every((x) => x.fataal));
});

test("fatale blok: niet-fatale en nvt-regels staan er niet in, aflopend naar urgentie", () => {
  const blok = maakFataalBlok([T({ id: "t_1", fase: "Opname gepland", opnamedatum: "2026-11-05" }), T({ id: "t_2", verzenddatumBesluitbrief: "2026-11-02" })], [R()], REGELS, VANDAAG);
  assert.ok(!blok.some((b) => b.regelId === "deal-opname"));
  assert.deepEqual(blok.map((b) => b.regelId).sort(), ["deal-besluit-controleren", "deal-bezwaar", "deal-bezwaar-beslissen", "deal-zienswijze"]);
});

// ---- regels / catalogus ----
// T19: Zoho-regelnamen uit dashboard/zoho-export/README.md (tabel Workflowregels), met het aantal acties,
// minus de bewust weggelaten regels (Big Deal Rule, dealnaam uit contact, de vier Kwalificatie-regels).
const ZOHO_REGELS = {
  "Lead: belpoging 2 na Poging 1": 1, "Deal: opname voorbereiden": 1, "Lead: belpoging 3 na Poging 2": 1,
  "Deal: zienswijze na adviesrapport": 1, "Lead: WhatsApp na Poging 3": 1, "Deal: termijnen na besluitbrief": 3,
  "Lead: afsluiten na WhatsApp": 1, "Deal: factuur na uitbetaling": 1, "Lead: nieuwe lead bellen": 1,
  "Lead: vangnet terugbeldatum": 1,
};
test("T19: catalogus = Zoho-lijst (regels met zoho: null vallen erbuiten)", () => {
  assert.deepEqual(valideerRegels(CATALOGUS), []);
  const tel = {};
  for (const r of CATALOGUS) if (r.zoho !== null) tel[r.zoho] = (tel[r.zoho] || 0) + 1;
  assert.deepEqual(tel, ZOHO_REGELS);
  assert.deepEqual(CATALOGUS.filter((r) => r.zoho === null).map((r) => r.id), ["lead-terugbellen"]);
  assert.ok(!CATALOGUS.some((r) => /Big Deal|dealnaam|Kwalificatie/.test(r.zoho || "")));
});

test("catalogus: ids en eigenschappen uit de aanvullingen", () => {
  const id = (x) => CATALOGUS.find((r) => r.id === x);
  assert.deepEqual(CATALOGUS.filter((r) => r.zoho === "Deal: termijnen na besluitbrief").map((r) => r.id),
    ["deal-besluit-controleren", "deal-bezwaar-beslissen", "deal-bezwaar"]);
  assert.equal(id("deal-bezwaar").fataal, true);
  assert.deepEqual(id("deal-bezwaar").afvinkActies, ["Bezwaar ingediend", "Besluit geaccepteerd"]);
  assert.equal(id("deal-besluit-controleren").fataal, null);
  assert.equal(id("deal-zienswijze").fataal, null);
  assert.deepEqual(id("deal-zienswijze").voorstelUitZoho, { aantal: 2, eenheid: "weken" });
  assert.equal(id("deal-opname").geldtZolang, null);
  assert.equal(id("lead-terugbeldatum").actief, false);
  assert.equal(id("lead-terugbellen").actief, true);
  assert.deepEqual(id("lead-afsluiten").vervolgActie, { status: "Afgevallen", redenAfgevallen: "Niet bereikt" });
  assert.ok(!id("lead-terugbellen").geldtZolang.status.some((s) => ["Afgevallen", "Klant", "Niet gekwalificeerd"].includes(s)));
});

test("T20: geen enkel getal, telling, weekendregel of feestdag zonder bevestiging", () => {
  assert.equal(FEESTDAGEN.length, 0);
  for (const r of CATALOGUS) {
    assert.equal(r.duur.aantal, null, r.id);
    assert.equal(r.duur.eenheid, null, r.id);
    assert.equal(r.telling, null, r.id);
    assert.equal(r.weekendFeestdag, null, r.id);
    assert.equal(r.bevestigd, null, r.id);
  }
  // voorstelUitZoho is alleen informatief en verandert niets
  const i = vind(traj(T({ fase: "Adviesrapport", datumAdviesrapport: "2026-11-01" }), R(), CATALOGUS), "deal-zienswijze");
  assert.equal(i.status, "niet-bevestigd");
  assert.equal(i.einddatum, null);
  // de testcatalogus mag niet in productiecode zitten
  for (const f of ["model.mjs", "datum.mjs", "termijnregels.mjs", "termijnen.mjs"]) {
    assert.ok(!readFileSync(new URL(f, import.meta.url), "utf8").includes("test-regels"), f);
  }
  // elke echte regel, zonder bevestiging, geeft nooit een einddatum
  for (const r of CATALOGUS) {
    const rec = r.record === "traject" ? T({ fase: "Uitbetaald", opnamedatum: "2026-11-01", datumAdviesrapport: "2026-11-01", verzenddatumBesluitbrief: "2026-11-01", fasegeschiedenis: [{ fase: "Uitbetaald", van: "2026-11-01", wie: "x" }] }) : null;
    const rel = R({ status: "Nieuw", terugbeldatum: "2026-11-20" });
    for (const x of termijnenVoor(rec, rel, [r], VANDAAG)) assert.equal(x.einddatum, null, r.id);
  }
});

test("titel null en <einddatum>", () => {
  assert.equal(titelVan({ zoho: "Zoho-naam", titel: null }), "Actie uit Zoho-regel 'Zoho-naam', inhoud nog onbekend");
  assert.equal(titelVan({ zoho: "x", titel: "Op <einddatum>" }), "Op <einddatum>");
  const regels = testCatalogus({ "deal-bezwaar": { titel: null } });
  assert.match(vind(traj(T({ verzenddatumBesluitbrief: "2026-11-02" }), R(), regels), "deal-bezwaar").titel, /^Actie uit Zoho-regel 'Deal: termijnen na besluitbrief', inhoud nog onbekend$/);
});

test("fataal null telt als fataal; geldtZolang geldt niet voor fatale regels", () => {
  assert.equal(isFataal({ fataal: null }), true);
  assert.equal(isFataal({ fataal: false }), false);
  // zienswijze (fataal null, geldtZolang null) blijft staan als de fase al verder is
  const i = vind(traj(T({ fase: "Uitbetaald", datumAdviesrapport: "2026-11-01" })), "deal-zienswijze");
  assert.equal(i.status, "open");
  // een niet-fatale regel met geldtZolang verdwijnt wel
  const regels = testCatalogus({ "deal-factuur": { geldtZolang: { fase: ["Uitbetaald"] } } });
  const f = (fase) => vind(traj(T({ fase, fasegeschiedenis: [{ fase: "Uitbetaald", van: "2026-11-01", wie: "x" }] }), R(), regels), "deal-factuur").status;
  assert.equal(f("Uitbetaald"), "open");
  assert.equal(f("Afgerond"), "nvt");
});

test("T25: deal-besluit-* bij fase Besluit zonder datum: drie fatale signalen", () => {
  const blok = maakFataalBlok([T()], [R()], REGELS, VANDAAG);
  const s = blok.filter((b) => b.status === "datum-ontbreekt" && (b.regelId.startsWith("deal-bezwaar") || b.regelId === "deal-besluit-controleren"));
  assert.deepEqual(s.map((b) => b.regelId).sort(), ["deal-besluit-controleren", "deal-bezwaar", "deal-bezwaar-beslissen"]);
  assert.ok(s.every((b) => b.fataal));
});

test("T26: één afgevinkt, de andere twee blijven", () => {
  const t = T({ verzenddatumBesluitbrief: "2026-11-02", afgevinkt: afgevinkt("2026-11-02") });
  const blok = maakFataalBlok([t], [R()], REGELS, VANDAAG);
  assert.deepEqual(blok.map((b) => b.regelId).sort(), ["deal-besluit-controleren", "deal-bezwaar-beslissen", "deal-zienswijze"]);
});

test("T27: actief false geeft nvt", () => {
  const regels = testCatalogus({ "deal-opname": { actief: false } });
  assert.equal(vind(traj(T({ opnamedatum: "2026-11-05" }), R(), regels), "deal-opname").status, "nvt");
  assert.equal(vind(traj(T({ opnamedatum: "2026-11-05" })), "deal-opname").status, "open");
  // het vangnet staat uit zoals in Zoho
  const rel = R({ status: "Contact gehad", statusgeschiedenis: [{ status: "Contact gehad", van: "2026-11-01", wie: "x" }] });
  assert.equal(vind(termijnenVoor(null, rel, REGELS, VANDAAG), "lead-terugbeldatum").status, "nvt");
});

test("T27b: actief false, geldtVoor en alsLeeg gelden niet voor fatale regels", () => {
  const t = T({ verzenddatumBesluitbrief: "2026-11-02", route: "AVV", opnamedatum: "2026-11-01" });
  const regels = testCatalogus({ "deal-bezwaar": { actief: false, geldtVoor: { routes: ["Herstel met aannemer"], fases: null }, alsLeeg: "opnamedatum" } });
  const i = vind(traj(t, R(), regels), "deal-bezwaar");
  assert.equal(i.status, "open");
  assert.ok(valideerRegels(regels).some((f) => f.startsWith("deal-bezwaar")));
  assert.equal(valideerRegels(regels).length, 3);
  assert.deepEqual(valideerRegels(REGELS), []);
  assert.deepEqual(valideerRegels(CATALOGUS), []);
});

test("deal-opname: aan opnamedatum gebonden, niet aan een fase", () => {
  assert.equal(vind(traj(T({ fase: "Schaderapport", opnamedatum: "2026-11-05" })), "deal-opname").status, "open");
  assert.equal(vind(traj(T({ fase: "Schaderapport" })), "deal-opname").status, "nvt");
});

test("vangnet terugbeldatum: status in de drie én terugbeldatum leeg", () => {
  const regels = testCatalogus({ "lead-terugbeldatum": { actief: true } });
  const rel = (extra) => R({ status: "Later opnieuw", statusgeschiedenis: [{ status: "Later opnieuw", van: "2026-11-01", wie: "x" }], ...extra });
  const st = (r) => vind(termijnenVoor(null, r, regels, VANDAAG), "lead-terugbeldatum");
  assert.equal(st(rel()).status, "open");
  assert.equal(st(rel()).titel, "Terugbeldatum zetten");
  assert.equal(st(rel({ terugbeldatum: "2026-12-01" })).status, "nvt");
  assert.equal(st(rel({ status: "Poging 1" })).status, "nvt");
  assert.equal(vind(termijnenVoor(null, rel({ terugbeldatum: "2026-12-01" }), regels, VANDAAG), "lead-terugbellen").status, "open");
  assert.equal(vind(termijnenVoor(null, rel({ status: "Niet gekwalificeerd", terugbeldatum: "2026-12-01" }), regels, VANDAAG), "lead-terugbellen").status, "nvt");
});

// ---- leadketen ----
const KETEN = ["lead-bellen", "lead-poging-2", "lead-poging-3", "lead-whatsapp", "lead-afsluiten"];
const lead = (status, geschiedenis) => R({ status, statusgeschiedenis: geschiedenis ?? [{ status, van: "2026-11-02", wie: "kevin" }] });
const ketenItems = (rel, regels = REGELS) => termijnenVoor(null, rel, regels, VANDAAG).filter((i) => KETEN.includes(i.regelId) && i.status !== "nvt");

test("T21: precies één ketentaak per stap", () => {
  const verwacht = { Nieuw: "lead-bellen", "Poging 1": "lead-poging-2", "Poging 2": "lead-poging-3", "Poging 3": "lead-whatsapp", "WhatsApp verstuurd": "lead-afsluiten" };
  for (const [status, id] of Object.entries(verwacht)) {
    for (const regels of [REGELS, CATALOGUS]) {
      const items = ketenItems(lead(status), regels);
      assert.deepEqual(items.map((i) => i.regelId), [id], status);
    }
    assert.equal(ketenItems(lead(status))[0].status, "open");
  }
});

test("T22: terugzetten Poging 2 naar Poging 1: Belpoging 3 verdwijnt, Belpoging 2 komt terug met nieuwe start", () => {
  const g = [
    { status: "Nieuw", van: "2026-11-01", wie: "x" }, { status: "Poging 1", van: "2026-11-02", wie: "x" },
    { status: "Poging 2", van: "2026-11-03", wie: "x" }, { status: "Poging 1", van: "2026-11-05", wie: "x" },
  ];
  const items = ketenItems(lead("Poging 1", g));
  assert.deepEqual(items.map((i) => i.regelId), ["lead-poging-2"]);
  assert.equal(items[0].brondatum, "2026-11-05");
  assert.equal(items[0].einddatum, "2026-11-26");
});

test("T23: Contact gehad stopt de keten (ook Afspraak gepland, Afgevallen, Klant)", () => {
  for (const s of ["Contact gehad", "Afspraak gepland", "Later opnieuw", "Afgevallen", "Klant", "Niet gekwalificeerd"]) {
    assert.deepEqual(ketenItems(lead(s)), [], s);
  }
});

test("T24b: de vervolgactie van elke ketenregel is een geldige statuswissel", () => {
  for (const r of CATALOGUS.filter((x) => KETEN.includes(x.id))) {
    const van = r.start.soort === "aangemaakt" ? "Nieuw" : r.start.waarde;
    const uit = wisselStatus(lead(van), r.vervolgActie.status, { reden: r.vervolgActie.redenAfgevallen, wie: "kevin", van: VANDAAG });
    assert.ok(uit.waarde, r.id + JSON.stringify(uit));
    assert.equal(uit.waarde.status, r.vervolgActie.status);
    // na de wissel is de oude ketentaak weg
    assert.ok(!ketenItems(uit.waarde).some((i) => i.regelId === r.id));
  }
  const afsluiten = wisselStatus(lead("WhatsApp verstuurd"), "Afgevallen", { reden: "Niet bereikt", wie: "kevin", van: VANDAAG });
  assert.equal(afsluiten.logregel.wijzigingen.length, 2);
});

test("lead-bellen: start is de aanmaakdatum (Amsterdam)", () => {
  const rel = R({ status: "Nieuw", aangemaakt: { wie: "x", op: "2026-11-02T23:30:00Z" }, statusgeschiedenis: [] });
  const i = vind(termijnenVoor(null, rel, REGELS, VANDAAG), "lead-bellen");
  assert.equal(i.brondatum, "2026-11-03");
  assert.equal(i.einddatum, "2026-11-24");
});

test("eigen test: status zonder geschiedenis geeft datum-ontbreekt, ander status nvt", () => {
  const rel = R({ status: "Poging 1", statusgeschiedenis: [] });
  assert.equal(vind(termijnenVoor(null, rel, REGELS, VANDAAG), "lead-poging-2").status, "datum-ontbreekt");
  assert.equal(vind(termijnenVoor(null, rel, REGELS, VANDAAG), "lead-poging-3").status, "nvt");
});

test("deal-zienswijze: vanaf fase Adviesrapport is een lege datum een fataal signaal", () => {
  const blok = maakFataalBlok([T({ fase: "Adviesrapport" })], [R()], REGELS, VANDAAG);
  const i = blok.find((b) => b.regelId === "deal-zienswijze");
  assert.equal(i.status, "datum-ontbreekt");
  assert.equal(i.fataal, true);
  assert.equal(vind(traj(T({ fase: "Uitbetaald" })), "deal-zienswijze").status, "datum-ontbreekt");
  assert.equal(vind(traj(T({ fase: "Opname gedaan" })), "deal-zienswijze").status, "nvt");
  // Schaderapport is samengevoegd met Adviesrapport (20-11-2026): een oud record telt als Adviesrapport.
  assert.equal(vind(traj(T({ fase: "Schaderapport" })), "deal-zienswijze").status, "datum-ontbreekt");
});

// ---- review-punten ----
const REGELS_ONB = testCatalogus({ "deal-besluit-controleren": { bevestigd: null }, "deal-bezwaar-beslissen": { bevestigd: null } });

test("sortering: verlopen open eerst, dan open op einddatum, dan signalen; fataal-null niet-bevestigd samengevat", () => {
  const trajecten = [
    T({ id: "t_b", verzenddatumBesluitbrief: undefined }),                       // signalen: datum ontbreekt
    T({ id: "t_c", verzenddatumBesluitbrief: "2026-11-05" }),                    // bezwaar open, nog 16 dagen
    T({ id: "t_a", verzenddatumBesluitbrief: "2026-10-01" }),                    // bezwaar verlopen (-19)
    T({ id: "t_d", verzenddatumBesluitbrief: "2026-11-01" }),                    // bezwaar open, nog 12 dagen
  ];
  const blok = maakFataalBlok(trajecten, [R()], REGELS_ONB, VANDAAG);
  const open = blok.filter((b) => b.status === "open");
  assert.deepEqual(open.map((b) => `${b.recordId}:${b.dagenOver}`), ["t_a:-19", "t_d:12", "t_c:16"]);
  // rang 0 (verlopen open, datum ontbreekt) vóór open-niet-verlopen vóór niet-bevestigd
  const volgorde = blok.map((b) => `${b.recordId}/${b.status}`);
  assert.ok(volgorde.indexOf("t_a/open") < volgorde.indexOf("t_b/datum-ontbreekt"));
  assert.ok(volgorde.lastIndexOf("t_b/datum-ontbreekt") < volgorde.indexOf("t_d/open"));
  assert.ok(volgorde.indexOf("t_c/open") < volgorde.findIndex((x) => x.endsWith("/niet-bevestigd")));
  // per traject één samengevat niet-bevestigd signaal voor de twee fataal-null regels
  const samen = blok.filter((b) => b.status === "niet-bevestigd");
  assert.equal(samen.length, 3);
  assert.ok(samen.every((b) => b.samengevat && b.aantal === 2 && b.regelId === null && b.zoho === null));
  assert.deepEqual(samen[0].regelIds.sort(), ["deal-besluit-controleren", "deal-bezwaar-beslissen"]);
});

test("sortering: fataal true niet-bevestigd blijft een eigen item en blijft onder de open termijnen", () => {
  const regels = testCatalogus({ "deal-bezwaar": { bevestigd: null } });
  const blok = maakFataalBlok([T({ verzenddatumBesluitbrief: "2026-11-02" })], [R()], regels, VANDAAG);
  assert.ok(blok.some((b) => b.regelId === "deal-bezwaar" && b.status === "niet-bevestigd" && !b.samengevat));
});

test("fase Verloren, Verloren (vervallen) of onbekend: vereiste datum blijft een signaal", () => {
  const st = (t) => vind(traj(T(t)), "deal-bezwaar").status;
  const gesch = (...f) => f.map((fase) => ({ fase, van: "2026-10-01", wie: "x" }));
  assert.equal(st({ fase: "Verloren", fasegeschiedenis: gesch("Aanvraag ingediend", "Besluit", "Verloren") }), "datum-ontbreekt");
  assert.equal(st({ fase: "Verloren", fasegeschiedenis: gesch("Aanvraag ingediend", "Verloren") }), "nvt");
  // Verloren zonder bruikbare geschiedenis: veilige kant (vereist). Alleen "Verloren" in de geschiedenis telt niet.
  assert.equal(st({ fase: "Verloren" }), "datum-ontbreekt");
  assert.equal(st({ fase: "Verloren", fasegeschiedenis: gesch("Verloren") }), "datum-ontbreekt");
  assert.equal(st({ fase: "Verloren (vervallen)" }), "datum-ontbreekt");
  assert.equal(st({ fase: "Onzin" }), "datum-ontbreekt");
  assert.equal(st({ fase: undefined }), "datum-ontbreekt");
  assert.equal(st({ fase: "Getekend", fasegeschiedenis: gesch("Bezwaar", "Getekend") }), "datum-ontbreekt"); // ooit voorbij Besluit
  assert.equal(st({ fase: "Opname gepland", fasegeschiedenis: gesch("Opname gepland") }), "nvt");
  // en dus staat zo'n traject in het blok
  const blok = maakFataalBlok([T({ fase: "Verloren (vervallen)" })], [R()], REGELS, VANDAAG);
  assert.ok(blok.some((b) => b.regelId === "deal-bezwaar" && b.status === "datum-ontbreekt"));
  assert.ok(blok.length > 0);
});

test("fout in één niet-fatale regel verbergt de fatale einddatum niet", () => {
  const t = T({ verzenddatumBesluitbrief: "2026-11-02", opnamedatum: "kapot" });
  const items = traj(t);
  assert.equal(vind(items, "deal-opname").status, "kon-niet-berekenen");
  assert.equal(vind(items, "deal-opname").titel, "kon niet berekenen: t_1");
  assert.equal(vind(items, "deal-bezwaar").einddatum, "2026-11-23");
  const { items: blokItems, gezondheid } = blokRuw([t], [R()], REGELS, VANDAAG);
  assert.ok(blokItems.some((b) => b.regelId === "deal-bezwaar" && b.status === "open"));
  // niet-fataal: niet in het fatale blok, wel in de gezondheidslijst (N5)
  assert.equal(blokItems.filter((b) => b.status === "kon-niet-berekenen").length, 0);
  assert.deepEqual(gezondheid.map((g) => `${g.recordId}/${g.regelId}`), ["t_1/deal-opname"]);
});

test("maakRegel: een eigen duur blijft behouden (null alleen als niets is opgegeven)", () => {
  const bezwaar = CATALOGUS.find((r) => r.id === "deal-bezwaar");
  assert.equal(isBevestigd(bezwaar), false);
  const r = maakRegel({ ...bezwaar, duur: { aantal: 3, eenheid: "weken" }, telling: "dag-na-start", weekendFeestdag: "niet", bevestigd: { door: "test", op: "2000-01-01", bron: "fictief" } });
  assert.deepEqual({ ...r.duur }, { aantal: 3, eenheid: "weken" });
  assert.equal(isBevestigd(r), true);
  const kopie = CATALOGUS.map((x) => (x.id === "deal-bezwaar" ? r : x));
  assert.equal(vind(traj(T({ verzenddatumBesluitbrief: "2026-11-02" }), R(), kopie), "deal-bezwaar").einddatum, "2026-11-23");
  assert.equal(maakRegel({ ...bezwaar, duur: undefined }).duur.aantal, null);
});

test("afvinkrecord: actie null bij niet-fatale regel, brondatum en wie gecontroleerd; model accepteert het", () => {
  const opname = testRegel("deal-opname");
  const a = maakAfvinkRecord(opname, "2026-11-01", { wie: "ruben" }, new Date("2026-11-03T08:00:00Z"));
  assert.equal(a.waarde.actie, null);
  assert.equal(valideerTraject({ relatieId: "r_1", fase: "Opname gepland", afgevinkt: { "deal-opname": a.waarde } }, { systeem: true }).ok, true);
  assert.equal(maakAfvinkRecord(opname, "2026-02-30", { wie: "ruben" }).fout, "brondatum-ontbreekt");
  assert.equal(maakAfvinkRecord(opname, "2026-11-01", { wie: " " }).fout, "wie-verplicht");
  assert.equal(maakAfvinkRecord(opname, "2026-11-01", {}).fout, "wie-verplicht");
  assert.equal(valideerTraject({ relatieId: "r_1", fase: "Getekend", afgevinkt: { x: { ...a.waarde, wie: "" } } }, { systeem: true }).ok, false);
});

test("relatie: afgevinkt is een systeemveld en de engine leest het voor relatieregels", () => {
  const rec = { ...lead("Nieuw"), afgevinkt: { "lead-bellen": { actie: null, brondatum: "2026-11-02", wie: "kevin", op: "2026-11-03T08:00:00Z" } } };
  assert.equal(valideerRelatie(rec, { systeem: true }).ok, true);
  assert.equal(valideerRelatie({ achternaam: "x", status: "Nieuw", afgevinkt: {} }).fouten.afgevinkt, "niet-wijzigbaar");
  assert.equal(vind(termijnenVoor(null, rec, REGELS, VANDAAG), "lead-bellen").status, "afgevinkt");
});

test("wisselFase laat afgevinkt ongemoeid", () => {
  const t = { relatieId: "r_1", fase: "Getekend", fasegeschiedenis: [], afgevinkt: { "deal-opname": { actie: null, brondatum: "2026-11-01", wie: "x", op: "2026-11-03T08:00:00Z" } } };
  const r = wisselFase(t, "Aanvraag ingediend", { wie: "kevin", van: "2026-11-04" });
  assert.deepEqual(r.waarde.afgevinkt, t.afgevinkt);
});

test("model: deel slaat kruisregels over; zonderWissel weigert status en fase", () => {
  assert.equal(valideerRelatie({ status: "Afgevallen" }, { deel: true }).ok, true); // kruisregel draait pas op het samengevoegde record
  assert.equal(valideerRelatie({ achternaam: "x", status: "Afgevallen" }, { systeem: true }).ok, false);
  assert.deepEqual(valideerRelatie({ status: "Poging 1", plaats: "x" }, { deel: true, zonderWissel: true }).fouten, { status: "alleen-via-wissel" });
  assert.deepEqual(valideerTraject({ fase: "Besluit" }, { deel: true, zonderWissel: true }).fouten, { fase: "alleen-via-wissel" });
  assert.equal(valideerTraject({ fee: 10 }, { deel: true, zonderWissel: true }).ok, true);
});

test("datum: tijdstip vereist echte datum en Z of offset", () => {
  assert.equal(isIsoTijdstip("2026-11-02T10:00:00Z"), true);
  assert.equal(isIsoTijdstip("2026-11-02T10:00:00+01:00"), true);
  assert.equal(isIsoTijdstip("2026-11-02T10:00:00.123Z"), true);
  for (const x of ["2026-11-02T10:00:00", "2026-02-30T10:00:00Z", "2026-11-02T25:00:00Z", "2026-11-02", "nu", null]) assert.equal(isIsoTijdstip(x), false, String(x));
  assert.throws(() => datumVan("2026-02-30T10:00:00Z"));
  assert.throws(() => datumVan("2026-11-02T10:00:00"));
  assert.equal(datumVan("2026-11-02T23:30:00+00:00"), "2026-11-03");
  assert.equal(valideerRelatie({ achternaam: "x", status: "Nieuw", aangemaakt: { wie: "k", op: "2026-11-02T10:00:00" } }, { systeem: true }).ok, false);
});

test("maandeinde met zelfde-dag (keuze K1, te bevestigen): 31 jan + 1 maand = 28 feb, min 1 dag = 27 feb", () => {
  assert.equal(plusMaanden("2026-01-31", 1), "2026-02-28");
  assert.equal(berekenEinddatum("2026-01-31", { aantal: 1, eenheid: "maanden" }, "zelfde-dag", "niet"), "2026-02-27");
  assert.equal(berekenEinddatum("2026-01-31", { aantal: 1, eenheid: "maanden" }, "dag-na-start", "niet"), "2026-02-28");
});

test("aantal moet minstens 1 zijn", () => {
  assert.throws(() => berekenEinddatum("2026-11-02", { aantal: 0, eenheid: "weken" }, "dag-na-start", "niet"));
  const regels = testCatalogus({ "deal-bezwaar": { duur: { aantal: 0, eenheid: "weken" } } });
  assert.equal(vind(traj(T({ verzenddatumBesluitbrief: "2026-11-02" }), R(), regels), "deal-bezwaar").status, "niet-bevestigd");
});

test("N1: kapotte fatale regel blijft fataal in het blok, met regelIds", () => {
  const { items, gezondheid } = blokRuw([T({ verzenddatumBesluitbrief: "2026-13-01", opnamedatum: "x" })], [R()], REGELS, VANDAAG);
  const kapot = items.filter((b) => b.status === "kon-niet-berekenen");
  assert.equal(kapot.length, 1);
  assert.equal(kapot[0].fataal, true);
  assert.ok(kapot[0].regelIds.includes("deal-bezwaar"));
  assert.equal(items.filter((b) => b.fataal).length, items.length);
  assert.deepEqual(gezondheid.map((g) => g.regelId), ["deal-opname"]);
});

test("N2: datum ontbreekt en kon niet berekenen staan boven een open termijn die pas over weken verloopt", () => {
  const trajecten = [
    T({ id: "t_open", verzenddatumBesluitbrief: "2026-11-09" }),                  // eindigt over 20 dagen
    T({ id: "t_lang", fase: "Bezwaar" }),                                         // lang in Bezwaar, geen besluitdatum
    T({ id: "t_kapot", verzenddatumBesluitbrief: "kapot" }),
  ];
  const blok = maakFataalBlok(trajecten, [R()], REGELS, VANDAAG);
  const pos = (f) => blok.findIndex(f);
  const eersteOpen = pos((b) => b.status === "open");
  assert.ok(eersteOpen > pos((b) => b.recordId === "t_lang" && b.status === "datum-ontbreekt"));
  assert.ok(eersteOpen > pos((b) => b.recordId === "t_kapot" && b.status === "kon-niet-berekenen"));
  // herbevestigen blijft achteraan
  const t = T({ id: "t_h", verzenddatumBesluitbrief: "2026-11-04", afgevinkt: afgevinkt("2026-11-02") });
  const b2 = maakFataalBlok([t, T({ id: "t_open2", verzenddatumBesluitbrief: "2026-11-09" })], [R()], REGELS, VANDAAG);
  assert.ok(b2.findIndex((x) => x.status === "herbevestigen") > b2.findIndex((x) => x.status === "open"));
});

test("N3: signalen van dezelfde soort op oudste brondatum, ontbrekende eerst, dan id", () => {
  const regels = testCatalogus({ "deal-bezwaar": { bevestigd: null }, "deal-besluit-controleren": { actief: true }, "deal-bezwaar-beslissen": { actief: true } });
  const zonderBezwaar = regels.filter((r) => r.id === "deal-bezwaar");
  const trajecten = [
    T({ id: "t_3", verzenddatumBesluitbrief: "2026-11-05" }), T({ id: "t_1", verzenddatumBesluitbrief: "2026-10-01" }),
    T({ id: "t_2", verzenddatumBesluitbrief: "2026-10-01" }), T({ id: "t_0" }),
  ];
  const blok = maakFataalBlok(trajecten, [R()], zonderBezwaar, VANDAAG);
  const nb = blok.filter((b) => b.status === "niet-bevestigd").map((b) => b.recordId);
  assert.deepEqual(nb, ["t_1", "t_2", "t_3"]);
  const dat = maakFataalBlok([T({ id: "t_b" }), T({ id: "t_a" })], [R()], zonderBezwaar, VANDAAG).map((b) => b.recordId);
  assert.deepEqual(dat, ["t_a", "t_b"]);
});

test("N4: samengevat item heeft oudste brondatum, zoho null en regels met brondatum", () => {
  const { items } = blokRuw([T({ verzenddatumBesluitbrief: "2026-11-02" })], [R()], REGELS_ONB, VANDAAG);
  const s = items.find((b) => b.samengevat);
  assert.equal(s.zoho, null);
  assert.equal(s.brondatum, "2026-11-02");
  assert.deepEqual(s.regels.map((x) => x.regelId).sort(), ["deal-besluit-controleren", "deal-bezwaar-beslissen"]);
  assert.ok(s.regels.every((x) => x.brondatum === "2026-11-02"));
  // oudste van verschillende brondatums
  const regels = testCatalogus({ "deal-besluit-controleren": { bevestigd: null, start: { soort: "veld", waarde: "opnamedatum" } }, "deal-bezwaar-beslissen": { bevestigd: null } });
  const t = T({ opnamedatum: "2026-10-20", verzenddatumBesluitbrief: "2026-11-02" });
  assert.equal(blokRuw([t], [R()], regels, VANDAAG).items.find((b) => b.samengevat).brondatum, "2026-10-20");
});

test("N5: gezondheidslijst bevat niet-fatale fouten, het blok niet", () => {
  const { items, gezondheid } = blokRuw([T({ opnamedatum: "x", verzenddatumBesluitbrief: "2026-11-02" })], [R()], REGELS, VANDAAG);
  assert.ok(items.every((b) => b.status !== "kon-niet-berekenen"));
  assert.equal(gezondheid.length, 1);
  assert.equal(gezondheid[0].titel, "kon niet berekenen: t_1");
  assert.deepEqual(blokRuw([T({ verzenddatumBesluitbrief: "2026-11-02" })], [R()], REGELS, VANDAAG).gezondheid, []);
});

test("restpunt: Verloren met lege geschiedenis geeft datum-ontbreekt, niet 0 items", () => {
  const blok = maakFataalBlok([T({ fase: "Verloren", fasegeschiedenis: [] })], [R()], REGELS, VANDAAG);
  assert.ok(blok.some((b) => b.regelId === "deal-bezwaar" && b.status === "datum-ontbreekt"));
  assert.ok(maakFataalBlok([T({ fase: "Verloren" })], [R()], REGELS, VANDAAG).length > 0);
});

test("taken: prototype-sleutels en ongeldige ids geweigerd, onbekend spec-type is een veldfout", () => {
  const basis = { achternaam: "x", status: "Nieuw" };
  for (const id of ["__proto__", "constructor", "prototype", "a b", "", "x".repeat(65)]) {
    const taken = JSON.parse(`{${JSON.stringify(id)}: {"soort":"taak","titel":"t"}}`);
    const r = valideerRelatie({ ...basis, taken });
    assert.equal(r.ok, false, id);
    assert.equal(r.fouten[`taken.${id}`], "ongeldig", id);
  }
  assert.equal(({}).soort, undefined); // prototype niet vervuild
  assert.equal(valideerRelatie({ ...basis, taken: { t_1: { soort: "taak", titel: "t" } } }).ok, true);
  assert.equal(valideerRelatie({ ...basis, afgevinkt: JSON.parse('{"__proto__":{}}') }, { systeem: true }).ok, false);
  assert.deepEqual(controleerWaarde({ type: "bestaat-niet" }, "x"), { fout: "ongeldig" });
});

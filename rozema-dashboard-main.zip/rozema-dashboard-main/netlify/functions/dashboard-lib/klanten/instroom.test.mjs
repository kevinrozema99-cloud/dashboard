// Tests voor instroom.mjs (K9). Alleen fictieve data.
import { test, beforeEach, afterEach } from "node:test";
import assert from "node:assert/strict";
import { zetStoreFabriek, zetContext, storeNaam } from "../opslag.mjs";
import { geheugenFabriek } from "../test-hulp.mjs";
import { leesRelatie, leesIndex, leesTijdlijn } from "./opslag.mjs";
import {
  vertaalAanvraag, splitsHuisnummer, ontdubbelHash, neemAanvraagOp, zetSituatie, bewaarZohoId, verwijderClaimVoorRelatie,
  ruimVerlopenClaimsOp, isEchteStore, wachtOpZohoId, ZOHO_BEZIG_MS, ONTDUBBEL_MS,
} from "./instroom.mjs";
import { wijzigRelatie } from "./opslag.mjs";

const NU = new Date("2026-11-10T10:00:00.000Z");
const aanvraag = (extra = {}) => ({
  spam: false, voorWie: "eigenaar", postcode: "9999 ZZ", huisnummer: "12a", straat: "Teststraat", plaats: "Testplaats",
  voornaam: "Test", achternaam: "Testpersoon", telefoon: "0612345678", email: "", contactvoorkeur: "bellen", bron: "", pagina: "/uw-mogelijkheden/",
  ...extra,
});

let fabriek;
beforeEach(() => {
  fabriek = geheugenFabriek();
  zetStoreFabriek(fabriek);
  delete process.env.DASHBOARD_ECHTE_DATA;
  process.env.DASHBOARD_INSTROOM_GEHEIM = "verzonnen-testgeheim-0123456789";
  zetContext({ deploy: { context: "deploy-preview" } });
});
afterEach(() => { delete process.env.DASHBOARD_ECHTE_DATA; delete process.env.DASHBOARD_INSTROOM_GEHEIM; zetStoreFabriek(null); zetContext(null); });

test("splitsHuisnummer", () => {
  assert.deepEqual(splitsHuisnummer("12"), { huisnummer: "12", toevoeging: null });
  assert.deepEqual(splitsHuisnummer("12a"), { huisnummer: "12", toevoeging: "a" });
  assert.deepEqual(splitsHuisnummer("12 A"), { huisnummer: "12", toevoeging: "A" });
  assert.deepEqual(splitsHuisnummer("12-3"), { huisnummer: "12", toevoeging: "3" });
  assert.equal(splitsHuisnummer("a12"), null);
  assert.equal(splitsHuisnummer(""), null);
});

test("vertaalAanvraag: velden, bron Website, herkomst website, status Nieuw", () => {
  const v = vertaalAanvraag(aanvraag());
  assert.equal(v.ok, true);
  assert.equal(v.velden.bron, "Website");
  assert.equal(v.velden.status, "Nieuw");
  assert.equal(v.velden.voorWie, "Eigenaar");
  assert.equal(v.velden.contactvoorkeur, "Bellen");
  assert.equal(v.velden.mobiel, "0612345678");
  assert.equal(v.velden.huisnummer, "12");
  assert.equal(v.velden.toevoeging, "a");
  assert.equal(v.velden.email, null);
  assert.deepEqual(v.herkomst, { website: { formulier: "aanvraag" } });
});

test("vertaalAanvraag: bron uit de pagina (nfc -> Deur, niet-thuis -> Niet thuis), herkomst blijft website", () => {
  assert.equal(vertaalAanvraag(aanvraag({ bron: "nfc" })).velden.bron, "Deur");
  const n = vertaalAanvraag(aanvraag({ bron: "niet-thuis" }));
  assert.equal(n.velden.bron, "Niet thuis");
  assert.deepEqual(n.herkomst, { website: { formulier: "aanvraag", kanaal: "niet-thuis" } });
  assert.equal(vertaalAanvraag(aanvraag({ voorWie: "helper" })).velden.voorWie, "Helpt een eigenaar");
  assert.equal(vertaalAanvraag(aanvraag({ voorWie: "helper" })).velden.soortWoning, "Woning van iemand die klant helpt");
  assert.equal(vertaalAanvraag(aanvraag()).velden.soortWoning, "Eigen woning");
});

test("vertaalAanvraag: onbekende keuzes en vreemd huisnummer geven codes, geen uitzondering", () => {
  assert.deepEqual(vertaalAanvraag(aanvraag({ huisnummer: "x" })).fouten, { huisnummer: "ongeldig" });
  assert.deepEqual(vertaalAanvraag(aanvraag({ voorWie: "huurder", contactvoorkeur: "post" })).fouten, { voorWie: "geen-keuze", contactvoorkeur: "geen-keuze" });
  assert.equal(vertaalAanvraag(null).ok, false);
  assert.equal(vertaalAanvraag([]).ok, false);
});

test("ontdubbelHash: genormaliseerd, en verschilt bij ander adres of telefoon", () => {
  const h = ontdubbelHash(aanvraag());
  assert.match(h, /^[0-9a-f]{32}$/);
  assert.notEqual(ontdubbelHash(aanvraag(), "een-ander-geheim-0123456789"), h);
  assert.equal(ontdubbelHash(aanvraag(), null), null);
  assert.equal(ontdubbelHash(aanvraag({ postcode: "9999zz", huisnummer: "12 A", telefoon: "06 1234 5678" })), h);
  assert.equal(ontdubbelHash(aanvraag({ telefoon: "+31612345678" })), h);
  assert.notEqual(ontdubbelHash(aanvraag({ huisnummer: "13" })), h);
  assert.notEqual(ontdubbelHash(aanvraag({ telefoon: "0687654321" })), h);
  assert.equal(ontdubbelHash(aanvraag({ voornaam: "Anders" })), h);
});

test("neemAanvraagOp: maakt een relatie met herkomst website, status Nieuw, in de index", async () => {
  const r = await neemAanvraagOp(aanvraag(), NU);
  assert.equal(r.ok, true, JSON.stringify(r));
  assert.equal(r.bestaatAl, false);
  assert.match(r.relatieId, /^r_[A-Za-z0-9_-]{1,62}$/);
  const rec = await leesRelatie(r.relatieId);
  assert.equal(rec.status, "Nieuw");
  assert.equal(rec.bron, "Website");
  assert.deepEqual(rec.herkomst, { website: { formulier: "aanvraag" } });
  assert.equal(rec.aangemaakt.wie, "website");
  assert.equal(rec.achternaam, "Testpersoon");
  const idx = await leesIndex();
  assert.ok(idx.rijen[r.relatieId]);
});

test("idempotent: hetzelfde formulier twee keer geeft één relatie", async () => {
  const a = await neemAanvraagOp(aanvraag(), NU);
  const b = await neemAanvraagOp(aanvraag(), new Date(NU.getTime() + 60000));
  assert.equal(b.ok, true);
  assert.equal(b.bestaatAl, true);
  assert.equal(b.relatieId, a.relatieId);
  const idx = await leesIndex();
  assert.equal(Object.keys(idx.rijen).length, 1);
  // Tijdlijn: de aanmaak en één herhalingsregel met alleen datum en kanaal, geen inhoud.
  const tl = await leesTijdlijn(a.relatieId);
  const herh = tl.filter((x) => x.soort === "herhaling");
  assert.equal(herh.length, 1);
  assert.deepEqual(herh[0].nieuw, { kanaal: "website", datum: "2026-11-10" });
  assert.equal(herh[0].wie, "website");
  assert.ok(!JSON.stringify(herh[0]).includes("Testpersoon"));
  assert.equal(tl.filter((x) => x.soort === "aanmaak").length, 1);
});

test("idempotent bij gelijktijdig versturen", async () => {
  const lijst = await Promise.all([1, 2, 3, 4].map(() => neemAanvraagOp(aanvraag(), NU)));
  assert.ok(lijst.every((r) => r.ok), JSON.stringify(lijst));
  assert.equal(new Set(lijst.map((r) => r.relatieId)).size, 1);
  assert.equal(lijst.filter((r) => !r.bestaatAl).length, 1);
  assert.equal(Object.keys((await leesIndex()).rijen).length, 1);
});

test("ander adres of telefoon is een andere relatie", async () => {
  const a = await neemAanvraagOp(aanvraag(), NU);
  const b = await neemAanvraagOp(aanvraag({ huisnummer: "14" }), NU);
  assert.notEqual(a.relatieId, b.relatieId);
  assert.equal(Object.keys((await leesIndex()).rijen).length, 2);
});

test("na 24 uur is dezelfde aanvraag weer een nieuwe relatie", async () => {
  const a = await neemAanvraagOp(aanvraag(), NU);
  const b = await neemAanvraagOp(aanvraag(), new Date(NU.getTime() + ONTDUBBEL_MS + 1000));
  assert.equal(b.bestaatAl, false);
  assert.notEqual(a.relatieId, b.relatieId);
});

test("onderbroken poging: claim staat er, relatie niet; herhaling maakt de relatie af zonder dubbel", async () => {
  const s = fabriek("dashboard-test-klanten");
  const echteSet = s.setJSON.bind(s);
  let eerste = true;
  s.setJSON = async (k, v, o) => { if (k.startsWith("relatie/") && eerste) { eerste = false; throw new Error("storing"); } return echteSet(k, v, o); };
  await assert.rejects(neemAanvraagOp(aanvraag(), NU));
  s.setJSON = echteSet;
  const r = await neemAanvraagOp(aanvraag(), new Date(NU.getTime() + 1000));
  assert.equal(r.ok, true, JSON.stringify(r));
  assert.ok(await leesRelatie(r.relatieId));
  assert.equal(Object.keys((await leesIndex()).rijen).length, 1);
});

test("ongeldige aanvraag: codes, niets opgeslagen", async () => {
  const r = await neemAanvraagOp(aanvraag({ huisnummer: "x" }), NU);
  assert.equal(r.ok, false);
  assert.deepEqual(r.fouten, { huisnummer: "ongeldig" });
  assert.equal(fabriek.stores.size, 0);
  // Een telefoon die het model weigert: de fout komt als code terug.
  const t = await neemAanvraagOp(aanvraag({ telefoon: "12" }), NU);
  assert.equal(t.ok, false);
  assert.ok(t.fouten.mobiel);
});

test("store: teststore tenzij DASHBOARD_ECHTE_DATA=aan en context production", async () => {
  assert.equal(isEchteStore(), false);
  assert.equal((await neemAanvraagOp(aanvraag(), NU)).echt, false);
  assert.ok(fabriek.stores.has("dashboard-test-klanten"));
  assert.ok(!fabriek.stores.has("dashboard-klanten"));
  process.env.DASHBOARD_ECHTE_DATA = "aan";
  zetContext({ deploy: { context: "production" } });
  assert.equal(storeNaam("klanten"), "dashboard-klanten");
  assert.equal(isEchteStore(), true);
  assert.equal((await neemAanvraagOp(aanvraag(), NU)).echt, true);
  assert.ok(fabriek.stores.has("dashboard-klanten"));
  // Aan, maar geen context: gooit (geen stille teststore); de aanroeper valt terug op Zoho/noodroute.
  zetContext(null);
  await assert.rejects(neemAanvraagOp(aanvraag({ huisnummer: "20" }), NU), /context/i);
  assert.throws(() => isEchteStore(), /context/i);
});

test("zetSituatie: zet, wist en weigert een relatie die niet van de website komt", async () => {
  const r = await neemAanvraagOp(aanvraag(), NU);
  assert.deepEqual(await zetSituatie(r.relatieId, "Nooit gemeld", NU), { ok: true });
  assert.equal((await leesRelatie(r.relatieId)).situatie, "Nooit gemeld");
  assert.deepEqual(await zetSituatie(r.relatieId, "Nooit gemeld", NU), { ok: true });
  assert.deepEqual(await zetSituatie(r.relatieId, null, NU), { ok: true });
  assert.equal((await leesRelatie(r.relatieId)).situatie ?? null, null);
  assert.equal((await zetSituatie(r.relatieId, "Onzin", NU)).ok, false);
  assert.equal((await zetSituatie("r_bestaatniet", "Nooit gemeld", NU)).ok, false);
});

test("zonder geheim (of te kort): niet gooien, niets opslaan", async () => {
  delete process.env.DASHBOARD_INSTROOM_GEHEIM;
  assert.deepEqual(await neemAanvraagOp(aanvraag(), NU), { ok: false, fouten: { _: "geen-geheim" } });
  process.env.DASHBOARD_INSTROOM_GEHEIM = "kort";
  assert.equal((await neemAanvraagOp(aanvraag(), NU)).ok, false);
  assert.equal(await bewaarZohoId(aanvraag(), "z1", NU), false);
  assert.equal(fabriek.stores.size, 0);
});

test("de claim bevat geen persoonsgegevens", async () => {
  await neemAanvraagOp(aanvraag(), NU);
  const s = fabriek("dashboard-test-klanten");
  const { blobs } = await s.list({ prefix: "ontdubbel/instroom/" });
  assert.equal(blobs.length, 1);
  const tekst = blobs[0].key + JSON.stringify(await s.get(blobs[0].key, { type: "json" }));
  for (const g of ["Test", "9999", "0612345678", "12"]) assert.ok(!tekst.includes(g.replace("12", "Teststraat")), g);
  assert.ok(!tekst.includes("0612345678") && !tekst.includes("9999"));
});

test("zohoId: bewaard na maakLead, teruggegeven bij herhaling; zonder bewaren blijft het null", async () => {
  const a = await neemAanvraagOp(aanvraag(), NU);
  assert.equal(a.zohoId, null);
  const b = await neemAanvraagOp(aanvraag(), NU);
  assert.equal(b.zohoId, null); // Zoho was nog niet gelukt: de herhaling moet Zoho opnieuw proberen
  assert.equal(await bewaarZohoId(aanvraag(), "zoho-123", NU), true);
  const c = await neemAanvraagOp(aanvraag(), NU);
  assert.equal(c.zohoId, "zoho-123");
  assert.equal(c.relatieId, a.relatieId);
  assert.equal(await bewaarZohoId(aanvraag({ huisnummer: "99" }), "zoho-9", NU), false); // geen claim
  assert.equal(await bewaarZohoId(aanvraag(), "ongeldig id!", NU), false);
  assert.equal(await bewaarZohoId(aanvraag(), "zoho-123", new Date(NU.getTime() + ONTDUBBEL_MS + 1)), false); // verlopen
});

test("herhaling met andere gegevens: relatie bijgewerkt, zohoId null (Zoho niet overslaan)", async () => {
  const a = await neemAanvraagOp(aanvraag(), NU);
  await bewaarZohoId(aanvraag(), "zoho-123", NU);
  const b = await neemAanvraagOp(aanvraag({ voornaam: "Anders", email: "test@example.invalid" }), NU);
  assert.equal(b.relatieId, a.relatieId);
  assert.equal(b.bijgewerkt, true);
  assert.equal(b.zohoId, null);
  const rec = await leesRelatie(a.relatieId);
  assert.equal(rec.voornaam, "Anders");
  assert.equal(rec.email, "test@example.invalid");
  assert.equal(Object.keys((await leesIndex()).rijen).length, 1);
  // Dezelfde nieuwe gegevens nog eens: niets nieuws.
  await bewaarZohoId(aanvraag(), "zoho-456", NU);
  const c = await neemAanvraagOp(aanvraag({ voornaam: "Anders", email: "test@example.invalid" }), NU);
  assert.equal(c.bijgewerkt, false);
  assert.equal(c.zohoId, "zoho-456");
});

test("valideren vóór de claim: weigering laat geen claim achter", async () => {
  const r = await neemAanvraagOp(aanvraag({ email: "geen-email" }), NU);
  assert.equal(r.ok, false);
  assert.ok(r.fouten.email);
  assert.equal(fabriek.stores.size, 0);
});

test("verwijderClaimVoorRelatie en ruimVerlopenClaimsOp", async () => {
  const a = await neemAanvraagOp(aanvraag(), NU);
  const b = await neemAanvraagOp(aanvraag({ huisnummer: "14" }), new Date(NU.getTime() + 2 * 3600 * 1000));
  const s = fabriek("dashboard-test-klanten");
  const n = async () => (await s.list({ prefix: "ontdubbel/instroom/" })).blobs.length;
  assert.equal(await n(), 2);
  assert.deepEqual(await ruimVerlopenClaimsOp(new Date(NU.getTime() + ONTDUBBEL_MS + 60000)), { verwijderd: 1, over: 1, overgeslagen: 0 });
  assert.equal(await n(), 1);
  assert.equal(await verwijderClaimVoorRelatie(a.relatieId), 0);
  assert.equal(await verwijderClaimVoorRelatie(b.relatieId), 1);
  assert.equal(await n(), 0);
  // De relaties zelf blijven staan.
  assert.ok(await leesRelatie(a.relatieId));
});

test("race met AVG-verwijderen (K11): een claim die naar een relatie met tombstone wijst, wordt als nieuw overgenomen", async () => {
  const a = await neemAanvraagOp(aanvraag(), NU);
  assert.equal(a.ok, true);
  await bewaarZohoId(aanvraag(), "zoho-oud-1", NU);
  const s = fabriek("dashboard-test-klanten");
  // Verwijderd terwijl de claim bleef staan (de race die de dagelijkse run anders pas 's nachts opruimt).
  await s.setJSON(`tombstone/${a.relatieId}`, { id: a.relatieId, verwijderdOp: NU.toISOString(), wie: "Kevin" });
  await s.delete(`relatie/${a.relatieId}`);
  const later = new Date(NU.getTime() + 3600 * 1000);
  const b = await neemAanvraagOp(aanvraag(), later);
  assert.equal(b.ok, true, JSON.stringify(b));
  assert.notEqual(b.relatieId, a.relatieId, "nieuwe relatie, niet de verwijderde");
  assert.equal(b.bestaatAl, false);
  assert.equal(b.zohoId, null, "het Zoho-id van de verwijderde relatie wordt niet hergebruikt");
  assert.equal(b.zohoBezig, false, "deze aanvraag maakt zelf de Zoho-lead");
  assert.ok(await leesRelatie(b.relatieId));
  assert.equal(await leesRelatie(a.relatieId), null);
  // Precies één claim, die nu naar de nieuwe relatie wijst.
  const { blobs } = await s.list({ prefix: "ontdubbel/instroom/" });
  assert.equal(blobs.length, 1);
  const cl = await s.get(blobs[0].key, { type: "json" });
  assert.equal(cl.relatieId, b.relatieId);
  assert.equal(cl.op, later.toISOString());
  assert.equal(cl.zohoId, undefined);
  // Nog een keer insturen: nu gewoon een herhaling van de nieuwe relatie.
  const c = await neemAanvraagOp(aanvraag(), new Date(later.getTime() + 60000));
  assert.equal(c.relatieId, b.relatieId);
  assert.equal(c.bestaatAl, true);
});

test("zetSituatie: alleen bij lege situatie of status Nieuw", async () => {
  const r = await neemAanvraagOp(aanvraag(), NU);
  assert.deepEqual(await zetSituatie(r.relatieId, "Nooit gemeld", NU), { ok: true });
  // Nog Nieuw: overschrijven mag (de tweede vraag verfijnt).
  assert.deepEqual(await zetSituatie(r.relatieId, "Historie, geen lopende zaak", NU), { ok: true });
  const rec = await leesRelatie(r.relatieId);
  const w = await wijzigRelatie(r.relatieId, { wijzigingId: "w-status", velden: { status: { oud: "Nieuw", nieuw: "Poging 1" } } }, "Kevin", NU);
  assert.equal(w.ok, true, JSON.stringify(w));
  assert.deepEqual(await zetSituatie(r.relatieId, "Nooit gemeld", NU), { ok: true, overgeslagen: true });
  assert.equal((await leesRelatie(r.relatieId)).situatie, rec.situatie);
  // Status verder, maar situatie leeg: wel zetten.
  const r2 = await neemAanvraagOp(aanvraag({ huisnummer: "30" }), NU);
  await wijzigRelatie(r2.relatieId, { wijzigingId: "w-status2", velden: { status: { oud: "Nieuw", nieuw: "Poging 1" } } }, "Kevin", NU);
  assert.deepEqual(await zetSituatie(r2.relatieId, "Nooit gemeld", NU), { ok: true });
});

test("alleen velden die anders zijn ingevuld dan de vorige aanvraag worden bijgewerkt; handmatige correcties blijven", async () => {
  const a = await neemAanvraagOp(aanvraag(), NU);
  // Kevin corrigeert de plaats met de hand.
  const w = await wijzigRelatie(a.relatieId, { wijzigingId: "w-hand", velden: { plaats: { oud: "Testplaats", nieuw: "Handplaats" } } }, "Kevin", NU);
  assert.equal(w.ok, true);
  // Herhaling: alleen de voornaam is anders ingevuld; plaats is gelijk aan de vorige aanvraag.
  const b = await neemAanvraagOp(aanvraag({ voornaam: "Anders" }), NU);
  assert.equal(b.bijgewerkt, true);
  const rec = await leesRelatie(a.relatieId);
  assert.equal(rec.voornaam, "Anders");
  assert.equal(rec.plaats, "Handplaats");
  // Nu wordt de plaats wel anders ingevuld dan de vorige aanvraag: die gaat over.
  await neemAanvraagOp(aanvraag({ voornaam: "Anders", plaats: "Nieuweplaats" }), NU);
  assert.equal((await leesRelatie(a.relatieId)).plaats, "Nieuweplaats");
});

test("afwijkende herhaling: zohoId is null, ook als het bijwerken mislukt", async () => {
  const a = await neemAanvraagOp(aanvraag(), NU);
  await bewaarZohoId(aanvraag(), "zoho-123", NU);
  const s = fabriek("dashboard-test-klanten");
  const echteSet = s.setJSON.bind(s);
  s.setJSON = async (k, v, o) => { if (k === `relatie/${a.relatieId}`) return { modified: false }; return echteSet(k, v, o); };
  const b = await neemAanvraagOp(aanvraag({ voornaam: "Anders" }), NU);
  s.setJSON = echteSet;
  assert.equal(b.ok, true);
  assert.equal(b.bijgewerkt, false);
  assert.equal(b.zohoId, null);
  // De claim is niet bijgewerkt: de volgende herhaling probeert het opnieuw en slaagt.
  const c = await neemAanvraagOp(aanvraag({ voornaam: "Anders" }), NU);
  assert.equal(c.bijgewerkt, true);
  assert.equal((await leesRelatie(a.relatieId)).voornaam, "Anders");
});

test("claim-update met onlyIfMatch: bij een conflict opnieuw lezen en nog eens", async () => {
  const a = await neemAanvraagOp(aanvraag(), NU);
  const s = fabriek("dashboard-test-klanten");
  const echteSet = s.setJSON.bind(s);
  let gestoord = false;
  s.setJSON = async (k, v, o) => {
    if (k.startsWith("ontdubbel/instroom/") && o?.onlyIfMatch && !gestoord) { gestoord = true; return { modified: false }; }
    return echteSet(k, v, o);
  };
  const b = await neemAanvraagOp(aanvraag({ voornaam: "Anders" }), NU);
  s.setJSON = echteSet;
  assert.equal(gestoord, true);
  assert.equal(b.relatieId, a.relatieId);
  assert.equal((await leesRelatie(a.relatieId)).voornaam, "Anders");
  const c = await neemAanvraagOp(aanvraag({ voornaam: "Anders" }), NU);
  assert.equal(c.bijgewerkt, false); // claim kent de nieuwe hashes
});

test("zohoBezig: eerste verzoek maakt Zoho, tweede wacht op het id, daarna time-out en toch Zoho", async () => {
  const a = await neemAanvraagOp(aanvraag(), NU);
  assert.equal(a.zohoBezig, false); // wij zijn het die Zoho aanroept
  const b = await neemAanvraagOp(aanvraag(), NU);
  assert.equal(b.zohoBezig, true);
  assert.equal(b.zohoId, null);
  // Het eerste verzoek bewaart het id terwijl het tweede wacht.
  setTimeout(() => { bewaarZohoId(aanvraag(), "zoho-77", NU); }, 50);
  assert.equal(await wachtOpZohoId(aanvraag(), { maxMs: 1000, stapMs: 20 }), "zoho-77");
  assert.equal((await neemAanvraagOp(aanvraag(), NU)).zohoId, "zoho-77");
});

test("wachtOpZohoId: time-out geeft null; zonder claim of geheim direct null", async () => {
  await neemAanvraagOp(aanvraag(), NU);
  const t0 = Date.now();
  assert.equal(await wachtOpZohoId(aanvraag(), { maxMs: 100, stapMs: 20 }), null);
  assert.ok(Date.now() - t0 < 1000);
  assert.equal(await wachtOpZohoId(aanvraag({ huisnummer: "77" }), { maxMs: 100, stapMs: 20 }), null);
  delete process.env.DASHBOARD_INSTROOM_GEHEIM;
  assert.equal(await wachtOpZohoId(aanvraag()), null);
});

test("zohoBezig verlopen (Zoho-poging mislukt): volgend verzoek maakt zelf Zoho, niet wachten", async () => {
  await neemAanvraagOp(aanvraag(), NU);
  const later = new Date(NU.getTime() + ZOHO_BEZIG_MS + 1000);
  const b = await neemAanvraagOp(aanvraag(), later);
  assert.equal(b.zohoBezig, false);
  assert.equal(b.zohoId, null);
  // En nu is dat verzoek de bezige.
  assert.equal((await neemAanvraagOp(aanvraag(), later)).zohoBezig, true);
});

test("opruimen: lezen mislukt of etag veranderd tussen lezen en verwijderen: niet verwijderen", async () => {
  await neemAanvraagOp(aanvraag(), NU);
  await neemAanvraagOp(aanvraag({ huisnummer: "14" }), NU);
  const s = fabriek("dashboard-test-klanten");
  const n = async () => (await s.list({ prefix: "ontdubbel/instroom/" })).blobs.length;
  const laat = new Date(NU.getTime() + ONTDUBBEL_MS + 60000);
  // Lezen mislukt.
  const echteGet = s.getWithMetadata.bind(s);
  s.getWithMetadata = async (k, o) => { if (k.startsWith("ontdubbel/instroom/")) throw new Error("leesfout"); return echteGet(k, o); };
  assert.deepEqual(await ruimVerlopenClaimsOp(laat), { verwijderd: 0, over: 0, overgeslagen: 2 });
  assert.equal(await n(), 2);
  // Etag verandert bij de tweede lezing (claim net vernieuwd).
  let tel = 0;
  s.getWithMetadata = async (k, o) => {
    const r = await echteGet(k, o);
    if (r && k.startsWith("ontdubbel/instroom/") && tel++ % 2 === 1) return { ...r, etag: "andere" };
    return r;
  };
  const uit = await ruimVerlopenClaimsOp(laat);
  s.getWithMetadata = echteGet;
  assert.equal(uit.verwijderd, 0);
  assert.equal(uit.overgeslagen, 2);
  assert.equal(await n(), 2);
  assert.deepEqual(await ruimVerlopenClaimsOp(laat), { verwijderd: 2, over: 0, overgeslagen: 0 });
});

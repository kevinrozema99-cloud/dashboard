// Gezamenlijke agenda (opdracht Ruben 20-11-2026): de afspraken uit de leadpijplijn (Afspraak gepland) en de opnames
// uit de klantpijplijn (Opname gepland) op één plek, van Kevin en Ruben samen. Pure functies; de route leest index en
// trajecten en geeft ze hier door.
//
// - Afspraak: een open taak van soort "afspraak" op de relatie (aangemaakt bij het slepen naar Afspraak gepland, of
//   met de hand op de klantkaart). Afvinken = uit de agenda.
// - Opname: de opnamedatum (en opnametijd) van een traject. Ook een opname in het verleden blijft staan; een verloren
//   traject niet.
// - "In te plannen": een lead op Afspraak gepland zonder afspraak, of een traject op Opname gepland zonder datum.
//   Zo blijft niets tussen wal en schip.
import { isIsoDatum, normFase, ARCHIEF_STATUSSEN } from "./model.mjs";

export const MAX_DAGEN = 62;
const isObj = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
const naamVan = (r) => [r?.voornaam, r?.achternaam].filter((x) => typeof x === "string" && x.trim()).join(" ") || r?.naam || null;
const basis = (rij) => ({ relatieId: rij.id, naam: naamVan(rij), plaats: rij.plaats ?? null, telefoon: rij.telefoon ?? null });

// Maandag van de week waarin `datum` valt (YYYY-MM-DD).
export function maandagVan(datum) {
  const d = new Date(`${datum}T12:00:00Z`);
  const dag = (d.getUTCDay() + 6) % 7; // ma = 0
  return new Date(d.getTime() - dag * 86400000).toISOString().slice(0, 10);
}
export const dagenTussen = (van, tot) => Math.round((Date.parse(`${tot}T12:00:00Z`) - Date.parse(`${van}T12:00:00Z`)) / 86400000);

// rijen: index-rijen; trajecten: records. {van, tot} inclusief; wie: "kevin" | "ruben" | null (= iedereen).
export function maakAgenda(rijen, trajecten, { van, tot, wie = null } = {}) {
  const perId = new Map();
  for (const r of Array.isArray(rijen) ? rijen : []) if (isObj(r) && r.id) perId.set(r.id, r);
  const inBereik = (d) => isIsoDatum(d) && d >= van && d <= tot;
  const items = [];
  const inTePlannen = [];

  for (const rij of perId.values()) {
    if (ARCHIEF_STATUSSEN.includes(rij.status)) continue;
    const afspraken = (Array.isArray(rij.openTaken) ? rij.openTaken : []).filter((t) => isObj(t) && t.soort === "afspraak");
    for (const t of afspraken) {
      if (!inBereik(t.datum)) continue;
      items.push({ ...basis(rij), id: `a:${rij.id}:${t.id}`, soort: "afspraak", taakId: t.id, titel: t.titel ?? null,
        datum: t.datum, tijd: t.tijd ?? null, eigenaar: t.eigenaar ?? rij.eigenaar ?? null, status: rij.status ?? null });
    }
    if (rij.status === "Afspraak gepland" && !afspraken.some((t) => isIsoDatum(t.datum))) {
      inTePlannen.push({ ...basis(rij), id: `a:${rij.id}`, soort: "afspraak", eigenaar: rij.eigenaar ?? null, status: rij.status });
    }
  }

  for (const t of Array.isArray(trajecten) ? trajecten : []) {
    if (!isObj(t) || !t.id) continue;
    const fase = normFase(t.fase);
    if (fase === "Verloren") continue;
    const rij = perId.get(t.relatieId) ?? { id: t.relatieId };
    const b = { ...basis(rij), id: `o:${t.id}`, soort: "opname", trajectId: t.id, fase, eigenaar: rij.eigenaar ?? null };
    if (inBereik(t.opnamedatum)) items.push({ ...b, datum: t.opnamedatum, tijd: t.opnametijd ?? null });
    else if (fase === "Opname gepland" && !isIsoDatum(t.opnamedatum)) inTePlannen.push(b);
  }

  const voorWie = (x) => !wie || x.eigenaar === wie;
  const opNaam = (a, b) => String(a.naam ?? "").localeCompare(String(b.naam ?? ""), "nl") || a.id.localeCompare(b.id);
  return {
    van, tot,
    // Op dag; binnen een dag eerst de dingen zonder tijd (hele dag), dan op tijd.
    items: items.filter(voorWie).sort((a, b) => a.datum.localeCompare(b.datum) || (a.tijd ?? "").localeCompare(b.tijd ?? "") || opNaam(a, b)),
    inTePlannen: inTePlannen.filter(voorWie).sort(opNaam),
  };
}

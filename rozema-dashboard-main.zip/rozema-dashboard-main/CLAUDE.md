# CLAUDE.md — rozema-adviseurs.nl

Website van Rozema Adviseurs v.o.f. (Drachten). Kevin en Ruben begeleiden woningeigenaren in het Groningse bevingsgebied door het IMG-traject *maatwerk met onderzoek*, op no cure no pay. Hosting: Netlify.

## Jouw rol

Jij bouwt structuur, opmaak en logica. **Je schrijft geen tekst die een bezoeker leest.** Klantteksten ontstaan in een aparte chat, worden daar getoetst aan B1 (onder Wat wij nooit zeggen) en komen daarna via Kevin in de content-bestanden. De kennisbank (K1, K2, B1, B2) staat in [C:\Users\kevin\OneDrive\Rozema Adviseurs\Kennisbank]. Lees daar, nooit uit een kopie in de repo.

## Regels

1. **Geen eigen klanttekst.** Dat geldt ook voor knoppen, formulierlabels, foutmeldingen, meta-descriptions, alt-teksten en paginatitels. Waar tekst hoort, zet je een placeholder:
   `[[TEKST: pagina.sectie.element]]` — de sleutel is gelijk aan de sleutel in het content-bestand.
   Uitzondering: teksten die letterlijk in `docs/bouwdocument.md` staan, mag je overnemen.
2. **Foto's zijn placeholders.** `[[FOTO: pagina.plek]]`, met de gewenste verhouding erbij. Nooit stockbeelden, nooit gegenereerde portretten.
3. **`docs/bouwdocument.md` is leidend voor structuur**: pagina's, URL's, secties en hun volgorde, de flow van de dossiercheck. Wijk je ervan af, vraag het dan eerst.
4. **Kennisbank gaat boven het bouwdocument.** Botst iets in het bouwdocument met K1, K2, B1 of B2, meld het en los het niet zelf op.
5. **Bestaande tekst niet wijzigen** zonder opdracht, ook niet "even verbeteren".
6. **Tekst en opmaak gescheiden houden.** Tekst in de content-bestanden, niet hardcoded in templates.
7. **Mobiel eerst.** Elke pagina werkt op een telefoonscherm voordat er aan desktop wordt gedacht. Grote tikvlakken, leesbare lettergrootte (de kernklant is vaak ouder).
8. **Geen persoonsgegevens** in code, logs, testdata of commits. Geen uploadveld in formulieren. Geen BSN- of zaaknummervelden.
9. **Geen externe scripts, trackers of fonts** toevoegen zonder opdracht.
10. **Werken op een branch.** Niet direct naar de live-branch; Kevin beoordeelt via de Netlify deploy preview.
11. Ontwerp volgt docs/ontwerp.md en B3 uit de kennisbank. Wat daar onder “Wat niet mag” staat, gebruik je nooit, ook niet als het ergens anders wordt voorgesteld.

## Na elke opdracht

Kort melden: wat er gebouwd is, welke placeholders er nieuw zijn (lijst met sleutels), en wat er nog open staat. Geen samenvatting van het proces.

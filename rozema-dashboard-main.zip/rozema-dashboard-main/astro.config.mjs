// @ts-check
import { defineConfig } from 'astro/config';
import sitemap from '@astrojs/sitemap';
import tailwindcss from '@tailwindcss/vite';

export default defineConfig({
  // Bepaalt de canonical-tags, de Open Graph-URL en de inhoud van sitemap-index.xml.
  // Kies in Netlify dezelfde variant als primair domein, anders wijzen ze naar elkaar langs.
  site: 'https://rozema-adviseurs.nl',
  integrations: [
    // De bedankpagina hoort niet in de sitemap; die is alleen bereikbaar na een inzending.
    sitemap({ filter: (pagina) => !pagina.includes('/bedankt') }),
  ],
  vite: {
    plugins: [tailwindcss()],
  },
});

# Rozema-dashboard — plan fase 1

Stand: 10 november 2026. Status: **voorstel, wacht op akkoord van Ruben.** Er is nog niets gebouwd of live gezet.

Dit plan volgt de opdracht "het Rozema-dashboard bouwen en blijven verbeteren". Onderzocht: `main` en `herbouw-v2` (alleen gelezen), de Netlify-documentatie over Blobs, en de echte PDOK- en CBS-bronnen (live bevraagd, testplaats Winsum). Zoho en het Netlify-account zelf heb ik niet kunnen inzien: daar zijn geen sleutels of toegang voor.

---

## 1. Wat het onderzoek opleverde

### Bronnen: wat klopt en wat niet

| Aanname in de bestaande code | Gecontroleerd | Gevolg |
|---|---|---|
| BAG-verblijfsobjecten via `api.pdok.nl/kadaster/bag/ogc/v2`, filter `woonplaats_naam` + `provincie_naam` | Klopt. Winsum: eerste pagina van 1000 in ca. 3 s | Geen |
| `gebruiksdoel` bevat "woonfunctie", `status` bevat "in gebruik" | Klopt | Geen |
| Verblijfsobject verwijst naar het pand met een 16-cijferig nummer in `pand` | **Klopt niet.** Het veld heet `pand.href` en bevat een URL met een uuid; het pand heeft die uuid als `id` | **Bug:** geen enkel adres krijgt bouwjaar of woningtype. Alles staat op "onbekend", dus de straatvolgorde op woningtype werkt niet. Herstel: koppelen op de uuid uit `pand.href` |
| Pand heeft `bouwjaar`, `aantal_verblijfsobjecten`, vlakgeometrie | Klopt | Geen |
| Buurtenlaag 2024 `api.pdok.nl/cbs/wijken-en-buurten-2024/ogc/v1`, velden `buurtcode`, `buurtnaam` | Klopt | Geen |
| CBS 85984NED, kolommen zoeken op begin van de naam | Klopt (`Koopwoningen_47`, `InBezitWoningcorporatie_49`, `HuurwoningenTotaal_48`, `Woningvoorraad_35`; peildatum 1 januari) | Werkt. De PDOK-buurtenlaag 2024 bevat dezelfde cijfers (`percentage_koopwoningen`, `perc_huurwoningen_in_bezit_woningcorporaties`, `woningvoorraad`): voor alle zes buurten van Winsum identiek aan de CBS-tabel. Voorstel: alleen de PDOK-laag gebruiken (één bron minder). Dat raakt een vastgestelde keuze, dus zie vraag 4 |
| Geheime of onbekende CBS-waarden | Komen voor als negatieve getallen (bijv. -99997); CBS vermeldt percentages pas vanaf 20 woningen per buurt | Moet als "onbekend" worden behandeld, niet als 0%, anders gaat een buurt ten onrechte aan. De regel "≥ 40% corporatiebezit standaard uit" blijft; wat een buurt met onbekend percentage krijgt, zie vraag 5 |
| PDOK-kaartstijl `grijs` | Bestaat (tegel geeft 200) | Geen |
| Proxy via de eigen Function nodig voor PDOK/CBS | PDOK staat CORS toe (`*`) | Proxy kan weg: de telefoon haalt rechtstreeks op. Minder code, minder Function-aanroepen, geen open doorgeefluik |

### Netlify Blobs

- `getStore()` is een **site-brede** store: data blijft bij nieuwe deploys en is zichtbaar in **alle** deploy-contexten (productie, branch deploy, deploy previews). Wat Kevin en Ruben op de branch deploy van `dashboard` vastleggen, staat na samenvoegen dus ook op www.rozema-adviseurs.nl/dashboard, **mits het om dezelfde Netlify-site gaat** (zie §8: eerst een testsite op een apart account). Dit staat zo in de documentatie; **in de praktijk testen** doe ik vóór er echte data in gaat: schrijven op de ene deploy, lezen op een andere.
- Keerzijde: ook een tijdelijke testbranch of deploy preview schrijft in dezelfde echte data. Daarom een **witte lijst**: alleen productie en de branch `dashboard` gebruiken de echte stores, en alleen als de omgevingsvariabele `DASHBOARD_ECHTE_DATA=aan` voor die context is gezet. Al het andere (andere branches, deploy previews, lokaal) gebruikt `dashboard-test-…`. Hoe de Function zijn branch en context leest (`context.deploy` in Functions v2), test ik op de eerste deploy en log ik zonder gegevens.
- Regio: `eu-central-1` (Frankfurt) wordt ondersteund, maar **moet bij elke aanroep worden meegegeven**. Een aanroep zonder regio leest en schrijft stilletjes in de VS (us-east-2). Ik zet dat in één gedeelde functie, zodat het niet vergeten kan worden.
- Blobs is "laatste schrijver wint". De bestaande opzet (elk bezoek een eigen blob) is daarom goed. Lijsten die worden gelezen-gewijzigd-geschreven (plaatsenlijst, buurtkeuzes, trillingssnelheden) kunnen bij gelijktijdig gebruik een wijziging kwijtraken; die krijgen een controle op versie (etag) of worden ook per stuk opgeslagen.
- Elke peiling leest nu de lijst van **alle** bezoeken van een plaats. Dat wordt traag naarmate er meer bezoeken zijn. Oplossing: na een samenvatting de verwerkte bezoeken naar een archief verplaatsen.

### De twee branches

| | `main` | `herbouw-v2` |
|---|---|---|
| Framework | Astro 5 + Tailwind, statisch | Zelfde |
| Publicatiemap | `dist` (inhoud van `public/` gaat ongewijzigd mee) | Zelfde |
| Functions | Geen | `netlify/functions/lead-aanmaken.mjs`, `lead-bijwerken.mjs`, gedeelde code in `netlify/lib/` |
| `[functions]` in `netlify.toml` | Niet aanwezig (Netlify gebruikt standaard `netlify/functions`) | `directory = "netlify/functions"`, `node_bundler = "esbuild"` |
| Zoho | Geen | Lead aanmaken via API, EU, met eigen `zoho.mjs` en `zoho-velden.mjs` |
| `/niet-thuis` | Bestaat niet | Bestaat, als landingspagina |
| Atkinson Hyperlegible Next | Niet aanwezig | In `public/fonts/` |

**Belangrijk botspunt met v2:** in v2 betekent `ZOHO_API_URL` de basis `https://www.zohoapis.eu`; in de bestaande deur-code betekent dezelfde variabele `https://www.zohoapis.eu/crm/v7`. Na samenvoegen breekt dan één van de twee. Het dashboard volgt daarom de betekenis van v2. Ook gebruikt v2 voor telefoon het Zoho-veld `Mobile` (de deur-code `Phone`) en voor de bron `Lead_Source = "Deur"`. Het dashboard sluit daarop aan.

---

## 2. Opbouw van het dashboard

```
public/dashboard/               frontend (komt in dist/dashboard/), vanilla JS, geen build
  index.html                    inlog + startscherm
  gedeeld/                      opmaak, huisstijl, lettertypen, meldknop, inlogcontrole, Leaflet (zelf gehost)
  deur/                         module deur-aan-deur (de bestaande app, omgebouwd)
  sw.js, manifest.webmanifest   één service worker en één beginschermicoon voor het hele dashboard
netlify/functions/
  dashboard-auth.mjs            /api/dashboard/auth/*      inloggen, uitloggen, wie ben ik
  dashboard-deur.mjs            /api/dashboard/deur/*      plaatsen, buurten, trilling, bezoeken, afspraak
  dashboard-meldingen.mjs       /api/dashboard/meldingen/* wens of fout melden
  dashboard-lib/                gedeelde code (sessie, store met vaste regio, antwoorden)
dashboard/                      documentatie, wordt NIET gepubliceerd
  PLAN.md, INTEGRATIE.md, WIJZIGINGEN.md
```

- Documentatie staat bewust in `dashboard/` in de root van de repo en niet in de publicatiemap; anders zou `INTEGRATIE.md` openbaar op de site staan. De frontend staat in `public/dashboard/`, want bij Astro is `public/` wat in de publicatiemap `dist/` belandt. Zo lees ik "frontend onder `dashboard/` in de publicatiemap"; zie vraag 7.
- Gedeelde code van de Functions komt in `netlify/functions/dashboard-lib/` en niet in `netlify/lib/` van v2. Een map zonder `index`-bestand hoort Netlify niet als Function te zien; dat controleer ik bij de eerste deploy op een tijdelijke branch. Klopt het niet, dan is het alternatief `netlify/dashboard-lib/`, maar dat ligt buiten de afgesproken mappen en vraag ik eerst.
- Modules los te testen: elke module heeft een eigen Function, eigen map en eigen tests (`node --test`, zonder extra pakketten).
- Lettertype: Atkinson Hyperlegible Next uit de site zelf, als kopie in `public/dashboard/gedeeld/fonts/`. Geen Google Fonts.
- Leaflet zelf gehost in `public/dashboard/gedeeld/`, niet via een CDN. Kaarttegels komen van PDOK (overheid, geen tracker).

### Inlog

- Twee accounts, elk een eigen wachtwoord (PBKDF2-hash in een Netlify-omgevingsvariabele), sessie 30 dagen.
- **Wijziging t.o.v. de bestaande code:** de sessie gaat in een `HttpOnly`, `Secure`, `SameSite=Strict`-cookie op pad `/api/dashboard`, niet in `localStorage`. Het dashboard deelt het domein met de publieke site; een cookie die JavaScript niet kan lezen, beschermt beter tegen een fout elders op de site.
- De lege schermen (HTML/JS) zijn openbaar op te vragen maar bevatten geen gegevens; alle data loopt via de API en die controleert de sessie.
- Offline: de app start zonder sessiecontrole (JavaScript kan de cookie niet lezen) en laat de laatst bekende stand zien. Een 401 maakt de wachtrij **nooit** leeg: de app vraagt dan om opnieuw in te loggen en verstuurt daarna. Een app op het beginscherm van een iPhone heeft eigen cookies, los van Safari: daar één keer apart inloggen.
- Uitloggen op een apparaat; bij verlies van een telefoon: sessiegeheim vervangen in Netlify, dan zijn alle sessies ongeldig.
- Blokkade na 5 foute pogingen per naam per kwartier blijft, plus een vertraging per IP, zodat iemand anders je niet buiten de deur kan houden door expres fout in te loggen.
- `noindex`: voor `/dashboard/*` via een header in `netlify.toml`; de API zet `X-Robots-Tag` zelf in elk antwoord (headers uit `netlify.toml` gelden niet voor Functions).

### Wie deed wat

Elke schrijfactie slaat `wie` (uit de sessie, niet uit het verzoek) en `wanneer` op. Een apart activiteitenlog per module houdt bij wie welke instelling veranderde (buurt aan/uit, trillingssnelheid, plaats opnieuw opgehaald).

### Meldknop "wens of fout melden"

Op elk scherm, rechtsonder, groot tikvlak. Slaat op: scherm (pad + module), wie, wanneer, de tekst, en technische info (schermbreedte, appversie). Store `dashboard-meldingen`. Een eigen scherm toont de lijst met status (nieuw, opgepakt, klaar). Dit is de werklijst voor elke sessie.

---

## 3. Datamodel (geschikt voor een latere Sales manager-agent)

Stores, allemaal met regio `eu-central-1`:

| Store | Sleutel | Inhoud |
|---|---|---|
| `dashboard-deur` | `plaatsen/index` | Lijst plaatsen: id, naam, aantal adressen, opgehaald op, door |
| | `plaats/<id>/adressen` | Adressen uit de BAG: BAG-id, straat, nummer, letter, toevoeging, postcode, coördinaat, m², pand-id, bouwjaar, woningtype, buurtcode |
| | `plaats/<id>/buurten/<code>` | Buurt: naam, % koop, % corporatie, aantal woningen, aan/uit, gewijzigd door/op |
| | `plaats/<id>/trilling/<postcode>` | mm/s, door, op |
| | `events/<id>/<tijd-sleutel>` | Eén bezoek (zie hieronder) |
| | `stand/<id>` | Samenvatting, voor snel laden |
| `dashboard-meldingen` | `<tijd-sleutel>` | Melding |
| `dashboard-auth` | `slot/<naam>` | Blokkade na foute pogingen |

**Een bezoek (event)** legt vast wat een analyse later nodig heeft, ook als de adreslijst of trillingssnelheid intussen verandert:

| Veld | Waarom |
|---|---|
| `ts` (telefoon), `k` (server) | Tijdstip aan de deur en volgorde van binnenkomst. Uit `ts` volgen dag, uur en weekdag |
| `w` | Wie (uit de sessie) |
| `st` | Uitkomst: afspraak, gesprek, niet thuis, geen interesse, huurder/geen woonhuis, niet aanbellen |
| `a`, `pc` | BAG-id van het adres, postcode |
| `bu` | Buurtcode op het moment van bezoek |
| `ty`, `bj` | Woningtype en bouwjaar op het moment van bezoek |
| `mms` | Trillingssnelheid die op dat moment voor de postcode gold (leeg als onbekend) |
| `koop`, `corp` | Buurtpercentages koop en corporatie op dat moment |
| `herstel` | Ongedaan gemaakt ja/nee |
| `no` | Korte notitie, met de hint in beeld: geen namen, geen gezondheid of persoonlijke situatie |

Het hoeveelste bezoek aan een adres wordt bij de analyse uitgerekend, niet op de telefoon (twee telefoons offline zouden anders allebei "eerste bezoek" opslaan).

**Klant in de straat** (derde criterium van de straatvolgorde): de bestaande code telt alleen afspraken uit de eigen deurregistratie. Echte klanten staan in Zoho. Zodra Zoho-stap 1 (lezen) is goedgekeurd, kan het dashboard de postcodes van klanten ophalen en alleen "ja/nee per straat" bewaren, zonder namen. Tot dan: alleen afspraken uit de deurregistratie.

Geen naam of telefoon van de bewoner in het event. Een afspraak krijgt alleen een verwijzing naar de lead (Zoho-ID), geen persoonsgegevens.

Daarmee kan een agent later bijvoorbeeld uitrekenen: kans op afspraak per buurt, woningtype, bouwjaarklasse en trillingsklasse; beste tijdstip en dag; rendement van een tweede bezoek na "niet thuis"; verschil per persoon. Een export (CSV, al aanwezig) en een alleen-lezen API-route `/api/dashboard/deur/export` maken die analyse mogelijk zonder bij de opslag te kunnen.

---

## 4. Eerste versie (fase 2), vanaf dag 1 bruikbaar

1. Inlog en startscherm met twee tegels: Deur-aan-deur en Meldingen.
2. Deur-aan-deur: de bestaande app, omgebouwd naar het dashboard, met:
   - de pand-bug hersteld (bouwjaar en woningtype werken);
   - buurtcijfers uit de PDOK-buurtenlaag, onbekende waarden als onbekend;
   - geen proxy meer;
   - de kaart, offline-wachtrij en synchronisatie zoals ze zijn, plus de verbeteringen uit de code-review (zie onder);
   - geen middenpuntjes en geen hoofdletters als stijl in de schermen (ontwerp.md, Wat niet mag).
3. Meldknop op elk scherm, met lijst.
4. `WIJZIGINGEN.md` en `INTEGRATIE.md` bijgewerkt.
5. Eerst gebouwd en getest op een tijdelijke branch met deploy preview (dus teststore), met één dorp. Daarna naar `dashboard`; de echte store gaat pas aan (`DASHBOARD_ECHTE_DATA`) na de praktijktest uit §1 en jouw akkoord.

**Afspraak aan de deur in versie 1:** de vastgestelde keuze is "afspraak wordt lead in Zoho", maar Zoho-stap 2 (schrijven) heeft jouw akkoord nodig en er mogen geen test-leads in de echte Zoho. Twee mogelijkheden voor versie 1, zie vraag 3:
- **a.** De app legt alleen de uitkomst "afspraak" vast; naam en telefoon zet je meteen zelf in Zoho (op papier of in de Zoho-app). Er staan dan geen persoonsgegevens in het dashboard of op de telefoon.
- **b.** De app bewaart naam en telefoon tijdelijk op de telefoon in een lijst "nog in Zoho zetten", met een vervaltijd van een paar dagen en wissen bij uitloggen. Handiger, maar persoonsgegevens op een telefoon die kwijt kan raken.

De koppeling met Zoho bouw ik pas na akkoord op stap 2, met dezelfde veldnamen als v2.

---

## 5. Zoho vervangen: aanpak fase 1 (lezen)

**Nog niet gedaan**: er is geen toegang. Voorstel (vraag 6): jij maakt in Zoho een aparte **Self Client met alleen leesrechten** (`ZohoCRM.modules.READ`, `ZohoCRM.settings.READ`), los van de client die v2 voor de website gebruikt, en zet de sleutels als omgevingsvariabelen in Netlify. Daarmee breng ik in kaart:

- modules en velden (`/settings/modules`, `/settings/fields`), inclusief picklistwaarden;
- workflows en automatische taken (welke stap maakt welke taak, met welke termijn) — de **bezwaartermijn** krijgt hier de meeste aandacht;
- aantallen per module, als nulmeting voor de latere migratie.

Workflowregels zijn via de API maar beperkt te lezen; waarschijnlijk moet je daarvoor een paar schermafdrukken uit Zoho maken. Daarna volgt een apart voorstel voor fase 2 tot 4 van de Zoho-vervanging.

---

## 6. Optimalisaties, op waarde per moeite

De nummers 1 tot en met 6 horen bij versie 1; zonder die punten kunnen bezoeken verloren gaan of klopt de volgorde niet.

| # | Wat | Waarde | Moeite |
|---|---|---|---|
| 1 | Offline-wachtrij nooit meer weggooien bij 401/429/5xx, tijdslimiet op verzoeken, wachtrij apart van de cache (review H2, H4, M11) | Hoog: anders verdwijnen bezoeken | Klein |
| 2 | Bezoeken die op de andere telefoon nooit aankomen of dubbel tellen (review H3, M5, M10) | Hoog | Klein-middel |
| 3 | Pand-koppeling herstellen (bouwjaar, woningtype) | Hoog: straatvolgorde werkt dan pas | Klein |
| 4 | Store met vaste regio en witte lijst echte/teststore | Hoog: data in de EU, geen testdata in de echte opslag | Klein |
| 5 | Sessie: HttpOnly-cookie, weigeren zonder geheim, intrekbaar, betere blokkade (review H1, M7, M8) | Hoog: beveiliging | Klein |
| 6 | Service worker die alleen de eigen app cachet (review M6) | Hoog: anders kan de browser alle opgeslagen data wissen | Klein |
| 7 | Bezoek met buurt, type, bouwjaar, trilling en buurtcijfers erin opslaan | Hoog voor de Sales manager-agent | Klein |
| 8 | Buurtcijfers uit de PDOK-laag, onbekend als onbekend (na vraag 4) | Middel-hoog | Klein |
| 9 | "Volgende huis" direct na vastleggen, zodat 5 seconden per deur haalbaar blijft | Hoog in het gebruik | Klein (bestaat deels) |
| 10 | Automatisch opruimen volgens de bewaartermijn (na jullie besluit) | Hoog voor AVG | Klein |
| 11 | Proxy weg | Middel: minder code en aanroepen | Klein |
| 12 | Verwerkte bezoeken archiveren na samenvatting (review M9) | Middel nu, hoog na een seizoen | Middel |
| 13 | Buurten en trilling per stuk opslaan en meenemen in de peiling (review L17) | Middel | Middel |
| 14 | Grotere plaatsen per buurt ophalen en opslaan (review M14) | Middel | Middel |
| 15 | Wekelijks overzicht per buurt en per persoon | Middel | Middel |

Alle bevindingen van de onafhankelijke code-review staan in `REVIEW-BESTAANDE-CODE.md`; de kleine (L15–L22, middenpuntjes, zelf gehoste bestanden) neem ik mee bij het ombouwen.

---

## 7. Wat niet van mij is om te beslissen (signaleren)

- **AVG-bewaartermijn** van adressen met uitkomst. Technisch voorstel: per uitkomst een termijn instelbaar in een omgevingsvariabele; een geplande Function ruimt dagelijks op. "Niet aanbellen" bewaren zolang jullie in het gebied werken (dat is ook een bezwaarlijst). De termijnen zelf zijn aan jullie.
- **Privacyverklaring** op de website aanvullen met deze registratie.
- **Verwerkersovereenkomsten** met Netlify (opslag in Frankfurt) en Zoho.
- **Kennisbank (K1, K2, B1, B2, B3)** staat lokaal bij Kevin en is vanuit hier niet te lezen. De straatvolgorde volgt volgens de bestaande code "B2, onder Adresselectie" (drempel 8,5 mm/s, of 5 mm/s bij bouwjaar vóór 1940). Dat heb ik niet aan B2 kunnen toetsen.

---

## 8. Testen op een apart Netlify-account (besluit Ruben, 10-11-2026)

Ruben test het dashboard eerst op een **eigen Netlify-account** (testsite). Pas daarna gaat het naar het Netlify-account van Kevin (de echte site). Gevolgen:

- **Inrichting testsite:** nieuwe site in Rubens account, gekoppeld aan deze repo, met **productiebranch `dashboard`**. Het dashboard staat dan op `<testsite>.netlify.app/dashboard/`. De rest van de website bouwt daar ook mee, maar dat is alleen een kopie van `main`. Voor de koppeling moet de Netlify-app toegang krijgen tot de repo van Kevin; dat moet Kevin als eigenaar mogelijk goedkeuren.
- **Data verhuist niet vanzelf.** Blobs horen bij één site. Wat op de testsite wordt vastgelegd, staat **niet** op de echte site. De eerdere aanname "wat ze nu vastleggen staat na samenvoegen ook op /dashboard" geldt dus pas na de overstap naar Kevins account. Twee mogelijkheden, zie vraag 9:
  - **a.** Op de testsite alleen proefdata; echte deurregistratie pas op Kevins site.
  - **b.** Ook echte data op de testsite; bij de overstap een eenmalige verhuizing met een exportroute en een importscript, met een telling vooraf en achteraf dat niets ontbreekt. Verhuizen van data is een beslissing van Ruben (opdracht §8).
- **Instellingen per site:** wachtwoord-hashes, sessiegeheim en Zoho-sleutels moeten op de testsite én later op Kevins site worden gezet, elk met een **eigen** sessiegeheim. Een nieuw geheim betekent: iedereen logt één keer opnieuw in.
- **Regio van de verwerking:** de opslag (Blobs) staat in Frankfurt. De Functions zelf draaien op een gratis account in de VS (Ohio); een EU-regio kiezen kan pas vanaf het Pro-abonnement (Netlify-documentatie, Functions → Region). Bij echte adressen met uitkomst gaan die dus via een server in de VS. Dat is een AVG-afweging voor jullie, niet voor mij (vraag 10). Geldt ook voor Kevins account als dat geen Pro is.
- **Verwerkersovereenkomst:** als er echte data op de testsite komt, geldt die voor Rubens Netlify-account.
- **Witte lijst opslag:** op de testsite is `dashboard` de productiebranch; `DASHBOARD_ECHTE_DATA` bepaalt per site of de echte stores worden gebruikt. Bij keuze a blijft die op de testsite uit.

## 9. Open uit fase 1 en wat ik van je nodig heb

- **Netlify:** testsite aanmaken zoals hierboven (productiebranch `dashboard`). Ik heb geen toegang tot Netlify; de instellingen uit `INTEGRATIE.md` zet jij in de site.
- **Zoho:** inventarisatie van modules, velden, workflows en automatische taken staat open tot er een leesclient is (vraag 6).
- **Kennisbank:** niet te lezen vanuit hier (zie §7).

## 10. Beslissingen nodig

1. **CLAUDE.md van Kevin** geldt in deze repo en botst op punten met de opdracht: geen eigen tekst maar placeholders (regel 1 en 6, ook knoppen en labels), `docs/bouwdocument.md` leidend en `/dashboard` staat er niet in (regel 3), geen externe scripts (regel 9: Leaflet zelf gehost, PDOK-kaarttegels), Kevin beoordeelt (regel 10), en de lijst "Wat niet mag" uit ontwerp.md (regel 11: o.a. geen rasters van gelijke kaartjes, geen schaduwen, iconen alleen beperkt; standaard-Leaflet heeft schaduwen en markericonen). Mijn voorstel: het dashboard is intern en valt niet onder regel 1, 3 en 6; regel 9 en 11 volg ik wel (Leaflet zelf gehost en zonder schaduwen, startscherm als lijst in plaats van tegels). **Is dat zo, en stemt Kevin daarmee in?**
2. **Branch:** ik heb `dashboard` gemaakt vanaf `main` en er alleen deze plannen op gezet. Kevins branch heet `herbouw-v2` (niet `v2-herbouw`); die heb ik alleen gelezen. Akkoord?
3. **Afspraak aan de deur in versie 1:** optie a (geen persoonsgegevens in de app, zelf in Zoho zetten) of b (tijdelijk op de telefoon, met vervaltijd)? Ik raad a aan tot Zoho-stap 2 is goedgekeurd.
4. **Buurtcijfers:** akkoord om alleen de PDOK-buurtenlaag 2024 te gebruiken in plaats van ook de CBS-tabel? De cijfers zijn gelijk (gecontroleerd voor Winsum).
5. **Buurt met onbekend percentage corporatiebezit** (minder dan 20 woningen of geheim): standaard **aan** of **uit**? Voorstel: aan, met de melding "onbekend".
6. **Zoho-leesclient:** mag ik je vragen een Self Client met alleen leesrechten aan te maken voor de inventarisatie (fase 1 Zoho)?
7. **Mappen en namen:** frontend in `public/dashboard/`, documentatie in `dashboard/` (niet openbaar), gedeelde backendcode in `netlify/functions/dashboard-lib/`, omgevingsvariabelen `DASHBOARD_…` in plaats van `DEUR_…` (één inlog voor het hele dashboard). Akkoord?
8. **Akkoord op dit plan** om met fase 2 te beginnen (eerste versie op een tijdelijke branch, daarna `dashboard`)?
9. **Testsite:** alleen proefdata (a) of ook echte deurregistratie met een verhuizing bij de overstap (b)? Ik raad a aan als jullie binnen een paar weken overstappen, anders b.
10. **Regio:** is verwerking via een Netlify-server in de VS acceptabel (opslag blijft in Frankfurt), of moet de site naar Pro voor een EU-regio voordat er echte adressen in komen?

## 11. Werkwijze per sessie (fase 3)

- Begin: meldingen uit het dashboard en vragen van Ruben ophalen, prioriteren.
- Klein (tekst, opmaak, filter, bugfix zonder gevolgen voor data): bouwen, zelf testen, onafhankelijke review, live op `dashboard`, regel in `WIJZIGINGEN.md`.
- Groot (nieuwe module, datamodel, opslag, inlog, Zoho, termijnen, data verwijderen): voorstel, tijdelijke branch met deploy preview (en dus teststore), live na akkoord.
- Voorstel: een **wekelijkse sessie** op een vaste dag die de meldingen oppakt. Die kan ik als geplande taak instellen zodra je dat wilt.

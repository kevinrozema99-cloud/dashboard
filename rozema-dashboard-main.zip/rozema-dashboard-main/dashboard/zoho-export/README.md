# Zoho CRM — inventaris (vastgelegd 10-11-2026, vóór het einde van de proefperiode)

Alleen-lezen opgehaald via de Zoho-koppeling. **Alleen inrichting, geen klantgegevens.** De klantrecords zelf staan niet in de repo.

## Account

- Proefperiode Enterprise, loopt af **11-11-2026 01:00**. Daarna waarschijnlijk terug naar de gratis editie (niet gecontroleerd); workflows en andere Enterprise-functies kunnen dan uitvallen.
- Tijdzone Europe/Brussels, valuta euro, 3 gebruikerslicenties.

## Wat er in staat (aantallen op 10-11-2026)

| Module | Records | In gebruik |
|---|---|---|
| Leads | 1 | Ja |
| Contactpersonen | 2 | Ja |
| Deals (klanttrajecten) | 2, beide fase "Aanvraag ingediend" | Ja |
| Taken | 0 | Module zichtbaar, niet gebruikt |
| Vergaderingen | niet geteld | Standaard |
| Klanten (Accounts), Oproepen, Producten, Offertes enz. | — | Verborgen |
| Machtigingsformulier, Overeenkomst Intermediair | bestanden bij deals | Blijven in de klantdossiers, niet in het dashboard (opdracht §6) |

## Deals: het klanttraject

Fases (met waarschijnlijkheid die Zoho erbij zet):

| Fase | % | Soort |
|---|---|---|
| Getekend | 10 | open |
| Aanvraag ingediend | 20 | open |
| Opname gepland | 30 | open |
| Opname gedaan | 40 | open |
| Schaderapport | 50 | open |
| Adviesrapport | 60 | open |
| Besluit | 75 | open |
| Bezwaar | 60 | open |
| Uitbetaald | 95 | open |
| Afgerond | 100 | gesloten |
| Verloren | 0 | uitgesloten |
| Verloren (vervallen) | — | staat in de keuzelijst, niet in de layout |

Velden in de sectie Traject: Aanvraagdatum, Route (Maatwerk met onderzoek, Herstel met aannemer, Vaste vergoeding, AVV), Opnamedatum, Datum schaderapport, Datum adviesrapport, Verzenddatum besluitbrief, Uitkering IMG (pas na besluit) (standaardveld `Amount`), Fee, Factuur voldaan op. Verder Reden van verlies, Lead Bron, Contactpersoon.

## Leads

- **Status:** Nieuw, Poging 1, Poging 2, Poging 3, WhatsApp verstuurd, Contact gehad, Afspraak gepland, Keukentafelgesprek gedaan, Later opnieuw, Niet gekwalificeerd, Afgevallen.
- **Kwalificatie:** Trillingssnelheid (mm/s), Bouwjaar, Ruimtes met schade, Eerder ontvangen bedrag, Situatie, Kwalificatie (Ja, Later, Nee, Twijfel, Vaste vergoeding of AVV adviseren), Reden afgevallen, BKO/6 km-zone/IEDB (ja/nee), Terugbeldatum.
- **Lead Bron:** o.a. Website, Deur (volledige lijst in `velden-Leads.json`). "Niet thuis" (nodig voor v2) bestaat nog niet.
- Velden die v2 verwacht maar die hier **niet** bestaan: `Voor_wie`, `Contactvoorkeur`.

## Automatisering

- **Gevonden:** workflow "Deal: dealnaam uit contact": bij een nieuwe deal wordt de naam `<achternaam> - <straat huisnummer>, <plaats>`.
- **Niet gevonden:** automatische taken. Er staan 0 taken in Zoho, en bij de fasewissel naar "Aanvraag ingediend" ontstond geen taak. De termijnbewaking (ook de bezwaartermijn) bestaat in Zoho dus nog niet, of is nog niet afgegaan.
- **Workflowregels** (schermafdruk Ruben, 10-11-2026; alle gewijzigd 27-10 tenzij anders vermeld). Inhoud (voorwaarden, acties, termijnen) nog niet bekend:

| Regel | Module | Uitvoeren op | Acties | Aan |
|---|---|---|---|---|
| Big Deal Rule | Deals | aanmaken of bewerken | 1 | uit (Zoho-voorbeeld) |
| Lead: belpoging 2 na Poging 1 (naam afgekapt) | Leads | aanmaken of bewerken | 1 | aan |
| Deal: opname voorbereiden | Deals | aanmaken of bewerken | 1 | aan |
| Lead: belpoging 3 na Poging 2 (naam afgekapt) | Leads | aanmaken of bewerken | 1 | aan |
| Deal: zienswijze na adviesrapport (naam afgekapt) | Deals | aanmaken of bewerken | 1 | aan |
| Lead: WhatsApp na Poging 3 | Leads | aanmaken of bewerken | 1 | aan |
| **Deal: termijnen na besluitbrief** (naam afgekapt) | Deals | aanmaken of bewerken | **3** | aan |
| Lead: afsluiten na WhatsApp | Leads | aanmaken of bewerken | 1 | aan |
| Deal: factuur na uitbetaling | Deals | aanmaken of bewerken | 1 | aan |
| Lead: nieuwe lead bellen | Leads | maken | 1 | aan |
| Deal: dealnaam uit contact | Deals | maken | 0 (veldupdate gezien in tijdlijn) | aan |
| Lead: vangnet terugbeldatum (10-11) | Leads | aanmaken of bewerken | 1 | uit |
| Kwalificatie: later (10-11) | Leads | aanmaken of bewerken | 0 | uit |
| Kwalificatie: nee, situatie (10-11) | Leads | aanmaken of bewerken | 0 | uit |
| Kwalificatie: nee, geen be… (10-11) | Leads | aanmaken of bewerken | 0 | uit |
| Kwalificatie: ja (10-11) | Leads | aanmaken of bewerken | 0 | uit |

- **Inhoud van regels** (schermafdrukken Ruben, 10-11-2026). Alle: "uitgevoerd als record wordt gemaakt of bewerkt om te voldoen aan de voorwaarde", één directe actie "Taak". Vervaldatum van de taak nog niet gezien (staat in de taak zelf).

| Regel | Voorwaarde | Taak (onderwerp) |
|---|---|---|
| Lead: belpoging 2 na Poging 1 | Lead Status IS Poging 1 | "Belpoging 2 (ander moment van de …" (afgekapt) |
| Lead: belpoging 3 na Poging 2 | Lead Status IS Poging 2 | "Belpoging 3" |
| Lead: WhatsApp na Poging 3 | Lead Status IS Poging 3 | "WhatsApp-bericht sturen (laatste po…" (afgekapt) |
| Deal: opname voorbereiden | Opnamedatum IS NIET LEEG | "Opname voorbereiden" |
| Deal: zienswijze na adviesrapport | Datum adviesrapport IS NIET LEEG | "Zienswijze indienen (termijn 2 weken)" |

| **Deal: termijnen na besluitbrief** | Verzenddatum besluitbrief IS NIET LEEG | 3 taken: "Besluit controleren"; "Bezwaar beslissen"; "FATALE TERMIJN: bezwaar uiterlijk o…" (afgekapt) |
| Lead: afsluiten na WhatsApp | Lead Status IS WhatsApp verstuurd | "Geen reactie op WhatsApp? Zet op A…" (afgekapt, vermoedelijk "Afgevallen") |
| Deal: factuur na uitbetaling | Fase IS Uitbetaald | "Factuur sturen" |
| Lead: nieuwe lead bellen | bij **maken**, Lead Status IS NIET Afgevallen | "Bellen: nieuwe lead" |
| Deal: dealnaam uit contact | bij **maken**, Contactpersoonnaam IS NIET LEEG | geen taak; veldupdate dealnaam (gezien in tijdlijn) |

| Lead: vangnet terugbeldatum (uit) | (Status IS Contact gehad OF Keukentafelgesprek gedaan OF Later opnieuw) EN Terugbeldatum IS LEEG | "Terugbeldatum zetten" |
| Kwalificatie: later (uit, geen actie) | Situatie IS Wacht op rapport of besluit EN (Trilling ≥ 2 mm/s OF BKO/6 km/IEDB) | — |
| Kwalificatie: nee, situatie (uit, geen actie) | Situatie IS Huurder of geen woonhuis OF Adres afgesloten | — |
| Kwalificatie: nee, geen bewijsvermoeden (uit, geen actie) | Trilling < 2 mm/s EN NIET BKO/6 km/IEDB | — |
| Kwalificatie: ja (uit, geen actie) | Situatie NIET Huurder/Adres afgesloten/Wacht op rapport of besluit EN (Trilling ≥ 2 mm/s OF BKO/6 km/IEDB) | — |

  De vier kwalificatieregels hadden nog geen actie; bedoeld was kennelijk dat Zoho het veld Kwalificatie zelf invult. In het dashboard worden ze een **kwalificatievoorstel** (één tik om over te nemen).

  Nog niet gezien: de **vervaldatum** van elke taak (staat in het taakvenster) en de volledige titel van de fatale taak.
- Een eventuele Blueprint is niet uit te lezen via de koppeling.
- Leads worden niet overgezet: Ruben begint met een verse leaddatabase (besluit 10-11-2026).
- Geen toewijzingsregels, geen CRM-variabelen.

## Bestanden

`velden-<module>.json`: alle gebruikte velden met type en keuzewaarden. `layout-<module>.json`: secties en volgorde zoals in Zoho.

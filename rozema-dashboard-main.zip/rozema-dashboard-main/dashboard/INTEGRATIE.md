# Dashboard — integratie met de website

Doel: de branch `dashboard` moet met `main` en met `herbouw-v2` samen te voegen zijn, in welke volgorde ook, met zo min mogelijk botsingen. Alles van het dashboard staat in eigen mappen. Hieronder staat elke regel die het dashboard in een **gedeeld** bestand zet, en welke aannames over v2 bij het samenvoegen moeten worden gecontroleerd.

Stand: fase 1 (plan). Er staat nog geen dashboardcode in gedeelde bestanden.

## Eigen mappen (botsen niet)

| Map | Inhoud |
|---|---|
| `dashboard/` (root, niet gepubliceerd) | Plan, integratie, wijzigingen |
| `public/dashboard/` | Frontend, komt op `/dashboard/` |
| `netlify/functions/dashboard-*.mjs` | Backend, routes onder `/api/dashboard/` |
| `netlify/functions/dashboard-lib/` | Gedeelde backendcode (zie PLAN.md, Opbouw) |
| Blobs-stores `dashboard-*` | Opslag, regio `eu-central-1` |

## Regels in gedeelde bestanden (verwacht in fase 2)

| Bestand | Regel | Waarom | Bij samenvoegen met v2 |
|---|---|---|---|
| `netlify.toml` | `[[headers]]` voor `/dashboard/*` met `X-Robots-Tag = "noindex, nofollow"`, `Cache-Control = "no-cache"` en `Content-Security-Policy = "default-src 'self'; img-src 'self' data: https://service.pdok.nl; connect-src 'self' https://api.pdok.nl; frame-ancestors 'none'; form-action 'none'; base-uri 'none'"` | Niet indexeren, altijd de nieuwste app, geen externe scripts; PDOK-tegels en -adressen wel toegestaan | Blok onderaan toevoegen; botst niet met de bestaande blokken. Deze headers gelden niet voor Functions: de API zet `X-Robots-Tag` zelf |
| `netlify.toml` | **Geen** `[functions]`-blok | Netlify gebruikt standaard `netlify/functions`; v2 zet dat blok al | v2's blok houden zoals het is |
| `package.json` | `"@netlify/blobs"` onder `dependencies` | Opslag | Regel toevoegen aan v2's `dependencies`; daarna `npm install` zodat `package-lock.json` opnieuw wordt gemaakt (lockfile niet met de hand samenvoegen) |
| `package-lock.json` | Volgt uit `npm install @netlify/blobs` | Netlify bouwt met de lockfile | Bij een conflict niet met de hand samenvoegen: v2's versie nemen, regel in `package.json` toevoegen, `npm install` |
| `public/robots.txt` | Geen wijziging | `noindex` gaat via de header | — |

## Wijzigingen van de klantenmodule in gedeelde dashboardbestanden

De klantenmodule (K6 en K7) staat in `public/dashboard/klanten/`. Voor deze gedeelde bestanden zijn kleine wijzigingen gedaan; de branch `dashboard-deur` wijzigt ze ook, dus bij samenvoegen controleren.

| Bestand | Wijziging | Waarom |
|---|---|---|
| `gedeeld/dashboard.css` | `.melding-tekst.fout`: tekstkleur Donker (was Klei-donker), de Klei-rand blijft | Contrast van de foutmelding (WCAG AA) |
| `gedeeld/dashboard.js` | `D.wisCache()` wist de sleutels `dashboard.*` in `sessionStorage` en de `kv`-cache in IndexedDB (database `rozema-klanten`), maar **nooit** de wachtrij met niet-verstuurde wijzigingen en conflicten. Nieuw: `D.wachtrijAantal()`. `D.naarInlog()` wist eerst de cache en gaat dan pas naar inloggen | Cache van klantgegevens weg bij uitloggen en bij een 401; wijzigingen die nog niet verstuurd zijn blijven bewaard |
| `gedeeld/start.js` en `index.html` | Uitloggen roept `D.wisCache()` aan en waarschuwt als er nog wijzigingen in de wachtrij staan (knoppen "Toch uitloggen" en "Annuleren") | Geen wijzigingen kwijt, wel een bewuste keuze |
| `gedeeld/teksten.js` | Blok `klanten` (en `start.uitlog...`) toegevoegd | Alle teksten op één plek |
| `sw.js` | Alleen de bestanden van `klanten/` aan de cachelijst toegevoegd | Offline openen |

Privacy en AVG rond de klantenschermen (besluit tot Ruben anders beslist):

- Elke wijziging in de offline-wachtrij krijgt `wie`. Alleen wijzigingen van de ingelogde gebruiker worden verstuurd; die van een ander op hetzelfde toestel staan als "van {wie}, wacht tot die inlogt" in Niet opgeslagen.
- Uitloggen met een gevulde wachtrij biedt twee keuzes: "Eerst versturen" (alleen met verbinding) of "Wissen van dit toestel" (met bevestiging die het aantal noemt). Annuleren blijft. Onbeslechte conflicten vervallen bij uitloggen.
- De cache van klantgegevens (`kv`) is hoogstens 7 dagen oud en wordt gewist bij uitloggen en een 401. De cache bevat alleen serverdata; wachtende wijzigingen worden er bij het tonen overheen gelegd.
- De knop "Navigeren" op het relatiescherm opent een link naar Google Maps met het adres van de klant (`https://www.google.com/maps/search/?api=1&query=...`). Het adres gaat dus naar Google zodra iemand op de knop tikt. Er worden geen externe scripts of kaarten geladen. WhatsApp (`wa.me`) en bellen (`tel:`) werken op dezelfde manier met het telefoonnummer van de klant.

Eén IndexedDB-database `rozema-klanten` met twee stores: `kv` (cache, wordt gewist) en `wachtrij` (nooit automatisch gewist). Het schema staat in `klanten/wachtrij.js` en in `gedeeld/dashboard.js`; wijzig beide samen. De klanten-wachtrij is gemodelleerd naar de deur-wachtrij (`deur/opslag.js`, `deur/verstuur.js` op `dashboard-deur`); die twee kunnen later tot één gedeelde wachtrij worden samengevoegd. Let op: de wachtrij bevat klantgegevens op het toestel tot ze zijn verstuurd, ook na uitloggen.

## Koppeling deur en klanten (K10)

Alleen `sw.js` is gedeeld geraakt: twee bestanden van `klanten/` (`deurteksten.js`, `deurlink.js`) en `deur/verstuur.js` aan de cachelijst, en `CACHE` naar `dashboard-v3`. `gedeeld/*` en `opslag.mjs` zijn niet gewijzigd; `relatie.js` ook niet (de verwijzing op de relatiepagina staat in `relatie.html` en het losse `deurlink.js`). Gewijzigd in de klantenmodule: `nieuw.js`, `nieuw.html`, `relatie.html`, `dashboard-klanten.mjs` (route `straten`, nieuw bestand `dashboard-lib/klanten/straten.mjs`). Teksten van de koppeling staan in `klanten/deurteksten.js` en `deur/teksten.js`, niet in `gedeeld/teksten.js`.

Na het samenvoegen op `integratie` (K10 met K7, K8, K9 en K11): `sw.js` bevat ook de bestanden van K11 (`klanten/beheer.html`, `beheer.css`, `beheer.js`, `beheer-teksten.js`, `beheerlink.js`) en `CACHE` is `dashboard-v4`. `relatie.html` laadt zowel `deurteksten.js`/`deurlink.js` (K10) als `beheer-teksten.js`/`beheerlink.js` (K11). `dashboard-klanten.mjs` heeft zowel `deurHerkomstOk` en `/straten` (K10) als 410 bij `verwijderd` (K11).

## Omgevingsvariabelen (in Netlify, nooit in de repo)

| Variabele | Gedeeld met v2? | Opmerking |
|---|---|---|
| `DASHBOARD_GEBRUIKERS` | Nee | JSON met naam → wachtwoord-hash |
| `DASHBOARD_SESSIE_GEHEIM` | Nee | Ondertekent de sessies. Vervangen = iedereen uitgelogd |
| `DASHBOARD_SESSIE_VERSIE` | Nee | Optioneel. Verhogen maakt alle bestaande sessies ongeldig (zonder het geheim te vervangen); zonder waarde is de versie 1. Het rondje-script zet dit om een verlopen sessie na te bootsen |
| `DASHBOARD_ECHTE_DATA` | Nee | `aan` alleen voor productie en de branch `dashboard`; anders gebruikt het dashboard teststores. Alleen voor de context Production zetten; de code controleert dit ook: echte data alleen in de context production, en staat de variabele op `aan` terwijl de context ontbreekt, dan geeft de Function een 500 (geen stille teststore). Op de testsite is `dashboard` de productiebranch; op Kevins hoofdsite gebruikt een branch-deploy van `dashboard` altijd de teststore en pas na samenvoegen in productie wordt het echt |
| `ZOHO_ACCOUNTS_URL`, `ZOHO_API_URL` | Niet door het dashboard gebruikt | Alleen van v2 (website en Zoho). Het dashboard leest ze niet; ze staan hier omdat de eerdere opzet ervan uitging. Voor het dashboard gelden alleen de `DASHBOARD_ZOHO_*`-variabelen hieronder (zie ook `DASHBOARD_INSTROOM*` bij K9) |
| `DASHBOARD_ZOHO_CLIENT_ID`, `DASHBOARD_ZOHO_CLIENT_SECRET`, `DASHBOARD_ZOHO_REFRESH_TOKEN` | Nee | Eigen Self Client voor het dashboard, zodat rechten en intrekken los staan van de website |

## Afwijkingen van de opdracht (ter bevestiging, zie PLAN.md §10)

- Kevins branch heet `herbouw-v2`, niet `v2-herbouw`.
- Frontend in `public/dashboard/` (Astro kopieert `public/` naar de publicatiemap `dist/`); documentatie in `dashboard/` in de root, zodat die niet openbaar wordt.
- Omgevingsvariabelen heten `DASHBOARD_…` in plaats van `DEUR_…`, omdat de inlog voor het hele dashboard geldt.

## Overstap van de testsite naar Kevins Netlify-account

Eerst wordt getest op een aparte site in Rubens Netlify-account (PLAN.md §8). Bij de overstap:

1. In Kevins site de omgevingsvariabelen hierboven zetten, met een **nieuw** sessiegeheim (niet dat van de testsite).
2. Alleen bij echte data op de testsite: data verhuizen met de exportroute en het importscript, en controleren dat de aantallen per plaats en per store gelijk zijn. Pas na akkoord van Ruben.
3. Na samenvoegen controleren dat `/dashboard/` en `/api/dashboard/` op Kevins site werken en dat de Blobs in `eu-central-1` staan.
4. De testsite daarna opheffen of de data daar verwijderen (besluit Ruben).

## Aannames over `herbouw-v2` (gelezen op 10-11-2026, commit 8bd7e05)

Bij het samenvoegen controleren of deze nog kloppen:

1. Framework Astro 5, build `npm run build`, publicatiemap `dist`; alles in `public/` gaat ongewijzigd naar `dist/`.
2. Functions in `netlify/functions/`, gedeelde code in `netlify/lib/` (het dashboard gebruikt die map niet).
3. Er is geen route of pagina onder `/dashboard` of `/api/dashboard`.
4. Zoho-velden in `netlify/lib/zoho-velden.mjs`: telefoon in `Mobile`, bron in `Lead_Source` met waarde `Deur` voor deur-aan-deur, API-versie `v7`. Het dashboard gebruikt dezelfde namen.
5. `/niet-thuis` is een pagina van v2 (QR op de flyer). Het dashboard raakt die niet.
6. De header-regel voor `/*` (`X-Frame-Options = "DENY"` enz.) geldt ook voor het dashboard; dat is gewenst.

## Website-instroom naar het dashboard (K9)

Een aanvraag van het websiteformulier wordt een nieuwe relatie (status Nieuw, `herkomst.website`, met het kanaal erbij) in de klantenopslag. De code staat in `netlify/functions/dashboard-lib/klanten/instroom.mjs` (eigen map, botst niet). De bestaande Functions `lead-aanmaken.mjs` en `lead-bijwerken.mjs` zijn van Kevin en zijn **niet** gewijzigd; het voorstel staat in `dashboard/voorstel-instroom.diff` (tegen `origin/herbouw-v2`, controle met `git apply --check`). Optie B (aparte Function met sleutel) is niet nodig: het dashboard komt op dezelfde site.

Wat het voorstel doet:

- **Uit tot Kevin het aanzet:** de dashboardstap draait alleen met `DASHBOARD_INSTROOM=aan` en een geheim `DASHBOARD_INSTROOM_GEHEIM` (minstens 16 tekens). Zonder een van beide gedraagt `lead-aanmaken` zich als nu en gooit `neemAanvraagOp` niet.
- **Wanneer is een aanvraag gelukt:** is Zoho ingesteld (parallelle periode), dan alleen als Zoho gelukt is; bij een Zoho-fout gaat de aanvraag altijd naar de noodroute, ook als het dashboard wel schreef. Is Zoho niet ingesteld, dan alleen als het dashboard in de **echte** store schreef (`echt:true`, dus `DASHBOARD_ECHTE_DATA=aan` en context production). Een teststore, een fout of een time-out van 3 seconden telt als mislukt.
- **Idempotent:** een HMAC-sha256 (met het geheim) van postcode, huisnummer en telefoon (genormaliseerd) staat 24 uur als claim in `ontdubbel/instroom/<hmac>`, met relatie-id, Zoho-id en een tweede hash over de overige velden. De claim bevat verder per overig veld een HMAC (geen waarden). Hetzelfde formulier nog eens insturen geeft dezelfde relatie, ook bij gelijktijdig versturen of een onderbroken eerste poging.
- **Herhaling:** er komt een tijdlijnregel bij de bestaande relatie (`soort: "herhaling"`, alleen datum en kanaal, geen inhoud); er wordt niet samengevoegd. Wijken de overige gegevens af, dan worden alleen de velden bijgewerkt die anders zijn ingevuld dan bij de vorige aanvraag (handmatige correcties blijven staan; de nieuwe hashes gaan met `onlyIfMatch` in de claim, bij een conflict opnieuw lezen) en gaat Zoho wel opnieuw, ook als het bijwerken mislukte. De frontend heeft nog een tekst nodig voor die regel: `[[TEKST: klanten.tl.herhaling]]` (nu valt hij onder `tl.overig`).
- **Zoho-id:** na een geslaagde `maakLead` slaat `bewaarZohoId` het id op in de claim. Zoho wordt bij een herhaling alleen overgeslagen als dat id bekend is. De claim krijgt `zohoBezig` (30 s) voor het verzoek dat Zoho aanroept; een tweede verzoek wacht hoogstens ~2 s op het id (`wachtOpZohoId`) en gaat bij een time-out toch naar Zoho: een dubbele lead is beter dan een verloren lead. `bewaarZohoId` wordt ook na een time-out van het dashboard aangeroepen (zelf met time-out, fouten genegeerd).
- **Code op de bedankpagina:** `"<relatieId>|<zohoId>"` (een relatie in de teststore komt er niet in). `lead-bijwerken` splitst die, zet Situatie in het dashboard en/of Zoho en geeft 204 zodra een doel gelukt is; niet gevonden telt niet als fout. Oude codes met alleen een Zoho-id blijven werken. In het dashboard wordt Situatie alleen gezet als die leeg is of de status nog Nieuw is.
- **Opruimen en AVG:** de dagelijkse run (`dagelijks.mjs`, stap `instroomClaims`) verwijdert claims ouder dan 24 uur, alleen als het lezen lukte en de etag vlak voor het verwijderen nog gelijk is. `verwijderClaimVoorRelatie(relatieId)` in `instroom.mjs` haalt de claims van een relatie weg; K11 (AVG-verwijderen) roept die aan (zie de K11-sectie hieronder). Race: wijst een geldige claim naar een relatie met een tombstone (verwijderd terwijl de claim bleef staan), dan neemt `claim()` hem als nieuw over (onlyIfMatch): de aanvraag wordt een nieuwe relatie met een nieuw id, het oude Zoho-id wordt niet hergebruikt en deze aanvraag maakt zelf de Zoho-lead. Test: `instroom.test.mjs`, "race met AVG-verwijderen".
- **Mapping:** telefoon naar `mobiel`; `voorWie` en `contactvoorkeur` met de waarden uit `zoho-velden.mjs`; bron per `?bron=` (nfc/kaart Deur, niet-thuis Niet thuis, anders Website). Een huisnummer dat niet in huisnummer plus toevoeging past (bijvoorbeeld "12 bis a") wordt geweigerd; dan vangt Zoho of de noodroute de aanvraag op. De relatie wordt gevalideerd vóór de claim.
- **Geen nieuwe tekst** voor bezoekers in `instroom.mjs` en het voorstel.

Bij samenvoegen: `netlify/functions/dashboard-lib/` moet naast `lead-aanmaken.mjs` staan (importpaden `./dashboard-lib/...`); `@netlify/blobs` staat in het voorstel in `package.json`, daarna `npm install` voor de lockfile (niet met de hand samenvoegen). Zet `DASHBOARD_INSTROOM_GEHEIM` voordat `DASHBOARD_INSTROOM=aan` gaat.

## Klantenmodule K11: export, AVG-verwijderen en agenda

- Routes staan in `netlify/functions/dashboard-klanten-export.mjs` onder `/api/dashboard/klantenbeheer/` (eigen voorvoegsel, zodat het niet overlapt met de wildcard `/api/dashboard/klanten/*` van `dashboard-klanten.mjs`).
- Store `dashboard-agenda` (of `dashboard-test-agenda`): alleen hashes van agenda-tokens. Store `klanten`: nieuwe sleutels `tombstone/<relatieId>` (id, datum, wie) en `exportlog/...`.
- Aanpassingen in gedeelde klantenbestanden (alleen toegevoegd): `opslag.mjs` krijgt `isVerwijderd(relatieId)`; `maakRelatie`, `maakTraject`, `bewaarJournaal` en `schrijfRegels` weigeren of slaan over voor een verwijderde relatie (code `verwijderd`, de API geeft 410, de wachtrij behandelt dat als afgekeurd); `vergelijkRegister` herstelt geen trajecten van een verwijderde relatie. `dashboard-klanten.mjs`: een regel in `vertaalFout` (410) en het commentaar bovenaan.
- **Koppeling met K9 (gebouwd op `integratie`):** `ruimOp` in `dashboard-lib/klanten/export.mjs` roept `verwijderClaimVoorRelatie(relatieId)` uit `instroom.mjs` aan. Daardoor doen alle drie de routes het: `verwijderRelatie`, een herhaald verwijderen (`alVerwijderd`) en `ruimTombstoneOp` in de dagelijkse run (stap "index", ook voor een claim die na een race nog naar de relatie wijst). Idempotent: een tweede keer vindt geen claim meer. Het aantal staat als `verwijderd.claims` in het antwoord van `beheer/verwijderen` (alleen een getal). Een fout bij het lezen of wissen van claims gaat net als de rest van `ruimOp` door als fout; in de dagelijkse run komt die in de hartslag bij de stap "index" en volgt de volgende nacht een nieuwe poging. Test: `dashboard-lib/klanten/handlers/dashboard-klanten-export.test.mjs`, "verwijderen haalt de instroomclaim van de relatie weg".
- **Caches op andere apparaten blijven bestaan.** Na verwijderen wist `beheer.js` alleen op het toestel waarmee is verwijderd: de kv-sleutels `relatie:<id>` en `tijdlijn:<id>` (leeggemaakt), wachtrij- en conflictitems voor dat id en `sessionStorage` `dashboard.klanten.*`. Op andere toestellen blijven die gegevens staan tot uitloggen of een 401 (dan wist `D.wisCache()` de kv-cache). Een wachtrijitem daar wordt bij versturen met 410 afgekeurd.
- **410 na verwijderen:** ontbreekt het record en bestaat er een tombstone, dan geven lezen en wijzigen van de relatie, de tijdlijn, aanmaken en wijzigen van een traject 410 (anders 404). Voor trajecten schrijft `ruimOp` per traject een sleutel `tombstone-traject/<trajectId>` (alleen het id); `isTrajectVerwijderd` controleert die, zodat wijzigen, afvinken en heropenen van een gewist traject 410 geven. `ruimOp` haalt register en indexrij altijd eerst weg, ook als het budget daarna op raakt. De client (`relatie.js`, `traject.js`) wist bij 404 of 410 van de eigen server `relatie:<id>` en `tijdlijn:<id>` uit de kv-cache en valt er niet op terug; een nog niet verstuurde aanmaak uit de wachtrij blijft bij 404 zichtbaar.
- **Tijdslimieten:** `beheer/verwijderen` werkt met een budget van ongeveer 8 s (`OPRUIM_BUDGET_MS`). Is het werk dan niet af, dan komt `{ok:true, deels:true}` terug (tombstone en relatie zijn dan al weg); de dagelijkse run maakt het af. De client (`beheer.js`, timeout ongeveer 25 s) toont dat als gelukt. De tombstone krijgt `opgeruimdOp` bij de eerste geslaagde opruiming door de dagelijkse run (anoniem veld, alleen een tijdstip); de run slaat tombstones over waarvan `opgeruimdOp` 7 dagen of ouder is, en leest de lijst met trajecten één keer per run. Een fout bij één tombstone wordt geteld (`tombstonesMislukt`) en stopt de rest niet; de index wordt altijd herbouwd.
- **Vervolgpunt:** de export met tijdlijnen (`opties.tijdlijnen`) leest per relatie een tijdlijn; bij veel relaties kan dat de Function-limiet (standaard 10 s, 26 s voor een achtergrondtaak) halen. Nu nog niet gemeten op echte aantallen. Bij tegenvallen: export in delen (per aantal relaties) of als geplande taak naar een tijdelijke blob.
- Bewaartermijn: open vraag aan Ruben (`TODO(Ruben)` in `export.mjs`); er is geen automatisch opruimen.
- Ook toegevoegd: `indexUpsert` en `afronden` (maakTraject) in `opslag.mjs` controleren `isVerwijderd`; `dagelijks.mjs` ruimt in de stap "index" per `tombstone/*` na een race alles op (`ruimTombstoneOp`); `wachtrij.js` verwijdert een item dat 410 krijgt direct (1 regel).

## Module deur-aan-deur

- Backend `netlify/functions/dashboard-deur.mjs`, hulpcode in `netlify/functions/dashboard-lib/deur/`. Importeert de gedeelde rekenlogica uit `public/dashboard/deur/logica.js` (de bundler neemt die mee).
- Leaflet 1.9.4 staat zelf gehost in `public/dashboard/gedeeld/leaflet/` (BSD-licentie meegeleverd). Geen CDN.
- `public/dashboard/sw.js`: lijst uitgebreid met de bestanden van de module, CACHE verhoogd naar `dashboard-v2`.
- `public/dashboard/gedeeld/dashboard.js`: `data-beveiligd="zacht"` laat de pagina de inlog zelf regelen (event `dashboard:sessie-verlopen`) in plaats van naar het startscherm te sturen.
- Geen wijzigingen in `netlify.toml` of `package.json`. De CSP uit `netlify.toml` volstaat: scripts, stijlen en lettertypen komen van de eigen site, PDOK-tegels en -adressen zijn al toegestaan.
- Store `deur` (via `store("deur")`): sleutels zie `dashboard-lib/deur/server.mjs`.

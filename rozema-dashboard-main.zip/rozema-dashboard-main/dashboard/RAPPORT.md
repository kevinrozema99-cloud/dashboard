# Rapport: dashboard-sessie (deur-aan-deur en klantenmodule)

Branch: `dashboard-bouw`. Niets op `main` of `herbouw-v2` gezet, niets gemerged.

## Gebouwd

| Onderdeel | Wat het doet |
|---|---|
| Deur-aan-deur | Kaart per plaats (BAG/PDOK), bezoeken vastleggen (ook offline), straatvolgorde, versies per plaats |
| K3 opslag | Klanten en trajecten in Netlify Blobs, samenvoegen per veld, journaal, logboek, register |
| K4 API | `/api/dashboard/klanten/*`: relaties, trajecten, termijnen, taken; 409 bij conflict, 410 na AVG-verwijderen |
| K5 startscherm | Fatale termijnen, taken vandaag en deze week, gezondheid; nachtelijke run (03:00) met hartslag |
| K6/K7 frontend | Startscherm, lijst, relatie, traject, nieuwe klant, conflictscherm, offline wachtrij per gebruiker, termijnregels |
| K8 Zoho-import | `scripts/dashboard-klanten-import.mjs`: proefrun eerst, idempotent, geen persoonsgegevens in de uitvoer |
| K9 website-instroom | Aanvragen van de site worden een relatie (ontdubbeld met HMAC). Voorstel voor Kevin: `dashboard/voorstel-instroom.diff` |
| K10 deur en klanten | Klant aanmaken vanuit een afspraak aan de deur, straten met klant in de deur-app, link terug naar de bezoeken |
| K11 beheer | Export (JSON/CSV), AVG-verwijderen met tombstone, agendafeed (.ics) met token |

Elk onderdeel is getest door de bouwer en gecontroleerd door een aparte reviewer. Daarna volgde een eindreview over het geheel. Uitslag: akkoord voor de testuitrol.

Laatste stand van de tests: 331 en 22 node-tests, de build, het klanten-rondje (246 van 246) en het deur-rondje op 390 en 360 px. Alles geslaagd.

## Netlify-instellingen voor de testuitrol (account van Ruben)

| Variabele | Doel |
|---|---|
| `DASHBOARD_GEBRUIKERS` | Logins; hash maken met `node scripts/dashboard-wachtwoord.mjs` |
| `DASHBOARD_SESSIE_GEHEIM` | Willekeurige sleutel van minstens 32 tekens |
| `DASHBOARD_SESSIE_VERSIE` | Optioneel; ophogen logt iedereen uit |

Nog **niet** zetten: `DASHBOARD_ECHTE_DATA` (pas na akkoord van Ruben, alleen in Production), `DASHBOARD_INSTROOM_GEHEIM` en `DASHBOARD_INSTROOM` (pas als Kevin de voorgestelde wijziging heeft overgenomen).

## Checklist eerste uitrol

1. Open de deploy preview van `dashboard-bouw`. Het deploy-log moet zes Functions tonen: auth, deur, klanten, klanten-export, klanten-dagelijks en meldingen.
2. Zet de drie variabelen uit de tabel. Laat `DASHBOARD_ECHTE_DATA` leeg.
3. Log in op de telefoon. Controleer dat er geen CSP-fouten zijn en dat `/dashboard/klanten/lijst.html` niet doorverwijst.
4. Controleer bij Netlify Blobs dat er alleen stores `dashboard-test-*` zijn.
5. Doe een rondje met twee telefoons: offline vastleggen, uitloggen terwijl er nog iets in de wachtrij staat, en een klant AVG-verwijderen die op het andere toestel open staat.
6. De geplande run draait alleen op de productiebranch. Controleer de dag erna de hartslag op het startscherm, of start de run met de hand via de beheerknop.
7. Daarna, met akkoord van Ruben: zet `DASHBOARD_ECHTE_DATA=aan` en draai de Zoho-import. Eerst de proefrun, daarna `--uitvoeren`.

Zoho-import: het exportbestand staat buiten de repo. Commando, eerst als proefrun:

```
DASHBOARD_COOKIE='dashboard_sessie=...' node scripts/dashboard-klanten-import.mjs <pad>/zoho.json --basis https://<site>
```

## Beslissingen voor Ruben

1. **Bewaartermijn:** hoe lang bewaren we klantgegevens en tombstones nadat een traject is afgerond of verloren? Er is nu niets ingevuld; zie `TODO(Ruben)` in `export.mjs`.
2. **AVG-keuzes, voorlopig door ons genomen:**
   - Bij uitloggen kies je tussen "Eerst versturen" en "Wissen van dit toestel".
   - Wissen gaat alleen over je eigen items.
   - Conflicten vervallen bij uitloggen.
   - De cache op het toestel is hooguit 7 dagen oud.
   - Akkoord?
3. **Klant vanaf de deur:** krijgt die de status "Afspraak gepland" met een afspraaktaak, en koppelt het deurbezoek terug naar de klant? Nu blijft de status "Nieuw".
4. **Sluitregel:** een traject kan pas gesloten worden als de fatale termijnen zijn afgehandeld. Is "Bezwaar beslissen" fataal?
5. **K0-termijnen:**
   - de vervaldatums per regel;
   - de volledige titel van "FATALE TERMIJN";
   - geldt de zienswijze voor elke route?
6. **Zoho-fases:** alleen "Aanvraag ingediend" wordt geïmporteerd. Moeten latere fases ook mee?
7. **Telling "klant in de straat":** telt een relatie met "Afspraak gepland" ook mee?
8. **PDF's in Zoho:** het machtigingsformulier en de overeenkomst worden bewust niet overgenomen. Zijn ze bewaard?

## Voor Kevin

- **Teksten:** alle dashboardteksten zijn door ons geschreven en moeten getoetst worden. Deze placeholders zijn nog open:
  - `klanten.tl.herhaling`
  - `start.uitlogMislukt`
  - `klanten.beheerK11.*`
  - `klanten.agenda.*`
  - `klanten.deurkoppeling.*`
  - `deur.klant.aanmaken`
  - `deur.klant.aanmakenLabel`
- **Bestaande tekst die niet meer klopt:** `deur.uitkomst.afspraakUitleg` zegt nog "zet de gegevens zelf in het klantsysteem".
- **Voorstel-diff:** `dashboard/voorstel-instroom.diff` voor `lead-aanmaken.mjs` en `lead-bijwerken.mjs`. Daarbij hoort `@netlify/blobs` in `package.json`.
- **Afwijkingen van de architectuur:**
  - K8 is een script in plaats van `POST /import`;
  - de deurkoppeling loopt via de relatie (`herkomst.deur`);
  - `/straten` geeft alleen ja/nee per straat.

## Vervolg (niet blokkerend)

- Straatnaam in de klantindex, zodat `/straten` geen relatierecords meer hoeft te lezen.
- Export met tijdlijnen meten bij veel data, en eventueel als achtergrondtaak draaien.
- Foutmeldingen van de server tonen op foutcode in plaats van met vaste servertekst.
- Overstap naar het Netlify-account van Kevin: daar een nieuw `DASHBOARD_SESSIE_GEHEIM` zetten.

# Klantenmodule: Zoho nabouwen in het dashboard

Stand: 10-11-2026. Opdracht Ruben: Zoho volledig nabouwen en verbeteren, met voorrang omdat de proefperiode afloopt. Bron: `zoho-export/` (inrichting zoals die in Zoho stond).

## Uitgangspunten

- **Eén record per huishouden.** In Zoho wordt een lead bij conversie gekopieerd naar een contactpersoon en een deal. Dan staan gegevens dubbel en lopen ze uit elkaar. Hier blijft het één **relatie** die van lead naar klant gaat, met per IMG-zaak een **traject**.
- **Termijnen zijn regels, geen losse taken.** Elke termijn volgt uit een datum in het traject (bijv. verzenddatum besluitbrief). Wordt de datum gewijzigd, dan schuift de termijn mee. Zoho had nog geen automatische taken (0 taken, geen taak bij fasewissel); hier zijn ze vanaf dag 1 ingebouwd.
- **Fatale termijnen zijn nooit uit beeld.** Bovenaan het startscherm, met het aantal dagen dat rest, totdat iemand de bijbehorende actie heeft afgevinkt.
- **Wie deed wat:** elke wijziging krijgt wie en wanneer, en een tijdlijn per relatie (zoals in Zoho).
- **Geen BSN, machtigingsformulieren of rapporten** in het dashboard; die blijven in de klantdossiers (opdracht §6). Wel een veld "dossier" met een verwijzing (bijv. mapnaam), geen bestand.

## Datamodel (store `dashboard-klanten`, regio eu-central-1)

### Relatie (`relatie/<id>`)

| Veld | Uit Zoho | Opmerking |
|---|---|---|
| voornaam, achternaam, aanhef | Lead/Contact | |
| telefoon, mobiel, e-mail | Lead/Contact | |
| straat, huisnummer, postcode, plaats | Lead adres | Adres los opgeslagen, zodat de deur-aan-deur-module erop kan koppelen (klant in de straat) |
| bron | Lead Bron | Zelfde waarden als Zoho, plus "Niet thuis" (v2 verwacht die) |
| status | Lead Status | Nieuw, Poging 1–3, WhatsApp verstuurd, Contact gehad, Afspraak gepland, Keukentafelgesprek gedaan, Later opnieuw, Niet gekwalificeerd, Afgevallen, **Klant** (nieuw: na Getekend) |
| terugbeldatum | Terugbeldatum | Maakt automatisch een taak |
| kwalificatie | Kwalificatie | Ja, Later, Nee, Twijfel, Vaste vergoeding of AVV adviseren |
| situatie | Situatie | Zoals Zoho |
| reden_afgevallen | Reden afgevallen | Verplicht bij status Afgevallen |
| trilling_mms, bouwjaar, ruimtes_met_schade, eerder_ontvangen, bko_6km_iedb | Kwalificatievelden | Bouwjaar en trilling kunnen uit de deur-aan-deur-module worden overgenomen |
| eigenaar | Lead-eigenaar | Kevin of Ruben |
| notitie | Beschrijving | |
| aangemaakt, gewijzigd (wie, wanneer) | systeem | |

### Traject (`traject/<id>`, hoort bij één relatie)

| Veld | Uit Zoho |
|---|---|
| naam | automatisch `<achternaam> - <straat huisnummer>, <plaats>` (was workflow "Deal: dealnaam uit contact") |
| fase | Getekend, Aanvraag ingediend, Opname gepland, Opname gedaan, Schaderapport, Adviesrapport, Besluit, Bezwaar, Uitbetaald, Afgerond, Verloren |
| route | Maatwerk met onderzoek, Herstel met aannemer, Vaste vergoeding, AVV |
| getekend_op, aanvraagdatum, opnamedatum, datum_schaderapport, datum_adviesrapport, verzenddatum_besluitbrief | datumvelden |
| uitkering_img (pas na besluit), fee, factuur_voldaan_op | |
| reden_verlies | |
| fasegeschiedenis | lijst {fase, van, tot, wie}, vervangt Zoho's Fasehistorie |

**Verbetering:** vul je een datum in die bij een latere fase hoort (bijv. opnamedatum), dan stelt het dashboard de fasewissel voor; je bevestigt met één tik. Zo blijven fase en datums met elkaar in lijn.

### Taak (`taak/<id>`)

`{relatie, traject?, titel, deadline, fataal, bron: "regel:<id>" | "handmatig", status: open|klaar, klaar_door, klaar_op}`. Taken uit regels worden opnieuw berekend als de brondatum wijzigt; een afgevinkte taak blijft afgevinkt.

## Termijnregels (één bestand, `dashboard-lib/termijnen.mjs`)

Elke regel: `{id, wanneer: <veld of fase>, titel, dagen of weken, fataal, kennisbankbron}`. **De termijnen zelf vul ik niet in uit eigen kennis**: ze komen uit K1/K2 en worden door Kevin of Ruben bevestigd voordat de module live gaat. Voorlopige lijst, alle termijnen gemarkeerd **TE BEVESTIGEN**:

| Regel | Start | Taak | Fataal |
|---|---|---|---|
| bezwaar | verzenddatum besluitbrief | Bezwaar indienen of besluit accepteren, uiterlijk op dag X | **Ja** |
| reactie-adviesrapport | datum adviesrapport | Reactie op adviesrapport (K1 §2.1 markeert deze termijn als onbevestigd) | Ja |
| terugbellen | terugbeldatum | Terugbellen | Nee |
| opname-voorbereiden | opnamedatum | Opname voorbereiden, dag ervoor | Nee |
| factuur | uitkering IMG ingevuld | Factuur sturen | Nee |
| factuur-controle | factuur verstuurd + X dagen | Betaling controleren | Nee |
| lead-opvolgen | status Poging 1/2 | Volgende poging na X dagen | Nee |

Algemeen bekend is dat een bezwaartermijn tegen een besluit van een bestuursorgaan zes weken is en begint op de dag na verzending (Awb, art. 6:7 en 6:8). Ik zet het pas als regel in na bevestiging uit K1, omdat het IMG-traject eigen afspraken kan hebben.

**Termijnbewaking** (opdracht §6, zwaarst getest):
- Geplande Function (dagelijks): herberekent alle regel-taken en legt een overzicht vast.
- Startscherm: eerst fatale termijnen (rood = minder dan 7 dagen, ook verlopen), dan taken van vandaag en deze week.
- Tests: per regel de datumrekening, inclusief weekend en feestdagen als K1 dat vraagt, en een test dat een verlopen fatale taak nooit verdwijnt.
- Een melding per e-mail of telefoon vraagt een extra dienst (vraag aan Ruben).

## Schermen (mobiel eerst)

1. **Klanten**: zoeken (naam, straat, postcode), filter op status en eigenaar, lijst gesorteerd op eerstvolgende actie.
2. **Relatie**: gegevens, tijdlijn, trajecten, taken. Bellen en WhatsApp met één tik (tel:, wa.me).
3. **Traject**: fase als stappenbalk, datums, termijnen.
4. **Taken**: mijn taken en alle taken, fatale termijnen bovenaan.
5. **Nieuwe lead** en **afspraak aan de deur**: de deur-aan-deur-module maakt hier straks direct een relatie aan, zonder Zoho.

## Wat er met Zoho en de website gebeurt

- **Website v2** (`herbouw-v2`) stuurt leads via de API naar Zoho. Na de proefperiode moet worden gecontroleerd of de API in de gratis editie nog werkt; anders valt de website terug op de noodroute (Netlify Forms). Later gaat `lead-aanmaken` naar het dashboard in plaats van naar Zoho; dat is een wijziging in Kevins code en dus een beslissing voor Kevin en Ruben.
- **Migratie**: in Zoho staan 1 lead, 2 contactpersonen en 2 deals. Overzetten kan met de hand of met een eenmalige import; geen van beide zonder akkoord.
- **Parallel draaien** (opdracht §6.3): zinvol zolang Zoho nog leads krijgt; met de huidige 2 trajecten is een korte vergelijking genoeg.

## AVG

Hier staan wél namen, telefoonnummers en adressen van klanten. Daarom: alleen ingelogd, opslag in Frankfurt, geen persoonsgegevens in logs, export alleen bewust. Bewaartermijn en verwerkersovereenkomst Netlify: besluit Kevin en Ruben. De Functions draaien op een gratis Netlify-account in de VS (zie PLAN.md §8).

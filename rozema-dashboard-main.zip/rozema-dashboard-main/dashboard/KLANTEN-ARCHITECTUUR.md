# Klantenmodule: architectuur (vervangt Zoho CRM)

Stand: 10-11-2026. Opgesteld door de architectuur-expert. Status: **ontwerp, wacht op akkoord van Ruben op de vragen in §7.** Vervangt het concept `ZOHO-NABOUW.md` (dat blijft als achtergrond).

Aanscherpingen t.o.v. het concept:
1. Termijnen worden **afgeleid, niet opgeslagen** als losse taken. Wat niet als record bestaat, kan niet kwijtraken.
2. Een **register** (sterk consistent gelezen) vervangt `list()` voor alles wat de termijnbewaking moet zien.
3. Wijzigingen worden **per veld samengevoegd** met etag; geen "laatste schrijver wint", ook niet na offline werken.
4. Een afgevinkte fatale termijn moet **opnieuw bevestigd** worden als de brondatum daarna wijzigt.

Gecontroleerd: `@netlify/blobs` 10.7.13 ondersteunt `onlyIfNew`, `onlyIfMatch`, `getWithMetadata` (etag) en `consistency: 'strong'`; `list()` heeft géén strong-optie.

## 0. Gevonden in Kevins websitecode (`herbouw-v2`), relevant voor parallel draaien

- In de Zoho-layout van Leads zijn `Phone` en `First_Name` verplicht; v2 vult `Mobile`.
- `Voor_wie` en `Contactvoorkeur` bestaan niet in Zoho.
- Situatie-waarden "Vaste vergoeding gehad" en "Besluit genomen" staan niet in de Zoho-keuzelijst.
- Zoho kan zulke leads weigeren; dan gaan ze via de noodroute (Netlify Forms).

## 1. Datamodel

Eén store `store("klanten")` (→ `dashboard-klanten` of `dashboard-test-klanten`, eu-central-1). Alle opslag via één module `dashboard-lib/klanten/opslag.mjs`, zodat een latere overstap naar een database alleen die module raakt.

| Sleutel | Inhoud | Waarom |
|---|---|---|
| `relatie/<id>` | Huishouden: gegevens, status, kwalificatie, handmatige taken en afspraken (map op id) | Eén blob per record, weinig botsingen |
| `traject/<id>` | IMG-zaak: `relatieId`, fase, route, datums, bedragen, `afgevinkt` per regel, fasegeschiedenis | Termijnbewaking leest alleen trajecten |
| `register/trajecten` | `{ids: {<id>: {relatieId, aangemaakt}}}` | Bron van "welke trajecten bestaan", strong gelezen, niet afhankelijk van `list()` |
| `index/relaties` | Compacte rijen: id, naam, straat+nr, postcode, plaats, status, eigenaar, eerstvolgende taak | Lijst, zoeken, "vandaag" in één leesactie |
| `log/<relatieId>/<iso-tijd>-<wijzigingId>` | Tijdlijnregel: wie, wanneer, soort, record, veld, oud, nieuw | Alleen toevoegen (`onlyIfNew`), historie kan niet verdwijnen |
| `status/dagelijks` | Laatste run geplande Function | Hartslag op het startscherm |
| `ontdubbel/instroom/<hash>` | Hash postcode+huisnummer+telefoon, 24 u | Dubbele websiteaanvragen herkennen zonder gegevens nogmaals op te slaan |

**Ids** maakt de telefoon (`crypto.randomUUID()`, voorvoegsel `r_`/`t_`), zodat offline aanmaken en verwijzen kan. Aanmaken met `onlyIfNew`; herhaling met `modified:false` = "bestaat al", geen fout.

### Relatie

| Veld | Uit Zoho | Opmerking |
|---|---|---|
| aanhef, voornaam, achternaam | Lead/Contact | Achternaam verplicht |
| telefoon, mobiel, email | idem | Bellen/WhatsApp met één tik |
| straat, huisnummer, toevoeging, postcode, plaats, bagId | Lead-adres | `bagId` bij afspraak uit de deur-app |
| bron | Lead_Source | Ingekort tot: Website, Deur, Niet thuis, Instagram, Facebook, Google Ads, Verwijzing, Anders (vraag 9) |
| voorWie, contactvoorkeur | (nieuw) | Uit websiteformulier |
| status | Lead_Status + **Klant** | Klant automatisch bij eerste traject |
| terugbeldatum | Terugbeldatum | Niet-fatale termijn |
| situatie, kwalificatie, redenAfgevallen | idem | Situatie aangevuld met v2-waarden; reden verplicht bij Afgevallen |
| trillingMms, bouwjaar, ruimtesMetSchade, eerderOntvangen, bkoZone | idem | Over te nemen uit deur-app |
| eigenaar | Owner | `kevin`/`ruben` |
| dossier | (nieuw) | Alleen verwijzing (mapnaam), nooit een bestand |
| notitie | Description | Hint: geen gezondheid, geen BSN |
| taken | Tasks/Events | `{id: {soort: taak/afspraak, titel, datum, tijd?, eigenaar, klaar:{wie,op}?}}` |
| herkomst | (nieuw) | `{zoho:{module,id}}` / `{website:{op}}` / `{deur:{eventId}}` |
| aangemaakt, gewijzigd | systeem | `{wie, op}` |
| toegepast | systeem | Laatste 50 `wijzigingId`'s (idempotentie offline-wachtrij) |

Bewust niet nagebouwd: verrijking, campagnes, coördinaten, tweede adres, Accounts, producten, offertes, waarschijnlijkheid per fase, opgeslagen dealnaam (wordt getoond als `<achternaam> - <straat nr>, <plaats>`).

### Traject

`relatieId`, `fase` (Getekend, Aanvraag ingediend, Opname gepland, Opname gedaan, Schaderapport, Adviesrapport, Besluit, Bezwaar, Uitbetaald, Afgerond, Verloren), `route` (Maatwerk met onderzoek, Herstel met aannemer, Vaste vergoeding, AVV), `getekendOp`, `aanvraagdatum`, `opnamedatum`, `datumSchaderapport`, `datumAdviesrapport`, `verzenddatumBesluitbrief`, `uitkeringImg`, `fee`, `factuurVerstuurdOp`, `factuurVoldaanOp`, `redenVerlies`, `machtigingGetekendOp` (alleen datum), `afgevinkt`, `fasegeschiedenis [{fase, van, wie}]`, `aangemaakt`, `gewijzigd`, `toegepast`.

**Fase en datum:** een fase vanaf "Besluit" kan niet worden opgeslagen zonder `verzenddatumBesluitbrief`, tenzij expliciet "verzenddatum nog onbekend" (geeft een fataal signaal). Een datum van een latere fase invullen stelt de fasewissel voor (één tik).

### Gelijktijdigheid: samenvoegen per veld

- Client stuurt `{wijzigingId, velden: {<veld>: {oud, nieuw}}}`; taken als `taken.<id>.<veld>`.
- Server: `getWithMetadata` (strong) → per veld toepassen als huidige waarde = `oud` of al `nieuw`, anders **conflict voor dat veld** → `setJSON(..., {onlyIfMatch: etag})`, bij `modified:false` max. 3× opnieuw → per toegepast veld een logregel (`onlyIfNew`).
- Conflict gaat terug naar de telefoon ("Ruben heeft dit veld intussen op X gezet. Wat wil je houden?"). Nooit stil overschrijven.
- `wijzigingId` al in `toegepast` → 200 zonder actie.
- `index/relaties` en `register/trajecten` met `onlyIfMatch` + herhaling; achterstand herstelt bij volgende schrijfactie of dagelijkse run.
- Nieuw traject: eerst register, dan record. Registeritem > 10 min zonder record → "onvolledig traject" op het startscherm.

### Tijdlijn

`list({prefix: "log/<id>/"})`, ook logregels van trajecten onder het relatie-id. Mag enkele seconden achterlopen. Bevat persoonsgegevens: alleen in de store, nooit in `console.log`; gaat mee bij AVG-verwijdering.

## 2. Termijnengine

### Regelvorm (`dashboard-lib/klanten/termijnregels.mjs`, in git)

```js
{ id: "bezwaar",
  titel: "Bezwaar indienen of besluit accepteren",
  start: { record: "traject", veld: "verzenddatumBesluitbrief" },
  duur: { aantal: null, eenheid: "weken" },   // null = NIET BEVESTIGD
  telling: "dag-na-start",                     // of "zelfde-dag"; uit K1
  weekendFeestdag: null,                       // "doorschuiven" | "niet"; uit K1
  geldtVoor: { routes: null, fases: ["Besluit", "Bezwaar"] },
  vereistVanafFase: "Besluit",
  fataal: true,
  afvinkActies: ["Bezwaar ingediend", "Besluit geaccepteerd"],
  bron: "K1 §…", bevestigd: null }             // {door, op, bron}
```

- **Geen enkele duur wordt door een bouwer ingevuld.** Alle regels krijgen `aantal: null`, `bevestigd: null`. Kevin of Ruben vult ze in uit K1 (taak K0); live pas met groene tests.
- Regels zoals in Zoho (zie `zoho-export/README.md`): leads: nieuwe lead bellen, belpoging 2 na poging 1, belpoging 3 na poging 2, WhatsApp na poging 3, afsluiten na WhatsApp, terugbellen (vangnet terugbeldatum); trajecten: opname voorbereiden, zienswijze na adviesrapport, termijnen na besluitbrief (bezwaar; de overige twee acties van die Zoho-regel nog onbekend), factuur na uitbetaling, factuurcontrole.
- `FEESTDAGEN`-lijst in hetzelfde bestand, leeg tot K1 het zegt.
- Regels in code, niet in een blob: een fatale regel verandert niet stil via een scherm. Alleen-lezen scherm "Termijnregels".

### Berekening (pure functies, `termijnen.mjs`)

`termijnenVoor(traject, relatie, regels, vandaag)` → per regel:

| Status | Wanneer |
|---|---|
| `open` | met `einddatum`, `dagenOver` (negatief = verlopen) |
| `afgevinkt` | brondatum gelijk aan die bij afvinken |
| `herbevestigen` | afgevinkt bij een andere brondatum |
| `datum-ontbreekt` | fase ≥ `vereistVanafFase`, brondatum leeg |
| `niet-bevestigd` | regel van toepassing, `aantal` of `bevestigd` ontbreekt; **nooit** een datum berekenen |
| `nvt` | regel geldt niet |

- Datums als `YYYY-MM-DD`; "vandaag" via `Intl.DateTimeFormat('nl-NL', {timeZone:'Europe/Amsterdam'})` (Functions draaien in de VS); rekenen op UTC-middag zodat zomer/wintertijd geen dag verschuift.
- Herberekening bij elke lezing; gewijzigde brondatum schuift vanzelf mee.
- Brondatum verwijderd: vóór `vereistVanafFase` → `nvt`; vanaf die fase → `datum-ontbreekt` (fataal signaal).
- Afvinken per regel: `afgevinkt[regelId] = {actie, brondatum, wie, op}`; bij fataal is een actie uit `afvinkActies` verplicht. Heropenen kan (tijdlijn). Verwijderen van een fatale termijn bestaat niet. Traject naar Afgerond/Verloren met open fatale termijn → eerst afvinken.

### "Nooit uit beeld"

1. Afgeleid uit brondata: geen taakrecord dat kan ontbreken of dubbel staan.
2. `GET /klanten/start` rekent live: register (strong) → alle trajecten (strong, parallel in groepen van 20) → engine. Geen cache voor het fatale blok.
3. Fatale blok is ongefilterd (zoeken/eigenaar/status hebben geen invloed); in elk klantenscherm een balk "N fatale termijnen, eerstvolgende over X dagen".
4. Signalen (`herbevestigen`, `datum-ontbreekt`, `niet-bevestigd`, onvolledig traject, "kon niet berekenen") staan in hetzelfde blok.
5. Verlopen blijft staan tot afvinken, ook bij Afgerond/Verloren.
6. Geplande Function `dashboard-klanten-dagelijks` (`0 3 * * *` UTC, dus 04:00 Amsterdamse wintertijd en 05:00 zomertijd): vergelijkt `list("traject/")` met register, herbouwt index, schrijft hartslag. Startscherm rood als laatste run > 26 uur. Geplande Functions draaien alleen op de productiedeploy (testsite: branch `dashboard`).
7. Offline: laatst opgehaalde fatale blok met "stand van <tijd>"; ouder dan 24 uur → rode melding.
8. Signaal buiten het dashboard (vraag 5): privé agenda-feed `.ics`, geen extra dienst.

### Testgevallen (`node --test`, fictieve aantallen in de test, nooit de echte)

| # | Geval | Verwacht |
|---|---|---|
| T1 | Brondatum + regel (3 weken, dag-na) | juiste einddatum, `dagenOver` |
| T2 | Brondatum gewijzigd, niet afgevinkt | einddatum schuift mee |
| T3 | Afgevinkt, daarna brondatum gewijzigd | `herbevestigen`, in fatale blok |
| T4 | Brondatum leeg bij fase Besluit | `datum-ontbreekt`, fataal |
| T5 | Fase Bezwaar zonder datum via API | 422, tenzij "verzenddatum onbekend" (dan T4) |
| T6 | Regel met `aantal: null` | `niet-bevestigd`, geen einddatum |
| T7 | 200 dagen verlopen, traject Afgerond, niet afgevinkt | nog in het blok, `dagenOver = -200` |
| T8 | `start` met filter eigenaar=ruben en zoekterm | fatale termijn van Kevin blijft zichtbaar |
| T9 | Traject in register, nep-`list()` laat het weg | toch op startscherm |
| T10 | Twee gelijktijdige PATCHes, verschillende velden | beide toegepast, 2 logregels |
| T11 | Twee PATCHes, zelfde veld, zelfde `oud` | één toegepast, één conflict |
| T12 | Zelfde `wijzigingId` twee keer | tweede no-op, één logregel |
| T13 | "Vandaag" om 23:30 UTC, zomer en winter | datum volgens Europe/Amsterdam |
| T14 | Einde op zaterdag, `doorschuiven`/`niet` | maandag / zaterdag |
| T15 | Status Afgerond met open fatale termijn | 409 met de termijn |
| T16 | Hartslag 27 uur oud | waarschuwing gezet |
| T17 | Fatale termijn afvinken zonder actie | 422 |
| T18 | Engine gooit fout voor één traject | "kon niet berekenen: <traject>" in het blok, niet overgeslagen |

## 3. API en Functions

| Function | Pad | Toegang |
|---|---|---|
| `dashboard-klanten.mjs` | `/api/dashboard/klanten/*` | sessiecookie |
| `dashboard-klanten-dagelijks.mjs` | gepland | — |
| `dashboard-instroom.mjs` | `/api/dashboard/instroom` | alleen bij optie B (§4), header met `DASHBOARD_INSTROOM_SLEUTEL` |
| later `dashboard-agenda.mjs` | `/api/dashboard/agenda/<token>.ics` | intrekbaar token (vraag 5) |

Gedeelde code `netlify/functions/dashboard-lib/klanten/`: `model.mjs` (velden, keuzelijsten, validatie), `datum.mjs`, `termijnregels.mjs`, `termijnen.mjs`, `opslag.mjs` (etag, samenvoegen, register, index, log), `instroom.mjs`.

| Route (`/api/dashboard/klanten`) | Doet |
|---|---|
| `GET /start` | fatale termijnen en signalen (live), vandaag/deze week, gezondheid |
| `GET /relaties?q=&status=&eigenaar=` | uit index |
| `POST /relaties` | aanmaken `{id, wijzigingId, velden}`, idempotent |
| `GET /relaties/:id` | relatie, trajecten, termijnen, etag |
| `PATCH /relaties/:id` | samenvoegen per veld → `{toegepast, conflicten, record}` |
| `GET /relaties/:id/tijdlijn` | logregels, nieuwste eerst |
| `POST /relaties/:id/trajecten` | nieuw traject (register eerst), status → Klant |
| `PATCH /trajecten/:id` | idem + controle fase/datum |
| `POST /trajecten/:id/termijnen/:regel/afvinken` | `{actie, wijzigingId}` |
| `POST /trajecten/:id/termijnen/:regel/heropenen` | |
| `GET /regels` | regels met bevestigingsstatus |
| `GET /straten?plaats=` | voor de deur-app: per straat klant ja/nee, zonder namen |
| `GET /export` | JSON/CSV, gelogd |
| `POST /import` | eenmalig, alleen bij `DASHBOARD_IMPORT=aan` |
| `POST /relaties/:id/verwijderen` | AVG: relatie, trajecten, log (later) |

Fouten: 401, 404, 409 (conflict, gesloten met open termijn), 422 (validatie).

## 4. Schermen en flows (mobiel eerst, lijsten, grote tikvlakken)

1. **Klanten-start:** fatale blok (achternaam + plaats, wat moet er gebeuren, "nog 5 dagen"/"3 dagen verlopen" in woorden), dan vandaag en deze week, dan "Nieuwe klant".
2. **Zoeken en lijst:** naam, straat, postcode; filters status en eigenaar; gesorteerd op eerstvolgende actie.
3. **Relatie:** bellen, WhatsApp, navigeren; gegevens per veld bewerkbaar; trajecten, taken, tijdlijn.
4. **Traject:** fase als verticale stappenlijst; datums met termijn ernaast; afvinken met actiekeuze.
5. **Conflictscherm:** "mijn waarde" of "die van Ruben/Kevin".
6. **Termijnregels:** alleen lezen, "niet bevestigd" opvallend.

**Offline:** dezelfde IndexedDB-wachtrij als de deur-app; nooit weggooien bij 401/429/5xx; elk item een `wijzigingId`; cache (index, fatale blok, laatst geopende relaties) gewist bij uitloggen (vraag 6).

**Deur-aan-deur → relatie:** bij "afspraak" opent een kort formulier (naam, telefoon, datum/tijd) → `POST /klanten/relaties` met id van de telefoon, bron Deur, status Afspraak gepland, adres + `bagId`, bouwjaar en trilling, en een afspraak-taak. Het deur-event krijgt alleen `relatieId`. "Klant in de straat" via `GET /straten`. Hiermee vervalt de Zoho-vraag (a/b) uit PLAN.

**Website-instroom** (voorstel; Kevins code, zijn akkoord):
- **A** (na samenvoegen op één site, aanbevolen): `lead-aanmaken` importeert `dashboard-lib/klanten/instroom.mjs` en schrijft direct in de store; volgorde dashboard → Zoho (zolang dat werkt) → noodroute. `maakCode(relatieId)` blijft werken; `lead-bijwerken` zet Situatie. Mapping uit `zoho-velden.mjs` naar `model.mjs`.
- **B** (zolang de testsite een andere site is): POST naar `/api/dashboard/instroom` met sleutel in header.
- Ontdubbelen: zelfde hash binnen 24 uur → "mogelijk dubbel" in tijdlijn, niet samenvoegen.

## 5. Migratie en parallel draaien

- Leads worden niet overgezet (besluit Ruben, 10-11-2026). Over: 2 contacten met hun deals (fase "Aanvraag ingediend"), **met de hand** via de nieuwe schermen; dat is meteen de acceptatietest. `herkomst.zoho` krijgt de Zoho-ids. Machtigingsformulier en overeenkomst niet; alleen `machtigingGetekendOp` en `dossier`.
- Controle: Ruben legt de Zoho-gegevens naast het relatiescherm, veld voor veld.
- Parallel: zolang de website naar Zoho schrijft, wekelijks Zoho en de noodroute controleren; einde als `lead-aanmaken` naar het dashboard schrijft en twee weken niets meer in Zoho binnenkomt.
- `POST /import` blijft voor de verhuizing testsite → Kevins site (PLAN §8b), met telling vooraf en achteraf.

## 6. Bouwvolgorde

| # | Taak | Klaar als | Testen |
|---|---|---|---|
| K1 | `model.mjs` | alle Zoho-velden uit §1 gedekt of bewust weggelaten | unit: geldig/ongeldig, Afgevallen zonder reden, fase zonder datum |
| K2 | `datum.mjs`, `termijnen.mjs`, `termijnregels.mjs` (alle aantallen `null`) | T1–T7, T13, T14, T17 groen; geen getal ingevuld | `node --test` |
| K3 | `klanten/opslag.mjs` + nep-store met etag | samenvoegen, idempotentie, register eerst, log, index | T9–T12, gesimuleerde race |
| K4 | `dashboard-klanten.mjs` CRUD + afvinken | alle routes behalve straten/export/import/verwijderen; 401 zonder cookie | T5, T8, T15 |
| K5 | `GET /start` + dagelijkse Function + hartslag | fatale blok live, signalen, gezondheid | T9, T16, T18; één run op testsite |
| K6 | Frontend start en lijst | fatale blok + balk, zoeken, filters, 360 px | telefoon, filterscenario |
| K7 | Frontend relatie, traject, tijdlijn, conflict, offline-wachtrij | bewerken per veld, afvinken, conflictkeuze, wachtrij overleeft 401 en vliegtuigmodus | twee telefoons offline |
| K8 | Migratie met de hand + `POST /import` | 2 relaties met trajecten ingevoerd en vergeleken | telling |
| K9 | `instroom.mjs` + voorstel-diff `lead-aanmaken`/`lead-bijwerken` (PR naar Kevin) | aanvraag wordt relatie, ontdubbelen werkt | unit, deploy preview teststore |
| K10 | Koppeling deur-app | afspraak offline aangemaakt, na sync gekoppeld, geen namen in events | vliegtuigmodus |
| K11 | Export, AVG-verwijderen, agenda-feed (na vraag 5) | export gelogd, verwijderen volledig | unit + telling |
| K0 | **Ruben/Kevin:** regels invullen uit K1 en bevestigen | geen `niet-bevestigd` bij bezwaar en adviesrapport | test per bevestigd getal |

Live pas na K0 voor bezwaar en reactie-adviesrapport; tot dan testsite met teststore.

## 7. Open beslissingen voor Ruben

1. **Blobs of database:** voorstel Blobs (tientallen tot enkele honderden trajecten per jaar). Overstap naar Netlify DB pas bij > 500 trajecten, `GET /start` vaak > 3 s, of behoefte aan rapportages. Akkoord?
2. **Termijnen uit K1:** wie vult ze in; per regel duur, start (dag na verzending?), weekend/feestdagen; bestaat er een termijn voor reactie op het adviesrapport?
3. **Regels in code (commit + review) of zelf aanpasbaar in een scherm?** Voorstel: code.
4. **Verzenddatum of ontvangstdatum** van de besluitbrief, of beide?
5. **Signaal buiten het dashboard:** agenda-feed `.ics` (klantnaam komt dan in je agenda, of alleen een trajectcode), e-mail (extra dienst), of geen?
6. **Klantgegevens offline op de telefoon** (laatst geopende relaties, gewist bij uitloggen)?
7. **Website-instroom:** optie A of B, en wanneer leggen jullie dit aan Kevin voor?
8. **"Verloren (vervallen)"**: voorstel een reden onder Verloren, geen aparte fase.
9. **Bronlijst inkorten** tot de waarden in §1?
10. **AVG:** bewaartermijn afgevallen leads en afgeronde trajecten, verwerkersovereenkomst Netlify, verwerking in de VS. Zwaarder dan bij de deur-app: hier staan namen en telefoonnummers.
11. **Risico:** geplande Functions draaien niet op branch deploys; de hartslag maakt dat zichtbaar.
12. **Risico:** een fout in de engine verbergt nooit stil een termijn (T18).

---

## Aanvulling: de Zoho-regels precies nagebouwd (architectuur-expert, 10-11-2026)

Vervangt in §2 de regelvorm en regellijst, §5 en de genoemde regels in §6/§7.

**Datamodel:** `relatie.statusgeschiedenis: [{status, van, wie}]` (vervangt Zoho's Lead_Status_Modified_Time), bij elke statuswissel in dezelfde schrijfactie bijgewerkt. `traject.fasegeschiedenis[].van` is startdatum voor faseregels; `relatie.aangemaakt.op` voor "nieuwe lead bellen".

**Regelvorm** (extra velden): `zoho` (naam in Zoho), `record` (relatie/traject), `start: {soort: aangemaakt|status|fase|veld, waarde}`, `geldtZolang: {status|fase: [...]}`, `vervolgActie`, `actief` (aan/uit zoals Zoho). Onbekend is veilig: `duur.aantal === null` → `niet-bevestigd`; `fataal === null` → behandeld als fataal; `titel === null` → "Actie uit Zoho-regel '<zoho>', inhoud nog onbekend".

**Zelfsluitend:** een regel met `geldtZolang` geldt alleen zolang de status/fase klopt (Poging 1 → Poging 2: "Belpoging 2" verdwijnt, "Belpoging 3" verschijnt). Niet voor fatale regels: die blijven tot afgevinkt.

**Catalogus** (alle duur/telling/weekend `null`):

| id | Zoho-naam | Start | Geldt zolang | Titel | Fataal | Actief |
|---|---|---|---|---|---|---|
| lead-bellen | Lead: nieuwe lead bellen | aangemaakt | status Nieuw | Nieuwe lead bellen | nee | aan |
| lead-poging-2 | Lead: belpoging 2 na Poging 1 | status Poging 1 | status Poging 1 | Belpoging 2 | nee | aan |
| lead-poging-3 | Lead: belpoging 3 na Poging 2 | status Poging 2 | status Poging 2 | Belpoging 3 | nee | aan |
| lead-whatsapp | Lead: WhatsApp na Poging 3 | status Poging 3 | status Poging 3 | WhatsApp sturen | nee | aan |
| lead-afsluiten | Lead: afsluiten na WhatsApp | status WhatsApp verstuurd | idem | Lead afsluiten | nee | aan |
| lead-terugbeldatum | Lead: vangnet terugbeldatum | veld terugbeldatum | niet Afgevallen/Klant | Terugbellen | nee | uit (vraag 13) |
| deal-opname | Deal: opname voorbereiden | veld opnamedatum | fase Opname gepland | Opname voorbereiden | nee | aan |
| deal-zienswijze | Deal: zienswijze na adviesrapport | veld datumAdviesrapport | fase Adviesrapport | Zienswijze op adviesrapport | null (= fataal) | aan |
| deal-besluit-1/2/3 | Deal: termijnen na besluitbrief (3 acties) | veld verzenddatumBesluitbrief | — (fataal tot afgevinkt) | null | null | aan |
| deal-factuur | Deal: factuur na uitbetaling | fase Uitbetaald | fase Uitbetaald | Factuur sturen | nee | aan |

Niet in de catalogus (als commentaar met reden): "dealnaam uit contact" (wordt weergavenaam), "Big Deal Rule" (Zoho-voorbeeld, uit), de vier kwalificatieregels (0 acties, uit; vraag 14). Zodra de inhoud van "termijnen na besluitbrief" bekend is, krijgt elke actie een definitief id (bijv. `deal-bezwaar`); een nieuw id betekent opnieuw bevestigen.

**Leadketen:** Nieuw → Poging 1 → 2 → 3 → WhatsApp verstuurd → afsluiten; hoogstens één ketentaak per lead. Vervolgknoppen (grote tikvlakken) doen een statuswissel; de engine wijzigt zelf nooit een status. "Afsluiten" = Afgevallen met reden "Niet bereikt". Keten stopt bij elke status buiten de keten.

**Extra tests:** T19 catalogus = Zoho-lijst uit `zoho-export/README.md`; T20 geen getal zonder bevestiging; T21 precies één ketentaak per stap; T22 terugzetten Poging 2 → 1; T23 Contact gehad stopt keten; T24 Afsluiten zet Afgevallen + reden, één logregel; T25 deal-besluit-1..3 bij fase Besluit zonder datum → drie fatale signalen; T26 één afgevinkt, andere twee blijven; T27 `actief: false` → nvt.

**§5 Migratie (vervangt):** leads niet overzetten. Twee contacten met deals met de hand: relatie status Klant (statusgeschiedenis start met Klant, zodat geen leadketen afgaat) + traject fase "Aanvraag ingediend", `herkomst.zoho` met Zoho-ids. `POST /import` alleen nog voor verhuizing testsite → Kevins site.

**§6:** K1 + statusgeschiedenis; K2 + starttypen, `geldtZolang`, `actief`, `vervolgActie`, fataal-null, catalogus, tests T19–T27; K6 vervolgknoppen; K8 alleen twee contacten/deals; K0 per catalogusregel invullen en bevestigen.

**Extra vragen:** 13. Vangnet terugbeldatum aanzetten (voorstel: aan)? 14. Wat deden de vier kwalificatieregels? 15. Vaste WhatsApp-tekst na poging 3, en wie levert die? 16. Lukt een schermafdruk van de inhoud van "termijnen na besluitbrief" vóór 01:00?

# Dashboard testen

Eenheids- en handlertests voor de backend (zonder extra pakketten, met een in-memory store uit `test-hulp.mjs`):

```
node --test "netlify/functions/dashboard-lib/**/*.test.mjs"
```

De aanhalingstekens zijn nodig: Node 22 leest een mapnaam zonder patroon als bestand.

Zet nooit een index.mjs in dashboard-lib/ en nooit tests direct in netlify/functions/ (die worden dan een Function).
De tests van de handlers `dashboard-klanten`, `-dagelijks`, `-export` en `-straten` staan daarom in
`netlify/functions/dashboard-lib/klanten/handlers/` en worden door hetzelfde commando opgepikt. Controle:
`ls netlify/functions/*.mjs` toont alleen echte Functions (met een default export).

Losse scripts: `node --test scripts/*.test.mjs`.

## Echte of teststore (witte lijst)

`store(naam)` gebruikt alleen de echte store `dashboard-<naam>` als beide waar zijn:

1. `DASHBOARD_ECHTE_DATA` is precies `aan`, en
2. de deploy-context van de Function is `production` (`context.deploy.context`, of anders het globale `Netlify.context.deploy.context`).

Bij een andere context (deploy-preview, branch-deploy, dev) wordt `dashboard-test-<naam>` gebruikt. Staat `DASHBOARD_ECHTE_DATA` op `aan` maar ontbreekt de context helemaal, dan is er geen stille teststore: de Function geeft een 500 met een algemene melding en logt alleen de contextwaarde. Elke handler roept daarvoor `zetContext(context)` aan het begin aan. Op de testsite is de branch `dashboard` de productiebranch, dus daar klopt dit. Op Kevins hoofdsite gebruikt een branch-deploy van `dashboard` altijd de teststore; pas na samenvoegen in productie is het echt. De tests dekken dit in `opslag.test.mjs`.

## Wachtwoordhash

Lokaal draaien, het wachtwoord (minstens 12 tekens) wordt met verborgen invoer gevraagd en staat nooit in argv:

```
node scripts/dashboard-wachtwoord.mjs
```

## Build

`npm run build`, daarna moet `dist/dashboard/index.html` bestaan.

## Deur-aan-deur

Tests staan in `netlify/functions/dashboard-lib/deur/` (niet in `netlify/functions/` zelf, dat zou een Function worden):
`logica.test.mjs` (rekenwerk), `deur.test.mjs` (de echte handler met in-memory store). De rekenlogica staat in
`public/dashboard/deur/logica.js` en wordt door browser, backend en tests gedeeld.

Rondje door de klantenschermen (K6 tot en met K11, inclusief `beheer.html`: laden, export en verwijderen met 410 op een tweede tab; na `npm run build`):

```
node scripts/dashboard-klanten-rondje.mjs
```

Rondje door pijplijn, overzicht en contactmoment (360 en 1280 px, filters, geen namen in het overzicht, contact offline
vastleggen zonder dubbele regel; na `npm run build`, `SCHERMAFDRUK=<map>` bewaart schermafdrukken):

```
node scripts/dashboard-overzicht-rondje.mjs
```

Rondje door de hele module met Chromium (na `npm run build`; `NEP=1` gebruikt nagebootste PDOK-antwoorden,
zonder `NEP` wordt echt PDOK bevraagd, standaard Winsum, `PLAATS=<naam>` voor een andere plaats):

```
NEP=1 node scripts/dashboard-deur-rondje.mjs
```

Oude plaatsdata (van vóór de versie-opzet, zonder `versie` in de meta onder `plaatsen/<id>`) wordt niet gemigreerd:
de plaats toont geen buurten en de API meldt `opnieuwOphalen: true`. Oplossing: de plaats opnieuw ophalen
bij Plannen (de bezoeken blijven bewaard). Er staat nog geen echte data in; dit geldt alleen voor testdata.

# Review van de bestaande deur-aan-deur-code

Onafhankelijke review (fase 1, 10-11-2026) van de code uit de opdracht: `deur-api.mjs`, `verwerk.js`, `app.js`, `index.html`, `app.css`, `sw.js`, `manifest.webmanifest`. Alles wordt in fase 2 meegenomen bij het ombouwen naar de dashboardmodule. XSS: niets gevonden (de enige `innerHTML` gebruikt `esc()`).

Daarnaast, live vastgesteld tegen PDOK: de pand-koppeling werkt niet (`pand.href` met uuid in plaats van een 16-cijferig nummer). Zie PLAN.md, onder Bronnen.

## Hoog

| # | Waar | Wat gaat er mis | Oplossing |
|---|---|---|---|
| 1 | `controleerToken` | Ontbreekt het sessiegeheim (bijv. in een deploy preview), dan kan iedereen een geldige sessie maken met een lege sleutel | Weigeren als het geheim ontbreekt of te kort is |
| 2 | `leegWachtrij` | Bij een verlopen sessie, 429 of 5xx wordt het bezoek uit de offline-wachtrij **weggegooid**; na een 401 gaat zo de hele wachtrij van de dag verloren | Alleen bij echte invoerfouten weggooien; 401/408/429/5xx is tijdelijk, later opnieuw |
| 3 | `eventKey`, `leesStand` | Sleutel wordt vóór het schrijven gemaakt en `list()` is niet strikt consistent: een bezoek kan blijvend ontbreken op de andere telefoon | Overlap bij het ophalen (bijv. 2 minuten terug) en ontdubbelen op id |
| 4 | `opslag.set` | Adrescache en stand vullen `localStorage` (~5 MB); daarna mislukt het bewaren van de wachtrij **stil** | Cache en stand in IndexedDB, wachtrij apart, zichtbare waarschuwing als bewaren mislukt |

## Middel

| # | Waar | Wat gaat er mis | Oplossing |
|---|---|---|---|
| 5 | `POST bezoeken`, `pasToe` | Opnieuw versturen na verloren antwoord geeft dubbele bezoeken; dubbel "ongedaan maken" verwijdert een echt bezoek | Id in de sleutel, schrijven alleen-als-nieuw, ontdubbelen op id |
| 6 | `sw.js` `isApp` | Vergelijking is altijd waar: kaarttegels en externe bestanden worden allemaal gecachet; opslag loopt vol en de browser kan alle sitegegevens wissen | Alleen eigen bestanden uit een vaste lijst cachen, alleen goede antwoorden |
| 7 | Inloggen | Blokkade per naam is te omzeilen met gelijktijdige pogingen én te misbruiken om Kevin of Ruben buiten te sluiten; namen zijn te raden via de reactietijd | Vertraging per IP en naam, altijd een hash uitrekenen, alleen bestaande namen bijhouden |
| 8 | Sessie | 30 dagen in `localStorage`, niet in te trekken, verwijderde gebruiker blijft binnen | HttpOnly-cookie, sessieversie om in te trekken, gebruiker bij elk verzoek controleren |
| 9 | `leesStand` | Elke peiling leest alle bezoeken ooit; na een uur offline kan het ophalen de tijdslimiet van 10 s overschrijden en blijft het mislukken | Archiveren na samenvatting, parallel ophalen, samenvatting eerder schrijven |
| 10 | `effectief`, `pasToe` | Telefoon en server ordenen anders (telefoonklok vs. serversleutel); ongedaan maken kan het bezoek van de ander raken | Ongedaan maken verwijst naar het id; één ordening; telefoontijd begrenzen |
| 11 | `api()` | `fetch` zonder tijdslimiet: bij slecht bereik blijft de wachtrij hangen tot herladen | Tijdslimiet 15 s, behandelen als netwerkfout |
| 12 | Zoho-wachtlijst, uitloggen | Naam en telefoon blijven onbeperkt op de telefoon; uitloggen wist niets | Vervaltijd op die lijst; bij uitloggen alles wissen behalve de wachtrij |
| 13 | Router `catch` | Interne foutmeldingen gaan naar de gebruiker | Algemene melding, details alleen in de serverlog (zonder persoonsgegevens) |
| 14 | Plaats opslaan/laden | Hele adreslijst in één verzoek; grote plaats loopt tegen de grens van 6 MB | In delen per buurt opslaan en laden |

## Laag

| # | Waar | Wat | Oplossing |
|---|---|---|---|
| 15 | Trilling invullen | Het veld wordt elke 30 s leeggemaakt door de peiling | Velden met focus niet opnieuw tekenen |
| 16 | `synchroniseer` | Wisselen van plaats tijdens een peiling mengt de standen | Antwoord negeren als de plaats intussen is gewisseld |
| 17 | Buurten, trilling | Wijzigingen bereiken de andere telefoon pas na herladen; gelijktijdige wijzigingen overschrijven elkaar | Meenemen in de peiling, per stuk opslaan |
| 18 | `csv` | Cel die met `=`, `+`, `-` of `@` begint wordt in Excel als formule uitgevoerd | Apostrof ervoor |
| 19 | Proxy | Redirects en poort niet beperkt | Vervalt: proxy gaat eruit |
| 20 | Zoho | Elk keer een nieuw token; verloren antwoord geeft dubbele lead | Token bewaren; idempotentie |
| 21 | Handmatig adres | Lange straatnaam kapt het huisnummer af: twee adressen delen hun bezoeken | Eerst straatnaam inkorten, dan nummer toevoegen |
| 22 | `sw.js` | Mislukte installatie wordt verborgen; foutantwoorden worden gecachet | Per bestand toevoegen, alleen goede antwoorden |

## Huisstijl en repo-regels

- Middenpuntjes `·` in de schermtekst (`app.js`, o.a. uitlogknop, statusregel, buurtkaart, stratenlijst, adresregel, logs): mag niet volgens ontwerp.md, Wat niet mag. Vervangen door komma's of aparte regels.
- Hoofdletters als stijl: geen `text-transform: uppercase`. De letters A, G, N, X, H, S zijn functionele kaartlabels.
- `index.html` laadt Google Fonts en Leaflet van unpkg. Dat wordt: lettertype en Leaflet zelf gehost in `public/dashboard/`, plus een Content-Security-Policy.

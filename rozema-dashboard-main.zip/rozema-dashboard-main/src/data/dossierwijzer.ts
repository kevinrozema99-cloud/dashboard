/* De inhoud van de Dossierwijzer.

   Opzet: per situatie kort waar iemand staat, de feiten die in díé situatie bepalen wat
   er in het rapport komt, en daarna wat wij op afstand niet kunnen zien. Dat laatste blok
   is de kern. Het zijn vragen die alleen aan de keukentafel te beantwoorden zijn, aan het
   dossier en aan de woning zelf.

   Alle feiten komen uit K1 v2.1 (11 september 2026); de vindplaats staat per blok in een
   commentaar. Niets hier doet een uitspraak over de uitkomst van een zaak. */

export interface Vraag {
  id: string;
  kop: string;
  toelichting?: string;
  type?: 'keuze' | 'datum';
  opties?: { waarde: string; label: string }[];
}

export const vragen: Vraag[] = [
  {
    id: 'eigendom',
    kop: 'Bent u eigenaar van de woning?',
    toelichting: 'Wij begeleiden woningeigenaren. Bij een huurwoning ligt het anders.',
    opties: [
      { waarde: 'eigenaar', label: 'Ja, ik ben eigenaar' },
      { waarde: 'huurder', label: 'Nee, ik huur de woning' },
    ],
  },
  {
    id: 'situatie',
    kop: 'Wat is er tot nu toe gebeurd op dit adres?',
    toelichting: 'Woont u hier nog niet zo lang? Kies dan wat u van het adres zelf weet.',
    opties: [
      { waarde: 'A', label: 'Er is nog nooit schade gemeld' },
      { waarde: 'B', label: 'Er is eerder schade gemeld, maar er loopt nu niets' },
      { waarde: 'loopt', label: 'Er loopt op dit moment een melding' },
      { waarde: 'F', label: 'Er is ooit een vaste vergoeding aangenomen' },
      { waarde: 'onbekend', label: 'Ik weet het niet' },
    ],
  },
  {
    id: 'voortgang',
    kop: 'Hoe ver is die melding?',
    opties: [
      { waarde: 'C', label: 'De schade-opname is nog niet geweest' },
      { waarde: 'C2', label: 'De opname is geweest, ik wacht op het adviesrapport' },
      { waarde: 'D', label: 'Ik heb het adviesrapport, nog geen besluit' },
      { waarde: 'E', label: 'Ik heb een besluit van het IMG ontvangen' },
    ],
  },
  {
    id: 'besluitdatum',
    kop: 'Wanneer is de besluitbrief verstuurd?',
    // K1 §12: de termijn loopt vanaf de verzenddatum, niet vanaf de ontvangst.
    toelichting:
      'De bezwaartermijn loopt vanaf de verzenddatum van de brief, niet vanaf de dag dat u hem las. Die datum staat bovenaan het besluit.',
    type: 'datum',
  },
];

export interface Blok {
  kop: string;
  tekst: string;
}

export interface Uitkomst {
  id: string;
  positie: string;
  kop: string;
  staat: string;
  /* De feiten die in deze situatie bepalen wat er in het rapport komt. */
  betekent: Blok[];
  /* De open vragen. Adresgebonden, geen ervan is online te beantwoorden. */
  nietZichtbaar: string[];
  /* Eén ding dat de lezer zonder ons verder helpt. */
  zelf?: Blok;
  toonCta: boolean;
}

export const uitkomsten: Uitkomst[] = [
  {
    id: 'huurder',
    positie: 'Huurwoning',
    kop: 'Voor schade aan het gebouw is uw verhuurder de aanvrager',
    staat:
      'Een aanvraag voor schade aan de woning doet de eigenaar van het gebouw. Bij een huurwoning is dat uw verhuurder. Wij begeleiden alleen woningeigenaren, dus voor u kunnen wij niets betekenen.',
    betekent: [
      {
        kop: 'Wat u wel kunt doen',
        tekst:
          'Meld de schade bij uw verhuurder en vraag of die een melding indient bij het IMG. Woont u bij een corporatie, dan hebben zij daar meestal vaste afspraken over.',
      },
      {
        kop: 'Regelingen die per persoon werken',
        // K1 §14.2 (immateriële schade per persoon) en §11 (rechtsbijstand alleen eigenaren).
        tekst:
          'Het IMG kent ook regelingen die aan een persoon toekomen in plaats van aan een gebouw, zoals de vergoeding voor immateriële schade. Wij begeleiden die niet. Vraag uw mogelijkheden na bij het IMG, via schadedoormijnbouw.nl of 0800 4444 111.',
      },
    ],
    nietZichtbaar: [],
    toonCta: false,
  },

  {
    id: 'A',
    positie: 'Nog geen schade gemeld',
    kop: 'Wat de opnemer die dag vastlegt, bepaalt waarover het IMG beslist',
    staat:
      'Op dit adres is nog geen schade bij het IMG gemeld. Kiest u voor maatwerk met onderzoek, dan komt er eerst een opname en beoordeelt daarna een onafhankelijke deskundige per schade de oorzaak en de omvang.',
    betekent: [
      {
        kop: 'Vastleggen en beoordelen zijn twee rollen',
        // K1 §4.1
        tekst:
          'De opnemer maakt foto’s, beschrijft de schade en meet op. Over de oorzaak zegt hij niets; dat doet de deskundige later, op basis van wat er is vastgelegd. Wat op de dag van de opname buiten het dossier blijft, komt bij de deskundige nooit op tafel.',
      },
      {
        kop: 'De opname heeft grenzen',
        // K1 §4.4
        tekst:
          'De opnemer kijkt vanaf de grond en gebruikt geen ladder of verrekijker. Het dak en de kruipruimte gaan niet standaard mee en naar de fundering kijkt hij niet. Schade achter behang neemt hij alleen op als u die aanwijst.',
      },
    ],
    nietZichtbaar: [
      'Hoeveel ruimtes in uw woning meetellen. Het IMG rekent de herstelkosten per ruimte uit, en de hele buitenkant telt daarbij als één ruimte.',
      'Welke trillingssnelheid het IMG op uw adres heeft geregistreerd, en of het wettelijk bewijsvermoeden voor u geldt.',
      'Of er schade in uw woning zit op plekken die bij een opname niet vanzelf in beeld komen.',
    ],
    zelf: {
      kop: 'Gaat u verbouwen of schilderen?',
      // K1 §4.9
      tekst:
        'Verdwijnt schade door werkzaamheden vóór de opname, leg die dan eerst zelf vast. Het IMG vraagt om drie soorten foto’s per schade: een overzicht van de ruimte, een foto van de wand of het geveldeel, en een detailfoto met een liniaal of meetlint erbij. Noteer per schade de ruimte, het materiaal en de maten.',
    },
    toonCta: true,
  },

  {
    id: 'B',
    positie: 'Historie, geen lopende zaak',
    kop: 'Een adres met historie is geen uitgeput adres',
    staat:
      'Er is eerder schade behandeld op dit adres en er loopt nu geen zaak. Een nieuwe melding kan, maar het IMG mag alleen beslissen over schade die niet eerder is behandeld.',
    betekent: [
      {
        kop: 'Die grens geldt per schade, niet per adres',
        // K1 §6
        tekst:
          'Het gaat erom of een schade onderdeel was van een eerdere behandeling door NAM, CVW, de Arbiter, de rechter of het IMG zelf. Ook als daar toen niets voor is vergoed. Een scheur die bij een eerdere opname nooit is aangewezen, is ook nooit beoordeeld en dus nooit behandeld.',
      },
      {
        kop: 'Twijfel valt uw kant op',
        // K1 §6
        tekst:
          'Kan de deskundige niet vaststellen of een schade eerder is behandeld, dan behandelt hij die als nieuwe schade. Van schade die na een eerdere behandeling is toegenomen, beoordeelt hij het toegenomen deel.',
      },
    ],
    nietZichtbaar: [
      'Welke schades destijds zijn opgenomen en beoordeeld. Dat staat in de eerdere rapporten in uw dossier.',
      'Of schade sinds die behandeling is toegenomen, en hoeveel.',
      'Welke delen van de woning bij de vorige opname buiten beeld zijn gebleven.',
    ],
    zelf: {
      kop: 'Uw historie staat online',
      // K1 §6
      tekst:
        'In Mijn dossier op schadedoormijnbouw.nl ziet u achter DigiD welke vergoedingen er op uw adres zijn uitgekeerd en welke dossiers er liggen.',
    },
    toonCta: true,
  },

  {
    id: 'C',
    positie: 'Melding loopt, opname moet nog komen',
    kop: 'Het moment dat het meeste bepaalt, moet nog komen',
    staat:
      'Uw aanvraag ligt bij het IMG en de opname heeft nog niet plaatsgevonden. Tussen aanvraag en opname zit in de praktijk twee tot drie maanden.',
    betekent: [
      {
        kop: 'Wat de opnemer wel en niet bekijkt',
        // K1 §4.4 en §4.8
        tekst:
          'Hij kijkt vanaf de grond en gebruikt geen ladder of verrekijker. Het dak en de kruipruimte gaan niet standaard mee en naar de fundering kijkt hij niet. Schade achter behang neemt hij alleen op als u die aanwijst. Wat er verder het vaakst uitvalt: kleine scheurtjes en scheuren in de aansluitingen tussen bouwdelen.',
      },
      {
        kop: 'U mag iets zeggen over de deskundige',
        // K1 §3.1 stap 4
        tekst:
          'Het IMG laat u weten wie uw deskundige wordt. Daarna heeft u twee weken om daar een zienswijze over te geven. Kunt u onderbouwen dat iemand niet onafhankelijk of onpartijdig is, dan wijst het IMG een ander aan. De verklaring van de deskundige over zijn eigen onafhankelijkheid kunt u opvragen.',
      },
    ],
    nietZichtbaar: [
      'Welke schade er in uw woning zit die die dag in het dossier zou moeten komen.',
      'Of er schade zit op plekken die bij een opname buiten beeld blijven.',
      'Of het wettelijk bewijsvermoeden voor uw woning geldt, en wat dat voor de beoordeling betekent.',
    ],
    zelf: {
      kop: 'Voorbereiden scheelt',
      // K1 §4.5 en §3.4
      tekst:
        'Het IMG vraagt u om vooraf een overzicht van de schades te maken, kasten en schilderijen weg te halen waar schade achter zit, bouwtekeningen klaar te leggen en moeilijk bereikbare schade van tevoren te melden. Ontdekt u nu nog schade, dan kunt u uw aanvraag tot aan de opname aanvullen in Mijn dossier. Daarna moet u een nieuwe aanvraag doen.',
    },
    toonCta: true,
  },

  {
    id: 'C2',
    positie: 'Opname geweest, rapport nog niet binnen',
    kop: 'In dit traject is het beslissende moment al geweest',
    staat:
      'De opname is geweest en u wacht op het adviesrapport. In de praktijk zit daar twee tot drie maanden tussen. Wat die dag in het dossier is gekomen, ligt nu vast. Het rapport gaat alleen nog over die schades.',
    betekent: [
      {
        kop: 'Waar wij van waarde zijn, is voorbij',
        // B1 §2.1: de kern van de dienst is aanwezigheid bij de opname.
        tekst:
          'Wij zijn er voor de opname zelf: elke ruimte, elke wand en elke aansluiting langsgaan zodat alles in het dossier komt. Die dag is geweest. In dit lopende traject kunnen wij daar weinig meer aan toevoegen, en dat zeggen wij liever nu dan achteraf.',
      },
      {
        kop: 'Wat er na dit traject kan',
        // K1 §3.4 (nieuwe aanvraag pas na het besluit), §2.5 (na maatwerk blijft melden mogelijk),
        // §6 (eerder behandelde schade valt buiten de bevoegdheid).
        tekst:
          'Een nieuwe aanvraag kan, maar het IMG neemt die pas in behandeling na het besluit op deze. Na een maatwerktraject blijft nieuwe of verergerde schade meldbaar. Wij laten een traject als dit daarom aflopen en starten daarna een nieuw traject, zodat wij bij díé opname wel aanwezig zijn. Wat in dit traject al is beoordeeld, komt dan niet opnieuw op tafel. Schade die nooit is aangewezen, is nooit beoordeeld en dus ook nooit behandeld.',
      },
    ],
    nietZichtbaar: [
      'Wat er tijdens uw opname wel en niet in het dossier is gekomen.',
      'Welke schade in uw woning buiten deze opname is gebleven.',
      'Of een nieuw traject in uw geval iets oplevert.',
    ],
    zelf: {
      kop: 'Loop uw woning zelf eens na',
      // K1 §4.4 en §4.8
      tekst:
        'Wat er in de praktijk het vaakst buiten een opname valt: kleine scheurtjes, scheuren in de aansluitingen tussen bouwdelen, alles wat vanaf de grond niet te zien is, en schade achter behang. Ga elke ruimte langs, ook de zolder, de schuur en de garage.',
    },
    toonCta: true,
  },

  {
    id: 'D',
    positie: 'Adviesrapport ontvangen, nog geen besluit',
    kop: 'Het rapport laat zien wat er is meegenomen, en wat niet',
    staat:
      'Het adviesrapport ligt er en het IMG heeft nog geen besluit genomen. Het rapport gaat uitsluitend over de schades die bij de opname in het dossier zijn gekomen.',
    betekent: [
      {
        kop: 'De codes achter elke schade',
        // K1 §7.2
        tekst:
          'T betekent oorzaak trillingen, V verergering door trillingen, B bewijsvermoeden niet weerlegd. X en N zijn de afwijzingen. I betekent dat het IMG de schade als eerder behandeld ziet en er daarom niet over mag beslissen.',
      },
      {
        kop: 'Wat wij in deze fase doen',
        // B1 §2.1 en K1 §3.4, §2.5, §6
        tekst:
          'Onze waarde zit bij de opname, en die is geweest. Wij laten een traject als dit daarom aflopen en starten daarna een nieuwe aanvraag met een nieuwe opname, zodat wij er dan wel bij zijn. Wat in dit rapport is beoordeeld, komt in een volgend traject niet opnieuw op tafel. Wat er nooit in is gekomen, wel.',
      },
    ],
    nietZichtbaar: [
      'Of elke ruimte met schade in uw rapport staat.',
      'Welke schade in uw woning buiten dit rapport is gebleven.',
      'Of een nieuw traject in uw geval iets oplevert.',
    ],
    zelf: {
      kop: 'U kunt nog reageren op het rapport',
      // K1 §7.3. Bewust kort: dit doet de eigenaar zelf, wij begeleiden het niet.
      tekst:
        'Vanaf het bericht dat het rapport klaarstaat heeft u twee weken om een zienswijze in te dienen, met vier weken uitstel op aanvraag. Dat regelt u zelf via Mijn dossier of 0800 4444 111. Wij nemen die zienswijzes niet over.',
    },
    toonCta: true,
  },

  {
    id: 'E',
    positie: 'Besluit ontvangen',
    kop: 'Dit traject is klaar. De vraag is wat er daarna nog kan',
    staat:
      'U heeft een besluit van het IMG ontvangen en daarmee is deze aanvraag afgerond. Het besluit gaat over de schades die bij de opname in het dossier kwamen, en over niets anders.',
    betekent: [
      {
        kop: 'Voor bezwaar in dit traject kunt u niet bij ons terecht',
        // B1 §2.1: de dienst is begeleiding van een maatwerktraject met aanwezigheid bij de
        // opname. Bezwaar doen wij alleen binnen onze eigen trajecten; zonder eigen opname
        // weten wij niet wat er die dag is aangewezen en voegen wij niets toe.
        tekst:
          'Wij maken alleen bezwaar in trajecten waarin wij zelf bij de opname zijn geweest. Alleen dan weten wij wat er die dag is aangewezen en wat er dus mist. Wilt u een beoordeelde schade toch aanvechten, dan kan dat alleen via bezwaar, binnen twaalf weken na de verzenddatum van de besluitbrief. Die termijn is hard en het IMG geeft er geen uitstel op.',
      },
      {
        kop: 'Wat een nieuw traject wel en niet dekt',
        // K1 §2.5 en §6
        tekst:
          'Na een maatwerktraject blijft nieuwe of verergerde schade meldbaar. Wat in dit traject is beoordeeld, is behandeld en komt niet opnieuw op tafel. Schade die nooit is aangewezen, is nooit beoordeeld en dus nooit behandeld. Daar zit de ruimte, en daar zijn wij bij de opname voor.',
      },
    ],
    nietZichtbaar: [
      'Welke schade in uw woning nooit in het dossier is gekomen.',
      'Of er ruimtes helemaal buiten het rapport zijn gebleven.',
      'Of een nieuw traject in uw geval iets oplevert.',
    ],
    zelf: {
      kop: 'Loop uw woning zelf eens na',
      // K1 §4.4 en §4.8
      tekst:
        'Wat er in de praktijk het vaakst buiten een opname valt: kleine scheurtjes, scheuren in de aansluitingen tussen bouwdelen, alles wat vanaf de grond niet te zien is, en schade achter behang. Ga elke ruimte langs, ook de zolder, de schuur en de garage.',
    },
    toonCta: true,
  },

  {
    id: 'F',
    positie: 'Vaste vergoeding aangenomen',
    kop: 'Dat sluit af wat er tóén was, niet alles daarna',
    staat:
      'Met een vaste vergoeding handelde het IMG alle schade af die op dat moment aanwezig was, inclusief de bijkomende kosten en de overlast. Dat bedrag is finaal. Toch staat daarmee niet alles permanent dicht.',
    betekent: [
      {
        kop: 'Een nieuwe beving opent de deur weer',
        // K1 §2.2 en §2.5
        tekst:
          'Is er sinds uw vaste vergoeding op uw adres een beving geregistreerd met een trillingssnelheid van 5 mm/s of meer, dan kunt u opnieuw schade melden. U kiest dan zelf hoe u het aanpakt.',
      },
      {
        kop: 'Het gaat om úw adres',
        // K1 §1.3 en §2.5
        tekst:
          'Het IMG rekent per beving en per adres uit of die drempel is gehaald, met een trillingstool. Binnen dezelfde straat kan dat verschillen. Of het bij u zo is, staat niet in het nieuws en niet op een kaart.',
      },
    ],
    nietZichtbaar: [
      'Of er sinds uw vaste vergoeding een beving is geweest die op úw adres boven de drempel uitkwam.',
      'Welke schade er sindsdien is bijgekomen of verergerd.',
      'Of er bij een nieuwe opname iets te halen valt in uw woning.',
    ],
    zelf: {
      kop: 'Vaak verandert er niets',
      tekst:
        'Bij veel adressen gaat die drempel niet op en blijft alles zoals het is. Wij weten vooraf niet of dat bij u zo is. Blijkt het zo te zijn, dan zeggen wij dat en houdt het op.',
    },
    toonCta: true,
  },

  {
    id: 'onbekend',
    positie: 'Nog niet duidelijk',
    kop: 'Wat er op uw adres ligt, kunt u zelf opzoeken',
    staat:
      'Bij een woning die u later heeft gekocht, is vaak onduidelijk wat er eerder is gebeurd. Uw dossier bij het IMG laat het zien.',
    betekent: [
      {
        kop: 'Waarom het uitmaakt',
        // K1 §6
        tekst:
          'Het IMG mag alleen beslissen over schade die niet eerder is behandeld. Wat er destijds is opgenomen en beoordeeld, bepaalt dus wat er nu nog op tafel kan komen. Kan de deskundige dat niet vaststellen, dan behandelt hij de schade als nieuw.',
      },
    ],
    nietZichtbaar: [
      'Welke dossiers er op uw adres liggen en wat daarin is behandeld.',
      'Wat er bij een eerdere opname wel en niet is vastgelegd.',
      'Of er sindsdien schade is bijgekomen of toegenomen.',
    ],
    zelf: {
      kop: 'Mijn dossier en de telefoon',
      // K1 §6 en §14.3
      tekst:
        'Uw schadehistorie staat in Mijn dossier op schadedoormijnbouw.nl, achter DigiD. Komt u er niet uit, dan kunt u het IMG bellen op 0800 4444 111. Dat kost u niets en u zit nergens aan vast.',
    },
    toonCta: true,
  },
];
